using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// Summary description for AdminClass
/// </summary>
public class AdminClass
{

    private SqlConnection sqlConn;
    SqlCommand sqlCmd;
    SqlDataReader sqlDataReader;
    SqlDataAdapter sqldataAdapter;
    DataTable dt;
    DataWorksClass dw;

	public AdminClass()
	{
		//
		// TODO: Add constructor logic here
		//
	}  
   

    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();
    string tdbold = ConfigurationManager.ConnectionStrings["TestOld"].ConnectionString.ToString();
    string tdbprevious = ConfigurationManager.ConnectionStrings["tdbprevious"].ConnectionString.ToString();
    string _errmessage;

    #region Inspector
    //Get Possible Payments
    public DataTable GetInspector(int INSPECTID)
    {
        string sqlSelect = @"select  INSPECTID,TITLECODE,SURNAME,INITIALS,EPFNO,DESIGNATION,GRADE,BRANCHCODE,TELENO,
                            ADDUSER,STATUS,DestAcNo,EmailOffice,TelRes,Mobile,ADDDateTime 
                            from Inspector 
                            where INSPECTID = @INSPECTID";

        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);

        sqldataAdapter.SelectCommand.Parameters.AddWithValue("INSPECTID", INSPECTID);
       
        dt = new DataTable();

        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return dt;

    }




    //Get Possible Payments
    public DataTable GetInspector()
    {
        string sqlSelect = @"select  INSPECTID,TITLECODE,SURNAME,INITIALS,EPFNO,DESIGNATION,GRADE,BRANCHCODE,
                            TELENO,ADDUSER,STATUS,DestAcNo,EmailOffice,TelRes,Mobile,ADDDateTime 
                            from Inspector";

        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);

        dt = new DataTable();

        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return dt;

    }

    //Get Possible Payments
    public DataTable GetInspector(string surname)
    {
        string sqlSelect = @"select  INSPECTID,TITLECODE,SURNAME,INITIALS,EPFNO,DESIGNATION,GRADE,BRANCHCODE,
                            TELENO,ADDUSER,STATUS,DestAcNo,EmailOffice,TelRes,Mobile,ADDDateTime 
                            from Inspector where surname like  '%" + surname + "%'";

        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);

        dt = new DataTable();

        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return dt;

    }


    //Get Possible Payments
    public DataTable GetTitle()
    {
        string sqlSelect = @"select  TITLECODE,TITLEDESC 
                            from Inspector";

        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);

        dt = new DataTable();

        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return dt;

    }


    // Isert Method

    //public int TextInserter(DateTime trdate,string trtime,DateTime capdate,string acno,decimal amount,string cardnumber,string atmnumber,
    //    int trnno,string accsign,string sbranch,int lineno,string mti,string trcode,string trmode,string status1,string billcode,decimal adddate)

    public int InsertInspector(int TITLECODE, string SURNAME, string INITIALS, string EPFNO, string DESIGNATION,
        string GRADE, string BRANCHCODE, string TELENO, string ADDUSER, string STATUS, string DestAcNo, string EmailOffice,
        string TelRes, string Mobile, DateTime ADDDateTime, string InspectorStatus)
    {
        SqlTransaction sqlTrans;
        string sqlInsert;

        sqlInsert = @"INSERT INTO INSPECTOR(TITLECODE,SURNAME,INITIALS,EPFNO,DESIGNATION,GRADE,BRANCHCODE,
                      TELENO,ADDUSER,STATUS,DestAcNo,EmailOffice,TelRes,Mobile,ADDDateTime,InspectorStatus)
                      VALUES (@TITLECODE,@SURNAME,@INITIALS,@EPFNO,@DESIGNATION,@GRADE,@BRANCHCODE,@TELENO,
                      @ADDUSER,@STATUS,@DestAcNo,@EmailOffice,@TelRes,@Mobile,@ADDDateTime,@InspectorStatus)";

        sqlConn = new SqlConnection(constring);
        sqlCmd = new SqlCommand(sqlInsert, sqlConn);


        sqlCmd.Parameters.AddWithValue("TITLECODE", TITLECODE);
        sqlCmd.Parameters.AddWithValue("SURNAME", SURNAME);
        sqlCmd.Parameters.AddWithValue("INITIALS", INITIALS);
        sqlCmd.Parameters.AddWithValue("EPFNO", EPFNO);
        sqlCmd.Parameters.AddWithValue("DESIGNATION", DESIGNATION);
        sqlCmd.Parameters.AddWithValue("GRADE", GRADE);
        sqlCmd.Parameters.AddWithValue("BRANCHCODE", BRANCHCODE);
        sqlCmd.Parameters.AddWithValue("TELENO", TELENO);
        sqlCmd.Parameters.AddWithValue("ADDUSER", ADDUSER);
        sqlCmd.Parameters.AddWithValue("STATUS", STATUS);
        sqlCmd.Parameters.AddWithValue("DestAcNo", DestAcNo);
        sqlCmd.Parameters.AddWithValue("EmailOffice", EmailOffice);
        sqlCmd.Parameters.AddWithValue("TelRes", TelRes);
        sqlCmd.Parameters.AddWithValue("Mobile", Mobile);
        sqlCmd.Parameters.AddWithValue("ADDDateTime", ADDDateTime);
        sqlCmd.Parameters.AddWithValue("InspectorStatus", InspectorStatus);

        int rowAdded = 0;

       
      

        try
        {
            sqlConn.Open();
            rowAdded = sqlCmd.ExecuteNonQuery();
        }

        catch (Exception err)
        {

           _errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return rowAdded;
    }



    // Update branchinfo with Branch Code
    public int UpdateInspector(int INSPECTID, int TITLECODE, string SURNAME, string INITIALS, string EPFNO, string DESIGNATION,
            string GRADE, string  BRANCHCODE, string TELENO, string ADDUSER, string STATUS, string DestAcNo, string EmailOffice,
            string TelRes, string Mobile)
    {
        string sqlUpdate;


        sqlUpdate = @"UPDATE INSPECTOR
        SET [TITLECODE] =TITLECODE, SURNAME= @SURNAME,INITIALS = @INITIALS,EPFNO = @EPFNO,DESIGNATION = @DESIGNATION,
        GRADE = @GRADE, BRANCHCODE = @BRANCHCODE, TELENO = @TELENO, ADDUSER = @ADDUSER, STATUS = @STATUS,
        DestAcNo = @DestAcNo, EmailOffice = @EmailOffice, TelRes = @TelRes, Mobile = @Mobile
        WHERE INSPECTID=@INSPECTID";

        sqlConn = new SqlConnection(constring);
        sqlCmd = new SqlCommand(sqlUpdate, sqlConn);

        sqlCmd.Parameters.AddWithValue("INSPECTID", INSPECTID);
        sqlCmd.Parameters.AddWithValue("TITLECODE",TITLECODE);
        sqlCmd.Parameters.AddWithValue("SURNAME", SURNAME.Trim());
        sqlCmd.Parameters.AddWithValue("INITIALS", INITIALS.Trim());
        sqlCmd.Parameters.AddWithValue("EPFNO", EPFNO.Trim());
        sqlCmd.Parameters.AddWithValue("DESIGNATION", DESIGNATION.Trim());
        sqlCmd.Parameters.AddWithValue("BRANCHCODE", BRANCHCODE.Trim());
        sqlCmd.Parameters.AddWithValue("GRADE", GRADE.Trim());
        sqlCmd.Parameters.AddWithValue("TELENO", TELENO.Trim());
        sqlCmd.Parameters.AddWithValue("ADDUSER", ADDUSER.Trim());
        sqlCmd.Parameters.AddWithValue("STATUS", STATUS.Trim());
        sqlCmd.Parameters.AddWithValue("DestAcNo", DestAcNo.Trim());
        sqlCmd.Parameters.AddWithValue("EmailOffice", EmailOffice.Trim());
        sqlCmd.Parameters.AddWithValue("TelRes", TelRes.Trim());
        sqlCmd.Parameters.AddWithValue("Mobile", Mobile.Trim());



        int rowAdded = 0;



        try
        {
            sqlConn.Open();

            rowAdded = sqlCmd.ExecuteNonQuery();

        }

        catch (Exception err)
        {


            _errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return rowAdded;
    }

#endregion

    #region Valuer
    //Get Possible Payments
    public DataTable GetValuer()
    {
        string sqlSelect = @"SELECT ValuerId,TitleCode,SurName,Initial,Location,Street,City,Telephone,NicNo,
                            ValuerType,Employerno,CommisRate,Qualification,AddUser,Status,BankCode,BranchCode,
                            DestAcNo,PayeeIns,Mobile,Fax,Email,ValuerId
                            FROM Valuer";

        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);

        dt = new DataTable();

        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return dt;

    }

    public DataTable GetValuer(string surname)
    {
        string sqlSelect = @"SELECT ValuerId,TitleCode,SurName,Initial,Location,Street,City,Telephone,NicNo,
                            ValuerType,Employerno,CommisRate,Qualification,AddUser,Status,BankCode,BranchCode,
                            DestAcNo,PayeeIns,Mobile,Fax,Email, ValuerId
                            FROM Valuer where surname like '%" + surname + "%'";

        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);

        dt = new DataTable();

        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return dt;

    }
    
    // Isert Method
   
    public int InsertValuer(int TitleCode, string SurName, string Initial, string Location, string Street,
        string City, string Telephone, string NicNo, string ValuerType, string Employerno, double CommisRate, string Qualification,
        string AddUser, string Status, int BankCode, int BranchCode, string DestAcNo, string Mobile, string fax, string Email)
    {
        SqlTransaction sqlTrans;
        string sqlInsert;

        sqlInsert = @"insert into Valuer(TitleCode,SurName,Initial,Location,Street,City,Telephone,NicNo,ValuerType,Employerno,
		                CommisRate,Qualification,AddUser,Status,BankCode,BranchCode,DestAcNo,Mobile,Fax,Email)
                        values (@TitleCode,@SurName,@Initial,@Location,@Street,@City,@Telephone,@NicNo,@ValuerType,@Employerno,
		                @CommisRate,@Qualification,@AddUser,@Status,@BankCode,@BranchCode,@DestAcNo,@Mobile,@Fax,@Email)";

        sqlConn = new SqlConnection(constring);
        sqlCmd = new SqlCommand(sqlInsert, sqlConn);


        sqlCmd.Parameters.AddWithValue("TitleCode", TitleCode);
        sqlCmd.Parameters.AddWithValue("SurName", SurName);
        sqlCmd.Parameters.AddWithValue("Initial", Initial);
        sqlCmd.Parameters.AddWithValue("Location", Location);
        sqlCmd.Parameters.AddWithValue("Street", Street);
        sqlCmd.Parameters.AddWithValue("City", City);
        sqlCmd.Parameters.AddWithValue("Telephone", Telephone);
        sqlCmd.Parameters.AddWithValue("NicNo", NicNo);
        sqlCmd.Parameters.AddWithValue("ValuerType", ValuerType);
        sqlCmd.Parameters.AddWithValue("Employerno", Employerno);
        sqlCmd.Parameters.AddWithValue("CommisRate", CommisRate);
        sqlCmd.Parameters.AddWithValue("Qualification", Qualification);
        sqlCmd.Parameters.AddWithValue("AddUser", AddUser);
        sqlCmd.Parameters.AddWithValue("Status", Status);
        sqlCmd.Parameters.AddWithValue("BankCode", BankCode);
        sqlCmd.Parameters.AddWithValue("BranchCode", BranchCode);
        sqlCmd.Parameters.AddWithValue("DestAcNo", DestAcNo);
        sqlCmd.Parameters.AddWithValue("Mobile", Mobile);
        sqlCmd.Parameters.AddWithValue("fax", fax);
        sqlCmd.Parameters.AddWithValue("Email", Email);

        int rowAdded = 0;

        try
        {
            sqlConn.Open();
            rowAdded = sqlCmd.ExecuteNonQuery();
        }

        catch (Exception err)
        {
            _errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return rowAdded;
    }

    // Update branchinfo with Branch Code
    public int UpdateValuer(int ValuerId, int TitleCode, string SurName, string Initial, string Location, string Street,
        string City, string Telephone, string NicNo, string ValuerType, string Employerno, double CommisRate, string Qualification,
        string AddUser, string Status, int BankCode, int BranchCode, string DestAcNo, string Mobile, string fax, string Email)
    {
        string sqlUpdate;


        sqlUpdate = @"UPDATE Valuer
                        SET  TitleCode=@TitleCode,SurName = @SurName, Initial = @Initial,
		                Location = @Location, Street = @Street, City = @City,Telephone = @Telephone,
	                    NicNo = @NicNo, ValuerType = @ValuerType,Employerno = @Employerno, 
		                CommisRate = @CommisRate , Qualification = @Qualification, AddUser = @AddUser, 
		                Status = @Status,BankCode = @BankCode, BranchCode = @BranchCode, DestAcNo = @DestAcNo,
		                Mobile = @Mobile, Fax = @Fax, Email= @Email
                        WHERE ValuerId = @ValuerId";

        sqlConn = new SqlConnection(constring);
        sqlCmd = new SqlCommand(sqlUpdate, sqlConn);

        sqlCmd.Parameters.AddWithValue("TitleCode", TitleCode);
        sqlCmd.Parameters.AddWithValue("SurName", SurName);
        sqlCmd.Parameters.AddWithValue("Initial", Initial);
        sqlCmd.Parameters.AddWithValue("Location", Location);
        sqlCmd.Parameters.AddWithValue("Street", Street);
        sqlCmd.Parameters.AddWithValue("City", City);
        sqlCmd.Parameters.AddWithValue("Telephone", Telephone);
        sqlCmd.Parameters.AddWithValue("NicNo", NicNo);
        sqlCmd.Parameters.AddWithValue("ValuerType", ValuerType);
        sqlCmd.Parameters.AddWithValue("Employerno", Employerno);
        sqlCmd.Parameters.AddWithValue("CommisRate", CommisRate);
        sqlCmd.Parameters.AddWithValue("Qualification", Qualification);
        sqlCmd.Parameters.AddWithValue("AddUser", AddUser);
        sqlCmd.Parameters.AddWithValue("Status", Status);
        sqlCmd.Parameters.AddWithValue("BankCode", BankCode);
        sqlCmd.Parameters.AddWithValue("BranchCode", BranchCode);
        sqlCmd.Parameters.AddWithValue("DestAcNo", DestAcNo);
        sqlCmd.Parameters.AddWithValue("Mobile", Mobile);
        sqlCmd.Parameters.AddWithValue("fax", fax);
        sqlCmd.Parameters.AddWithValue("Email", Email);
        sqlCmd.Parameters.AddWithValue("ValuerId", ValuerId);

        int rowAdded = 0;

        try
        {
            sqlConn.Open();
            rowAdded = sqlCmd.ExecuteNonQuery();
        }

        catch (Exception err)
        {
            _errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return rowAdded;
    }

    public DataTable GetAllValuersName()
    {
        string error;
        string SqlSelec;

        SqlSelec = @"select rtrim(surname + initial) as fullname , valuerid from valuer";

        SqlConnection sqlcon = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(SqlSelec, sqlcon);

        dt = new DataTable();     

        try
        {
            sqlcon.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }
        finally
        {
            sqlcon.Close();
        }

        return dt;
    }

    public DataTable GetValuersDistrics(int ValuerId)
    {
        string Error;
        string SqlSelect;

        SqlSelect = @"select d.DistName from Valuer v ,ValuerArea va , District d
                      where d.Distcode=va.DistCode and va.ValuerId=v.ValuerId and v.ValuerId=@ValuerId";

        

        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(SqlSelect, sqlConn);

        sqldataAdapter.SelectCommand.Parameters.AddWithValue("ValuerId", ValuerId);
        dt = new DataTable();

        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }
        finally
        {
            sqlConn.Close();
        }

        return dt;
    }

    public int AddDistric(int ValuerId,int DistCode)
    {
        string Error;
        string SqlInsert;

        SqlInsert = @"insert into ValuerArea values(@ValuerId,@DistCode,-100)";

        sqlConn = new SqlConnection(constring);
        sqlCmd = new SqlCommand(SqlInsert, sqlConn);

        sqlCmd.Parameters.AddWithValue("ValuerId",ValuerId);
        sqlCmd.Parameters.AddWithValue("DistCode", DistCode);

        int RowAdded = 0;

        try
        {
            sqlConn.Open();
            RowAdded = sqlCmd.ExecuteNonQuery();
        }
        catch (Exception er)
        {
            _errmessage = er.Message;
        }
        finally
        {
            sqlConn.Close();
        }

        return RowAdded;
    }

    public int DeleteDistric(int ValuerId, int DistCode)
    {
        string Error;
        string SqlInsert;

        SqlInsert = @"delete from ValuerArea where ValuerId=@ValuerId and DistCode=@DistCode";

        sqlConn = new SqlConnection(constring);
        sqlCmd = new SqlCommand(SqlInsert, sqlConn);

        sqlCmd.Parameters.AddWithValue("ValuerId", ValuerId);
        sqlCmd.Parameters.AddWithValue("DistCode", DistCode);

        int RowAdded = 0;

        try
        {
            sqlConn.Open();
            RowAdded = sqlCmd.ExecuteNonQuery();
        }
        catch (Exception er)
        {
            _errmessage = er.Message;
        }
        finally
        {
            sqlConn.Close();
        }

        return RowAdded;
    }

    public DataTable GetAllDistric()
    {
        string Error;
        string SqlSelect;       

        SqlSelect = @"select DistName,Distcode from District";

        SqlConnection conn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(SqlSelect, conn);

        dt = new DataTable();

        try
        {
            conn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }
        finally
        {
            conn.Close();
        }

        return dt;
    }


    #endregion

    #region AddLoanType

    public DataTable GetLoanTypes()
    {
        string sqlSelect = @"SELECT CrCatCode,CrDes
                            FROM CrCategory";

        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);

        dt = new DataTable();

        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return dt;

    }


    public int InsertLoanType(string CrDes)
    {
        SqlTransaction sqlTrans;
        string sqlInsert;

        sqlInsert = @"insert into Valuer(CrDes)
                        values (@CrDes)
                        FROM Valuer";

        sqlConn = new SqlConnection(constring);
        sqlCmd = new SqlCommand(sqlInsert, sqlConn);

        sqlCmd.Parameters.AddWithValue("CrDes", CrDes);


        int rowAdded = 0;

        try
        {
            sqlConn.Open();
            rowAdded = sqlCmd.ExecuteNonQuery();
        }

        catch (Exception err)
        {

            _errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return rowAdded;
    }




    public int UpdateLoanType(int CatCode, string CrDes)
    {
        string sqlUpdate;


        sqlUpdate = @"UPDATE Valuer
                        SET  CrDes = @CrDes
                        WHERE CatCode = @CatCode;";

        sqlConn = new SqlConnection(constring);
        sqlCmd = new SqlCommand(sqlUpdate, sqlConn);

        sqlCmd.Parameters.AddWithValue("CrDes", CrDes);
       
        int rowAdded = 0;

        try
        {
            sqlConn.Open();

            rowAdded = sqlCmd.ExecuteNonQuery();

        }

        catch (Exception err)
        {


            _errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return rowAdded;
    }

    #endregion

    //2008-12-22 vihanga
    public string Getoldpassword(string userid)
    {
        string err;
        string sqlSelect;
        dt = new DataTable();
        SqlConnection myconn = new SqlConnection(constring);

        sqlSelect = @"select paswd from users where userid=@userid";
        sqldataAdapter = new SqlDataAdapter(sqlSelect, myconn);
        sqldataAdapter.SelectCommand.Parameters.AddWithValue("userid", userid);

        try
        {
            myconn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            err = er.ToString();
        }
        finally
        {
            myconn.Close();
        }

        if (dt.Rows.Count > 0)
            return (dt.Rows[0][0].ToString());
        else
            return null;

    }
    public int changepassword(string userid, string paswd)
    {
        string er;
        string sqlUpdate;
        SqlConnection myconn = new SqlConnection(constring);
        DateTime adddate = System.DateTime.Now;

        sqlUpdate = @"update users set paswd=@paswd,adddate=@adddate where userid=@userid";
        sqlCmd = new SqlCommand(sqlUpdate, myconn);

        sqlCmd.Parameters.AddWithValue("userid", userid);
        sqlCmd.Parameters.AddWithValue("paswd", paswd);
        sqlCmd.Parameters.AddWithValue("adddate", adddate);

        int rows = 0;

        try
        {
            myconn.Open();
            rows = sqlCmd.ExecuteNonQuery();
        }
        catch (Exception err)
        {
            er = err.ToString();
        }
        finally
        {
            myconn.Close();
        }

        return rows;
    }

    public DataTable gettempdetails(long cracno)
    {
        string sqlSelect = @"select rtrim(cast(year(rt.datedue) as nvarchar(5)))+ '/' + (cast(month(rt.datedue) as nvarchar(5))) +  '/' +
                            (cast(day(rt.datedue) as nvarchar(5))) as DueDate,rt.TrCode as TrCode,
                            tc.trdesc as Description ,rt.assignAmt as Amount ,rt.RefNo as RecRefNo,rt.refglaccno as GlRefAcc
                            from TransAssign rt , TransCat tc
                            where cracno=@cracno and TrStatus!='F' and rt.trcode=tc.trcode and rt.transref='RECN'
                            order by rt.datedue , rt.recorder";

        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);

        sqldataAdapter.SelectCommand.Parameters.AddWithValue("cracno", cracno);

        dt = new DataTable();

        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return dt;
    }

    //2009-02-20 Vihanga Nikeshana
    public string GetGLCode(string RefGlCode)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select glcode from glcode where refglcode=@refglcode");
        dw.SetSqlCommandParameters("RefGlCode", RefGlCode);
        return dw.GetSingleData();
    }

    //2009-02-20 Vihanga Nikeshana
    public int UpdateGLCode(string glcode, string RefGlCode)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update glcode set glcode=@glcode where RefGlCode=@RefGlCode");
        dw.SetSqlCommandParameters("glcode", glcode);
        dw.SetSqlCommandParameters("RefGlCode", RefGlCode);
        return dw.Update();
    }

    //vihanga 2009-08-27
    public DataTable GetNewData()
    {
        dw = new DataWorksClass(tdbold);
        dw.SetDataAdapter(@"select cracno, actoutbal, outbal from housprop where outbal >0 and outbal != actoutbal");
        return dw.GetDataTable();
    }


    //vihanga 2009-08-27
    public DataTable Getcrcano()
    {
        dw = new DataWorksClass(constring);
        //dw.SetDataAdapter(@"select distinct cracno from transassign where taskid = 'CAPD' and trtype = 'E' and transref = 'OTHR'
         //                   and left(cracno,1)='6' order by cracno");
        dw.SetDataAdapter(@"select cracno, actoutbal, outbal from housprop where actoutbal >0 and outbal != actoutbal");
       // dw.SetDataAdapter(@"select distinct cracno,batchno from gltrans where trdate='2009/10/01' and left(batchno,1)<>9
          //                  and left(cracno,1)=6
          //                  ");
        return dw.GetDataTable();
    }
 

    //vihanga 2009-08-27
    public int UpdateHousprop(double outbal, double actoutbal, string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update housprop set outbal=@outbal , actoutbal=@actoutbal where cracno=@cracno");
        dw.SetSqlCommandParameters("outbal", outbal);
        dw.SetSqlCommandParameters("actoutbal", actoutbal);
        dw.SetSqlCommandParameters("cracno", cracno);
        return dw.Update();
    }
    
    //vihanga 2009-08-27
    public double GetTransactions(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select (
                        select isnull(sum(assignamt),0) as assignamt 
                        from transassign where trstatus != 'C'  and taskid='CAPD' and (system != 'M' or system is null)
                        and transref != 'DISB' and trtype = 'I'
                        and cracno = @cracno)
                        -
                        (select isnull(sum(assignamt),0) as assignamt 
                        from transassign where trstatus != 'C'  and taskid='CAPD' and (system != 'M' or system is null)
                        and transref != 'DISB' and trtype = 'E'
                        and cracno = @cracno)");
        dw.SetSqlCommandParameters("cracno", cracno);
        return double.Parse(dw.GetSingleData());
    }


    public double GetActTransactions(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select (
                        select isnull(sum(g.tramt),0) as assignamt 
                        from transassign t, gltrans g where t.trstatus != 'C'  and t.taskid='CAPD' and (t.system != 'M' or t.system is null)
                        and t.transref != 'DISB' and t.trtype = 'I' and t.transno is not null  and right(g.refglcode,3) <  '870'
                        and t.refno = g.transassignrefno
                        and t.cracno = @cracno)
                        -
                        (select isnull(sum(g.tramt),0) as assignamt 
                        from transassign t, gltrans g where t.trstatus != 'C'  and t.taskid='CAPD' and (t.system != 'M' or t.system is null)
                        and t.transref != 'DISB' and t.trtype = 'E' and t.transno is not null and right(g.refglcode,3) <  '870'
                        and t.refno = g.transassignrefno
                        and t.cracno = @cracno)");
        dw.SetSqlCommandParameters("cracno", cracno);
        return double.Parse(dw.GetSingleData());
    }

    public double GetActTransactions(string cracno, DateTime trdate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select (
                        select isnull(sum(g.tramt),0) as assignamt 
                        from transassign t, gltrans g where t.trstatus != 'C'  and t.taskid='CAPD' and (t.system != 'M' or t.system is null)
                        and t.transref != 'DISB' and t.trtype = 'I' and t.transno is not null  and right(g.refglcode,3) <  '870'
                        and t.refno = g.transassignrefno
                        and t.cracno = @cracno and g.trdate=@trdate)
                        -
                        (select isnull(sum(g.tramt),0) as assignamt 
                        from transassign t, gltrans g where t.trstatus != 'C'  and t.taskid='CAPD' and (t.system != 'M' or t.system is null)
                        and t.transref != 'DISB' and t.trtype = 'E' and t.transno is not null and right(g.refglcode,3) <  '870'
                        and t.refno = g.transassignrefno
                        and t.cracno = @cracno and g.trdate=@trdate)");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("trdate", trdate);
        return double.Parse(dw.GetSingleData());
    }


    public DataTable GetHousData(string cracno)
    {
        dw = new DataWorksClass(tdbold);
        dw.SetDataAdapter(@"select cracno, actoutbal, outbal from 
                            housprop where cracno = @cracno");
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }

    public DataTable GetDatedTransaction()
    {
        dw = new DataWorksClass(constring);
        //dw.SetDataAdapter(@"select distinct cracno from transassign where taskid = 'CAPD' and trtype = 'E' and transref = 'OTHR'
        //                   and left(cracno,1)='6' order by cracno");
        //dw.SetDataAdapter(@"select cracno, actoutbal, outbal from housprop where outbal >0 and outbal != actoutbal");
        dw.SetDataAdapter(@"select distinct cracno,transno from gltrans where trdate='2009/10/01' and left(batchno,1)<>9
                            and left(cracno,1)=6
                            ");
        return dw.GetDataTable();
    }

    public int UpdateCorrectedNICAppHolder(string appno, string nicno, string holdertype, string changeuser)
    {
        InsertAppHoderHistory(appno, nicno, holdertype, changeuser);

        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update appholder  set nicno = @nicno where appno  = @appno and holdertype = @holdertype");
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("nicno", nicno);
        dw.SetSqlCommandParameters("holdertype", holdertype);
        return dw.Update();
    }

    public int UpdateCorrectedNICCrHolder(string appno, string nicno, string holdertype, string changeuser)
    {
        InsertCrHolderHistory(appno, nicno, holdertype, changeuser);

        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update crholder  set nicno = @nicno where appno  = @appno and holdertype = @holdertype");
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("nicno", nicno);
        dw.SetSqlCommandParameters("holdertype", holdertype);
        return dw.Update();
    }

    private void InsertAppHoderHistory(string appno, string newnicno, string holdertype, string changeuser)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO AppholderHistory 
           select appno,holdertype,nicno,custno,
				holdrelation,isadditional,updatelevel,@newnicno,@changeuser,getdate() from appholder where 
					appno = @appno and holdertype = @holdertype");
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("newnicno", newnicno);
        dw.SetSqlCommandParameters("holdertype", holdertype);
        dw.SetSqlCommandParameters("changeuser", changeuser);
        dw.Insert();
    }

    private void InsertCrHolderHistory(string appno, string newnicno, string holdertype, string changeuser)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO CrHolderHistory
                      select cracno,appno,holdertype,holdercount,nicno,custno,
				                    holdrelation,isadditional,@newnicno,@changeuser,getdate() from crholder where
					                    appno = @appno and holdertype = @holdertype");
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("newnicno", newnicno);
        dw.SetSqlCommandParameters("holdertype", holdertype);
        dw.SetSqlCommandParameters("changeuser", changeuser);
        dw.Insert();
    }



    public DataTable GetValuerIndividual(int valuerID)
    {
        dw = new DataWorksClass(constring);
        dt = new DataTable();
        dw.SetDataAdapter(@"SELECT v.SurName,v.Initial,v.Location,v.Street,v.City,v.Telephone,
                            v.NicNo,v.Status,v.ValuerType,v.Qualification FROM Valuer v,title t 
                            where v.valuerID=@valuerID and v.titlecode=t.titlecode order by  v.ValuerId");
        dw.SetDataAdapterParameters("valuerID", valuerID);
        return dw.GetDataTable();
    }

    public int UpdateValuer(int ValuerId, int TitleCode, string SurName, string Initial, string Location, string Street,
        string City, string Telephone, string NicNo, string ValuerType, string Employerno, string CommisRate, string Qualification,
        string AddUser, string Status, int BankCode, string DestAcNo, string Mobile, string fax, string Email)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"UPDATE Valuer
                        SET  TitleCode=@TitleCode,SurName = @SurName, Initial = @Initial,
		                Location = @Location, Street = @Street, City = @City,Telephone = @Telephone,
	                    NicNo = @NicNo, ValuerType = @ValuerType,Employerno = @Employerno, 
		                CommisRate = @CommisRate , Qualification = @Qualification, AddUser = @AddUser, 
		                Status = @Status,BankCode = @BankCode, DestAcNo = @DestAcNo,
		                Mobile = @Mobile, Fax = @Fax, Email= @Email
                        WHERE ValuerId = @ValuerId");
        dw.SetSqlCommandParameters("TitleCode", TitleCode);
        dw.SetSqlCommandParameters("SurName", SurName);
        dw.SetSqlCommandParameters("Initial", Initial);
        dw.SetSqlCommandParameters("Location", Location);
        dw.SetSqlCommandParameters("Street", Street);
        dw.SetSqlCommandParameters("City", City);
        dw.SetSqlCommandParameters("Telephone", Telephone);
        dw.SetSqlCommandParameters("NicNo", NicNo);
        dw.SetSqlCommandParameters("ValuerType", ValuerType);
        dw.SetSqlCommandParameters("Employerno", Employerno);
        dw.SetSqlCommandParameters("CommisRate", CommisRate);
        dw.SetSqlCommandParameters("Qualification", Qualification);
        dw.SetSqlCommandParameters("AddUser", AddUser);
        dw.SetSqlCommandParameters("Status", Status);
        dw.SetSqlCommandParameters("BankCode", BankCode);
        dw.SetSqlCommandParameters("DestAcNo", DestAcNo);
        dw.SetSqlCommandParameters("Mobile", Mobile);
        dw.SetSqlCommandParameters("fax", fax);
        dw.SetSqlCommandParameters("Email", Email);
        dw.SetSqlCommandParameters("ValuerId", ValuerId);
        return dw.Update();
    }

    public int InsertValuer(int valuerId,int TitleCode, string SurName, string Initial, string Location, string Street,
        string City, string Telephone, string NicNo, string ValuerType, string Employerno, string CommisRate, string Qualification,
        string AddUser, string Status, int BankCode, string DestAcNo, string Mobile, string fax, string Email)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into Valuer(valuerId,TitleCode,SurName,Initial,Location,Street,City,Telephone,NicNo,ValuerType,Employerno,
		                CommisRate,Qualification,AddUser,Status,BankCode,DestAcNo,Mobile,Fax,Email)
                        values (@valuerId,@TitleCode,@SurName,@Initial,@Location,@Street,@City,@Telephone,@NicNo,@ValuerType,@Employerno,
		                @CommisRate,@Qualification,@AddUser,@Status,@BankCode,@DestAcNo,@Mobile,@Fax,@Email)");
        dw.SetSqlCommandParameters("valuerId", valuerId);
        dw.SetSqlCommandParameters("TitleCode", TitleCode);
        dw.SetSqlCommandParameters("SurName", SurName);
        dw.SetSqlCommandParameters("Initial", Initial);
        dw.SetSqlCommandParameters("Location", Location);
        dw.SetSqlCommandParameters("Street", Street);
        dw.SetSqlCommandParameters("City", City);
        dw.SetSqlCommandParameters("Telephone", Telephone);
        dw.SetSqlCommandParameters("NicNo", NicNo);
        dw.SetSqlCommandParameters("ValuerType", ValuerType);
        dw.SetSqlCommandParameters("Employerno", Employerno);
        dw.SetSqlCommandParameters("CommisRate", CommisRate);
        dw.SetSqlCommandParameters("Qualification", Qualification);
        dw.SetSqlCommandParameters("AddUser", AddUser);
        dw.SetSqlCommandParameters("Status", Status);
        dw.SetSqlCommandParameters("BankCode", BankCode);
        dw.SetSqlCommandParameters("DestAcNo", DestAcNo);
        dw.SetSqlCommandParameters("Mobile", Mobile);
        dw.SetSqlCommandParameters("fax", fax);
        dw.SetSqlCommandParameters("Email", Email);
        return dw.Insert();
    }

    public void InsertRecordTovaluerarea()
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select max(valuerid) from valuer");

        int maxvaluerid = int.Parse(dw.GetSingleData());

        for (int discode = 1; discode < 26; discode++)
        {
            insertrecordtovalarea(maxvaluerid, discode, -110);
        }
    }

    private void insertrecordtovalarea(int maxvaluerid, int discode, int updatelevel)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into valuerarea values(@maxvaluerid,@discode,@updatelevel)");
        dw.SetSqlCommandParameters("maxvaluerid", maxvaluerid);
        dw.SetSqlCommandParameters("discode", discode);
        dw.SetSqlCommandParameters("updatelevel", updatelevel);
        dw.Insert();
    }

    public int getmaxvaluerID()
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select max(valuerid) from valuer");
        return int.Parse(dw.GetSingleData());
    }

    //2011-12-12 Nikeshana
    public DataTable GetInterestRate()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select i.SerialNo,c.crDes as Category,p.Descrip as Purpose,
                            CAST(CONVERT(varchar, CAST(i.AmountFrom  AS money), 1)  AS varchar)as AmountFrom,
                            CAST(CONVERT(varchar, CAST(i.amountto  AS money), 1)  AS varchar)as amountto,i.IntRate
                            from intrates i,crcategory c,crpurpose p where i.category=c.crcatcode and i.purpose=p.purposecode
                            order by i.category,i.purpose,i.IntRate");
        return dw.GetDataTable();
    }

    //2011-12-12 Nikeshana
    public DataTable GetCategory()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select crcatcode,crdes from crcategory");
        return dw.GetDataTable();
    }

    //2011-12-12 Nikeshana
    public DataTable GetPurpose()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select purposecode,descrip from crpurpose");
        return dw.GetDataTable();
    }

    //2011-12-12 Nikeshana
    public DataTable GetParticularIntRateDetails(string serialNo)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select i.category as categoryID,c.crDes as Category,i.purpose as purposeID,p.Descrip as Purpose,
                            CAST(CONVERT(varchar, CAST(i.AmountFrom 
                            AS money), 1)  AS varchar)as AmountFrom,CAST(CONVERT(varchar, CAST(i.amountto  
                            AS money), 1)  AS varchar)as amountto,i.IntRate from intrates i,crcategory c,crpurpose p
                            where i.category=c.crcatcode and i.purpose=p.purposecode and i.SerialNo=@serialNo");
        dw.SetDataAdapterParameters("serialNo", serialNo);
        return dw.GetDataTable();
    }

    //2011-12-12 Nikeshana
    public int insertIntointrates(int category, int purpose, decimal AmountFrom, decimal AmountTo, decimal IntRate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into intrates(category,purpose,AmountFrom,amountto,intrate) 
                        values (@category,@purpose,@AmountFrom,@amountto,@intrate)");
        dw.SetSqlCommandParameters("category",category);
        dw.SetSqlCommandParameters("purpose",purpose);
        dw.SetSqlCommandParameters("AmountFrom",AmountFrom);
        dw.SetSqlCommandParameters("amountto",AmountTo);
        dw.SetSqlCommandParameters("intrate",IntRate);
        return dw.Insert();
    }

    //2011-12-12 Nikeshana
    public int updateintrates(int category, int purpose, decimal AmountFrom, decimal AmountTo, decimal IntRate, int SerialNo)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update intrates set category=@category,purpose=@purpose,AmountFrom=@AmountFrom,
                        amountto=@amountto, IntRate=@IntRate where SerialNo=@SerialNo");
        dw.SetSqlCommandParameters("category", category);
        dw.SetSqlCommandParameters("purpose", purpose);
        dw.SetSqlCommandParameters("AmountFrom", AmountFrom);
        dw.SetSqlCommandParameters("amountto", AmountTo);
        dw.SetSqlCommandParameters("IntRate", IntRate);
        dw.SetSqlCommandParameters("SerialNo", SerialNo);
        return dw.Update();
    }

    //--------------------2016-08-03 Aruni------------------------------

    //get loan category
    public DataTable GetLoanCategory()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select C.crdes,C.crcatcode from crcategory C where C.crdes != 'All' order by C.crdes ASC");

        return dw.GetDataTable();
    }

    //Get Exist rate
    public DataTable GetExistLoanCategoryInterest(int CategoryID)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select I.IntRate,C.crdes,I.Status,I.InterestRateType
                            from InterestCode I,crcategory C 
                            where I.CrCat = C.crcatcode and I.CrCat = @CategoryID and (I.Status = 'Inactive' OR I.Status = 'Active' OR I.Status is NULL)  order by I.IntRate ASC");
        dw.SetDataAdapterParameters("CategoryID", CategoryID);
        return dw.GetDataTable();
    }
    //Check interest rate exist
    public DataTable CheckInterestRateExist(int CategoryID, decimal Rate)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select I.IntRate,C.crdes,I.Status,I.InterestRateType
                            from InterestCode I,crcategory C 
                            where I.CrCat = C.crcatcode and I.CrCat = @CategoryID and IntRate = @IntRate
							order by I.IntRate ASC");
        dw.SetDataAdapterParameters("CategoryID", CategoryID);
        dw.SetDataAdapterParameters("IntRate", Rate);
        return dw.GetDataTable();
    }
    //insert Interest rate
    public DataTable InsertInterestRate(DateTime DateFrom, DateTime DateTo, decimal IntRate, string AddUser, string ChngUser, int UpdateLevel, int CrCat, string Status, string InterestRateType)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"insert into InterestCode(DateFrom,DateTo,IntRate,AddUser,ChngUser,UpdateLevel,CrCat,Status,InterestRateType) values (@DateFrom,@DateTo,@IntRate,@AddUser,@ChngUser,@UpdateLevel,@CrCat,@Status,@InterestRateType)");
        dw.SetDataAdapterParameters("DateFrom", DateFrom);
        dw.SetDataAdapterParameters("DateTo", DateTo);
        dw.SetDataAdapterParameters("IntRate", IntRate);
        dw.SetDataAdapterParameters("AddUser", AddUser);
        dw.SetDataAdapterParameters("ChngUser", ChngUser);
        dw.SetDataAdapterParameters("UpdateLevel", UpdateLevel);
        dw.SetDataAdapterParameters("CrCat", CrCat);
        dw.SetDataAdapterParameters("Status", Status);
        dw.SetDataAdapterParameters("InterestRateType", InterestRateType);
        return dw.GetDataTable();
    }

    //update Interest Rate
    public DataTable UpdateInterestRate(decimal IntRate, string Status, string RateType, int CategoryID)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"update InterestCode 
                            set Status =@Status,InterestRateType =@InterestRateType 
                            where CrCat = @CategoryID and IntRate = @IntRate");
        dw.SetDataAdapterParameters("IntRate", IntRate);
        dw.SetDataAdapterParameters("Status", Status);
        dw.SetDataAdapterParameters("InterestRateType", RateType);
        dw.SetDataAdapterParameters("CategoryID", CategoryID);
        return dw.GetDataTable();
    }

    //delete interest rate
    public DataTable DeleteInterestRate(string Status, DateTime Change_Date, string Change_User, decimal IntRate, int CategoryID)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"update InterestCode 
                            set Status =@Status,ChngUser =@ChngUser,DateTo =@DateTo 
                            where CrCat = @CategoryID and IntRate = @IntRate");
        dw.SetDataAdapterParameters("IntRate", IntRate);
        dw.SetDataAdapterParameters("Status", Status);
        dw.SetDataAdapterParameters("ChngUser", Change_User);
        dw.SetDataAdapterParameters("DateTo", Change_Date);
        dw.SetDataAdapterParameters("CategoryID", CategoryID);
        return dw.GetDataTable();
    }

}
