using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// Summary description for valuerreport
/// </summary>
public class valuerpayments
{
    SqlConnection myconnection = new SqlConnection(ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString);
    private SqlDataAdapter sqlAdapter;
    private SqlCommand sqlCmd;
    private DataTable dt;

	public valuerpayments()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public DataTable valfee(int valid , DateTime frmd , DateTime tday)
    {
        string sqlSelect;

        sqlSelect = @"select v.appno as Application_Num, (v.ValuerFee + v.ExpValuerFee) as Valuation_Fee , (v.TrportFee + v.ExpressTrPort) 
                      as Valuation_Transport from valuation v where valuerid = @valid and RECVDATE > @frmd and RECVDATE < @tday and v.updatelevel=-100";


        // sqlConn = new SqlConnection(conStringServer);
        sqlAdapter = new SqlDataAdapter(sqlSelect, myconnection);

        sqlAdapter.SelectCommand.Parameters.AddWithValue("valid", valid);
        sqlAdapter.SelectCommand.Parameters.AddWithValue("frmd", frmd);
        sqlAdapter.SelectCommand.Parameters.AddWithValue("tday", tday);

        dt = new DataTable();

        try
        {
            myconnection.Open();
            sqlAdapter.Fill(dt);
        }
        catch (Exception err)
        {
            //
        }

        finally
        {
            myconnection.Close();
        }

        return dt;
    }

    public DataTable totvalfee(int valid, DateTime frmd, DateTime tday)
    {
        string sqlSelect;

        sqlSelect = @"select sum(v.ValuerFee + v.ExpValuerFee) as totvalfee , sum(v.TrportFee + v.ExpressTrPort) 
                      as totvaltranst from valuation v 
                      where valuerid = @valid and RECVDATE > @frmd and RECVDATE < @tday and RECVDATE is not null and 
                     (IsTrPortPd='N' or  IsTrPortPd is null) and (IsExpTrPaid='N' or IsExpTrPaid is null) and 
                     (IsValuerPd='N' or IsValuerPd is null) and (IsExpValuerPd='N' or IsExpValuerPd is null) and v.updatelevel=-100";


        // sqlConn = new SqlConnection(conStringServer);
        sqlAdapter = new SqlDataAdapter(sqlSelect, myconnection);

        sqlAdapter.SelectCommand.Parameters.AddWithValue("valid", valid);
        sqlAdapter.SelectCommand.Parameters.AddWithValue("frmd", frmd);
        sqlAdapter.SelectCommand.Parameters.AddWithValue("tday", tday);

        dt = new DataTable();

        try
        {
            myconnection.Open();
            sqlAdapter.Fill(dt);
        }
        catch (Exception err)
        {
            //
        }

        finally
        {
            dt.Dispose();
            myconnection.Close();
        }

        return dt;
    }

    public bool CheckCustPayed(string APPNO)
    {
        string sqlSelect;

        sqlSelect = @"select AppNo from paymentmade where appno = @appno and ispaid = @ispaid";

        sqlAdapter = new SqlDataAdapter(sqlSelect, myconnection);

        sqlAdapter.SelectCommand.Parameters.AddWithValue("APPNO", APPNO);

        dt = new DataTable();

        try
        {
            myconnection.Open();
            sqlAdapter.Fill(dt);
        }
        catch (Exception err)
        {
            //
        }

        finally
        {
            myconnection.Close();
        }
        // nEED TO CHECK

        return true;

    }


    public int PaydToValuer(int VALUERID, DateTime datefrm, DateTime dateto, DateTime PaidDate, long TransactionNo)
    {
        string _errmessage;
        string sqlUpdate;

        sqlUpdate = @"update valuation set IsTrPortPd='Y' , IsValuerPd='Y' , IsExpTrPaid='Y' , IsExpValuerPd='Y' , 
                      TransactionNo=@TransactionNo , PaidDate=@PaidDate
                      where VALUERID=@VALUERID and SENDDATE > @datefrm and SENDDATE < @dateto and RECVDATE is not null
                      and HIDE='U' and IsTrPortPd!='Y' and IsValuerPd!='Y' and IsExpTrPaid!='Y' and IsExpValuerPd!='Y' and updatelevel=-100";

        sqlCmd = new SqlCommand(sqlUpdate, myconnection);        
        //*****
        sqlCmd.Parameters.AddWithValue("TransactionNo", TransactionNo);
        sqlCmd.Parameters.AddWithValue("datefrm", datefrm);
        sqlCmd.Parameters.AddWithValue("dateto", dateto);
        sqlCmd.Parameters.AddWithValue("VALUERID", VALUERID);
        sqlCmd.Parameters.AddWithValue("PaidDate", PaidDate);
      
        int rowAdded = 0;

        try
        {
            myconnection.Open();
            rowAdded = sqlCmd.ExecuteNonQuery();
        }

        catch (Exception err)
        {
            _errmessage = err.Message;
        }

        finally
        {
            myconnection.Close();
        }

        return rowAdded;
    }

    public int UpdateOutSidePayment(long TransactionId, decimal TotalAmount, DateTime SendDate, string PaymentType)
    {
        string sqlString;
        string sqlError;

        sqlString = "insert into OutsidePayments (TransactionId,TotalAmount,SendDate,PaymentType) values(@TransactionId,@TotalAmount,@SendDate,@PaymentType)";

        sqlCmd = new SqlCommand(sqlString, myconnection);

        sqlCmd.Parameters.AddWithValue("TransactionId", TransactionId);
        sqlCmd.Parameters.AddWithValue("TotalAmount", TotalAmount);
        sqlCmd.Parameters.AddWithValue("SendDate", SendDate);
        sqlCmd.Parameters.AddWithValue("PaymentType", PaymentType);

        int rowAdded = 0;

        try
        {
            myconnection.Open();
            rowAdded = sqlCmd.ExecuteNonQuery();
        }
        catch (Exception er)
        {
            sqlError = er.Message;
        }
        finally
        {
            myconnection.Close();
        }

        return rowAdded;
    }


    public DataTable ValuationAuthorities()
    {
        string sqlSelect;

        sqlSelect = @"select AName from ValuationAuthorities";


        // sqlConn = new SqlConnection(conStringServer);
        sqlAdapter = new SqlDataAdapter(sqlSelect, myconnection);

        dt = new DataTable();

        try
        {
            myconnection.Open();
            sqlAdapter.Fill(dt);
        }
        catch (Exception err)
        {
            //
        }

        finally
        {
            myconnection.Close();
        }

        return dt;
    }

    //2008/12/29
    public bool IsCalCommision(int valuerID)
    {
        string sqlSelect;
        string error;
        dt = new DataTable();
        string valtype = " ";
        bool iscal = true;

        sqlSelect = @"select RTRIM(ValuerType) AS ValuerT from valuer where valuerid=@valuerID";

        sqlAdapter = new SqlDataAdapter(sqlSelect, myconnection);
        sqlAdapter.SelectCommand.Parameters.AddWithValue("valuerID", valuerID);
              

        try
        {
            myconnection.Open();
            sqlAdapter.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                valtype = dt.Rows[0][0].ToString();
                if (valtype == "I")
                {
                    iscal = false;
                }
                else
                {
                    iscal = true;
                }
            }
        }
        catch (Exception er)
        {
            error = er.ToString();
        }
        finally
        {
            dt.Dispose();
            myconnection.Close();
        }

       
      
        return iscal;
    }
}
