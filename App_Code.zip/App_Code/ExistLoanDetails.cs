using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// Summary description for ExistLoanDetails
/// </summary>
public class ExistLoanDetails
{
    
    private SqlConnection mycon;
    DataWorksClass dw;
    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();
	public ExistLoanDetails()
	{
        SqlConnection myconnection = new SqlConnection(ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString);
        this.mycon = myconnection;
	}

    public decimal getExistLoanAmount(string appno)
    {
        //decimal existLoanAmt = 0;
        dw = new DataWorksClass(constring);
        //string amount;
        //string sql = " SELECT ISNULL(SUM(M.GrantAmt),0) FROM AppHolder A, CrHolder H,"+
        //             " CrMast M, HousProp Hp WHERE A.NicNo=H.NicNo AND M.CrAcNo=H.CrAcNo AND "+
        //             " A.AppNo=" + appno + " AND H.HolderType='P'" +
        //             " AND M.CracNo=Hp.CrAcNo AND Hp.ActOutBal>0";

        dw.SetCommand(@"SELECT (SELECT ISNULL(SUM(M.GrantAmt),0) FROM AppHolder A, CrHolder H,
                         CrMast M, HousProp Hp WHERE A.NicNo=H.NicNo AND M.AcStatus != 'I' AND M.CrAcNo=H.CrAcNo AND
                         A.AppNo=@appno AND H.HolderType='P'  
                         AND M.CracNo=Hp.CrAcNo AND Hp.ActOutBal>0)
                         + 
                         (SELECT ISNULL(SUM(M.GrantAmt),0) FROM AppHolder A, CrHolder H,
                         CrMast M, HousProp Hp WHERE A.NicNo=H.NicNo AND M.AcStatus != 'I' AND M.CrAcNo=H.CrAcNo AND
                         A.AppNo=@appno AND H.HolderType='P'
                         AND M.CracNo=Hp.CrAcNo AND Hp.ActOutBal=0
                         AND Hp.CrCat=9)
                        +
                        (SELECT ISNULL(SUM(M.GrantAmt),0) FROM AppHolder A, CREDITBRDB.TDBBranches.CreditAdmin.CrHolder H,
                         CREDITBRDB.TDBBranches.CreditAdmin.CrMast M, CREDITBRDB.TDBBranches.CreditAdmin.HousProp Hp 
                        WHERE A.NicNo=H.NicNo AND M.AcStatus != 'I' AND M.CrAcNo=H.CrAcNo AND
                        A.AppNo=@appno AND H.HolderType='P'  
                        AND M.CracNo=Hp.CrAcNo AND Hp.ActOutBal>0)");

        //SqlCommand scm = new SqlCommand(sql, mycon);
        //mycon.Open();

        //SqlDataReader dr = scm.ExecuteReader();

        //if (dr.Read())
        //{
        //    amount = dr[0].ToString();
        //    if (amount == "")
        //        existLoanAmt = 0;
        //    else
        //        existLoanAmt = decimal.Parse(amount);
            
        //}
        //dr.Close();
        //mycon.Close();
        dw.SetSqlCommandParameters("appno", appno);
        return decimal.Parse(dw.GetSingleData());
    }

    public string getExistAppNo(string appno)
    {
        string oldappno = "";
        
        string sql = " SELECT DISTINCT A.AppNo AS AppNo FROM AppHolder A,CrHolder C, CrMast M "+
                     " WHERE A.AppNo=C.AppNo AND M.CrAcNo=C.CrAcNo AND M.AcStatus<>'C' AND A.AppNo="+appno+" ";

        SqlCommand scm = new SqlCommand(sql, mycon);
        mycon.Open();

        SqlDataReader dr = scm.ExecuteReader();

        if (dr.Read())
        {
            oldappno = dr[0].ToString();
            
        }
        dr.Close();
        mycon.Close();
        return oldappno;
    }



    public double GetExtTotOutbal(string AppNo)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"SELECT 
                        (SELECT isnull(sum(ActOutBal),0)
                        FROM AppHolder A, HousProp H, CrHolder R, CrMast CM
                        WHERE A.NicNo=R.NicNo AND
                        CM.CrAcNo=R.CrAcNo AND
                        CM.CrAcNo=H.CrAcNo AND
                        R.HolderType='P' AND
                        CM.AcStatus != 'I' AND
                        A.AppNo=@AppNo)
                        +
                        (SELECT isnull(sum(ActOutBal),0)
                        FROM AppHolder A, CREDITBRDB.TDBBranches.CreditAdmin.HousProp H, 
                        CREDITBRDB.TDBBranches.CreditAdmin.CrHolder R, CREDITBRDB.TDBBranches.CreditAdmin.CrMast CM
                        WHERE A.NicNo=R.NicNo AND
                        CM.CrAcNo=R.CrAcNo AND
                        CM.CrAcNo=H.CrAcNo AND
                        R.HolderType='P' AND
                        CM.AcStatus != 'I' AND
                        A.AppNo=@AppNo)");
        dw.SetSqlCommandParameters("AppNo",AppNo);
        return double.Parse(dw.GetSingleData());
    }



    public double GetExtTotInstalment(string AppNo)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"SELECT
                        (SELECT isnull(sum(H.Instalment),0) as Instalment
                        FROM AppHolder A, HousProp H, CrHolder R, CrMast CM
                        WHERE
                        A.NicNo=R.NicNo AND
                        CM.CrAcNo=R.CrAcNo AND
                        CM.CrAcNo=H.CrAcNo AND
                        R.HolderType='P' AND
                        actoutbal > 0 AND
                        CM.AcStatus != 'I' AND
                        A.AppNo=@AppNo)
                        +
                        (SELECT isnull(sum(H.Instalment),0) as Instalment
                        FROM AppHolder A, CREDITBRDB.TDBBranches.CreditAdmin.HousProp H, 
                        CREDITBRDB.TDBBranches.CreditAdmin.CrHolder R, CREDITBRDB.TDBBranches.CreditAdmin.CrMast CM
                        WHERE
                        A.NicNo=R.NicNo AND
                        CM.CrAcNo=R.CrAcNo AND
                        CM.CrAcNo=H.CrAcNo AND
                        R.HolderType='P' AND
                        actoutbal > 0 AND
                        CM.AcStatus != 'I' AND
                        A.AppNo=@AppNo)");
        dw.SetSqlCommandParameters("AppNo", AppNo);
        return double.Parse(dw.GetSingleData());
    }

}
