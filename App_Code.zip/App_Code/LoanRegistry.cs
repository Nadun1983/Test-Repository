using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// Summary description for OpeningRegistry
/// </summary>
public class LoanRegistry
{
	public LoanRegistry()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    private SqlConnection sqlConn;
    SqlCommand sqlCmd;
    SqlDataReader sqlDataReader;
    SqlDataAdapter sqldataAdapter;
    DataTable dt;
    DataWorksClass dw;
    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();
    string _errmessage;


    //Get Loan Types
    public DataTable GetLoanTypes()
    {
        string sqlSelect = @"select CrCatCode, CrDes from CrCategory";

        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);

        dt = new DataTable();

        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return dt;

    }

    //Get Status
    public DataTable GetCrCatStatus()
    {
        string sqlSelect = @"select status, Description  from CrAppStatus";

        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);

        dt = new DataTable();

        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return dt;

    }

    //Get AppicationDate
    public DataTable GetApplicationData(string status, int crCatCode, DateTime fromdate, DateTime todate)
    {
        string sqlSelect;

        if ((status == "0") && (crCatCode == 0)) 
        {
            /*sqlSelect = @"select tab1.appno,cm.nicno,cm.surname,cm.initials,
							cast(day(cr.recvdate) as char(2)) + '/' + cast(month(cr.recvdate) as char(2)) + '/' + cast(Year(cr.recvdate) 
							as char(4)) as  RecieveDate,cr.cramt,case tab3.ispaid
							when 1 then 'Paid'
							when 0 then 'Not Paid' end as Ispaid,
							tab2.valfee ,tab1.inspecfee, p.crdes,
							case a.status
							when 'A' then 'Approved'
							when 'N' then 'Pending'
							else 'Cancel' end as status,
							cr.adduser as AddUser 
							from (select cracno as appno, sum(tramt) as inspecfee from transassign where left(cracno,1) = 3 and transno is not null and trstatus='F'
							and taskid in ('INSN900000','ITRN900000','INSE900000','ITRE900000')
							group by cracno) as tab1 ,
							(select cracno as appno , sum(tramt) as valfee from transassign where left(cracno,1) = 3 and transno is not null and trstatus='F'
							and taskid in ('VALN900000','VTRN900000','VALE900000','VTRE900000')
							group by cracno) as tab2 ,
							(select distinct appno,ispaymentok as ispaid from approvalstatus where ispaymentok is not null) as tab3 ,
							customermain cm , appholder ah, Crapp Cr, CrCategory p,approvalstatus a
							where tab1.appno=tab2.appno and cm.nicno=ah.nicno and ah.appno=tab1.appno and a.appno=tab1.appno
							and ah.appno=cr.appno and cr.crcatcode=p.crcatcode and tab3.appno=tab1.appno and 
							cr.recvdate >= @fromdate and cr.recvdate<= @todate 
							order by ah.appno ";*/

            sqlSelect = @"select ca.AppNo,cm.nicno,cm.SurName,cm.Initials,ah.holdRelation,
                            convert(varchar, ca.RecvDate, 111) as RecvDate,ca.CrAmt,cc.crdes as LoanCategory,
                            case aps.status
                            when 'A' then 'Approved'
                            when 'N' then 'Pending'
                            else 'Cancel' end as status,ca.AddUser
                            from crapp ca, appholder ah, Customermain cm ,crcategory cc,approvalstatus aps
                            where ca.appno=ah.appno  and cm.nicno=ah.nicno and
                            cc.crcatcode=ca.crcatcode and aps.appno=ca.appno and 
                            ca.recvdate >= @fromdate and ca.recvdate<= @todate 
                            order by ca.appno";
           
            dt = new DataTable();
        }
        else
        {
            if(status=="0")
            {
                /*sqlSelect = @"select tab1.appno,cm.nicno,cm.surname,cm.initials,
								cast(day(cr.recvdate) as char(2)) + '/' + cast(month(cr.recvdate) as char(2)) + '/' + cast(Year(cr.recvdate) 
								as char(4)) as  RecieveDate,cr.cramt,case tab3.ispaid
								when 1 then 'Paid'
								when 0 then 'Not Paid' end as Ispaid,
								tab2.valfee ,tab1.inspecfee, p.crdes,
								case a.status
								when 'A' then 'Approved'
								when 'N' then 'Pending'
								else 'Cancel' end as status,
								cr.adduser as AddUser 
								from (select cracno as appno, sum(tramt) as inspecfee from transassign where left(cracno,1) = 3 and transno is not null and trstatus='F'
								and taskid in ('INSN900000','ITRN900000','INSE900000','ITRE900000')
								group by cracno) as tab1 ,
								(select cracno as appno , sum(tramt) as valfee from transassign where left(cracno,1) = 3 and transno is not null and trstatus='F'
								and taskid in ('VALN900000','VTRN900000','VALE900000','VTRE900000')
								group by cracno) as tab2 ,
								(select distinct appno,ispaymentok as ispaid from approvalstatus where ispaymentok is not null) as tab3 ,
								customermain cm , appholder ah, Crapp Cr, CrCategory p,approvalstatus a
								where tab1.appno=tab2.appno and cm.nicno=ah.nicno and ah.appno=tab1.appno and a.appno=tab1.appno
								and ah.appno=cr.appno and cr.crcatcode=p.crcatcode and tab3.appno=tab1.appno and 
								cr.recvdate > @fromdate and cr.recvdate< @todate and p.CrCatCode=@crCatCode
								order by ah.appno ";*/

                sqlSelect = @"select ca.AppNo,cm.nicno,cm.SurName,cm.Initials,ah.holdRelation,
                            convert(varchar, ca.RecvDate, 111) as RecvDate,ca.CrAmt,cc.crdes as LoanCategory,
                            case aps.status
                            when 'A' then 'Approved'
                            when 'N' then 'Pending'
                            else 'Cancel' end as status,ca.AddUser
                            from crapp ca, appholder ah, Customermain cm ,crcategory cc,approvalstatus aps
                            where ca.appno=ah.appno  and cm.nicno=ah.nicno and
                            cc.crcatcode=ca.crcatcode and aps.appno=ca.appno and 
                            ca.recvdate >= @fromdate and ca.recvdate<= @todate and cc.CrCatCode=@crCatCode
                            order by ca.appno";
               
                dt = new DataTable();
            }
            else
            {
                if (crCatCode == 0)
                {
                    /*sqlSelect = @"select tab1.appno,cm.nicno,cm.surname,cm.initials,
									cast(day(cr.recvdate) as char(2)) + '/' + cast(month(cr.recvdate) as char(2)) + '/' + cast(Year(cr.recvdate) 
									as char(4)) as  RecieveDate,cr.cramt,case tab3.ispaid
									when 1 then 'Paid'
									when 0 then 'Not Paid' end as Ispaid,
									tab2.valfee ,tab1.inspecfee, p.crdes,
									case a.status
									when 'A' then 'Approved'
									when 'N' then 'Pending'
									else 'Cancel' end as status,
									cr.adduser as AddUser 
									from (select cracno as appno, sum(tramt) as inspecfee from transassign where left(cracno,1) = 3 and transno is not null and trstatus='F'
									and taskid in ('INSN900000','ITRN900000','INSE900000','ITRE900000')
									group by cracno) as tab1 ,
									(select cracno as appno , sum(tramt) as valfee from transassign where left(cracno,1) = 3 and transno is not null and trstatus='F'
									and taskid in ('VALN900000','VTRN900000','VALE900000','VTRE900000')
									group by cracno) as tab2 ,
									(select distinct appno,ispaymentok as ispaid from approvalstatus where ispaymentok is not null) as tab3 ,
									customermain cm , appholder ah, Crapp Cr, CrCategory p,approvalstatus a
									where tab1.appno=tab2.appno and cm.nicno=ah.nicno and ah.appno=tab1.appno and a.appno=tab1.appno
									and ah.appno=cr.appno and cr.crcatcode=p.crcatcode and tab3.appno=tab1.appno and 
									cr.recvdate > @fromdate and cr.recvdate< @todate and a.status=@status
									order by ah.appno ";*/

                    sqlSelect = @"select ca.AppNo,cm.nicno,cm.SurName,cm.Initials,ah.holdRelation,
                            convert(varchar, ca.RecvDate, 111) as RecvDate,ca.CrAmt,cc.crdes as LoanCategory,
                            case aps.status
                            when 'A' then 'Approved'
                            when 'N' then 'Pending'
                            else 'Cancel' end as status,ca.AddUser
                            from crapp ca, appholder ah, Customermain cm ,crcategory cc,approvalstatus aps
                            where ca.appno=ah.appno  and cm.nicno=ah.nicno and
                            cc.crcatcode=ca.crcatcode and aps.appno=ca.appno and 
                            ca.recvdate >= @fromdate and ca.recvdate<= @todate and aps.status=@status
                            order by ca.appno";
                    
                    dt = new DataTable();
                }
                else
                {
                    /*sqlSelect = @"select tab1.appno,cm.nicno,cm.surname,cm.initials,
									cast(day(cr.recvdate) as char(2)) + '/' + cast(month(cr.recvdate) as char(2)) + '/' + cast(Year(cr.recvdate) 
									as char(4)) as  RecieveDate,cr.cramt,case tab3.ispaid
									when 1 then 'Paid'
									when 0 then 'Not Paid' end as Ispaid,
									tab2.valfee ,tab1.inspecfee, p.crdes,
									case a.status
									when 'A' then 'Approved'
									when 'N' then 'Pending'
									else 'Cancel' end as status,
									cr.adduser as AddUser 
									from (select cracno as appno, sum(tramt) as inspecfee from transassign where left(cracno,1) = 3 and transno is not null and trstatus='F'
									and taskid in ('INSN900000','ITRN900000','INSE900000','ITRE900000')
									group by cracno) as tab1 ,
									(select cracno as appno , sum(tramt) as valfee from transassign where left(cracno,1) = 3 and transno is not null and trstatus='F'
									and taskid in ('VALN900000','VTRN900000','VALE900000','VTRE900000')
									group by cracno) as tab2 ,
									(select distinct appno,ispaymentok as ispaid from approvalstatus where ispaymentok is not null) as tab3 ,
									customermain cm , appholder ah, Crapp Cr, CrCategory p,approvalstatus a
									where tab1.appno=tab2.appno and cm.nicno=ah.nicno and ah.appno=tab1.appno and a.appno=tab1.appno
									and ah.appno=cr.appno and cr.crcatcode=p.crcatcode and tab3.appno=tab1.appno and 
									 cr.recvdate > @fromdate and cr.recvdate < @todate and a.status=@status and p.CrCatCode=@crCatCode
									order by ah.appno ";*/

                    sqlSelect = @"select ca.AppNo,cm.nicno,cm.SurName,cm.Initials,ah.holdRelation,
                            convert(varchar, ca.RecvDate, 111) as RecvDate,ca.CrAmt,cc.crdes as LoanCategory,
                            case aps.status
                            when 'A' then 'Approved'
                            when 'N' then 'Pending'
                            else 'Cancel' end as status,ca.AddUser
                            from crapp ca, appholder ah, Customermain cm ,crcategory cc,approvalstatus aps
                            where ca.appno=ah.appno  and cm.nicno=ah.nicno and
                            cc.crcatcode=ca.crcatcode and aps.appno=ca.appno and 
                            ca.recvdate >= @fromdate and ca.recvdate<= @todate and aps.status=@status and cc.CrCatCode=@crCatCode
                            order by ca.appno";
                    
                    dt = new DataTable();

                }
            }
        }

        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);

        sqldataAdapter.SelectCommand.Parameters.AddWithValue("status", status);
        sqldataAdapter.SelectCommand.Parameters.AddWithValue("crCatCode", crCatCode);
        sqldataAdapter.SelectCommand.Parameters.AddWithValue("fromdate", fromdate);
        sqldataAdapter.SelectCommand.Parameters.AddWithValue("todate", todate);


        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return dt;

    }

    public DataTable CountApplicationData(string status, int crCatCode, DateTime fromdate, DateTime todate)
    {
        string sqlSelect;

        if ((status == "0") && (crCatCode == 0))
        {
            /*sqlSelect = @"select tab1.appno,cm.nicno,cm.surname,cm.initials,
                            cast(day(cr.recvdate) as char(2)) + '/' + cast(month(cr.recvdate) as char(2)) + '/' + cast(Year(cr.recvdate) 
                            as char(4)) as  RecieveDate,
                            cr.cramt,
                            case tab3.ispaid
                            when 1 then 'Paid'
                            when 0 then 'Not Paid'end as Ispaid,
                            tab2.valfee ,tab1.inspecfee, p.crdes,
                            case cr.status
                            when 'A' then 'Approved'
                            when 'I' then 'Pending'
                            when 'N' then 'Not Approved' end as status
                            from 
                            (select appno,sum(amount) as inspecfee
                            from paymentmade 
                            where PaymentTypeID IN (3,4,140,185) group by appno ) as tab1 ,
                            (select appno,sum(amount) as valfee
                            from paymentmade 
                            where PaymentTypeID IN (1,2,141,186) group by appno ) as tab2 ,
                            (select distinct appno,ispaid from paymentmade ) as tab3 ,
                            customermain cm , appholder ah, Crapp Cr, CrCategory p
                            where tab1.appno=tab2.appno and cm.nicno=ah.nicno and ah.appno=tab1.appno 
                            and ah.appno=cr.appno and cr.crcatcode=p.crcatcode and tab3.appno=tab1.appno and
                            cr.recvdate > @fromdate and cr.recvdate< @todate and ah.holdertype='P'
                            order by ah.appno";*/

            sqlSelect = @"select ca.AppNo,cm.nicno,cm.SurName,cm.Initials,ah.holdRelation,
                            convert(varchar, ca.RecvDate, 111) as RecvDate,ca.CrAmt,cc.crdes as LoanCategory,
                            case aps.status
                            when 'A' then 'Approved'
                            when 'N' then 'Pending'
                            else 'Cancel' end as status,ca.AddUser
                            from crapp ca, appholder ah, Customermain cm ,crcategory cc,approvalstatus aps
                            where ca.appno=ah.appno  and cm.nicno=ah.nicno and
                            cc.crcatcode=ca.crcatcode and aps.appno=ca.appno and 
                            ca.recvdate >= @fromdate and ca.recvdate<= @todate and ah.holdertype='P'
                            order by ca.appno";


            dt = new DataTable();
        }
        else
        {
            if (status == "0")
            {
                /*sqlSelect = @"select tab1.appno,cm.nicno,cm.surname,cm.initials,
                            cast(day(cr.recvdate) as char(2)) + '/' + cast(month(cr.recvdate) as char(2)) + '/' + cast(Year(cr.recvdate) 
                            as char(4)) as  RecieveDate,
                            cr.cramt,
                            case tab3.ispaid
                            when 1 then 'Paid'
                            when 0 then 'Not Paid'end as Ispaid,
                            tab2.valfee ,tab1.inspecfee, p.crdes,
                            case cr.status
                            when 'A' then 'Approved'
                            when 'I' then 'Pending'
                            when 'N' then 'Not Approved' end as status
                            from 
                            (select appno,sum(amount) as inspecfee
                            from paymentmade 
                            where PaymentTypeID IN (3,4,140,185) group by appno ) as tab1 ,
                            (select appno,sum(amount) as valfee
                            from paymentmade 
                            where PaymentTypeID IN (1,2,141,186) group by appno ) as tab2 ,
                            (select distinct appno,ispaid from paymentmade ) as tab3 ,
                            customermain cm , appholder ah, Crapp Cr, CrCategory p
                            where tab1.appno=tab2.appno and cm.nicno=ah.nicno and ah.appno=tab1.appno 
                            and ah.appno=cr.appno and cr.crcatcode=p.crcatcode and tab3.appno=tab1.appno and
                            cr.recvdate > @fromdate and cr.recvdate< @todate and p.CrCatCode=@crCatCode and ah.holdertype='P'
                            order by ah.appno";*/

                sqlSelect = @"select ca.AppNo,cm.nicno,cm.SurName,cm.Initials,ah.holdRelation,
                            convert(varchar, ca.RecvDate, 111) as RecvDate,ca.CrAmt,cc.crdes as LoanCategory,
                            case aps.status
                            when 'A' then 'Approved'
                            when 'N' then 'Pending'
                            else 'Cancel' end as status,ca.AddUser
                            from crapp ca, appholder ah, Customermain cm ,crcategory cc,approvalstatus aps
                            where ca.appno=ah.appno  and cm.nicno=ah.nicno and
                            cc.crcatcode=ca.crcatcode and aps.appno=ca.appno and 
                            ca.recvdate >= @fromdate and ca.recvdate<= @todate and cc.CrCatCode=@crCatCode and ah.holdertype='P'
                            order by ca.appno";

                dt = new DataTable();
            }
            else
            {
                if (crCatCode == 0)
                {
                    /*sqlSelect = @"select tab1.appno,cm.nicno,cm.surname,cm.initials,
                                    cast(day(cr.recvdate) as char(2)) + '/' + cast(month(cr.recvdate) as char(2)) + '/' + cast(Year(cr.recvdate) 
                                    as char(4)) as  RecieveDate,
                                    cr.cramt,
                                    case tab3.ispaid
                                    when 1 then 'Paid'
                                    when 0 then 'Not Paid'end as Ispaid,
                                    tab2.valfee ,tab1.inspecfee, p.crdes,
                                    case cr.status
                                    when 'A' then 'Approved'
                                    when 'I' then 'Pending'
                                    when 'N' then 'Not Approved' end as status
                                    from 
                                    (select appno,sum(amount) as inspecfee
                                    from paymentmade 
                                    where PaymentTypeID IN (3,4,140,185) group by appno ) as tab1 ,
                                    (select appno,sum(amount) as valfee
                                    from paymentmade 
                                    where PaymentTypeID IN (1,2,141,186) group by appno ) as tab2 ,
                                    (select distinct appno,ispaid from paymentmade ) as tab3 ,
                                    customermain cm , appholder ah, Crapp Cr, CrCategory p
                                    where tab1.appno=tab2.appno and cm.nicno=ah.nicno and ah.appno=tab1.appno 
                                    and ah.appno=cr.appno and cr.crcatcode=p.crcatcode and tab3.appno=tab1.appno and
                                    cr.recvdate > @fromdate and cr.recvdate< @todate and cr.status=@status and ah.holdertype='P'
                                    order by ah.appno";*/

                    sqlSelect = @"select ca.AppNo,cm.nicno,cm.SurName,cm.Initials,ah.holdRelation,
                            convert(varchar, ca.RecvDate, 111) as RecvDate,ca.CrAmt,cc.crdes as LoanCategory,
                            case aps.status
                            when 'A' then 'Approved'
                            when 'N' then 'Pending'
                            else 'Cancel' end as status,ca.AddUser
                            from crapp ca, appholder ah, Customermain cm ,crcategory cc,approvalstatus aps
                            where ca.appno=ah.appno  and cm.nicno=ah.nicno and
                            cc.crcatcode=ca.crcatcode and aps.appno=ca.appno and 
                            ca.recvdate >= @fromdate and ca.recvdate<= @todate and aps.status=@status and ah.holdertype='P'
                            order by ca.appno";

                    dt = new DataTable();
                }
                else
                {
                    /*sqlSelect = @"select tab1.appno,cm.nicno,cm.surname,cm.initials,
                                    cast(day(cr.recvdate) as char(2)) + '/' + cast(month(cr.recvdate) as char(2)) + '/' + cast(Year(cr.recvdate) 
                                    as char(4)) as  RecieveDate,
                                    cr.cramt,
                                    case tab3.ispaid
                                    when 1 then 'Paid'
                                    when 0 then 'Not Paid'end as Ispaid,
                                    tab2.valfee ,tab1.inspecfee, p.crdes,
                                    case cr.status
                                    when 'A' then 'Approved'
                                    when 'I' then 'Pending'
                                    when 'N' then 'Not Approved' end as status
                                    from 
                                    (select appno,sum(amount) as inspecfee
                                    from paymentmade 
                                    where PaymentTypeID IN (3,4,140,185) group by appno ) as tab1 ,
                                    (select appno,sum(amount) as valfee
                                    from paymentmade 
                                    where PaymentTypeID IN (1,2,141,186) group by appno ) as tab2 ,
                                    (select distinct appno,ispaid from paymentmade ) as tab3 ,
                                    customermain cm , appholder ah, Crapp Cr, CrCategory p
                                    where tab1.appno=tab2.appno and cm.nicno=ah.nicno and ah.appno=tab1.appno 
                                    and ah.appno=cr.appno and cr.crcatcode=p.crcatcode and tab3.appno=tab1.appno and
                                    cr.recvdate > @fromdate and cr.recvdate < @todate and cr.status=@status and p.CrCatCode=@crCatCode and ah.holdertype='P'
                                    order by ah.appno";*/

                    sqlSelect = @"select ca.AppNo,cm.nicno,cm.SurName,cm.Initials,ah.holdRelation,
                            convert(varchar, ca.RecvDate, 111) as RecvDate,ca.CrAmt,cc.crdes as LoanCategory,
                            case aps.status
                            when 'A' then 'Approved'
                            when 'N' then 'Pending'
                            else 'Cancel' end as status,ca.AddUser
                            from crapp ca, appholder ah, Customermain cm ,crcategory cc,approvalstatus aps
                            where ca.appno=ah.appno  and cm.nicno=ah.nicno and
                            cc.crcatcode=ca.crcatcode and aps.appno=ca.appno and 
                            ca.recvdate >= @fromdate and ca.recvdate<= @todate and aps.status=@status and cc.CrCatCode=@crCatCode
                            and ah.holdertype='P'
                            order by ca.appno";

                    dt = new DataTable();

                }
            }
        }

        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);

        sqldataAdapter.SelectCommand.Parameters.AddWithValue("status", status);
        sqldataAdapter.SelectCommand.Parameters.AddWithValue("crCatCode", crCatCode);
        sqldataAdapter.SelectCommand.Parameters.AddWithValue("fromdate", fromdate);
        sqldataAdapter.SelectCommand.Parameters.AddWithValue("todate", todate);


        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return dt;

    }



    public DataTable GetLoanTransactionSummery(string cracno, string transFrom)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select t1.CapitalCR,t2.CapitalDR,t3.InterestCR,t4.InterestDR,t5.PenalCR,t6.PenalDR,
                             sum(isnull(t1.CapitalCR,0)+isnull(t3.InterestCR,0)+isnull(t5.PenalCR,0)) as SumCredit,
							 sum(isnull(t2.CapitalDR,0)+isnull(t4.InterestDR,0)+isnull(t6.PenalDR,0)) as SumDebit from
                            (select sum(g.tramt) as CapitalCR from transassign t , gltrans g
                            where t.refno=g.transassignrefno and t.cracno=@cracno and 
                             g.transno>=@transFrom and t.trtype='I'
                            and g.trstatus<> 'C' and g.acsign = 'CR' and t.taskid='CAPD') as t1,
                            (select sum(g.tramt) as CapitalDR from transassign t , gltrans g
                            where t.refno=g.transassignrefno and t.cracno=@cracno and
                             g.transno>=@transFrom and t.trtype='E'
                            and g.trstatus<> 'C' and g.acsign = 'DR' and t.taskid='CAPD') as t2,
                            (select sum(g.tramt) as InterestCR from transassign t , gltrans g
                            where t.refno=g.transassignrefno and t.cracno=@cracno and 
                             g.transno>=@transFrom and t.trtype='I'
                            and g.trstatus<> 'C' and g.acsign = 'CR' and t.taskid='INTR') as t3,
                            (select sum(g.tramt) as InterestDR from transassign t , gltrans g
                            where t.refno=g.transassignrefno and t.cracno=@cracno and
                             g.transno>=@transFrom and t.trtype='E'
                            and g.trstatus<> 'C' and g.acsign = 'DR' and t.taskid='INTR') as t4,
                            (select sum(g.tramt) as PenalCR from transassign t , gltrans g
                            where t.refno=g.transassignrefno and t.cracno=@cracno and 
                             g.transno>=@transFrom and t.trtype='I'
                            and g.trstatus<> 'C' and g.acsign = 'CR' and t.taskid='PNLR') as t5,
                            (select sum(g.tramt) as PenalDR from transassign t , gltrans g
                            where t.refno=g.transassignrefno and t.cracno=@cracno and
                             g.transno>=@transFrom and t.trtype='E'
                            and g.trstatus<> 'C' and g.acsign = 'DR' and t.taskid='PNLR') as t6
							group by t1.CapitalCR,t2.CapitalDR,t3.InterestCR,t4.InterestDR,t5.PenalCR,t6.PenalDR");
        dw.SetDataAdapterParameters("cracno", cracno);
        dw.SetDataAdapterParameters("transFrom", transFrom);
        return dw.GetDataTable();
    }
   
}
