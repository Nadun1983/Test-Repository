﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data;
using System.Data.SqlClient;

/// <summary>
/// Summary description for LoanPosition
/// </summary>
public class LoanPosition
{

    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();
    //string Oldconstring = ConfigurationManager.ConnectionStrings["TestOld"].ConnectionString.ToString();
    private SqlDataAdapter sqldataadap;
    private SqlCommand sqlcmd;
    private DataTable dt;
    int RowAdded;
    DataWorksClass dw;
    FunctionClass fc;
    Corrections cs;
    CrTransClass cc;
    Recovery rc;

	public LoanPosition()
	{
		//
		// TODO: Add constructor logic here
		//
	}

//    public DataTable GetLoanCurrentPosition(string cracno, string trstatus)
//    {
//        dw = new DataWorksClass(constring);
//        dw.SetDataAdapter(@"SELECT DISTINCT T.RefNo,
//                            rtrim(rtrim(year(t.datedue))+'/'+rtrim(month(t.datedue))+'/'+rtrim(day(t.datedue)))as Datedue,
//                            T.TaskId,T.AssignAmt,G.TrAmt,
//                            T.TrStatus,
//                            Hp.IntRate,
//                            rtrim(rtrim(year(T.TrDate))+'/'+rtrim(month(T.TrDate))+'/'+rtrim(day(T.TrDate))) As TransactionDate
//                            FROM CrMast M, Tdbold.CreditAdmin.HousProp H,HousProp Hp,
//                            TransAssign T, GLtrans G
//                            WHERE M.CrAcNo=H.CrAcNo AND H.CrACno=Hp.CrAcNo AND
//                            M.CrAcNo=T.CrAcNo AND T.TransNo IS NOT NULL AND
//                            T.RefNo=G.TransAssignRefNo AND G.AcSign='CR'
//                            AND T.Transref='RECV' and t.trstatus <> @trstatus
//                            and t.batchno is not null and t.cracno=@cracno
//                            ORDER BY t.datedue,t.refno,t.taskid  desc");
//        dw.SetDataAdapterParameters("cracno", cracno);
//        dw.SetDataAdapterParameters("trstatus", trstatus);
//        return dw.GetDataTable();
//    }


    //change at 14/08/2009 Dilanka
    public DataTable GetLoanCurrentPosition(string cracno, string trstatus)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"SELECT DISTINCT t.cracno, 
                        rtrim(rtrim(year(t.datedue))+'/'+rtrim(month(t.datedue))+'/'+rtrim(day(t.datedue)))as Datedue,
                        T.TaskId,T.AssignAmt,t.TrAmt,
                        T.TrStatus,
                        Hp.IntRate,
                        rtrim(rtrim(year(T.TrDate))+'/'+rtrim(month(T.TrDate))+'/'+rtrim(day(T.TrDate))) As TransactionDate
                        FROM CrMast M, Tdbold.CreditAdmin.HousProp H,HousProp Hp,
                        TransAssign T, GLtrans G
                        WHERE M.CrAcNo=H.CrAcNo AND H.CrACno=Hp.CrAcNo AND
                        M.CrAcNo=T.CrAcNo AND T.TransNo IS NOT NULL AND
                        T.RefNo=G.TransAssignRefNo AND G.AcSign='CR'
                        AND T.Transref='RECV' and t.trstatus <> 'F'
                        and t.batchno is not null and t.cracno=@cracno
                        ORDER BY t.cracno,t.datedue,t.taskid  desc");
        dw.SetDataAdapterParameters("cracno", cracno);
        dw.SetDataAdapterParameters("trstatus", trstatus);
        return dw.GetDataTable();
    }



    public DataTable GetLoanDetails(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select cracno,graceperiod,crperiod,paidinstalments,(crperiod - paidinstalments)
                      as RemainingInstalment from housprop  where cracno=@cracno");
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();

    }

    public int GetRemainIns(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select count(*) as remainIns from transassign where cracno=@cracno and 
                        (trstatus = 'N' or trstatus = 'P') group by adddate");
        dw.SetSqlCommandParameters("cracno", cracno);
        return int.Parse(dw.GetSingleData());
    }

    public DataTable GetAreas(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"SELECT DISTINCT T.TaskId,(sum(T.AssignAmt) - sum(G.TrAmt)) as Amount
                            FROM TransAssign T, GLtrans G WHERE T.RefNo=G.TransAssignRefNo AND G.AcSign='CR'
                            AND T.Transref='RECV' and (t.trstatus = 'P' or t.trstatus = 'N')
                            and t.batchno is not null and t.cracno=@cracno group BY t.taskid ");
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }

    //public DataTable GetDetailReport(double LoanAmt, double IntRate, double Instalment, int LoanPeriod)
    //{
    //    DataTable dt = new DataTable();
    //    dt = SetAmtzDataTable(dt);
    //    DateTime recoveryProcessDate;
    //    fc = new FunctionClass();
    //    cc = new CrTransClass();
    //    rc = new Recovery();
    //    double intamount = 0, capital = 0;
    //    double actoutbal = 0, outbal = 0;
    //    int serialno = 0;
    //    DataTable basicRec = new DataTable(); //Loan Number Table       

    //    int refno = 1;

    //    while (LoanAmt > 0)
    //    {
    //        intamount = CalculateIntAmount(LoanAmt, IntRate);
    //        capital = CalculateCapital(Instalment, intamount, '1', LoanAmt);
    //        LoanAmt -= capital;
    //        LoanAmt = Math.Round(LoanAmt, 2);
    //        dt = InsertRow(refno.ToString(), capital, intamount, LoanAmt, dt);
    //        refno = refno + 1;
    //    }

    //    return dt;

    //}

    public void GetDetailReport(double LoanAmt, double IntRate, double Instalment, int LoanPeriod, string cracno)
    {
        DataTable dt = new DataTable();
        RecoveryProcesClass rpc = new RecoveryProcesClass();
        dt = SetAmtzDataTable(dt);
        DateTime recoveryProcessDate;
        fc = new FunctionClass();
        cc = new CrTransClass();
        rc = new Recovery();
        double intamount = 0, capital = 0;
        double actoutbal = 0, outbal = 0;
        int serialno = 0;
        DataTable basicRec = new DataTable(); //Loan Number Table       

        int refno = 1;

        while (LoanAmt > 0)
        {
            intamount = CalculateIntAmount(LoanAmt, IntRate);
            capital = CalculateCapital(Instalment, intamount, '1', LoanAmt);
            LoanAmt -= capital;
            LoanAmt = Math.Round(LoanAmt, 2);
            //dt = InsertRow(refno.ToString(), capital, intamount, LoanAmt, dt);
            rpc.InsertAmortizationData(refno, cracno, capital, intamount, LoanAmt);
            refno = refno + 1;
        }

        //return dt;

    }

    private double CalculateIntAmount(double outbal, double intrate)
    {
        return Math.Round(outbal * intrate / 1200, 2);
    }

    private double CalculateCapital(double installment, double intAmount, int crcat, double outbal)
    {
        if (crcat != 6)
        {
            if (installment >= outbal)
            {
                return Math.Round(outbal, 2);
            }
            else
            {
                return Math.Round(installment - intAmount, 2);
            }
        }
        else
        {
            return 0;
        }
    }


    private DataTable SetAmtzDataTable(DataTable dt)
    {
        dt = new DataTable();
        DataColumn refno;
        refno = new DataColumn();
        refno.DataType = Type.GetType("System.String");
        refno.ColumnName = "Refno";
        dt.Columns.Add(refno);

        DataColumn capital;
        capital = new DataColumn();
        capital.DataType = Type.GetType("System.Decimal");
        capital.ColumnName = "capital";
        dt.Columns.Add(capital);

        DataColumn intamount;
        intamount = new DataColumn();
        intamount.DataType = Type.GetType("System.Decimal");
        intamount.ColumnName = "intamount";
        dt.Columns.Add(intamount);

        DataColumn LoanAmt;
        LoanAmt = new DataColumn();
        LoanAmt.DataType = Type.GetType("System.Decimal");
        LoanAmt.ColumnName = "LoanAmt";
        dt.Columns.Add(LoanAmt);

        return dt;
    }

    private DataTable InsertRow(string refno, double capital, double intamount, double LoanAmt, DataTable dt)
    {
        DataRow dr;
        dr = dt.NewRow();
        dr["refno"] = refno;
        dr["capital"] = capital;
        dr["intamount"] = intamount;
        dr["LoanAmt"] = LoanAmt;
        dt.Rows.Add(dr);
        return dt;
    }
}
