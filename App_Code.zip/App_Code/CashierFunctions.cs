﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Data.SqlClient;

/// <summary>
/// Summary description for CashierFunctions
/// </summary>
public class CashierFunctions
{
    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();
    DataWorksClass dw;
    DataTable dt;

	public CashierFunctions()
	{
		//
		// TODO: Add constructor logic here
		//
	}    

    public string GetCashierBalance(string sysdate,string username)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select sum(amount) as TotalAmount from CashierTransaction 
                        where username=@username and sysdate=@sysdate");
        dw.SetSqlCommandParameters("username", username);
        dw.SetSqlCommandParameters("sysdate", sysdate);
        return dw.GetSingleData();
    }

    public string GetCashierBalance(string sysdate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select sum(amount) as TotalAmount from CashierTransaction where sysdate=@sysdate");
        dw.SetSqlCommandParameters("sysdate", sysdate);
        return dw.GetSingleData();
    }

    //Get Cash Box Names 
    public DataTable GetCashBoxNames(string BranchId)
    {
        dt = new DataTable();
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select cashboxno from cashbox where BranchId=@BranchId");
        dw.SetDataAdapterParameters("BranchId", BranchId);
        dt = dw.GetDataTable();
        return dt;
    }

    //Get User BranchID
    public string GetBranchId(string userid)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select brcode from users where userid=@userid");
        dw.SetSqlCommandParameters("userid", userid);
        return dw.GetSingleData();
    }

    public DataTable GetCashierNames(string BrCode)
    {
        dt = new DataTable();
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select username,userid from users where status='A' and BrCode=@BrCode");
        dw.SetDataAdapterParameters("BrCode", BrCode);
        dt = dw.GetDataTable();
        return dt;
    }

    //Get cash box begin bal as well as beginbal=previous day 'Dayend' balance
    public DataTable GetDayEndCashBoxBal(string cashboxno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select beginbal,ToDaycr,todaydr from cashbox where cashboxno=@cashboxno");
        dw.SetDataAdapterParameters("cashboxno", cashboxno);
        dt = dw.GetDataTable();
        return dt;
    }

    //Assign InterCashier TransAction
    public int InsertCashMvmnt(string userid, string in_out, double amount, string refid, string refCashbox, string sysDate)
    {
        DateTime adddate = Convert.ToDateTime(System.DateTime.Now.ToShortDateString());
        string addtime = System.DateTime.Now.ToShortTimeString();
        int Rowadded = 0;
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into cashmvmnt values('A',@userid,@in_out,@amount,@refid,@adddate,@addtime,0,@refCashbox,@sysDate,NULL,NULL)");
        dw.SetSqlCommandParameters("userid", userid);
        dw.SetSqlCommandParameters("in_out", in_out);
        dw.SetSqlCommandParameters("amount", amount);
        dw.SetSqlCommandParameters("refid", refid);
        dw.SetSqlCommandParameters("adddate", adddate);
        dw.SetSqlCommandParameters("addtime", addtime);
        dw.SetSqlCommandParameters("refCashbox", refCashbox);
        dw.SetSqlCommandParameters("sysDate", sysDate);
        Rowadded = dw.Insert();
        return Rowadded;
    }    

    //update cashbox in the morning when cash Assing to CashBox and Cashier
    public int UpdateCashBox(int cashboxno, double beginbal, string OfficerId, DateTime workdate, double todaycr, double todaydr,
        string IsReleased, string status, string sysDate, string cashierid)
    {
        int rowAdded;
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update cashbox set workdate=@workdate , beginbal=@beginbal , sysDate=@sysDate ,
                      todaycr=@todaycr , todaydr=@todaydr , OfficerId=@OfficerId , IsReleased=@IsReleased ,
                      cashierid=@cashierid where cashboxno=@cashboxno and status=@status");
        dw.SetSqlCommandParameters("workdate", workdate);
        dw.SetSqlCommandParameters("beginbal", beginbal);
        dw.SetSqlCommandParameters("cashboxno", cashboxno);
        dw.SetSqlCommandParameters("OfficerId", OfficerId);
        dw.SetSqlCommandParameters("todaycr", todaycr);
        dw.SetSqlCommandParameters("todaydr", todaydr);
        dw.SetSqlCommandParameters("IsReleased", IsReleased);
        dw.SetSqlCommandParameters("status", status);
        dw.SetSqlCommandParameters("sysDate", sysDate);
        dw.SetSqlCommandParameters("cashierid", cashierid);
        rowAdded = dw.Update();
        return rowAdded;
    }

    public int Updatecashmvmnt(string refid, string acceptSysDate, DateTime acceptActualDatetime)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update cashmvmnt set isaccept=1,acceptSysDate=@acceptSysDate,
                        acceptActualDatetime=@acceptActualDatetime where refid=@refid");
        dw.SetSqlCommandParameters("refid", refid);
        dw.SetSqlCommandParameters("acceptSysDate", acceptSysDate);
        dw.SetSqlCommandParameters("acceptActualDatetime", acceptActualDatetime);
        return dw.Update();
    }

    public DataTable GetCashiersDayStartDetails(string cashierid)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select beginbal,cashboxno from cashbox where cashierid=@cashierid");
        dw.SetDataAdapterParameters("cashierid", cashierid);
        return dw.GetDataTable();
    }

    
    //2009-12-15
    public string Getactoutbal(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select actoutbal from housprop where cracno=@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return dw.GetSingleData();
    }

    //2009-12-15
    public string Getintrate(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select intrate from housprop where cracno=@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return dw.GetSingleData();
    }
}
