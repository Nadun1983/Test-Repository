﻿
using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Data.SqlClient;
using Microsoft.SqlServer.Server;

/// <summary>
/// Summary description for ClosingDataClass
/// </summary>
public class ClosingDataClass
{

    string reportcastring = ConfigurationManager.ConnectionStrings["reportCAString"].ConnectionString;
    string oldhousdbString = ConfigurationManager.ConnectionStrings["oldhousdbString"].ConnectionString;
    DataWorksClass dw;
    FunctionClass fc;
    DirectGlClass dgc;


    public ClosingDataClass()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public int insertClosingData(string operationdate, string cracno, string closingtype,
    double returnamt, double tramt, string trmode, string batchrefno, long batchno, int repetition, string fullname, string brcode)
    {
        dw = new DataWorksClass(reportcastring);
        dw.SetCommand(@"INSERT INTO Closingdata ( operationdate, cracno, closingtype,
                        returnamount, tramt, trmode, batchrefno, batchno, repititions, fullname, brcode)
                        values (@operationdate, @cracno, @closingtype,
                        @returnamt, @tramt, @trmode, @batchrefno, @batchno, @repetition, @fullname, @brcode)");
        dw.SetSqlCommandParameters("operationdate", operationdate);
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("closingtype", closingtype);
        dw.SetSqlCommandParameters("returnamt", returnamt);
        dw.SetSqlCommandParameters("tramt", tramt);
        dw.SetSqlCommandParameters("trmode", trmode);
        dw.SetSqlCommandParameters("batchrefno", batchrefno);
        dw.SetSqlCommandParameters("batchno", batchno);
        dw.SetSqlCommandParameters("repetition", repetition);
        dw.SetSqlCommandParameters("fullname", fullname);
        dw.SetSqlCommandParameters("brcode", brcode);
        return dw.Insert();
    }

    public int getRepetition(string cracno)
    {
        dw = new DataWorksClass(reportcastring);
        dw.SetCommand(@"select max(repititions) as repititions from Closingdata where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return int.Parse(dw.GetSingleData());
    }



    public void UpdateClosingData(string cracno, double tramt, double returnamt, string batchusr, long batchno, string batchrefno, DateTime operationdate, string trmode, string closingtype)
    {
        fc = new FunctionClass();
        string brcode = cracno.Substring(1, 4);
        fc = new FunctionClass();
        dgc = new DirectGlClass();

        string datekey = fc.GetDateKeyinDate(operationdate).ToString();
        int repetition = getRepetition(cracno);
        string fullname = dgc.GetUserNameCracno(cracno);
        insertClosingData(datekey, cracno, closingtype, returnamt, tramt, trmode, batchrefno, batchno, repetition, fullname, brcode);
    }

  

    public DataTable GetTransactions()
    {
        dw = new DataWorksClass(reportcastring);
        dw.SetDataAdapter(@"select distinct adddate from transassign
                            order by adddate");
        return dw.GetDataTable();
    }
}

