﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Data;
using System.Configuration;

/// <summary>
/// Summary description for AccountPosition
/// </summary>
public class AccountPosition
{
    string msg = "";
    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();
    double reversalamt, outbal, intamt, scheduledcharges, prematureamt, closingbal, cappayment, capcapital, cramt, dramt;
    DateTime datedue, nextdue, intdatedue;
    int intdays;
    RecoveryProcesClass rpc;
    DataWorksClass dw;
    FunctionClass fc;
    CrTransClass ctc;
    LastSerialClass ls;
    Recovery rc;
    Trans tr;
    DataTable dt;
    ClosingDataClass cdc;
    //public AccountPosition()
    //{
    //    //
    //    // TODO: Add constructor logic here
    //    //
    //}
    //  Exxecc of Advance Payment

    # region Vatiables
    public double ReversalAmt
    {
        get
        {
            return reversalamt;
        }
    }
    public string Message
    {
        get
        {
            return msg;
        }
    }


    public DateTime NextDue
    {
        get
        {
            return nextdue;
        }
    }

    public DateTime IntDateDue
    {
        get
        {
            return intdatedue;
        }
    }


    public double OutBal
    {
        get
        {
            return outbal;
        }
    }


    public DateTime DateDue
    {
        get
        {
            return datedue;
        }
    }


    public int IntDays
    {
        get
        {
            return intdays;
        }
    }

    public double IntAmt
    {
        get
        {
            return intamt;
        }
    }

    public double ScheduledCharges
    {
        get
        {
            return scheduledcharges;
        }
    }


    public double PrematureAmt
    {
        get
        {
            return prematureamt;
        }
    }


    public double ClosingBalance
    {
        get
        {
            return closingbal;
        }
    }

    public double CapPayment
    {
        get
        {
            return cappayment;
        }
    }

    public double CapCapital
    {
        get
        {
            return capcapital;
        }
    }
    public double CrAmt
    {
        get
        {
            return cramt;
        }
    }
    public double DrAmt
    {
        get
        {
            return dramt;
        }
    }
    #endregion

    // To be implemented
    public string GetRecoveryData(string cracno, double tramt, DateTime trdate, DateTime opdate, long batchno, string adduser, string batchrefno, int closingmode)
    {
        dt = new DataTable();
        dt = GetnormalDetails(cracno);
        double actoutbal = double.Parse(dt.Rows[0]["OutstandBal"].ToString());
        int crcat = int.Parse(dt.Rows[0]["crcat"].ToString());
        double intrate = double.Parse(dt.Rows[0]["InterestRate"].ToString());

        string rectype;
        fc = new FunctionClass();
        rpc = new RecoveryProcesClass();

        GetAccountClosingData(cracno, trdate, opdate, actoutbal, intrate);
        if (tramt >= this.closingbal)
        {
            InsertRecords(cracno, trdate, opdate, actoutbal, intrate, batchno, crcat, tramt, adduser, batchrefno, closingmode);
            rectype = "CR";
        }
        else
        {
            DataTable setclosingdata = new DataTable();
            setclosingdata = SetDataTable(setclosingdata);
            setclosingdata = rpc.RecoveryProcessTemp(cracno, tramt, trdate, setclosingdata);
            this.nextdue = rpc.NextDue;
            this.outbal = rpc.OutBal;
            SetScheduleData(cracno, intrate, crcat, batchno, adduser, opdate, trdate, outbal, nextdue, batchrefno, setclosingdata);
            rectype = "NR";
        }

        return rectype;
    }

    public string GetRecoveryData(string cracno, double tramt, DateTime trdate, DateTime opdate, long batchno, string adduser, string batchrefno, int closingmode, double cramt, double dramt)
    {
        this.dramt = 0;
        this.cramt = 0;
        dt = new DataTable();
        dt = GetnormalDetails(cracno);
        double actoutbal = double.Parse(dt.Rows[0]["OutstandBal"].ToString());
        int crcat = int.Parse(dt.Rows[0]["crcat"].ToString());
        double intrate = double.Parse(dt.Rows[0]["InterestRate"].ToString());

        string rectype;
        fc = new FunctionClass();
        rpc = new RecoveryProcesClass();

        GetAccountClosingData(cracno, trdate, opdate, actoutbal, intrate);
        if (tramt >= this.closingbal)
        {
            InsertRecords(cracno, trdate, opdate, actoutbal, intrate, batchno, crcat, tramt, adduser, batchrefno, closingmode, cramt, dramt);
            cramt = this.cramt;
            dramt = this.dramt;
            rectype = "CR";
        }
        else
        {
            DataTable setclosingdata = new DataTable();
            setclosingdata = SetDataTable(setclosingdata);
            setclosingdata = rpc.RecoveryProcessTemp(cracno, tramt, trdate, setclosingdata);
            this.nextdue = rpc.NextDue;
            this.outbal = rpc.OutBal;
            SetScheduleData(cracno, intrate, crcat, batchno, adduser, opdate, trdate, outbal, nextdue, batchrefno, setclosingdata, cramt, dramt);
            cramt = this.cramt;
            dramt = this.dramt;
            rectype = "NR";
        }
        this.cramt = cramt;
        this.dramt = dramt;
        return rectype;
    }

    public DataTable GetAmertizationSchedule(string cracno, DateTime trdate, DateTime opDate, double actoutbal, double intrate)
    {
        DataTable setclosingdata = new DataTable();
        setclosingdata = SetDataTable(setclosingdata);
        setclosingdata = GetAdvanceData(cracno, trdate, setclosingdata, actoutbal);
        if (setclosingdata.Rows.Count == 0)
        {
            setclosingdata = GetArreasData(cracno, trdate, opDate, actoutbal, intrate);
        }
        return setclosingdata;
    }

    public DataTable GetArreasData(string cracno, DateTime trdate, DateTime opDate, double actoutbal, double intrate)
    {
        fc = new FunctionClass();
        rpc = new RecoveryProcesClass();
        DataTable setclosingdata = new DataTable();
        setclosingdata = SetDataTable(setclosingdata);
        setclosingdata = GetAdvanceData(cracno, trdate, setclosingdata, actoutbal);
        if (this.reversalamt == 0)
        {
            setclosingdata = rpc.RecoveryProcessTemp(cracno, opDate, trdate, setclosingdata);
            outbal = rpc.OutBal;
            // Check
            datedue = rpc.DateDue;
            nextdue = rpc.NextDue;
        }
        return setclosingdata;
    }


    public DataTable GetAccountClosingData(string cracno, DateTime trdate, DateTime opDate, double actoutbal, double intrate)
    {
        fc = new FunctionClass();
        rpc = new RecoveryProcesClass();
        DataTable setclosingdata = new DataTable();
        setclosingdata = SetDataTable(setclosingdata);
        GetReversalData(cracno, trdate, setclosingdata, actoutbal);
        if (this.reversalamt == 0)
        {
            setclosingdata = rpc.RecoveryProcessTemp(cracno, opDate, trdate, setclosingdata);
            outbal = rpc.OutBal;
            // Check
            datedue = rpc.DateDue;
            nextdue = rpc.NextDue;
            intdatedue = rpc.IntDateDue;
        }

        intdays = GetNoDaysForInterest(intdatedue, trdate);
        intamt = GetInterestAmountFortheMonth(intdays, outbal, intrate);
        scheduledcharges = fc.CalculateTotal("tramt", setclosingdata);
        prematureamt = GetPrematureSettlingCharges(cracno, actoutbal);

        if (reversalamt > 0)
        {
            closingbal = CalulateClosingAmount(intamt, prematureamt,
                                scheduledcharges, actoutbal);
            this.outbal = actoutbal;
        }
        else
        {
            closingbal = CalulateClosingAmount(intamt, prematureamt,
                                scheduledcharges, outbal);
        }
        return setclosingdata;
    }

    public DataTable GetCapitalRecoveryDataFromcapitalGiven(string cracno, DateTime trdate, DateTime opDate, double actoutbal, double intrate, double CapitalAmount)
    {
        rc = new Recovery();
        fc = new FunctionClass();
        DataTable setclosingdata = new DataTable();
        setclosingdata = SetDataTable(setclosingdata);
        rpc = new RecoveryProcesClass();

        GetReversalData(cracno, trdate, setclosingdata, actoutbal);
        if (this.reversalamt == 0)
        {
            setclosingdata = rpc.RecoveryProcessTemp(cracno, opDate, trdate, setclosingdata);
            outbal = rpc.OutBal;
            // Check
            datedue = rpc.DateDue;
            nextdue = rpc.NextDue;
            intdatedue = rpc.IntDateDue;
        }

        intdays = GetNoDaysForInterest(intdatedue, trdate);
        scheduledcharges = fc.CalculateTotal("tramt", setclosingdata);
        prematureamt = GetPrematureSettlingCharges(cracno, CapitalAmount);
        double preintrate = rc.PrematureRate(cracno);
        cappayment = rc.GetCustomerPaymentForCapitalRec(CapitalAmount, scheduledcharges, intrate, preintrate, intdays);
        prematureamt = rc.GetPrematureSettlingCharges(cracno, CapitalAmount);
        intamt = rc.GetInterestAmountFortheMonth(intdays, CapitalAmount, intrate);
        capcapital = CapitalAmount;
        return setclosingdata;
    }


    //public DataTable GetCapitalRecoveryDataFromPaymentGiven(string cracno, DateTime trdate, DateTime opDate, double actoutbal, double intrate, double customerpayment, double cramt, double dramt)
    //{
    //    rc = new Recovery();
    //    fc = new FunctionClass();
    //    DataTable setclosingdata = new DataTable();
    //    setclosingdata = SetDataTable(setclosingdata);
    //    rpc = new RecoveryProcesClass();

    //    GetReversalData(cracno, trdate, setclosingdata, actoutbal);
    //    if (this.reversalamt == 0)
    //    {
    //        setclosingdata = rpc.RecoveryProcessTemp(cracno, opDate, trdate, setclosingdata);
    //        outbal = rpc.OutBal;
    //        // Check
    //        datedue = rpc.DateDue;
    //        nextdue = rpc.NextDue;
    //        intdatedue = rpc.IntDateDue;
    //    }

    //    intdays = GetNoDaysForInterest(intdatedue, trdate);
    //    scheduledcharges = fc.CalculateTotal("tramt", setclosingdata);

    //    if (customerpayment > scheduledcharges)
    //    {
    //        capcapital = rc.GetCapitalRecoveryAmt(customerpayment, scheduledcharges, intdatedue, intrate, cracno, trdate);
    //        intdays = rc.GetNoDaysForInterest(intdatedue, trdate);
    //        intamt = rc.GetInterestAmountFortheMonth(intdays, capcapital, intrate);
    //        prematureamt = rc.GetPrematureSettlingCharges(cracno, capcapital);
    //        closingbal = CalulateClosingAmount(intamt, prematureamt,
    //                                       scheduledcharges, capcapital);
    //    }
    //    return setclosingdata;
    //}


    public DataTable GetCapitalRecoveryDataFromPaymentGiven(string cracno, DateTime trdate, DateTime opDate, double actoutbal, double intrate, double customerpayment)
    {
        rc = new Recovery();
        fc = new FunctionClass();
        DataTable setclosingdata = new DataTable();
        setclosingdata = SetDataTable(setclosingdata);
        rpc = new RecoveryProcesClass();

        GetReversalData(cracno, trdate, setclosingdata, actoutbal);
        if (this.reversalamt == 0)
        {
            setclosingdata = rpc.RecoveryProcessTemp(cracno, opDate, trdate, setclosingdata);
            outbal = rpc.OutBal;
            // Check
            datedue = rpc.DateDue;
            nextdue = rpc.NextDue;
            intdatedue = rpc.IntDateDue;
        }

        intdays = GetNoDaysForInterest(intdatedue, trdate);
        scheduledcharges = fc.CalculateTotal("tramt", setclosingdata);

        if (customerpayment > scheduledcharges)
        {
            capcapital = rc.GetCapitalRecoveryAmt(customerpayment, scheduledcharges, intdatedue, intrate, cracno, trdate);
            intdays = rc.GetNoDaysForInterest(intdatedue, trdate);
            intamt = rc.GetInterestAmountFortheMonth(intdays, capcapital, intrate);
            prematureamt = rc.GetPrematureSettlingCharges(cracno, capcapital);
            closingbal = CalulateClosingAmount(intamt, prematureamt,
                                           scheduledcharges, capcapital);
        }
        return setclosingdata;
    }




    // Get Intest Days       
    public int GetNoDaysForInterest(DateTime intdatedue, DateTime trdate)
    {
        int days = 0;
        fc = new FunctionClass();
        TimeSpan t = trdate.Subtract(intdatedue);
        days = t.Days;
        return days;
    }
    //Get Interest amount
    public double GetInterestAmountFortheMonth(int daysarreas, double outbal, double intrate)
    {
        double intfordays = Math.Round((outbal * daysarreas * intrate) / (100 * 365), 2);
        return intfordays;
    }
    // Closing Balalce
    public double CalulateClosingAmount(double daysinterest, double prematsettlement, double othercharges, double caprecievable)
    {
        double closingbal = daysinterest + prematsettlement + othercharges + caprecievable;
        return (Math.Round(closingbal, 2));
    }

    //edit 12/06/2009
    public double GetPrematureSettlingCharges(string cracno, double outbal)
    {
        Recovery r = new Recovery();
        FunctionClass fc = new FunctionClass();
        DateTime grantdate;
        double preSettle = 0;

        int noOfdays = 0, noOfMonths = 0, noOfYears = 0;
        grantdate = r.getGrantdate(cracno);
        int crcat = r.getcrcat(cracno);
        DateTime today = fc.GetSystemDate("A");
        DateDifference df = new DateDifference(grantdate, today);
        noOfdays = df.Days;
        noOfMonths = df.Months;
        noOfYears = df.Years;

        //if (grantdate > DateTime.Parse("2016/04/01"))
        //{
            // Decide premature settlement - changed on 08/04/2016 according to the circular

            if (crcat == 11 || crcat == 9)
            {
                preSettle = 0.00;
            }
            else if (crcat == 19 || crcat == 16)
            {
                preSettle = outbal * 0.03;
            }
            else
            {
                if (grantdate > DateTime.Parse("2016/04/01"))
                {
                    preSettle = outbal * 0.05;
                }
                else
                {

                    if (noOfYears >= 5)
                        preSettle = 0.0;
                    else if ((noOfYears < 5) && (noOfYears >= 3))
                        preSettle = outbal * 0.005;
                    else if (noOfYears < 3)
                        preSettle = outbal * 0.01;
                }
            }
        //}
        //else
        //{
        //    if (crcat == 11 || crcat == 9 || crcat == 19 || crcat == 16)
        //    {
        //        preSettle = 0.00;
        //    }
        //    else
        //    {
        //        if (noOfYears >= 5)
        //            preSettle = 0.0;
        //        else if ((noOfYears < 5) && (noOfYears >= 3))
        //            preSettle = outbal * 0.005;
        //        else if (noOfYears < 3)
        //            preSettle = outbal * 0.01;
        //    }
        //}

        return (Math.Round(preSettle, 2));

    }

    public DataTable GetReversalData(string cracno, DateTime trdate, DataTable setclosingdata, double actoutbal)
    {
        if (actoutbal != 0)
        {
            DateTime datedue = new DateTime(); //Set Date Due for advance payments
            fc = new FunctionClass();
            DataTable dt = new DataTable();
            dt = GetAdvancePayments(cracno, trdate, "C");
            reversalamt = 0;
            for (int a = 0; a < dt.Rows.Count; a++)
            {
                double rectramount = double.Parse(dt.Rows[a]["tramt"].ToString());
                string rectaskid = dt.Rows[a]["taskid"].ToString();
                string rectransacref = dt.Rows[a]["transref"].ToString();
                double recintrate = double.Parse(dt.Rows[a]["intrate"].ToString());
                int recrecOrder = int.Parse(dt.Rows[a]["recOrder"].ToString());
                //int recdisbrefno = int.Parse(dt.Rows[a]["disbrefno"].ToString());
                DateTime rectrDate = DateTime.Parse(dt.Rows[a]["trDate"].ToString());
                string recdescription = dt.Rows[a]["trDate"].ToString();
                DateTime recduedate = DateTime.Parse(dt.Rows[a]["datedue"].ToString());
                int reccrcate = int.Parse(dt.Rows[a]["crcat"].ToString());
                string displayduedate = fc.GetDisplayDate(recduedate);

                if (rectramount != 0)
                {
                    if (dt.Rows.Count > 1)
                    {
                        switch (rectaskid)
                        {
                            case "INTR":
                                setclosingdata = InsertRow("0", cracno, -rectramount, -rectramount, displayduedate, "F", rectaskid, setclosingdata);
                                datedue = recduedate;
                                reversalamt += rectramount;
                                break;

                            case "CAPD":
                                actoutbal += rectramount;
                                datedue = recduedate;
                                break;
                        }
                    }
                    else
                    {
                        datedue = recduedate;
                        reversalamt = -1;
                    }
                }
                else
                {
                    datedue = recduedate;
                }
            }
            // To show the exxecc payments  // commented 22/09/2009 at 12.32 p.m. by bimali
            if (dt.Rows.Count > 0)
            {

                this.outbal = actoutbal;
                this.nextdue = datedue;
                this.intdatedue = datedue.AddMonths(-1);
                this.datedue = datedue;
            }
            else
            {

            }

        }
        return setclosingdata;
        //Pudate outbal to previuose state
    }


    public DataTable GetAdvanceData(string cracno, DateTime trdate, DataTable setclosingdata, double actoutbal)
    {
        double reveamt = 0;
        if (actoutbal != 0)
        {
            DateTime datedue = new DateTime(); //Set Date Due for advance payments
            fc = new FunctionClass();
            DataTable dt = new DataTable();
            dt = GetAdvancePayments(cracno, trdate, "C");

            for (int a = 0; a < dt.Rows.Count; a++)
            {
                double rectramount = double.Parse(dt.Rows[a]["tramt"].ToString());
                double recassignamt = double.Parse(dt.Rows[a]["assignamt"].ToString());
                string rectrstatus = dt.Rows[a]["trstatus"].ToString();
                string rectaskid = dt.Rows[a]["taskid"].ToString();
                string recrefno = dt.Rows[a]["refno"].ToString();
                string rectransacref = dt.Rows[a]["transref"].ToString();
                double recintrate = double.Parse(dt.Rows[a]["intrate"].ToString());
                int recrecOrder = int.Parse(dt.Rows[a]["recOrder"].ToString());
                //int recdisbrefno = int.Parse(dt.Rows[a]["disbrefno"].ToString());
                DateTime rectrDate = DateTime.Parse(dt.Rows[a]["trDate"].ToString());
                string recdescription = dt.Rows[a]["trDate"].ToString();
                DateTime recduedate = DateTime.Parse(dt.Rows[a]["datedue"].ToString());
                int reccrcate = int.Parse(dt.Rows[a]["crcat"].ToString());
                string displayduedate = fc.GetDisplayDate(recduedate);
                setclosingdata = InsertRow(recrefno, cracno, -recassignamt, -rectramount, displayduedate,
                    rectrstatus, rectaskid, setclosingdata);
                reveamt += rectramount;
            }
        }
        this.reversalamt = reveamt;
        return setclosingdata;
    }

    private DataTable InsertRow(string refno, string cracno, double assignamt, double tramt, string datedue,
    string trstatus, string taskid, DataTable dt)
    {
        DataRow dr;
        dr = dt.NewRow();
        dr["refno"] = refno;
        dr["cracno"] = cracno;
        dr["assignamt"] = assignamt;
        dr["tramt"] = tramt;
        dr["datedue"] = datedue;
        dr["trstatus"] = trstatus;
        dr["taskid"] = taskid;
        dt.Rows.Add(dr);
        return dt;
    }

    //private DataTable InsertRow(string cracno, double tramt, string datedue, string trstatus, string taskid, DataTable dt)
    //{
    //    if (taskid == "CAPD")
    //    {
    //        DataRow dr;
    //        dr = dt.NewRow();
    //        dr["cracno"] = cracno;
    //        dr["tramt"] = tramt;
    //        dr["datedue"] = datedue;
    //        dr["trstatus"] = trstatus;
    //        dr["taskid"] = taskid;
    //        dt.Rows.Add(dr);
    //    }
    //    else
    //    {
    //        if (tramt != 0)
    //        {
    //            DataRow dr;
    //            dr = dt.NewRow();
    //            dr["cracno"] = cracno;
    //            dr["tramt"] = tramt;
    //            dr["datedue"] = datedue;
    //            dr["trstatus"] = trstatus;
    //            dr["taskid"] = taskid;
    //            dt.Rows.Add(dr);
    //        }
    //    }
    //    return dt;
    //}

    public DataTable GetAdvancePayments(string cracno, DateTime today, string trstatus)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from transassign where datedue>=@today and 
                            cracno =@cracno and (trstatus!=@trstatus and trstatus!='R') and trtype = 'I'
                            and (system != 'M' or system is null and taskid != 'pnlr')
			    and transref = 'recv'
                            order by datedue desc");
        dw.SetDataAdapterParameters("today", today);
        dw.SetDataAdapterParameters("cracno", cracno);
        dw.SetDataAdapterParameters("trstatus", trstatus);
        return dw.GetDataTable();
    }

    private DataTable SetDataTable(DataTable dt)
    {
        dt = new DataTable();

        DataColumn refno;
        refno = new DataColumn();
        refno.DataType = Type.GetType("System.String");
        refno.ColumnName = "refno";
        dt.Columns.Add(refno);

        DataColumn cracno;
        cracno = new DataColumn();
        cracno.DataType = Type.GetType("System.String");
        cracno.ColumnName = "cracno";
        dt.Columns.Add(cracno);

        DataColumn TrStatus;
        TrStatus = new DataColumn();
        TrStatus.DataType = Type.GetType("System.String");
        TrStatus.ColumnName = "trstatus";
        dt.Columns.Add(TrStatus);


        DataColumn datedue;
        datedue = new DataColumn();
        datedue.DataType = Type.GetType("System.String");
        datedue.ColumnName = "datedue";
        dt.Columns.Add(datedue);


        DataColumn assignamt;
        assignamt = new DataColumn();
        assignamt.DataType = Type.GetType("System.String");
        assignamt.ColumnName = "assignamt";
        dt.Columns.Add(assignamt);

        DataColumn tramt;
        tramt = new DataColumn();
        tramt.DataType = Type.GetType("System.String");
        tramt.ColumnName = "tramt";
        dt.Columns.Add(tramt);

        DataColumn dcTaskId;
        dcTaskId = new DataColumn();
        dcTaskId.DataType = Type.GetType("System.String");
        dcTaskId.ColumnName = "TaskId";
        dt.Columns.Add(dcTaskId);

        DataColumn outbal;
        outbal = new DataColumn();
        outbal.DataType = Type.GetType("System.String");
        outbal.ColumnName = "outbal";
        dt.Columns.Add(outbal);


        return dt;
    }

    public DataTable GetnormalDetails(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select distinct cm.grantamt as GrantAmt,hp.instalment as Installment, 
                            hp.intrate as InterestRate,
                            CONVERT(VARCHAR(10), hp.DateDue, 111) as DateDue,
                            CONVERT(VARCHAR(10), cm.GrantDate, 111) as GrantDate,
                            CONVERT(VARCHAR(10), hp.LstPaiddate, 111) as  LstPaiddate,
                            CONVERT(VARCHAR(10), hp.lastcompletedduedate, 111) as lastcompletedduedate,
                            CONVERT(VARCHAR(10), hp.LstPaiddate, 111) as lstrecoverydate,
                            cast(hp.ActOutBal as decimal(20,2)) As OutstandBal ,cast(hp.OutBal as decimal(20,2)) 
                            As OutBal, hp.crperiod, hp.crcat                            
                            from crmast cm,housprop hp
                            where cm.cracno=hp.cracno
                            and cm.cracno=@cracno");
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }


    public void InsertRecords(string cracno, DateTime trdate, DateTime opdate, double actoutbal, double intrate,
        long batchno, int crcat, double tramt, string adduser, string batchrefno, int closingmode)
    {
        cdc = new ClosingDataClass();
        fc = new FunctionClass();
        string desc;
        DataTable dt = new DataTable();
        ctc = new CrTransClass();
        tr = new Trans();
        string closingreferance = "";
        if (closingmode == 1)
        {
            closingreferance = "CASH";
        }
        else
        {
            closingreferance = "BTCH";
        }
       
        GetAccountClosingData(cracno, trdate, opdate, actoutbal, intrate);
        if (tramt >= closingbal)
        {
            desc = "Account Closing";
            dt = new DataTable();
            dt = GetAccountClosingData(cracno, trdate, opdate, actoutbal, intrate);
        }
        else
        {
            desc = "Capital Recovery";
            dt = new DataTable();
            dt = GetCapitalRecoveryDataFromPaymentGiven(cracno, trdate, opdate, actoutbal, intrate, tramt);
            this.outbal = this.capcapital;
        }

        if (this.scheduledcharges > 0)
        {
            SetScheduleData(cracno, intrate, crcat, batchno, adduser, opdate, trdate, outbal, datedue, batchrefno, dt);
        }
        else
        {
            if (this.reversalamt > 0)
            {
                // Revesal
                string refglcode = tr.GetGlCode(9, 0, "INTR", "RECV", cracno, adduser);
                ctc.InsertTransAssign(refglcode, "OTHR", reversalamt, reversalamt, "N", adduser, trdate, "OTHR",
                       "E", intrate, 1, batchno, trdate, cracno + " " + " Interest" + " Excess Payment Reversal ", datedue, crcat, batchrefno);
                if (closingmode == 1)
                {
                    ctc.InsertTransAssign("903081000000994", "OTHR", reversalamt, reversalamt, "N", adduser, opdate, "OTHR", "I", intrate, 1,
                                    batchno, trdate, cracno + "| Excess Payment", trdate, crcat, batchrefno);
                }
            }
        }

        if (this.intamt > 0)
        {
            ctc.InsertTransAssign(cracno, "INTR", intamt, intamt, "N", adduser, opdate, "RECV", "I", intrate, 1, batchno, trdate, desc + " - Days Interest", datedue, crcat, batchrefno);
        }
        if (this.prematureamt > 0)
        {
            ctc.InsertTransAssign(cracno, "PSOC900000", prematureamt, prematureamt, "N", "batchuser", opdate, "RECV", "I", intrate, 1,
                batchno, trdate, desc + " - Prematuater settlement", datedue, crcat, batchrefno);
        }

        if (this.outbal > 0)
        {
            ctc.InsertTransAssign(cracno, "CAPD", this.outbal, this.outbal, "N", adduser, opdate, "RECV", "I", intrate, 1,
                batchno, trdate, desc + " - Capital", datedue, crcat, batchrefno);
        }

        double excesspayment = Math.Round((tramt - closingbal), 2);
        if (excesspayment > 0)
        {
            ctc.InsertTransAssign("903080000000000", "OTHR", excesspayment, excesspayment, "N", adduser, opdate, "OTHR", "I", intrate, 1,
                                    batchno, trdate, cracno + "| Error Entry", trdate, crcat, batchrefno);
            if (excesspayment > 1000)
            {
                ctc.InsertTransAssign("903081000000987", "OTHR", excesspayment, excesspayment, "N", adduser, opdate, "OTHR", "I", 0, 1,
                    batchno, trdate, cracno + " Excess Payment to BOC", trdate, crcat, batchrefno);
                cdc.UpdateClosingData(cracno, tramt, tramt, adduser, batchno, batchrefno, fc.GetSystemDate("A"), closingreferance, "Excess Payment to BOC");
            }
            else
            {
                tr = new Trans();
                string refglcode = tr.GetGlCode(9, 0, "INTR", "RECV", cracno, adduser);
                // cc.GetGLCode();
                ctc.InsertTransAssign(refglcode, "OTHR", excesspayment, excesspayment, "N", adduser, opdate, "OTHR", "I", 0, 1,
                    batchno, trdate, cracno + "Excess Payment to Interest Account", trdate, crcat, batchrefno);
                cdc.UpdateClosingData(cracno, tramt, tramt, adduser, batchno, batchrefno, fc.GetSystemDate("A"), closingreferance, "Excess Payment to Interest");
            }

            if (closingmode == 1)
            {
                ctc.InsertTransAssign("903081000000994", "OTHR", excesspayment, excesspayment, "N", adduser, opdate, "OTHR", "E", intrate, 1,
                                   batchno, trdate, cracno + "| Excess Payment", trdate, crcat, batchrefno);
            }
            ctc.InsertTransAssign("903080000000000", "OTHR", excesspayment, excesspayment, "N", adduser, opdate, "OTHR", "E",
                intrate, 1, batchno, trdate, cracno + "| Error Entry", trdate, crcat, batchrefno);

        }
        else
        {
            if (excesspayment == 0)
            {
                cdc.UpdateClosingData(cracno, tramt, tramt, adduser, batchno, batchrefno, fc.GetSystemDate("A"), closingreferance, "Excess Payment = 0");
            }
        }
        
    }


    public void InsertRecords(string cracno, DateTime trdate, DateTime opdate, double actoutbal, double intrate,
    long batchno, int crcat, double tramt, string adduser, string batchrefno, int closingmode, double cramt, double dramt)
    {
        string desc;
        DataTable dt = new DataTable();
        ctc = new CrTransClass();
        tr = new Trans();
        GetAccountClosingData(cracno, trdate, opdate, actoutbal, intrate);
        if (tramt >= closingbal)
        {
            desc = "Account Closing";
            dt = new DataTable();
            dt = GetAccountClosingData(cracno, trdate, opdate, actoutbal, intrate);
        }
        else
        {
            desc = "Capital Recovery";
            dt = new DataTable();
            dt = GetCapitalRecoveryDataFromPaymentGiven(cracno, trdate, opdate, actoutbal, intrate, tramt);
            this.outbal = this.capcapital;
        }

        if (this.scheduledcharges > 0)
        {
            SetScheduleData(cracno, intrate, crcat, batchno, adduser, opdate, trdate, outbal, datedue, batchrefno, dt, cramt, dramt);
            cramt = this.cramt;
            dramt = this.dramt;
        }
        else
        {
            if (this.reversalamt > 0)
            {
                // Revesal
                string refglcode = tr.GetGlCode(9, 0, "INTR", "RECV", cracno, adduser);
                dramt += reversalamt;

                if (closingmode == 1)
                {
                    cramt += reversalamt;
                }
            }
        }

        if (this.intamt > 0)
        {
            cramt += intamt;
        }
        if (this.prematureamt > 0)
        {
            cramt += prematureamt;
        }

        if (this.outbal > 0)
        {
            cramt += outbal;
        }

        double excesspayment = Math.Round((tramt - closingbal), 2);
        if (excesspayment > 0)
        {

            if (excesspayment > 1000)
            {
                cramt += excesspayment;
            }
            else
            {
                cramt += excesspayment;
            }
            if (closingmode == 1)
            {
                dramt += excesspayment;
            }
        }

        double dif = Math.Round((dramt - cramt),2);
        if ((dif == -0.01) || (dif == 0.01))
        {
            dramt = cramt;
        }

        this.cramt = cramt;
        this.dramt = dramt;
    }

    private void SetScheduleData(string cracno, double intrate, int crcat, long batchno, string adduser,
        DateTime opdate, DateTime trdate, double outbal, DateTime nextdue, string batchrefno, DataTable dt)
    {
        ClosingDataClass cdc;
        string trtype;
        rc = new Recovery();
        ctc = new CrTransClass();
        fc = new FunctionClass();
        for (int i = 0; i < dt.Rows.Count; i++)
        {

            string taskid = dt.Rows[i]["taskid"].ToString();
            double tramt = double.Parse(dt.Rows[i]["tramt"].ToString());
            // Change assignamt  to tramt
            double assignamt = double.Parse(dt.Rows[i]["assignamt"].ToString());
            string trstatus = dt.Rows[i]["trstatus"].ToString();
            string refno = dt.Rows[i]["refno"].ToString();
            DateTime datedue = fc.GetDatefromDisplayDate(dt.Rows[i]["datedue"].ToString());
            if (tramt >= 0)
            {
                if (taskid == "OTHR")
                {
                    string tcracno = dt.Rows[i]["cracno"].ToString();
                    string desc;
                    if (tcracno == "903081000000987")
                    {
                        desc = cracno + " Customer Return";
                        cdc = new ClosingDataClass();
                        cdc.UpdateClosingData(cracno, tramt, tramt, adduser, batchno, batchrefno, fc.GetSystemDate("A"), "BTCH", desc);
                    }
                    else
                    {
                        desc = cracno + " Excess Payment";
                    }
                    ctc.InsertTransAssign(tcracno, taskid, assignamt, tramt, trstatus, adduser, opdate, "OTHR", "I", intrate, 1, batchno, trdate, desc, datedue, crcat, batchrefno);
                   
                }
                else
                {
                    switch (trstatus)
                    {

                        case "N":
                            if (refno == "0")
                            {
                                ctc.InsertTransAssign(cracno, taskid, assignamt, tramt, trstatus, adduser, opdate, "RECV", "I", intrate, 1, batchno, trdate, taskid, datedue, crcat, batchrefno);
                            }
                            else
                            {
                                UpdateDisbRefNo(batchno, refno, assignamt, tramt, trstatus, batchrefno);
                            }
                            break;

                        case "P":
                            if (refno == "0")
                            {
                                refno = ctc.InsertTransAssign(cracno, taskid, assignamt, tramt, trstatus, adduser, opdate, "RECV", "I", intrate, 1, batchno, trdate, taskid, datedue, crcat, batchrefno);
                                ctc.InsertTransAssignTemp(refno, cracno, tramt, batchno, trdate, assignamt, "I", datedue, taskid, "P", adduser, "RECV", intrate, crcat, batchrefno);
                            }
                            else
                            {
                                UpdateDisbRefNo(batchno, refno, assignamt, tramt, trstatus, batchrefno);
                                ctc.InsertTransAssignTemp(refno, cracno, tramt, batchno, trdate, assignamt, "I", datedue, taskid, "P", adduser, "RECV", intrate, crcat, batchrefno);
                            }
                            break;
                    }
                }
            }
        }
        DateTime recoveryProcessDate = fc.SetRecoveryProcessDate(trdate, cracno);
        rc.UpdatePenalValidDate(cracno, recoveryProcessDate);
        ctc.UpdateDueDateandOutBal(cracno, nextdue, outbal);
    }


    private void SetScheduleData(string cracno, double intrate, int crcat, long batchno, string adduser,
       DateTime opdate, DateTime trdate, double outbal, DateTime nextdue, string batchrefno, DataTable dt, double cramt, double dramt)
    {
        this.dramt = 0;
        this.cramt = 0;
        string trtype;
        ctc = new CrTransClass();
        fc = new FunctionClass();
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            string taskid = dt.Rows[i]["taskid"].ToString();
            double tramt = double.Parse(dt.Rows[i]["tramt"].ToString());
            // Change assignamt  to tramt
            double assignamt = double.Parse(dt.Rows[i]["assignamt"].ToString());
            string trstatus = dt.Rows[i]["trstatus"].ToString();
            string refno = dt.Rows[i]["refno"].ToString();
            DateTime datedue = fc.GetDatefromDisplayDate(dt.Rows[i]["datedue"].ToString());
            if (tramt >= 0)
            {
                cramt += tramt;
            }
        }
        this.cramt = cramt;
        this.dramt = dramt;
    }



    private int UpdateDisbRefNo(long disbrefno, string refno, double assignamt, double tramt, string trstatus, string batchrefno)
    {
        double paidamount = GetPaidAmount(refno);
        if (paidamount + tramt <= assignamt)
        {
            tramt = Math.Round((paidamount + tramt), 2);
        }
        else
        {
            tramt = assignamt;
        }
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update transassign set disbrefno=@disbrefno, tramt=@tramt, trstatus=@trstatus, batchrefno=@batchrefno where refno=@refno");
        dw.SetSqlCommandParameters("disbrefno", disbrefno);
        dw.SetSqlCommandParameters("refno", refno);
        dw.SetSqlCommandParameters("tramt", tramt);
        dw.SetSqlCommandParameters("trstatus", trstatus);
        dw.SetSqlCommandParameters("batchrefno", batchrefno);
        return dw.Update();
    }


    private int UpdateDisbRefNo(long disbrefno, string refno, double assignamt, double tramt)
    {
        double paidamount = GetPaidAmount(refno);
        if (paidamount + tramt <= assignamt)
        {
            tramt = Math.Round((paidamount + tramt), 2);
        }
        else
        {
            tramt = assignamt;
        }
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update transassign set disbrefno=@disbrefno, tramt=@tramt where refno=@refno");
        dw.SetSqlCommandParameters("disbrefno", disbrefno);
        dw.SetSqlCommandParameters("refno", refno);
        dw.SetSqlCommandParameters("tramt", tramt);
        return dw.Update();
    }
    private double GetPaidAmount(string refno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select isnull(tramt, 0) from transassign where refno=@refno");
        dw.SetSqlCommandParameters("refno", refno);
        return double.Parse(dw.GetSingleData());
    }

    public string ClosingInsert(string cracno, DateTime trdate, DateTime opdate, string closingmode, double intrate, int crcat,
        double reverseamount, double prematureAmt, double Interestamt, double excessCapAmt, double actoutbal, string user, double customerpayment, string cldesc)
    {
        ls = new LastSerialClass();
        tr = new Trans();
        fc = new FunctionClass();
        ctc = new CrTransClass();
        rc = new Recovery();
        int datekey = fc.GetDateKeyinDate(opdate);
        long batchno = 0;

        if (closingmode != "0")
        {
            switch (closingmode)
            {
                case "1":
                    batchno = ls.GetMaxNumber("DisbRefNo", true);
                    rc.UpdateRecStatus(cracno, batchno, cldesc, customerpayment);
                    ls.UpdateLastserial("DisbRefNo", batchno + 1);
                    msg = "Selected closing method is Cashier Payment | " + cracno + " - Account will be Closed when completion of counter payment | Rs. " + customerpayment + " is assigned";
                    break;
                case "2":
                    batchno = long.Parse(datekey.ToString() + closingmode);
                    rc.UpdateRecStatus(cracno, batchno, cldesc, customerpayment);
                    msg = "Selected closing method is Branch Advise | " + cracno + " - Account will be Closed when the " + batchno + "is processing Rs. " + customerpayment + " is assigned";
                    break;
                case "3":
                    batchno = long.Parse(datekey.ToString() + closingmode);
                    rc.UpdateRecStatus(cracno, batchno, cldesc, customerpayment);
                    msg = "Selected closing method is Cheque | " + cracno + " - Account will be Closed when the " + batchno + "is processing Rs. " + customerpayment + " is assigned";
                    break;

                case "4":
                    batchno = long.Parse(datekey.ToString() + "1000");
                    rc.UpdateRecStatus(cracno, batchno, cldesc, customerpayment);
                    msg = "Selected closing method is Reversal | " + cracno + " - Account will be Closed when the " + batchno + "is processing Rs. " + customerpayment + " is assigned";
                    break;
            }


            // Need to Complete - Urgent
            //if (closingmode == "1")
            //{
            //    rpc = new RecoveryProcesClass();
            //    if (reverseamount > 0)
            //    {
            //        ctc.InsertTransAssign("903080000000000", "OTHR", reverseamount, reverseamount, "N", user, trdate, "OTHR",
            //                "E", intrate, 1, batchno, trdate, cracno + " " + "OTHR" + " Excess Payment Reversal ", trdate, crcat);

            //        string refglcode = tr.GetGlCode(9, 0, "INTR", "RECV", cracno, user);
            //        ctc.InsertTransAssign(refglcode, "OTHR", reverseamount, reverseamount, "N", user, trdate, "OTHR",
            //               "E", intrate, 1, batchno, trdate, cracno + " " + "RECV" + " Excess Payment Reversal ", trdate, crcat);
            //        //Only for cash recovery
            //        ctc.InsertTransAssign("903081000000994", "OTHR", reverseamount, reverseamount, "N", user, trdate, "OTHR",
            //               "I", intrate, 1, batchno, trdate, cracno + " " + "OTHR" + " Excess Payment Reversal ", trdate, crcat);

            //        ctc.InsertTransAssign("903080000000000", "OTHR", reverseamount, reverseamount, "N", user, trdate, "OTHR",
            //           "I", intrate, 1, batchno, trdate, cracno + " " + "OTHR" + " Excess Payment Reversal ", trdate, crcat);

            //    }
            //    else
            //    {
            //        rpc.RecoveryProcess(user, batchno, cracno, opdate, trdate);
            //    }


            //    if (excessCapAmt >= 0)
            //    {

            //        if (Interestamt > 0)
            //        {
            //            ctc.InsertTransAssign(cracno, "INTR", Interestamt, Interestamt, "N", user, opdate, "RECV", "I", intrate, 1, batchno, trdate, "Account Closing - Interest", trdate, crcat);
            //        }
            //        else
            //        {
            //            ctc.InsertTransAssign(cracno, "INTR", Interestamt * -1, Interestamt * -1, "N", user, opdate, "RECV", "E", intrate, 1, batchno, trdate, "Account Closing - Interest reverse", trdate, crcat);
            //            //string refglcode = tr.GetGlCode(9, 0, "INTR", "RECV", cracno, user);
            //            //ctc.InsertTransAssign(refglcode, "INTR", Interestamt, Interestamt, "N", user, date, "RECV", "E", intrate, 1, batchno, trdate, cracno + " Interest Reversal", date, crcat);
            //        }
            //        if (prematureAmt != 0)
            //        {
            //            ctc.InsertTransAssign(cracno, "PSOC900000", prematureAmt, prematureAmt, "N", user, opdate, "RECV", "I", intrate, 1, batchno, trdate, "Account Closing - Prematuater settlement", trdate, crcat);
            //        }

            //        if (actoutbal != 0)
            //        {
            //            ctc.InsertTransAssign(cracno, "CAPD", actoutbal, actoutbal, "N", user, opdate, "RECV", "I", intrate, 1, batchno, trdate, "Account Closing - Capital ", trdate, crcat);
            //        }


            //        if (excessCapAmt < 1000 && excessCapAmt > 0)
            //        {
            //            ctc.InsertTransAssign(cracno, "INTR", excessCapAmt, excessCapAmt, "N", user, opdate, "RECV", "I", intrate, 1, batchno, trdate, "Account Closing - Exess interest", trdate, crcat);
            //        }
            //        else
            //        {
            //            if (excessCapAmt > 0 && excessCapAmt < 1000)
            //            {
            //                ctc.InsertTransAssign(cracno, "INTR", excessCapAmt, excessCapAmt, "N", user, opdate, "RECV", "I", intrate, 1, batchno, trdate, "Capital Recovery - Excess payment ", trdate, 0);
            //            }
            //            else
            //            {
            //                ctc.InsertTransAssign("903080000000000", "OTHR", excessCapAmt, excessCapAmt, "N", user, opdate, "OTHR", "I", 0, 1, batchno, trdate, cracno + " | Account is closed", trdate, 0);
            //                ctc.InsertTransAssign("903081000000994", "OTHR", excessCapAmt, excessCapAmt, "N", user, opdate, "OTHR", "E", 0, 1, batchno, trdate, cracno + " | Customer Return", trdate, 0);
            //                ctc.InsertTransAssign("903080000000000", "OTHR", excessCapAmt, excessCapAmt, "N", user, opdate, "OTHR", "E", 0, 1, batchno, trdate, cracno + " | Account is closed", trdate, 0);
            //                ctc.InsertTransAssign("903081000000987", "OTHR", excessCapAmt, excessCapAmt, "N", user, opdate, "OTHR", "I", 0, 1, batchno, trdate, cracno + " | Account is closed", trdate, 0);
            //            }
            //        }
            //        msg = "Payments are added to the system succesfully ";
            //    }
            //    else
            //    {
            //        msg = "Please Enter Correct Amount to Close the Account ";
            //    }
            //}

        }
        else
        {
            msg = "Please Select the Closing Mode";
        }
        return msg;
    }






    //public void SetAccountClosingData(string cracno, DateTime trdate, DateTime opDate, double actoutbal,
    //    double intrate, string user, long disbrefno, int crcat, string paymentmode, string recstatus)
    //{
    //    fc = new FunctionClass();
    //    DataTable setclosingdata = new DataTable();
    //    setclosingdata = SetDataTable(setclosingdata);
    //    rpc = new RecoveryProcesClass();
    //    rpc.SetArreasAmounts(cracno, trdate, user, disbrefno, actoutbal);
    //    this = rpc.ExessPayment;
    //    if (execesspayment > 0)
    //    {
    //        outbal = rpc.OutBal;
    //        datedue = rpc.DateDue;
    //        intdays = GetNoDaysForInterest(datedue.AddMonths(-1), trdate);
    //    }
    //    else
    //    {
    //        setclosingdata = rpc.RecoveryProcessTemp(cracno, opDate, trdate, setclosingdata);
    //        outbal = rpc.OutBal;
    //        datedue = rpc.DateDue;
    //        intdays = GetNoDaysForInterest(datedue, trdate);
    //    }

    //    intamt = GetInterestAmountFortheMonth(intdays, outbal, intrate);
    //    scheduledcharges = fc.CalculateTotal("tramt", setclosingdata);
    //    prematureamt = GetPrematureSettlingCharges(cracno, actoutbal);

    //    if (execesspayment > 0)
    //    {
    //        closingbal = CalulateClosingAmount(intamt, prematureamt,
    //                            scheduledcharges, actoutbal);
    //    }
    //    else
    //    {
    //        closingbal = CalulateClosingAmount(intamt, prematureamt,
    //                            scheduledcharges, outbal);
    //    }
    //    InsertClosingData(cracno, intamt, prematureamt, execesspayment, intrate, crcat, datedue, trdate, opDate, paymentmode, user, disbrefno, recstatus);
    //}

    //public void InsertClosingData(string cracno, double intamt, double prematureamt, double execesspayment,
    //    double intrate, int crcat, DateTime datedue, DateTime trdate, DateTime opDate, string PaymentMode, string user, long disbrefno, string recstatus)
    //{
    //    rpc = new RecoveryProcesClass();
    //    tr = new Trans();
    //    ctc = new CrTransClass();
    //    string desc = "";
    //    switch (recstatus)
    //    {
    //        case "AC":
    //            desc = "Account Closing";
    //            break;
    //        case "CR":
    //            desc = "Capital Recovery";
    //            break;
    //    }

    //    // PreMature
    //    if (prematureamt > 0)
    //    {
    //        ctc.InsertTransAssign(cracno, "PSOC900000", prematureamt, prematureamt, "N", user, opDate, "RECV", "I", intrate, 1,
    //            disbrefno, trdate, desc + " - Prematuater settlement", datedue, crcat);
    //    }
    //    //interest amount for days
    //    if (intamt>0)
    //    {
    //        ctc.InsertTransAssign(cracno, "INTR", intamt, intamt, "N", user, opDate, "RECV", "I", intrate, 1,
    //            disbrefno, trdate, desc + " - Days Interest", datedue, crcat);
    //    }


    //    if (execesspayment <= 0)
    //    {
    //        rpc.RecoveryProcess(user, disbrefno, cracno, opDate, trdate);
    //    }
    //    else
    //    {
    //        string refglcode = "";
    //        switch (PaymentMode)
    //        {
    //            case "CAP":
    //                ctc.InsertTransAssign("903080000000000", "OTHR", execesspayment, execesspayment, "N", user, trdate, "OTHR",
    //               "E", intrate, 1, disbrefno, trdate, desc + " " + cracno + " " + "OTHR" + " Error Record ", datedue, crcat);

    //                refglcode = tr.GetGlCode(9, 0, "INTR", "RECV", cracno, user);
    //                ctc.InsertTransAssign(refglcode, "OTHR", execesspayment, execesspayment, "N", user, trdate, "OTHR",
    //                       "E", intrate, 1, disbrefno, trdate, cracno + " " + "RECV" + " Excess Payment Reversal ", datedue, crcat);
    //                //Only for cash recovery
    //                ctc.InsertTransAssign("903081000000994", "OTHR", execesspayment, execesspayment, "N", user, trdate, "OTHR",
    //                       "I", intrate, 1, disbrefno, trdate, desc + " " + cracno + " " + "OTHR" + " Excess Payment Reversal ", datedue, crcat);

    //                ctc.InsertTransAssign("903080000000000", "OTHR", execesspayment, execesspayment, "N", user, trdate, "OTHR",
    //                                "I", intrate, 1, disbrefno, trdate, desc + " " + cracno + " " + "OTHR" + " Error Record ", datedue, crcat);

    //                break;

    //            case "CHQ":
    //                refglcode = tr.GetGlCode(9, 0, "INTR", "RECV", cracno, user);
    //                ctc.InsertTransAssign(refglcode, "OTHR", execesspayment, execesspayment, "N", user, trdate, "OTHR",
    //                       "E", intrate, 1, disbrefno, trdate, desc + " " + cracno + " " + "RECV" + " Excess Payment Reversal ", datedue, crcat);
    //                break;

    //            case "BAV":
    //                refglcode = tr.GetGlCode(9, 0, "INTR", "RECV", cracno, user);
    //                ctc.InsertTransAssign(refglcode, "OTHR", execesspayment, execesspayment, "N", user, trdate, "OTHR",
    //                       "E", intrate, 1, disbrefno, trdate, desc + " " + cracno + " " + "RECV" + " Excess Payment Reversal ", datedue, crcat);
    //                break;
    //        }

    //    }


    //}

    public double GetAssignAmount(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select CapAssign from housprop where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return double.Parse(dw.GetSingleData());
    }

    public double InsertHousrpoHistry(string CrAcNo, DateTime ChangeDate, double IntRate, double Instalment, double OutBal, DateTime DateDue,
        int GracePeriod, DateTime LstPaiddate, string AddUser, DateTime Adddate, DateTime LastCompletedDueDate, string IsDisbursed, int CrPeriod,
        int LoanStatusCode, int PaidInstalments, double ActOutBal, DateTime penalvaliddate, string recstatus, long disbrefno, string ChangeUser)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO HouspropHistry (CrAcNo,ChangeDate,IntRate,Instalment,OutBal,DateDue,GracePeriod,LstPaiddate
			            ,AddUser,Adddate,LastCompletedDueDate,IsDisbursed,CrPeriod,LoanStatusCode,PaidInstalments
		                ,ActOutBal,penalvaliddate,recstatus,disbrefno,ChangeUser)
                        VALUES (@CrAcNo,@ChangeDate,@IntRate,@Instalment,@OutBal,@DateDue,@GracePeriod,@LstPaiddate
                       ,@AddUser,@Adddate,@LastCompletedDueDate,@IsDisbursed,@CrPeriod,@LoanStatusCode,@PaidInstalments
		               ,@ActOutBal,@penalvaliddate,@recstatus,@disbrefno,@ChangeUser)");
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        dw.SetSqlCommandParameters("ChangeDate", ChangeDate);
        dw.SetSqlCommandParameters("IntRate", IntRate);
        dw.SetSqlCommandParameters("Instalment", Instalment);
        dw.SetSqlCommandParameters("OutBal", OutBal);
        dw.SetSqlCommandParameters("DateDue", DateDue);
        dw.SetSqlCommandParameters("GracePeriod", GracePeriod);
        dw.SetSqlCommandParameters("LstPaiddate", LstPaiddate);
        dw.SetSqlCommandParameters("AddUser", AddUser);
        dw.SetSqlCommandParameters("Adddate", Adddate);
        dw.SetSqlCommandParameters("LastCompletedDueDate", LastCompletedDueDate);
        dw.SetSqlCommandParameters("IsDisbursed", IsDisbursed);
        dw.SetSqlCommandParameters("LoanStatusCode", LoanStatusCode);
        dw.SetSqlCommandParameters("PaidInstalments", PaidInstalments);
        dw.SetSqlCommandParameters("ActOutBal", ActOutBal);
        dw.SetSqlCommandParameters("penalvaliddate", penalvaliddate);
        dw.SetSqlCommandParameters("recstatus", recstatus);
        dw.SetSqlCommandParameters("disbrefno", disbrefno);
        dw.SetSqlCommandParameters("ChangeUser", ChangeUser);
        return double.Parse(dw.GetSingleData());
    }

    public DataTable GetAssignData(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select disbrefno as BatchNo, capassign as [Payment Assigned], recstatus as [Type of Assignment] from housprop 
                        where cracno = @cracno and recstatus != 'nr'");
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }

    public int CancellAssignment(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update housprop set capassign=0, recstatus='NR', disbrefno=NULL where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return dw.Update();
    }

    public int InsertSavingsAC(string cracno, string savingsAc)
    {
        int Rowadded = 0;
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into LoanSavingDetails values(@cracno,@savingsAc)");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("savingsAc", savingsAc);
        Rowadded = dw.Insert();
        return Rowadded;
    }

    public string SavingsAc(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select SavingAcNo from LoanSavingDetails where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return (dw.GetSingleData());
    }

    public string Gettopupapp(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select AppNo from CreditAdmin.TopUpLoans where CrAcNo=@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return (dw.GetSingleData());
    }

    public string getLegalactionData(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select Action1 from CreditAdmin.LegalActionData where CrAcNo=@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return (dw.GetSingleData());
    }
}