﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
/// <summary>
/// Summary description for CancelTransaction
/// </summary>
public class CancelTransaction
{
    DataWorksClass dw, dw1, dw2;
    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();
    string msg;
    DataTable dt;
	public CancelTransaction()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public string Msg
    {
        get
        {
            return this.msg;
        }
    }



    public DataTable GetTrasanction(string transno, string trstatus1, string trstatus2)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select gltransno as Referance, glcode as [G/L Account] , 
                            RefGlCode as [Referance G/L Accont], trdate as [Date], 
                            tramt as Amount from gltrans where transno = @transno and 
                            (trstatus=@trstatus1 or trstatus=@trstatus2)");
        dw.SetDataAdapterParameters(@"transno", transno);
        dw.SetDataAdapterParameters(@"trstatus1", trstatus1);
        dw.SetDataAdapterParameters(@"trstatus2", trstatus2);
        return dw.GetDataTable();
    }


    public DataTable GetTrasanction(string transno, string trstatus)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select gltransno as Referance, glcode as [G/L Account] , 
                            RefGlCode as [Referance G/L Accont], trdate as [Date], 
                            tramt as Amount from gltrans where gltransno = @transno and 
                            (trstatus=@trstatus)");
        dw.SetDataAdapterParameters(@"transno", transno);
        dw.SetDataAdapterParameters(@"trstatus", trstatus);
        return dw.GetDataTable();
    }



    public DataTable GetGLTrans(string transno, string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select t.RefGlCode, AcSign, sum(t.tramt) as tramt from 
                            (select RefGlCode, AcSign, case AcSign 
                            when 'CR' 
                            then sum(tramt*-1)
                            else sum(tramt) end as tramt 
                            from gltrans as g where transno = @transno and trstatus != 'C'
                            and cracno = @cracno
                            group by RefGlCode, AcSign)  as t group by refglcode, AcSign");
        dw.SetDataAdapterParameters(@"transno", transno);
        dw.SetDataAdapterParameters(@"cracno", cracno);
        return dw.GetDataTable();
    }

    public DataTable GetGLTrans(string transno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select t.RefGlCode, sum(t.tramt) as tramt from 
                            (select RefGlCode, AcSign, case AcSign 
                            when 'CR' 
                            then sum(tramt*-1)
                            else sum(tramt) end as tramt 
                            from gltrans as g where transno = @transno and trstatus != 'C'
                            group by RefGlCode, AcSign)  as t group by refglcode");
        dw.SetDataAdapterParameters(@"transno", transno);
        return dw.GetDataTable();
    }

    public double GetTrAmt(string transno, string taskid, string cracno)
    {
        DataWorksClass dw3 = new DataWorksClass(constring);
        dw3.SetCommand(@"select t.cracno, sum(g.tramt) as tramt
                            from transassign t, gltrans g
                            where g.transno = 30056
                            and t.refno = g.transassignrefno
                            and t.taskid='capd' and t.cracno = 603080384227
                            and t.trstatus != 'C'
                            group by t.cracno");
        dw3.SetSqlCommandParameters(@"transno", transno);
        dw3.SetSqlCommandParameters(@"taskid", taskid);
        dw3.SetSqlCommandParameters(@"cracno", cracno);
        return double.Parse(dw3.GetSingleData());
    }

    public double GetAssignAmt(string transno, string taskid, string cracno)
    {
        DataWorksClass dw3 = new DataWorksClass(constring);
        dw3.SetCommand(@"select sum(distinct t.assignamt) as Assignamt 
                        from transassign t, gltrans g
                        where g.transno = @transno
                        and t.refno = g.transassignrefno
                        and t.taskid=@taskid and t.cracno = @cracno
                        and t.trstatus != 'C'  and t.system is null");
        dw3.SetSqlCommandParameters(@"transno", transno);
        dw3.SetSqlCommandParameters(@"taskid", taskid);
        dw3.SetSqlCommandParameters(@"cracno", cracno);
        return double.Parse(dw3.GetSingleData());
    }

    public DataTable GetCapitalTransactions(string transno, string taskid)
    {
        DataWorksClass dw3 = new DataWorksClass(constring);
        dw3.SetDataAdapter(@"select cracno, sum(tramt) as tramt, sum(Assignamt) as Assignamt from transassign 
                                where transno = @transno
                                and taskid=@taskid
                                group by cracno");
        dw3.SetDataAdapterParameters(@"transno", transno);
        dw3.SetDataAdapterParameters(@"taskid", taskid);
        return dw3.GetDataTable();
    }

    private DateTime GetLastDateDue(string transno, string cracno)
    {
        dw1 = new DataWorksClass(constring);
        dw1.SetCommand(@"select min(Datedue) from transassign 
                        where transno = @transno and cracno = @cracno ");
        dw1.SetSqlCommandParameters("transno", transno);
        dw1.SetSqlCommandParameters("cracno", cracno);
        return DateTime.Parse(dw1.GetSingleData());
    }

    private double GetActOutBal(string cracno)
    {
        dw1 = new DataWorksClass(constring);
        dw1.SetCommand(@"select actoutbal from housprop 
                        where cracno = @cracno");
        dw1.SetSqlCommandParameters("cracno", cracno);
        return double.Parse(dw1.GetSingleData());
    }

   

    private double GetOutBal(string cracno)
    {
        dw1 = new DataWorksClass(constring);
        dw1.SetCommand(@"select outbal from housprop 
                        where cracno = @cracno");
        dw1.SetSqlCommandParameters("cracno", cracno);
        return double.Parse(dw1.GetSingleData());
    }

    public int CancelTransactions(string transno, DataTable dt, string cracno, DateTime trdate, string truser)
    {
        if (cracno == "603080118955")
        {

        }

        if (cracno == "603080264275")
        {

        }
        double totamt = CancelTrans(transno, cracno, trdate,truser,dt);
        if (totamt != 0)
        {
            SetTrans(totamt, cracno, transno);
            return SetOutBal(cracno, transno);
        }
        else
            return 0;

    }

    private double CancelTrans(string transno, DataTable dt)
    {
        double totamt = 0;
        dw = new DataWorksClass(constring);
        dw.SetCommand();

        // CrTransJrnl
        dw.SetSqlCommandParameters("trstatusCT", "C");
        dw.SetSqlCommandParameters("transNoCT", transno);

        //Trans
        dw.SetSqlCommandParameters("trstatusT", "C");
        dw.SetSqlCommandParameters("transNoT", transno);

        //TransAssign
        dw.SetSqlCommandParameters("trstatusTA", "C");
        dw.SetSqlCommandParameters("transNoTA", transno);

        //GlTrans
        dw.SetSqlCommandParameters("trstatusGT", "C");
        dw.SetSqlCommandParameters("transNoGT", transno);

        //DataTable dt1 = new DataTable();
        //dt1 = GetCapitalTransactions(transno, "CAPD");

        string[] commandarray = new string[5 + dt.Rows.Count];

        commandarray[0] = @"update crtransjrnl set trstatus=@trstatusCT where transNo=@transNoCT";
        commandarray[1] = @"update trans set trstatus=@trstatusT where transNo=@transNoT";
        commandarray[2] = @"update transassign set trstatus=@trstatusTA where transNo=@transNoTA";
        commandarray[3] = @"update gltrans set trstatus=@trstatusGT where transNo=@transNoGT";

        for (int i = 0; i < dt.Rows.Count; i++)
        {
            // parameters
            string refglcode = dt.Rows[i]["refglcode"].ToString();
            double tramt = double.Parse(dt.Rows[i]["tramt"].ToString());
            
            double curbal = 0;
            curbal = GetCurrentBalance(refglcode);
            //if (tramt >= 0)
            //{
            curbal += tramt;
            //}
            //else
            //{
            //    curbal += tramt;
            //}
            dw.SetSqlCommandParameters("refglcode" + i, refglcode);
            dw.SetSqlCommandParameters("CurBal" + i, curbal);
            commandarray[i + 4] = "update glcode set curbal = @curbal" + i + " where refglcode=@refglcode" + i;
            totamt += tramt;
        }
        int rows = dw.Trans(commandarray);
        if (rows != 0)
        {
            return totamt;
        }
        else
        {
            return 0;
        }


    }


    private void SetTrans(double totamt, string cracno, string transno)
    {
        totamt = Math.Round(totamt, 2);
        DataTable dt = new DataTable();
        dt = GetTransactions(cracno, transno);
        for (int i = 0; dt.Rows.Count > i; i++)
        {
            string refno = dt.Rows[i]["refno"].ToString();
            double tramt = double.Parse(dt.Rows[i]["tramt"].ToString());
            if (totamt < tramt)
            {
                if (totamt - tramt < 0)
                {
                    tramt -= GetMaxTramt(refno);
                    UpdateTransAssgn(refno, tramt, "P");
                    DeleteOtherRef(cracno, refno);
                }
                else
                {
                    UpdateTransAssgn(refno, totamt, "P");
                    DeleteOtherRef(cracno, refno);
                }
            }

            string system = dt.Rows[i]["system"].ToString();
            if (system == "T")
            {
                double tempamt = GetTransAssignTmp(refno);
                UpdateTransAssgn(refno, tempamt, "P");
                DeleteRef(cracno, refno);
            }
           
            totamt -= tramt;
            totamt = Math.Round(totamt, 2);
        }
        UpdateNotPayedCapital(cracno, transno);
    }

    private double GetTransAssignTmp(string refno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select (assignamt - tramt) as tramt from  transassigntmp where refno = @refno ");
        dw.SetSqlCommandParameters("refno", refno);
        return double.Parse(dw.GetSingleData());
    }

    private int UpdateNotPayedCapital(string cracno, string transno)
    {
        string refno = GetMaxRefNo(cracno, transno);
        if (refno != "0")
        {
            return UpdateTransAssgn(refno, 0, "N");
        }
        else
        {
            return 0;
        }
    }

    private string GetMaxRefNo(string cracno, string transno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select min(refno) from  transassign where transno = @transno and cranco = @cranco
                        and taskid = 'CAPD' and tramt =0");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("transno", transno);
        return dw.GetSingleData();
    }

    private int DeleteOtherRef(string cracno, string refno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"delete from  transassigntmp where refno != @refno and cracno =@cracno ");
        dw.SetSqlCommandParameters("refno", refno);
        dw.SetSqlCommandParameters("cracno", cracno);
        return dw.Delete();
    }

    private int DeleteRef(string cracno, string refno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"delete from  transassigntmp where refno = @refno and cracno =@cracno ");
        dw.SetSqlCommandParameters("refno", refno);
        dw.SetSqlCommandParameters("cracno", cracno);
        return dw.Delete();
    }


    private double GetMaxTramt(string refno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select max(tramt) from  transassigntmp where refno = @refno");
        dw.SetSqlCommandParameters("refno", refno);
        return double.Parse(dw.GetSingleData());
    }

    public DataTable GetPreTransactions(string cracno, DateTime trdate)
    {
        DataWorksClass dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select transno from gltrans where cracno=@cracno and trdate>@trdate
                             and trstatus!= 'C' ");
        dw.SetDataAdapterParameters("cracno", cracno);
        dw.SetDataAdapterParameters("trdate", trdate);
        return dw.GetDataTable();
    
    }

    private DataTable GetTransactions(string cracno, string transno)
    {
        DataWorksClass dww = new DataWorksClass(constring);
        dww.SetDataAdapter(@"select * from transassign where cracno = @cracno and 
                            transno = @transno order by datedue desc, taskid desc");
        dww.SetDataAdapterParameters("cracno", cracno);
        dww.SetDataAdapterParameters("transno", transno);
        return  dww.GetDataTable();
    }

    private int SetOutBal(string cracno, string transno)
    {

        //2009-08-27 vihanga
        //Get current housprop status
        DataTable data = new DataTable();
        data = GetExtData(cracno);
        double exOutbal = 0;
        double exActoutbal = 0;
        exOutbal = double.Parse(data.Rows[0]["outbal"].ToString());
        exActoutbal = double.Parse(data.Rows[0]["actoutbal"].ToString());

        //Get cancel housprop details
        data = new DataTable();
        data = this.GetExtTransCapital(transno, cracno);
        try
        {
            double canOutbal = double.Parse(data.Rows[0]["assignamt"].ToString());
            double canActOutbal = double.Parse(data.Rows[0]["tramt"].ToString());

            //update housprop
            exOutbal = exOutbal + canOutbal;
            exActoutbal = exActoutbal + canActOutbal;
            DateTime datedue = GetLastDateDue(transno, cracno);

            dw.SetCommand(@"update housprop set outbal=@outbal, actoutbal=@actoutbal, lastcompletedduedate=@lastcompletedduedate , 
                        datedue=@datedue, penalvaliddate=@penalvaliddate where cracno = @cracno");

            dw.SetSqlCommandParameters("outbal", exOutbal);
            dw.SetSqlCommandParameters("actoutbal", exActoutbal);
            dw.SetSqlCommandParameters("datedue", datedue);
            dw.SetSqlCommandParameters("lastcompletedduedate", datedue.AddMonths(-1));
            dw.SetSqlCommandParameters("penalvaliddate", datedue.AddMonths(-1));
            dw.SetSqlCommandParameters("cracno", cracno);
            return dw.Insert();
        }
        catch(Exception er)
        {    
            return 1;
        }

    }

    //vihanga 2009-08-27
    private DataTable GetExtTransCapital(string transno,string cracno)
    {
        DataWorksClass dw20 = new DataWorksClass(constring);
        dw20.SetDataAdapter(@"select sum(assignamt) as assignamt,sum(tramt) as tramt 
                             from transassign where cracno = @cracno and transno= @transno 
                             and trstatus='C' and taskid='CAPD' and system is null");
        dw20.SetDataAdapterParameters("cracno", cracno);
        dw20.SetDataAdapterParameters("transno", transno);
        return dw20.GetDataTable();
    }

    //vihanga 2009-08-27
    private DataTable GetExtData(string cracno)
    {
        DataWorksClass dw20 = new DataWorksClass(constring);
        dw20.SetDataAdapter(@"select outbal , actoutbal from housprop where cracno = @cracno");
        dw20.SetDataAdapterParameters("cracno", cracno);
        return dw20.GetDataTable();
    }

//    private DataTable GetTransaAssign(string transno)
//    {
//       // (31072009)
//     DataWorksClass dw4 = new DataWorksClass(constring);
////        dw4.SetDataAdapter(@"select cracno, tramt as tramt, sum(Assignamt) as Assignamt from transassign 
////                                where transno = @transno
////                                and taskid=@taskid 
////                                group by cracno");
////        dw4.SetDataAdapterParameters(@"transno", transno);
//       return dw4.GetDataTable();
//    }


    //public int CancelTransAll(string transno, string cracno, DateTime trdate, string truser)
    //{
    //    DataTable dt1 = new DataTable();
    //    DataTable dt2 = new DataTable();
    //    dt1 = GetTransNo(cracno, transno);
    //    for(int x=0;dt1.Rows.Count>x;x++)
    //    {
    //        string pretransno = dt1.Rows[x]["transno"].ToString();
    //        dt2 = GetGLTrans(pretransno, cracno);
    //        CancelTransPre(pretransno, cracno, trdate, truser, dt2);
    //    }
    //    dt2 = GetGLTrans(transno, cracno);
    //    return CancelTrans(transno, cracno, trdate, truser, dt2);
    //}

    private DataTable  GetTransNo(string cracno,string transno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select distinct transno from gltrans where transno>@transno and cracno=@cracno");
        dw.SetDataAdapterParameters("cracno", cracno);
        dw.SetDataAdapterParameters("transno", transno);
        return dw.GetDataTable();

    }

    private int CancelTransPre(string transno, string cracno, DateTime trdate, string truser, DataTable dt)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand();

        //GlTrans
        dw.SetSqlCommandParameters("trstatusGT", "C");
        dw.SetSqlCommandParameters("transNoGT", transno);

        //CrTransJrnl
        dw.SetSqlCommandParameters("TransNo", transno);
        dw.SetSqlCommandParameters("TrDate", trdate);
        dw.SetSqlCommandParameters("TrStatus", "R");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("ErrorAccount", "903080000000000");
        dw.SetSqlCommandParameters("truser", truser);
        dw.SetSqlCommandParameters("Time", DateTime.Now.ToShortTimeString());


        //27/08/2009
        DataTable dt1 = new DataTable();
        //dt1 = GetCapitalTransactions(transno, "CAPD", cracno);

        string[] commandarray = new string[2 + (dt.Rows.Count) * 2];

        commandarray[0] = @"update gltrans set trstatus=@trstatusGT where transNo=@transNoGT and cracno=@cracno";
        double errorcurbal = GetCurrentBalance("903080000000000");
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            // parameters
            string refglcode = dt.Rows[i]["refglcode"].ToString();
            double tramt = double.Parse(dt.Rows[i]["tramt"].ToString());
            string acsign = dt.Rows[i]["acsign"].ToString();
            double curbal = 0;
            curbal = GetCurrentBalance(refglcode);
            //if (tramt >= 0)
            //{
            curbal += tramt;
            errorcurbal -= tramt;
            //}
            //else
            //{
            //    curbal += tramt;
            //}
            dw.SetSqlCommandParameters("refglcode" + i, refglcode);
            dw.SetSqlCommandParameters("CurBal" + i, curbal);



            //Insert Params 

            switch (acsign)
            {
                case "CR":
                    acsign = "DR";
                    break;

                case "DR":
                    acsign = "CR";
                    break;
            }

            if (tramt < 0)
            {
                tramt *= -1;
            }



            dw.SetSqlCommandParameters("TrAmt" + i, tramt);
            dw.SetSqlCommandParameters("AcSign" + i, acsign);

            commandarray[i * 2 + 1] = "update glcode set curbal = @curbal" + i + " where refglcode=@refglcode" + i;
            string command = "INSERT INTO CrTransJrnl (TransNo,TrDate,TrStatus,CrAcNo,AcSign,TrAmt,TrUser,Time) ";
            command += "VALUES (@TransNo,@TrDate,@TrStatus,@ErrorAccount,@AcSign" + i + ",@TrAmt" + i + ",@TrUser,@Time)";
            commandarray[i * 2 + 2] = command;
        }
        dw.SetSqlCommandParameters("errorcurbal", errorcurbal);
        commandarray[dt.Rows.Count * 2 + 1] = "update glcode set curbal = @errorcurbal where refglcode='903080000000000'";

        if (dw.Trans(commandarray) != 0)
        {

            //for (int i = 0; dt1.Rows.Count > i; i++)
            //{
            //    //commandarray = new string[dt1.Rows.Count];
            //dw = new DataWorksClass(constring);
            //dw.SetCommand();
            //double tramt = double.Parse(dt1.Rows[i]["tramt"].ToString());
            //double assignamt = double.Parse(dt1.Rows[i]["Assignamt"].ToString());
            //double actoutbal = GetActOutBal(cracno);
            //double outbal = GetOutBal(cracno);
            //actoutbal += tramt;
            //outbal += assignamt;
            //DateTime datedue = GetLastDateDue(transno, cracno);
            //dw.SetSqlCommandParameters("outbal" + i, outbal);
            //dw.SetSqlCommandParameters("actoutbal" + i, actoutbal);
            //dw.SetSqlCommandParameters("datedue" + i, datedue);
            //dw.SetSqlCommandParameters("cracno" + i, cracno);
            //commandarray[i] = "update housprop set outbal=@outbal" + i + ",actoutbal=@actoutbal" + i + ", lastcompletedduedate=@datedue" + i + " , datedue=@datedue" + i + " where cracno = @cracno" + i;
            //if (dw.Trans(commandarray) != 0)
            //{
            dt = new DataTable();
            dt = GetTrasAssignData(cracno, transno);
            for (int x = 0; x < dt.Rows.Count; x++)
            {
                string refno = dt.Rows[x]["refno"].ToString();
                string trstatus = dt.Rows[x]["trstatus"].ToString();
                double tramt = double.Parse(dt.Rows[x]["trstatus"].ToString());
                trstatus = "C";

                UpdateTransAssgn(refno, tramt, trstatus);
            }
        }
        UpdateBatchTmp(transno, cracno, "C");
        return -1;
        //    }
        //}


    }
    private int UpdateBatchTmp(string transno, string cracno, string status)
    {
        dw1 = new DataWorksClass(constring);
        dw1.SetCommand(@"update batchtmp set status=@status where cracno =@cracno and transno =@transno ");
        dw1.SetSqlCommandParameters("transno", transno);
        dw1.SetSqlCommandParameters("cracno", cracno);
        dw1.SetSqlCommandParameters("status", status);
        return dw.Update();
    }


//    public int CancelTrans(string transno, string cracno, DateTime trdate,string truser, DataTable dt)
//    {
//        dw = new DataWorksClass(constring);
//        dw.SetCommand();

//        double tramt = 0;
//        //GlTrans
//        dw.SetSqlCommandParameters("trstatusGT", "C");
//        dw.SetSqlCommandParameters("transNoGT", transno);

//        //CrTransJrnl
//        dw.SetSqlCommandParameters("TransNo", transno);
//        dw.SetSqlCommandParameters("TrDate", trdate);
//        dw.SetSqlCommandParameters("TrStatus", "R");
//        dw.SetSqlCommandParameters("cracno", cracno);
//        dw.SetSqlCommandParameters("ErrorAccount", "903080000000000");
//        dw.SetSqlCommandParameters("truser", truser);
//        dw.SetSqlCommandParameters("Time", DateTime.Now.ToShortTimeString());

       

//        string[] commandarray = new string[2 + (dt.Rows.Count) * 3];

//        commandarray[0] = @"update gltrans set trstatus=@trstatusGT where transNo=@transNoGT 
//                            and cracno=@cracno";
//        double errorcurbal = GetCurrentBalance("903080000000000");
//        for (int i = 0; i < dt.Rows.Count; i++)
//        { 
           

//            // parameters
//            string refglcode = dt.Rows[i]["refglcode"].ToString();
//            tramt = double.Parse(dt.Rows[i]["tramt"].ToString());
//            string acsign = dt.Rows[i]["acsign"].ToString();

//            //GLTrans
//            dw.SetSqlCommandParameters("cracnoG"+i, cracno);
//            dw.SetSqlCommandParameters("transnoG" + i, transno);
//            dw.SetSqlCommandParameters("TrLineNoG" + i, i);
//            dw.SetSqlCommandParameters("TrStatusG" + i, "F");
//            dw.SetSqlCommandParameters("TrDateG" + i, trdate);
           
//            double curbal = 0;
//            curbal = GetCurrentBalance(refglcode);
//            //if (tramt >= 0)
//            //{
//            curbal += tramt;
//            errorcurbal -= tramt;

//            dw.SetSqlCommandParameters("refglcode" + i, refglcode);
//            dw.SetSqlCommandParameters("CurBal" + i, curbal);
            
//            switch (acsign)
//            {
//                case "CR":
//                    acsign = "DR";
//                    break;

//                case "DR":
//                    acsign = "CR";
//                    break;
//            }

//            if (tramt < 0)
//            {
//                tramt *= -1;
//            }

//            dw.SetSqlCommandParameters("TrAmt" + i, tramt);
//            dw.SetSqlCommandParameters("AcSign"+i, acsign);

//            //GLTrans
//            dw.SetSqlCommandParameters("AcSignG" + i, acsign);
//            dw.SetSqlCommandParameters("TrAmtG" + i, tramt);
//            dw.SetSqlCommandParameters("RefGlCodeG" + i, "903080000000000");

//            commandarray[i * 3 + 1] = "update glcode set curbal = @curbal" + i + " where refglcode=@refglcode" + i;
//            string command = "INSERT INTO CrTransJrnl (TransNo,TrDate,TrStatus,CrAcNo,AcSign,TrAmt,TrUser,Time) ";
//            command += "VALUES (@TransNo,@TrDate,@TrStatus,@ErrorAccount,@AcSign" + i + ",@TrAmt" + i + ",@TrUser,@Time)";
//            commandarray[i * 3 + 2] = command;
//            //string command2 = "INSERT INTO Gltrans(cracno,RefGlCode,TransNo,TrLineNo,TrDate,AcSign,TrAmt,TrStatus)";
//            //command2 += "values(@cracnoG" + i + ",@RefGlCodeG" + i + ",@transnoG" + i + ",@TrLineNoG" + i + ",@TrDateG" + i + ",@AcSignG" + i + ",@TrAmtG" + i + ",@TrStatusG" + i + ")";
//            //commandarray[i * 3 + 3] = command2;
//        }
//        dw.SetSqlCommandParameters("errorcurbal", errorcurbal);
//        commandarray[dt.Rows.Count*3+1] = "update glcode set curbal = @errorcurbal where refglcode='903080000000000'";

//        dw.Trans(commandarray);
//        DataTable dt1 = new DataTable();
//        dt1 = GetCapitalTransactions(transno, "CAPD", cracno);
//        double tramtT = 0, assignamt = 0;
//        for (int i = 0; dt1.Rows.Count > i; i++)
//        {
//            dt = new DataTable();
//            dt = GetTrasAssignData(cracno, transno);
//            for (int x = 0; x < dt.Rows.Count; x++)
//            {
//                tramt = double.Parse(dt.Rows[x]["tramt"].ToString());
//                assignamt = double.Parse(dt.Rows[x]["assignamt"].ToString());
//                string refno = dt.Rows[x]["refno"].ToString();
//                string trstatus = dt.Rows[x]["trstatus"].ToString();

//                if (assignamt == tramt)
//                {
//                    //tramt = 0;
//                    trstatus = "C";
//                }
//                else
//                {
//                    tramt = tramt;
//                    trstatus = "P";
//                }
//                UpdateTransAssgn(refno, tramt, trstatus);
//            }

//            commandarray = new string[dt1.Rows.Count];
//            dw = new DataWorksClass(constring);
//            dw.SetCommand();
//            tramt = double.Parse(dt1.Rows[i]["tramt"].ToString());
//            assignamt = double.Parse(dt1.Rows[i]["Assignamt"].ToString());
//            double actoutbal = GetActOutBal(cracno);
//            double outbal = GetOutBal(cracno);
//            actoutbal += tramt;
//            outbal += assignamt;
//            DateTime datedue = GetLastDateDue(transno, cracno);
//            dw.SetSqlCommandParameters("outbal" + i, outbal);
//            dw.SetSqlCommandParameters("actoutbal" + i, actoutbal);
//            dw.SetSqlCommandParameters("datedue" + i, datedue);
//            dw.SetSqlCommandParameters("cracno" + i, cracno);
//            commandarray[i] = "update housprop set outbal=@outbal" + i + ",actoutbal=@actoutbal" + i + ", lastcompletedduedate=@datedue" + i + " , datedue=@datedue" + i + " where cracno = @cracno" + i;
//            dw.Trans(commandarray);

//            UpdateBatchTmp(transno, cracno, "C");
//        }

//        return -1;

//    }


    private double CancelTrans(string transno, string cracno, DateTime trdate, string truser, DataTable dt)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand();
        double totamt = 0;
        double tramt = 0;
        //GlTrans
        dw.SetSqlCommandParameters("cracnoGT", cracno);
        dw.SetSqlCommandParameters("trstatusGT", "C");
        dw.SetSqlCommandParameters("transNoGT", transno);

        //GlTrans
        dw.SetSqlCommandParameters("cracnoT", cracno);
        dw.SetSqlCommandParameters("trstatusT", "C");
        dw.SetSqlCommandParameters("transNoT", transno);

        //CrTransJrnl
        dw.SetSqlCommandParameters("TransNo", transno);
        dw.SetSqlCommandParameters("TrDate", trdate);
        dw.SetSqlCommandParameters("TrStatus", "R");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("ErrorAccount", "903080000000000");
        dw.SetSqlCommandParameters("truser", truser);
        dw.SetSqlCommandParameters("Time", DateTime.Now.ToShortTimeString());

        string[] commandarray = new string[3 + (dt.Rows.Count) * 2];

        commandarray[0] = @"update gltrans set trstatus=@trstatusGT where transNo=@transNoGT 
                            and cracno=@cracnoGT";
        commandarray[1] = @"update transassign set trstatus=@trstatusT where transNo=@transNoT 
                            and cracno=@cracnoT";
        for (int i = 0; i < dt.Rows.Count; i++)
        {

            // parameters
            string refglcode = dt.Rows[i]["refglcode"].ToString();
            tramt = double.Parse(dt.Rows[i]["tramt"].ToString());
            string acsign = dt.Rows[i]["acsign"].ToString();

            double curbal = 0;
            curbal = GetCurrentBalance(refglcode);
            //if (tramt >= 0)
            //{
            curbal += tramt;
            dw.SetSqlCommandParameters("refglcode" + i, refglcode);
            dw.SetSqlCommandParameters("CurBal" + i, curbal);

            switch (acsign)
            {
                case "CR":
                    acsign = "DR";

                    break;

                case "DR":
                    acsign = "CR";
                    break;
            }

            if (tramt < 0)
            {
                tramt *= -1;
                totamt += tramt;
            }
            else
            {
                
            }
            dw.SetSqlCommandParameters("TrAmt" + i, tramt);
            dw.SetSqlCommandParameters("AcSign" + i, acsign);

            commandarray[i * 2 + 2] = "update glcode set curbal = @curbal" + i + " where refglcode=@refglcode" + i;
            string command = "INSERT INTO CrTransJrnl (TransNo,TrDate,TrStatus,CrAcNo,AcSign,TrAmt,TrUser,Time) ";
            command += "VALUES (@TransNo,@TrDate,@TrStatus,@ErrorAccount,@AcSign" + i + ",@TrAmt" + i + ",@TrUser,@Time)";
            commandarray[i * 2 + 3] = command;
        }

        if (dw.Trans(commandarray) != 0)
        {
            return totamt;
        }
        else
        {
            return 0;
        }
        //DataTable dt1 = new DataTable();
        //27/08/2009
        // dt1 = GetCapitalTransactions(transno, "CAPD", cracno);
        //double tramtT = 0, assignamt = 0;
        //for (int i = 0; dt1.Rows.Count > i; i++)
        //{
        //    dt = new DataTable();
        //    dt = GetTrasAssignData(cracno, transno);
        //    for (int x = 0; x < dt.Rows.Count; x++)
        //    {
        //        tramt = double.Parse(dt.Rows[x]["tramt"].ToString());
        //        assignamt = double.Parse(dt.Rows[x]["assignamt"].ToString());
        //        string refno = dt.Rows[x]["refno"].ToString();
        //        string trstatus = dt.Rows[x]["trstatus"].ToString();

        //        if (assignamt == tramt)
        //        {
        //            //tramt = 0;
        //            trstatus = "C";
        //        }
        //        else
        //        {
        //            tramt = tramt;
        //            trstatus = "P";
        //        }
        //        UpdateTransAssgn(refno, tramt, trstatus);
        //    }

        //    commandarray = new string[dt1.Rows.Count];
        //    dw = new DataWorksClass(constring);
        //    dw.SetCommand();
        //    tramt = double.Parse(dt1.Rows[i]["tramt"].ToString());
        //    assignamt = double.Parse(dt1.Rows[i]["Assignamt"].ToString());
        //    double actoutbal = GetActOutBal(cracno);
        //    double outbal = GetOutBal(cracno);
        //    actoutbal += tramt;
        //    outbal += assignamt;
        //    DateTime datedue = GetLastDateDue(transno, cracno);
        //    dw.SetSqlCommandParameters("outbal" + i, outbal);
        //    dw.SetSqlCommandParameters("actoutbal" + i, actoutbal);
        //    dw.SetSqlCommandParameters("datedue" + i, datedue);
        //    dw.SetSqlCommandParameters("cracno" + i, cracno);
        //    commandarray[i] = "update housprop set outbal=@outbal" + i + ",actoutbal=@actoutbal" + i + ", lastcompletedduedate=@datedue" + i + " , datedue=@datedue" + i + " where cracno = @cracno" + i;
        //    dw.Trans(commandarray);

        //    UpdateBatchTmp(transno, cracno, "C");
        //}

    }

    private int UpdateTransAssgn(string refno, double tramt, string trstatus)
    {
        dw.SetCommand(@"update transassign set tramt=@tramt, trstatus=@trstatus  where refno=@refno");
        dw.SetSqlCommandParameters("tramt", tramt);
        dw.SetSqlCommandParameters("trstatus", trstatus);
        dw.SetSqlCommandParameters("refno", refno);
        return dw.Update();
    }

    //public string CancelTrans(string transno, DataTable dt)
    //{
    //    dw = new DataWorksClass(constring);
    //    dw.SetCommand();

    //    // CrTransJrnl
    //    dw.SetSqlCommandParameters("trstatusCT", "C");
    //    dw.SetSqlCommandParameters("transNoCT", transno);

    //    //Trans
    //    dw.SetSqlCommandParameters("trstatusT", "C");
    //    dw.SetSqlCommandParameters("transNoT", transno);

    //    //TransAssign
    //    dw.SetSqlCommandParameters("trstatusTA", "C");
    //    dw.SetSqlCommandParameters("transNoTA", transno);

    //    //GlTrans
    //    dw.SetSqlCommandParameters("trstatusGT", "C");
    //    dw.SetSqlCommandParameters("transNoGT", transno);


    //    string[] commandarray = new string[4 + dt.Rows.Count];

    //    commandarray[0] = @"update crtransjrnl set trstatus=@trstatusCT where transNo=@transNoCT";
    //    commandarray[1] = @"update trans set trstatus=@trstatusT where transNo=@transNoT";
    //    commandarray[2] = @"update transassign set trstatus=@trstatusTA where transNo=@transNoTA";
    //    commandarray[3] = @"update gltrans set trstatus=@trstatusGT where transNo=@transNoGT";

    //    for (int i = 0; i < dt.Rows.Count; i++)
    //    {
    //        // parameters
    //        string refglcode = dt.Rows[i]["refglcode"].ToString();
    //        double tramt = double.Parse(dt.Rows[i]["tramt"].ToString());
    //        double curbal = 0;
    //        curbal = GetCurrentBalance(refglcode);
    //        //if (tramt >= 0)
    //        //{
    //        curbal += tramt;
    //        //}
    //        //else
    //        //{
    //        //    curbal += tramt;
    //        //}
    //        dw.SetSqlCommandParameters("refglcode" + i, refglcode);
    //        dw.SetSqlCommandParameters("CurBal" + i, curbal);
    //        commandarray[i + 4] = "update glcode set curbal = @curbal" + i + " where refglcode=@refglcode" + i;
    //    }
    //    if (dw.Trans(commandarray) != 0)
    //    {
    //        msg = "Transaction cancelled succesfully";
    //    }
    //    else
    //    {
    //        msg = "Error " + dw.ErrMsg;
    //    }
    //    return msg;
    //}

    //public int CancelTrans(string transno, string cracno, DateTime trdate, string truser, DataTable dt)
    //{
    //    dw = new DataWorksClass(constring);
    //    dw.SetCommand();

    //    // CrTransJrnl
    //    dw.SetSqlCommandParameters("trstatusCT", "C");
    //    dw.SetSqlCommandParameters("transNoCT", transno);

    //    //Trans
    //    dw.SetSqlCommandParameters("trstatusT", "C");
    //    dw.SetSqlCommandParameters("transNoT", transno);

    //    //TransAssign
    //    //dw.SetSqlCommandParameters("trstatusTA", "C");
    //    //dw.SetSqlCommandParameters("transNoTA", transno);

    //    //GlTrans
    //    dw.SetSqlCommandParameters("trstatusGT", "C");
    //    dw.SetSqlCommandParameters("transNoGT", transno);

    //    //CrTransJrnl
    //    dw.SetSqlCommandParameters("TransNo", transno);
    //    dw.SetSqlCommandParameters("TrDate", trdate);
    //    dw.SetSqlCommandParameters("TrStatus", "R");
    //    dw.SetSqlCommandParameters("cracno", cracno);
    //    dw.SetSqlCommandParameters("truser", truser);
    //    dw.SetSqlCommandParameters("Time", DateTime.Now.ToShortTimeString());

    //    DataTable dt1 = new DataTable();
    //    dt1 = GetCapitalTransactions(transno, "CAPD", cracno);

    //    string[] commandarray = new string[4 + (dt.Rows.Count) * 3];

    //    commandarray[0] = @"update crtransjrnl set trstatus=@trstatusCT where transNo=@transNoCT";
    //    commandarray[1] = @"update trans set trstatus=@trstatusT where transNo=@transNoT";
    //    //commandarray[2] = @"update transassign set trstatus=@trstatusTA where transNo=@transNoTA and cracno=@cracno";
    //    commandarray[2] = @"update gltrans set trstatus=@trstatusGT where transNo=@transNoGT and cracno=@cracno";

    //    for (int i = 0; i < dt.Rows.Count; i++)
    //    {
    //        // parameters
    //        string refglcode = dt.Rows[i]["refglcode"].ToString();
    //        double tramt = double.Parse(dt.Rows[i]["tramt"].ToString());
    //        string acsign = dt.Rows[i]["acsign"].ToString();
    //        double curbal = 0;
    //        curbal = GetCurrentBalance(refglcode);
    //        //if (tramt >= 0)
    //        //{
    //        curbal += tramt;
    //        //}
    //        //else
    //        //{
    //        //    curbal += tramt;
    //        //}
    //        dw.SetSqlCommandParameters("refglcode" + i, refglcode);
    //        dw.SetSqlCommandParameters("CurBal" + i, curbal);

    //        //Insert Params 

    //        switch (acsign)
    //        {
    //            case "CR":
    //                acsign = "DR";
    //                break;

    //            case "DR":
    //                acsign = "CR";
    //                break;
    //        }

    //        if (tramt < 0)
    //        {
    //            tramt *= -1;
    //        }

    //        dw.SetSqlCommandParameters("TrAmt" + i, tramt);
    //        dw.SetSqlCommandParameters("AcSign" + i, acsign);

    //        commandarray[i * 3 + 3] = "update glcode set curbal = @curbal" + i + " where refglcode=@refglcode" + i;
    //        string command = "INSERT INTO CrTransJrnl (TransNo,TrDate,TrStatus,CrAcNo,AcSign,TrAmt,TrUser,Time) ";
    //        command += "VALUES (@TransNo,@TrDate,@TrStatus,@CrAcNo,@AcSign" + i + ",@TrAmt" + i + ",@TrUser,@Time)";
    //        commandarray[i * 3 + 4] = command;
    //    }

    //    dw.Trans(commandarray);

    //    for (int i = 0; dt1.Rows.Count > i; i++)
    //    {
    //        commandarray = new string[dt1.Rows.Count];
    //        dw = new DataWorksClass(constring);
    //        dw.SetCommand();
    //        double tramt = double.Parse(dt1.Rows[i]["tramt"].ToString());
    //        double assignamt = double.Parse(dt1.Rows[i]["Assignamt"].ToString());
    //        double tramttransassign = double.Parse(dt1.Rows[i]["tramtT"].ToString());
    //        double actoutbal = GetActOutBal(cracno);
    //        double outbal = GetOutBal(cracno);
    //        actoutbal += tramt;
    //        outbal += assignamt;
    //        DateTime datedue = GetLastDateDue(transno, cracno);
    //        dw.SetSqlCommandParameters("outbal" + i, outbal);
    //        dw.SetSqlCommandParameters("actoutbal" + i, actoutbal);
    //        dw.SetSqlCommandParameters("datedue" + i, datedue);
    //        dw.SetSqlCommandParameters("cracno" + i, cracno);
    //        commandarray[i] = "update housprop set outbal=@outbal" + i + ",actoutbal=@actoutbal" + i + ", lastcompletedduedate=@datedue" + i + " , datedue=@datedue" + i + " where cracno = @cracno" + i;
    //        dw.Trans(commandarray);
    //        dt = new DataTable();
    //        dt = GetTrasAssignData(cracno, transno);
    //        for (int x = 0; x < dt.Rows.Count; x++)
    //        {
    //            double tramtT = double.Parse(dt.Rows[x]["tramtT"].ToString());
    //            tramt = double.Parse(dt.Rows[x]["tramt"].ToString());
    //            assignamt = double.Parse(dt.Rows[x]["assignamt"].ToString());
    //            string refno = dt.Rows[x]["refno"].ToString();
    //            string trstatus = dt.Rows[x]["trstatus"].ToString();

    //            if (tramtT == tramt)
    //            {
    //                tramt = 0;
    //                trstatus = "C";
    //            }
    //            else
    //            {
    //                tramt = assignamt - (tramtT - tramt);
    //                trstatus = "P";
    //            }
    //            UpdateTransAssgn(refno, tramt, trstatus);


    //        }
    //    }

    //    return 1;

    //}
   
    public double GetCurrentBalance(string refglcode)
    {
        dw1 = new DataWorksClass(constring);
        dw1.SetCommand(@"select curbal from glcode where refglcode=@refglcode");
        dw1.SetSqlCommandParameters("refglcode", refglcode);
        return Convert.ToDouble(dw1.GetSingleData());
    }

    private DataTable GetTrasAssignData(string cracno, string transno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select distinct t.refno, t.trstatus,  t.tramt as tramtT, t.assignamt, g.tramt as tramt
                            from transassign t, gltrans g
                            where t.cracno=@cracno and t.transno=@transno
                            and t.refno = g.transassignrefno");
        dw.SetDataAdapterParameters("cracno", cracno);
        dw.SetDataAdapterParameters("transno", transno);
        return dw.GetDataTable();
    }

    public void GetCapitalAmt(string transno, string trstatus, string taskid)
    {
        dt=new DataTable();
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select tramt, cracno from  transassign where trstatus=@trstatus 
                            and transno=transno and trstatus=@trstatus and left(taskid,4)=@taskid");
        dw.SetDataAdapterParameters("transno", transno);
        dw.SetDataAdapterParameters("trstatus", trstatus);
        dw.SetDataAdapterParameters("taskid", taskid);
        dt = dw.GetDataTable();
        for(int i=0;dt.Rows.Count>i;i++)
        {
            string cracno = dt.Rows[i]["cracno"].ToString();
            double tramt = double.Parse(dt.Rows[i]["tramt"].ToString());
            UpdateCapital(cracno, tramt);

        }

        CancelShedule(transno, "C");
        
    }

    private int UpdateCapital(string cracno, double tramt)
    {

        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select grantamt from crmast where cracno=cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        double exttramt = double.Parse(dw.GetSingleData());
        exttramt -= tramt;

        dw.SetCommand(@"update crmast set grantamt=@grantamt where cracno=cracno");
        dw.SetSqlCommandParameters("grantamt", exttramt);
        return dw.Update();
    }


    private int CancelShedule(string transno, string status)
    {

        dw.SetCommand(@"update disbbalsum set status=@status where transno=transno");
        dw.SetSqlCommandParameters("transno", transno);
        dw.SetSqlCommandParameters("status", status);
        return dw.Update();
    }
    //private int CancelTransActionTransAssign(string transNo, string trstatus)
    //{
    //    dw = new DataWorksClass(constring);
    //    dw.SetCommand(@"update transassign set trstatus=@trstatus where transNo=transNo");
    //    dw.SetSqlCommandParameters("transNo", transNo);
    //    dw.SetSqlCommandParameters("trstatus", trstatus);
    //    return dw.Update();
    //}

    //private int CancelTransActionCrGlTrans(string transNo, string trstatus)
    //{
    //    dw = new DataWorksClass(constring);
    //    dw.SetCommand(@"update gltrans set trstatus=@trstatus where transNo=transNo");
    //    dw.SetSqlCommandParameters("transNo", transNo);
    //    dw.SetSqlCommandParameters("trstatus", trstatus);
    //    return dw.Update();
    //}


    public DataTable GetCancelData(string batchno, string transno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select t1.cracno as cracno from
                            (select batchno,cracno,sum(tramt) as amt from batchtmp where batchno=@batchno and transno=@transno
                             group by batchno, cracno )as t1,
                            (select batchno,cracno,sum(tramt) as amt from gltrans where batchno=@batchno  and transno=@transno
                            group by batchno, cracno) as t2
                            where t1.cracno = t2.cracno and t1.amt <> t2.amt");
        dw.SetDataAdapterParameters("batchno", batchno);
        dw.SetDataAdapterParameters("transno", transno);
        return dw.GetDataTable();
    }
}
