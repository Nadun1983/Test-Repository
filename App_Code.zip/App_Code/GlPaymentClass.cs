using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// Summary description for GlPaymentClass
/// </summary>
public class GlPaymentClass
{
    private SqlConnection sqlConn;
    SqlCommand sqlCmd;
    SqlDataReader sqlDataReader;
    SqlDataAdapter sqldataAdapter;
    DataTable dt;

    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();
    string oldhousdbString = ConfigurationManager.ConnectionStrings["oldhousdbString"].ConnectionString.ToString();
    string testhousdbString = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();
	public GlPaymentClass()
	{
		//
		// TODO: Add constructor logic here
		//
	}


    public int InsertCrTransJrnlOld(long TransNo, DateTime TransDate, string TranStatus, string CrAcNo, int TrCode, string AcSign, string Action,
                       long RefAcNo, int BatchNo, DateTime BatchDate, string TrGenSec, double TransAmt, string TransDetail,
                       string TransUser, string IsUpdate, string IsBchConfrm, string IsGrTrGen, string IsGlUpd, string IsProcess,
                       string IsDayEnd, int TrStationId, string Time, string NormalRecov)
    {
        string error;
        string SqlInsert;

        Time = Time.Substring(0, 8);

        SqlInsert = @"insert into CrTransJrnl (TransNo,TransDate, TranStatus, CrAcNo, TrCode, AcSign, Action,RefAcNo, BatchNo,
                       BatchDate, TrGenSec, TransAmt, TransDetail,TransUser, IsUpdate, IsBchConfrm, IsGrTrGen, IsGlUpd, 
                       IsProcess,IsDayEnd, TrStationId, Time, NormalRecov)
                       values (@TransNo,@TransDate, @TranStatus, @CrAcNo, @TrCode, @AcSign, @Action,@RefAcNo, @BatchNo,
                       @BatchDate, @TrGenSec, @TransAmt, @TransDetail,@TransUser, @IsUpdate, @IsBchConfrm, @IsGrTrGen, @IsGlUpd, 
                       @IsProcess,@IsDayEnd, @TrStationId, @Time, @NormalRecov)";

        sqlConn = new SqlConnection(testhousdbString);
        sqlCmd = new SqlCommand(SqlInsert, sqlConn);

        sqlCmd.Parameters.AddWithValue("TransNo", TransNo);
        sqlCmd.Parameters.AddWithValue("TransDate", TransDate);
        sqlCmd.Parameters.AddWithValue("TranStatus", TranStatus);
        sqlCmd.Parameters.AddWithValue("CrAcNo", CrAcNo);
        sqlCmd.Parameters.AddWithValue("TrCode", TrCode);

        sqlCmd.Parameters.AddWithValue("AcSign", AcSign);
        sqlCmd.Parameters.AddWithValue("Action", Action);
        sqlCmd.Parameters.AddWithValue("RefAcNo", RefAcNo);
        sqlCmd.Parameters.AddWithValue("BatchNo", BatchNo);
        sqlCmd.Parameters.AddWithValue("BatchDate", BatchDate);

        sqlCmd.Parameters.AddWithValue("TrGenSec", TrGenSec);
        sqlCmd.Parameters.AddWithValue("TransAmt", TransAmt);
        sqlCmd.Parameters.AddWithValue("TransDetail", TransDetail);
        sqlCmd.Parameters.AddWithValue("TransUser", TransUser);
        sqlCmd.Parameters.AddWithValue("IsUpdate", IsUpdate);

        sqlCmd.Parameters.AddWithValue("IsBchConfrm", IsBchConfrm);
        sqlCmd.Parameters.AddWithValue("IsGrTrGen", IsGrTrGen);
        sqlCmd.Parameters.AddWithValue("IsGlUpd", IsGlUpd);
        sqlCmd.Parameters.AddWithValue("IsProcess", IsProcess);
        sqlCmd.Parameters.AddWithValue("IsDayEnd", IsDayEnd);

        sqlCmd.Parameters.AddWithValue("TrStationId", TrStationId);
        sqlCmd.Parameters.AddWithValue("Time", Time);
        sqlCmd.Parameters.AddWithValue("NormalRecov", NormalRecov);

        int RowAdded = 0;

        try
        {
            sqlConn.Open();
            RowAdded = sqlCmd.ExecuteNonQuery();
        }
        catch (Exception er)
        {
            error = er.ToString();
        }
        finally
        {
            sqlConn.Close();
        }

        return RowAdded;
    }


    public int InsertCrTransJrnl(long TransNo, DateTime TransDate, string TranStatus, string CrAcNo, int TrCode, string AcSign, string Action,
                      long RefAcNo, int BatchNo, DateTime BatchDate, string TrGenSec, double TransAmt, string TransDetail,
                      string TransUser, string IsUpdate, string IsBchConfrm, string IsGrTrGen, string IsGlUpd, string IsProcess,
                      string IsDayEnd, int TrStationId, string Time, string NormalRecov)
    {
        string error;
        string SqlInsert;

        Time = Time.Substring(0, 8);

        SqlInsert = @"insert into CrTransJrnl (TransNo,TransDate, TranStatus, CrAcNo, TrCode, AcSign, Action,RefAcNo, BatchNo,
                       BatchDate, TrGenSec, TransAmt, TransDetail,TransUser, IsUpdate, IsBchConfrm, IsGrTrGen, IsGlUpd, 
                       IsProcess,IsDayEnd, TrStationId, Time, NormalRecov)
                       values (@TransNo,@TransDate, @TranStatus, @CrAcNo, @TrCode, @AcSign, @Action,@RefAcNo, @BatchNo,
                       @BatchDate, @TrGenSec, @TransAmt, @TransDetail,@TransUser, @IsUpdate, @IsBchConfrm, @IsGrTrGen, @IsGlUpd, 
                       @IsProcess,@IsDayEnd, @TrStationId, @Time, @NormalRecov)";

        sqlConn = new SqlConnection(oldhousdbString);
        sqlCmd = new SqlCommand(SqlInsert, sqlConn);

        sqlCmd.Parameters.AddWithValue("TransNo", TransNo);
        sqlCmd.Parameters.AddWithValue("TransDate", TransDate);
        sqlCmd.Parameters.AddWithValue("TranStatus", TranStatus);
        sqlCmd.Parameters.AddWithValue("CrAcNo", CrAcNo);
        sqlCmd.Parameters.AddWithValue("TrCode", TrCode);

        sqlCmd.Parameters.AddWithValue("AcSign", AcSign);
        sqlCmd.Parameters.AddWithValue("Action", Action);
        sqlCmd.Parameters.AddWithValue("RefAcNo", RefAcNo);
        sqlCmd.Parameters.AddWithValue("BatchNo", BatchNo);
        sqlCmd.Parameters.AddWithValue("BatchDate", BatchDate);

        sqlCmd.Parameters.AddWithValue("TrGenSec", TrGenSec);
        sqlCmd.Parameters.AddWithValue("TransAmt", TransAmt);
        sqlCmd.Parameters.AddWithValue("TransDetail", TransDetail);
        sqlCmd.Parameters.AddWithValue("TransUser", TransUser);
        sqlCmd.Parameters.AddWithValue("IsUpdate", IsUpdate);

        sqlCmd.Parameters.AddWithValue("IsBchConfrm", IsBchConfrm);
        sqlCmd.Parameters.AddWithValue("IsGrTrGen", IsGrTrGen);
        sqlCmd.Parameters.AddWithValue("IsGlUpd", IsGlUpd);
        sqlCmd.Parameters.AddWithValue("IsProcess", IsProcess);
        sqlCmd.Parameters.AddWithValue("IsDayEnd", IsDayEnd);

        sqlCmd.Parameters.AddWithValue("TrStationId", TrStationId);
        sqlCmd.Parameters.AddWithValue("Time", Time);
        sqlCmd.Parameters.AddWithValue("NormalRecov", NormalRecov);

        int RowAdded = 0;

        try
        {
            sqlConn.Open();
            RowAdded = sqlCmd.ExecuteNonQuery();
        }
        catch (Exception er)
        {
            error = er.ToString();
        }
        finally
        {
            sqlConn.Close();
        }

        return RowAdded;
    }



    public DataTable GetPayentMade(int paymenttypeid)
    {
        string sqlSelect = @"select GLCodeOld, Description ,Type from Paymenttype where paymenttypeid = @paymenttypeid";

        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);

        sqldataAdapter.SelectCommand.Parameters.AddWithValue("paymenttypeid", paymenttypeid);

        dt = new DataTable();

        try
        {

            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return dt;

    }

    //Get Payments
    public DataTable GetPaidPayment(int paymenttypeid, string appno, bool ispaid)
    {
        string sqlSelect = @"select * from paymentmade where appno = @appno and
                             paymenttypeid = @paymenttypeid and
                             ispaid=@ispaid";

        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);

        sqldataAdapter.SelectCommand.Parameters.AddWithValue("paymenttypeid", paymenttypeid);
        sqldataAdapter.SelectCommand.Parameters.AddWithValue("appno", appno);
        sqldataAdapter.SelectCommand.Parameters.AddWithValue("ispaid", ispaid);
        dt = new DataTable();

        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return dt;

    }




//    public int InsertGlPayments(string GlCode,DateTime GlProcDate, int TransNo,int TrLineNo,DateTime TrDate,
//               int TrCode,string AcSign,double TrAmt, string TrDetail)
//    {

//        string sqlInsert;

//        sqlInsert = @"INSERT INTO GlTrans (GlCode,GlProcDate,TransNo,TrLineNo,TrDate,TrCode,AcSign,TrAmt,TrDetail)
//                        VALUES (@GlCode,@GlProcDate,@TransNo,@TrLineNo,@TrDate,@TrCode,@AcSign,@TrAmt,@TrDetail)";

//        sqlConn = new SqlConnection(constring);
//        sqlCmd = new SqlCommand(sqlInsert, sqlConn);

//        sqlCmd.Parameters.AddWithValue("GlCode",GlCode );
//        sqlCmd.Parameters.AddWithValue("GlProcDate",GlProcDate );
//        sqlCmd.Parameters.AddWithValue("TransNo",TransNo );
//        sqlCmd.Parameters.AddWithValue("TrLineNo",TrLineNo );
//        sqlCmd.Parameters.AddWithValue("TrLineNo",TrLineNo );
//        sqlCmd.Parameters.AddWithValue("TrDate", TrDate);
//        sqlCmd.Parameters.AddWithValue("TrCode", TrCode);
//        sqlCmd.Parameters.AddWithValue("AcSign", AcSign);
//        sqlCmd.Parameters.AddWithValue("TrAmt", TrAmt);
//        sqlCmd.Parameters.AddWithValue("TrDetail", TrDetail);

//        int rowAdded = 0;

//        try
//        {
//            sqlConn.Open();
//            rowAdded = sqlCmd.ExecuteNonQuery();

//        }

//        catch (Exception err)
//        {

//        }

//        finally
//        {
//            sqlConn.Close();
//            sqlConn.Dispose();
//        }

//        return rowAdded;
//    }
}
