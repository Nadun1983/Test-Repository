using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Microsoft.Win32;

/// <summary>
/// Summary description for RegistryEditer
/// </summary>
public class RegistryEditor
{
    string msg;


    private RegistryKey regkey;

    public RegistryKey RegKey
    {
        get
        {
            return this.regkey;
        }
    }

    public RegistryEditor()
    {
        this.regkey = Registry.LocalMachine.OpenSubKey(@"Software\gest\appcon\setpan\_ting\sap");

    }



    public string ReadMyTestRegKey()
    {
        //string bcode;
        //string regKeyToGet = @"Software\gest\appcon\setpan\_ting\sap";//@"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\";
        //string keyToRead = "bCode";
        //ConnectionOptions oConn = new ConnectionOptions();
        //oConn.Username = "dell";
        //oConn.Password = "asd";

        //ManagementScope scope = new ManagementScope(@"\\" + "10.18.0.105" + @"\root\default");// oConn);
        //ManagementClass registry;
        //registry = new ManagementClass(scope, new ManagementPath("StdRegProv"), null);
        //// Returns a specific value for a specified key
        //ManagementBaseObject inParams = registry.GetMethodParameters("GetStringValue");
        //inParams["sSubKeyName"] = regKeyToGet;
        //inParams["sValueName"] = keyToRead;
        //ManagementBaseObject outParams = registry.InvokeMethod("GetStringValue", inParams, null);
        //bcode = outParams["sValue"].ToString();
        //return bcode;



        //RegistryKey regKey = RegistryKey.OpenRemoteBaseKey(RegistryHive.LocalMachine, "DB195");
        //regKey = regKey.OpenSubKey(@"Software\gest\appcon\setpan\_ting\sap");
        //string[] names = regKey.GetValueNames();

        //string branchcode = (string)regkey.GetValue(names[0]);
        //foreach (string entry in names)
        //{
        //    string a = entry.ToString();
        //    //MessageBox.Show(entry.ToString());
        //}
        //regKey.Close();

        //RegistryKey regkey;/* new Microsoft.Win32 Registry Key */

        //regkey = Registry.LocalMachine.OpenSubKey(@"Software\gest\appcon\setpan\_ting\sap");
        //string[] valnames = regkey.GetValueNames();
        //string branchcode = (string)regkey.GetValue(valnames[0]);
        //return branchcode;

        //RegistryKey regKey = RegistryKey.OpenRemoteBaseKey(RegistryHive.LocalMachine, "10.1.2.38");
        //regKey = regKey.OpenSubKey(@"Software\gest\appcon\setpan\_ting\sap");
        //string[] names = regKey.GetValueNames();

        //string branchcode = (string)regkey.GetValue(names[0]);
        ////foreach (string entry in names)
        ////{
        ////    string a = entry.ToString();
        ////    //MessageBox.Show(entry.ToString());
        ////}
        //regKey.Close();

        //RegistryKey regkey;/* new Microsoft.Win32 Registry Key */

        //regkey = Registry.LocalMachine.OpenSubKey(@"Software\gest\appcon\setpan\_ting\sap");
        //string[] valnames = regkey.GetValueNames();
        //string branchcode = (string)regkey.GetValue(valnames[0]);
        return "0308";

    }
    public int CreateMyTestRegKey(string text)
    {
        int i = 0;
        //RegistryKey regkey;/* new Microsoft.Win32 Registry Key */
        RegistryKey regkey;
        try
        {
            regkey = Registry.LocalMachine.CreateSubKey(@"Software\gest\appcon\setpan\_ting\sap");
            regkey.SetValue("bCode", text);
            regkey.SetValue("IP", text);
            regkey.SetValue("MAC", text);
            regkey.Close();
            i = 1;
        }
        catch (Exception ex)
        {
            i = 0;
            msg = ex.Message;
        }
        return i;
    }

}