﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Data;
using System.Configuration;

/// <summary>
/// Summary description for InterestProvision
/// </summary>
public class InterestProvision
{
    private string constring = ConfigurationManager.ConnectionStrings["housdbString"].ToString();
    DataWorksClass dw;
    DataTable NPLCategory;
    DataTable NPLData;
    DataTable NPLTranfer;
    DataTable NPLCredtDetails;
    DataTable IntProTransfer;
    DataTable PerformingInt;
    DataTable PeformExcess;
    FunctionClass fc;
    RecoveryProcesClass rpc;
    int arreasdays;
     double inttotal = 0, captotal = 0;
    public InterestProvision()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public double IntTotal
    {
        get
        {
            return inttotal;
        }
    }

    public double CapTotal
    {
        get
        {
            return captotal;
        }
    }

    public void SetInterestPrvision(DateTime opDate)
    {
        DataTable namedata;
        DataTable FNRData;
        fc = new FunctionClass();
        int datekey = fc.GetDateKeyinDate(opDate);
        NPLCategory = new DataTable();
        NPLCategory = GetNPLCategory();
        for (int q = 0; NPLCategory.Rows.Count>q; q++)
        {
            int param1 = int.Parse(NPLCategory.Rows[q]["param1"].ToString());
            int param2 = int.Parse(NPLCategory.Rows[q]["param2"].ToString());
            int statusid = int.Parse(NPLCategory.Rows[q]["statusid"].ToString());

            if (statusid != 6)
            {
                DataTable CrCat = new DataTable();
                CrCat = GetCategory();
                for (int e = 0; CrCat.Rows.Count > e; e++)
                {
                    int crcat = int.Parse(CrCat.Rows[e]["CrCatCode"].ToString());

                    NPLData = new DataTable();
                    DataTable IntRateData = new DataTable();
                    IntRateData = GetIntRate(crcat);
                    for (int r = 0; IntRateData.Rows.Count > r; r++)
                    {
                        namedata = new DataTable();
                        double intprovision = 0;
                        double exessinterest = 0;
                        double actoutbaltot = 0;
                        int intprocount = 0, intexccount = 0;
                        double intrate = double.Parse(IntRateData.Rows[r]["intrate"].ToString());
                        NPLData = GetLoanData(opDate, param1, param2, statusid, crcat, intrate, opDate);
                        for (int w = 0; NPLData.Rows.Count > w; w++)
                        {
                            string cracno = NPLData.Rows[w]["cracno"].ToString();
                            if (cracno == "603086212389")
                            {

                            }
                            double actoutbal = double.Parse(NPLData.Rows[w]["actoutbal"].ToString());
                            double grantamt = double.Parse(NPLData.Rows[w]["grantamt"].ToString());
                            double instalment = double.Parse(NPLData.Rows[w]["instalment"].ToString());
                            intrate = double.Parse(NPLData.Rows[w]["intrate"].ToString());
                            DateTime datedue = DateTime.Parse(NPLData.Rows[w]["lastcompletedduedate"].ToString());
                            DateTime nextdue = DateTime.Parse(NPLData.Rows[w]["datedue"].ToString());
                            int purposecode = int.Parse(NPLData.Rows[w]["purposecode"].ToString());
                            namedata = GetNames(cracno);
                            string name = "";
                            string nicno = "";
                            if (namedata.Rows.Count > 0)
                            {
                                name = namedata.Rows[0]["name"].ToString();
                                nicno = namedata.Rows[0]["nicno"].ToString();
                            }
                            if (cracno == "603080371339")
                            {

                            }

                            if (crcat == 3 || crcat == 9 || crcat == 11 || crcat == 12)
                            {
                                InsertInterestProvision(datekey, cracno, 0, 0, actoutbal, intrate, crcat, 1, 0,
                                                        datedue, instalment, name, nicno, grantamt);
                            }

                            else
                            {
                                if ((crcat == 5 || crcat == 19) && (grantamt == actoutbal) && (purposecode == 48))
                                {
                                    InsertInterestProvision(datekey, cracno, 0, 0, actoutbal, intrate, crcat, 1, 0,
                                                            datedue, instalment, name, nicno, grantamt);
                                }
                                else
                                {
                                    //duedate, noofdays  

                                    if (datedue <= opDate)
                                    {

                                        if (datedue.AddMonths(1) <= nextdue)
                                            nextdue = datedue.AddMonths(1);
                                        double amt = RecoveryProcessInt(cracno, opDate, intrate, crcat, instalment, datedue, nextdue, actoutbal);
                                        if (amt > 0)
                                        {
                                            intprovision += amt;
                                            intprocount++;
                                            int arreasdays = GetNoDaysForInterest(nextdue, opDate);
                                            InsertInterestProvision(datekey, cracno, amt, 0, actoutbal, intrate, crcat, statusid,
                                                                    arreasdays, datedue, instalment, name, nicno, grantamt);
                                        }
                                        else if (amt == 0)
                                        {
                                            InsertInterestProvision(datekey, cracno, amt, 0, actoutbal, intrate, crcat, statusid, 0,
                                                                    datedue, instalment, name, nicno, grantamt);
                                        }
                                        else if (amt < 0)
                                        {
                                            InsertInterestProvision(datekey, cracno, amt, 0, actoutbal, intrate, crcat, statusid, 0,
                                                                    datedue, instalment, name, nicno, grantamt);
                                        }
                                    }
                                    else
                                    {
                                        double amt = GetExcessInterest(cracno, "I", opDate) - GetExcessInterest(cracno, "E", opDate);
                                        if (amt > 0)
                                        {
                                            exessinterest += amt;
                                            intexccount++;
                                            int arreasdays = GetNoDaysForInterest(nextdue, opDate);
                                            InsertInterestProvision(datekey, cracno, 0, amt, actoutbal, intrate, crcat, statusid,
                                                                    arreasdays, datedue, instalment, name, nicno, grantamt);
                                        }
                                        else
                                        {
                                            if (amt == 0)
                                            {
                                                if (datedue == nextdue)
                                                {
                                                    nextdue = nextdue.AddMonths(-1);
                                                    amt = GetDaysInt(actoutbal, nextdue, opDate, intrate);
                                                    int arreasdays = GetNoDaysForInterest(nextdue, opDate);
                                                    InsertInterestProvision(datekey, cracno, amt, 0, actoutbal, intrate, crcat, statusid,
                                                                            arreasdays, datedue, instalment, name, nicno, grantamt);
                                                    intprovision += amt;
                                                    intprocount++;
                                                }
                                                else
                                                {
                                                    nextdue = nextdue.AddMonths(-1);
                                                    amt = GetDaysInt(actoutbal, nextdue, opDate, intrate);
                                                    int arreasdays = GetNoDaysForInterest(nextdue, opDate);
                                                    InsertInterestProvision(datekey, cracno, amt, 0, actoutbal, intrate, crcat, statusid,
                                                                            arreasdays, datedue, instalment, name, nicno, grantamt);
                                                    intprovision += amt;
                                                    intprocount++;

                                                }
                                            }

                                        }
                                    }

                                    actoutbaltot += actoutbal;
                                }

                            }
                        }
                        //InsertIntProvision(datekey, crcat, statusid, intprovision, actoutbaltot, "Interest Provision", intprocount, intrate);
                        //InsertIntProvision(datekey, crcat, statusid, exessinterest, actoutbaltot, "Excess Interest", intexccount, intrate);
                    }
                }
            }
            else
            {
                FNRData = new DataTable();
                FNRData = GetFinalNotReleaseData();
                for (int fn = 0; FNRData.Rows.Count > fn; fn++)
                {
                    string cracno = FNRData.Rows[fn]["cracno"].ToString();
                    if (cracno == "603086212389")
                    {

                    }
                    double amt = double.Parse(FNRData.Rows[fn]["InterestReceivable"].ToString());
                    double actoutbal = double.Parse(FNRData.Rows[fn]["actoutbal"].ToString());
                    double intrate = double.Parse(FNRData.Rows[fn]["intrate"].ToString());
                    int crcat = int.Parse(FNRData.Rows[fn]["crcat"].ToString());
                    int arreasdays = int.Parse(FNRData.Rows[fn]["NoOfDaysInterest"].ToString());
                    DateTime datedue = DateTime.Parse(FNRData.Rows[fn]["lastcompletedduedate"].ToString());
                    double instalment = double.Parse(FNRData.Rows[fn]["instalment"].ToString());
                    

                    namedata = GetNames(cracno);
                    string name = "";
                    string nicno = "";
                    if (namedata.Rows.Count > 0)
                    {
                        name = namedata.Rows[0]["name"].ToString();
                        nicno = namedata.Rows[0]["nicno"].ToString();
                    }
                    //string name = FNRData.Rows[fn]["CustomerName"].ToString();
                    //string nicno = FNRData.Rows[fn]["nicno"].ToString();


                    InsertInterestProvision(datekey, cracno, amt, 0, actoutbal, intrate, crcat, 6,
                                            arreasdays, datedue, instalment, name, nicno, actoutbal);
                }

            }
        }

        //********************************************** For Previous Month NPL Calculation *********************************************
        DataTable PrevMonthNPL = new DataTable();
        string PrevDateKey = GetPreviousMonthEndDate(datekey.ToString());
        PrevMonthNPL = GetPrevMonthDataforNPL(datekey.ToString(), PrevDateKey, opDate);
        for (int i = 0; PrevMonthNPL.Rows.Count > i; i++)
        {
            string cracno = PrevMonthNPL.Rows[i]["cracno"].ToString();
            if (cracno == "603086212389")
            {

            }
            UpdatePrevNPLtoNPL(cracno, datekey.ToString(), 2);
        }
        //********************************************** For Previous Month NPL Calculation **********************************************

        //********************************************** NPL Reschedule Process **********************************************************
        DataTable dtres = new DataTable();
        dtres = GetRescheduleNPLData(opDate);
        if (dtres.Rows.Count > 0)
        {
            for (int a = 0; dtres.Rows.Count > a; a++)
            {
                string cracno = dtres.Rows[a]["cracno"].ToString();

                if (cracno == "603086212389")
                {

                }
                //string oldcracno = dtres.Rows[a]["oldcracno"].ToString();
                int noofdays = int.Parse(dtres.Rows[a]["NoofDays"].ToString());
                int statusid = int.Parse(dtres.Rows[a]["statusid"].ToString());
                if ((noofdays <= 90) && (statusid == 2))
                {
                    UpdatePrevNPLtoNPL(cracno, datekey.ToString(), statusid);
                    //UpdatePrevNPLtoNPL(oldcracno, datekey.ToString(), statusid);
                }
                if ((noofdays <= 180) && ((statusid == 3 || statusid == 4)))
                {
                    UpdatePrevNPLtoNPL(cracno, datekey.ToString(), statusid);
                    //UpdatePrevNPLtoNPL(oldcracno, datekey.ToString(), statusid);
                }
                if ((noofdays <= 360) && (statusid == 5))
                {
                    UpdatePrevNPLtoNPL(cracno, datekey.ToString(), statusid);
                    //UpdatePrevNPLtoNPL(oldcracno, datekey.ToString(), statusid);
                }
            }
        }

        //-------------------------------------- NPL Reshedule of after monitoring period ----------------------------------------------
        DataTable dtrm = new DataTable();
        dtrm = GetRescheduleAfterMonitoring(opDate, datekey.ToString());
        if (dtrm.Rows.Count > 0)
        {
            for (int b = 0; dtrm.Rows.Count > b; b++)
            {
                string cracno = dtrm.Rows[b]["cracno"].ToString();
                if (cracno == "603086212389")
                {

                }
                //string oldcracno = dtres.Rows[a]["oldcracno"].ToString();
                int noofdays = int.Parse(dtrm.Rows[b]["NoofDays"].ToString());
                int statusid = int.Parse(dtrm.Rows[b]["statusid"].ToString());
                if ((noofdays > 90) && (statusid == 2))
                {
                    UpdatePrevNPLtoNPL(cracno, datekey.ToString(), statusid);
                    //UpdatePrevNPLtoNPL(oldcracno, datekey.ToString(), statusid);
                }
                if ((noofdays > 180) && ((statusid == 3 || statusid == 4)))
                {
                    UpdatePrevNPLtoNPL(cracno, datekey.ToString(), statusid);
                    //UpdatePrevNPLtoNPL(oldcracno, datekey.ToString(), statusid);
                }
                if ((noofdays > 360) && (statusid == 5))
                {
                    UpdatePrevNPLtoNPL(cracno, datekey.ToString(), statusid);
                    //UpdatePrevNPLtoNPL(oldcracno, datekey.ToString(), statusid);
                }
            }
        }


        //********************************************** NPL Reschedule Process **********************************************************

        //********************************************** For NPL New Calculation ********************************************************
        DataTable CurrentMonthNPL = new DataTable();
        DataTable pawning = new DataTable();
        CurrentMonthNPL = GetNonPerformingLoans(datekey.ToString());
        for (int i = 0; CurrentMonthNPL.Rows.Count > i; i++)
        {
            string nicno = CurrentMonthNPL.Rows[i]["nicno"].ToString();

            if (nicno == "848302090v")
            {

            }
            //double pawningNPLOutBal = 0.00;
            double NPLGrantAmt = double.Parse(CurrentMonthNPL.Rows[i]["NPLGrantAmt"].ToString());
            double NPLOutBal = double.Parse(CurrentMonthNPL.Rows[i]["NPLOutBal"].ToString());
            double PLGrantAmt = GetPerformingGrantAmt(nicno, datekey.ToString());
           // pawning = GetPawningNPLBalance();
            double NPLPawningAmt = GetPawningNPLBalance(nicno, datekey.ToString());
            if (PLGrantAmt != 0.00)
            {
                double pawningGrantAmt = GetPawningGrantedAmount(nicno, datekey.ToString());
                double percentage = ((NPLOutBal + NPLPawningAmt) / (NPLGrantAmt + PLGrantAmt + pawningGrantAmt)) * 100;
                if (percentage > 30.0)
                {
                    UpdateOtherPerformingLoans(nicno, datekey.ToString(), 2);
                }
            }
        }
        //********************************************** For NPL New Calculation ********************************************************
    }

    private DataTable GetRescheduleNPLData(DateTime opDate)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select Cracno, DATEDIFF(day,resheduledate,@opDate) as NoofDays, statusid 
                            from NPLReshedule where DATEDIFF(day,resheduledate,@opDate) <=360 
                            union all
                            select OldCracno, DATEDIFF(day,resheduledate,@opDate) as NoofDays, statusid 
                            from NPLReshedule where DATEDIFF(day,resheduledate,@opDate) <=360 ");
        dw.SetDataAdapterParameters("opDate", opDate);
        return dw.GetDataTable();
    }

    private DataTable GetRescheduleAfterMonitoring(DateTime opDate, string DateKey)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select N.Cracno, DATEDIFF(day,resheduledate,@opDate) as NoofDays, 
                            N.statusid from NPLReshedule N, IntProvisionIndividual I 
                            where N.Cracno = I.Cracno
                            and I.DateKey = @DateKey 
                            and I.statusid != N.StatusId and I.statusid not in (1,6) 
                            union all
                            select N.OldCracno, DATEDIFF(day,resheduledate,@opDate) as NoofDays, 
                            N.statusid from NPLReshedule N, IntProvisionIndividual I 
                            where N.OldCracno = I.Cracno
                            and I.DateKey = @DateKey 
                            and I.statusid != N.StatusId and I.statusid not in (1,6) ");
        dw.SetDataAdapterParameters("opDate", opDate);
        dw.SetDataAdapterParameters("DateKey", DateKey);
        return dw.GetDataTable();
    }

    public void SetNPLTransferForProvision(DateTime opDate)
    {
        fc = new FunctionClass();
        string datekey = fc.GetStringDate(opDate);
        NPLTranfer = new DataTable();
        NPLCredtDetails = new DataTable();
        IntProTransfer = new DataTable();
        NPLTranfer = GetNPLTransferData(datekey);
        for (int i = 0; NPLTranfer.Rows.Count > i; i++)
        {
            //DateTime Trdate = NPLTranfer.Rows[i]["cracno"].ToString();
            double TrAmt = double.Parse(NPLTranfer.Rows[i]["TrAmt"].ToString());
            string refglcode = NPLTranfer.Rows[i]["refglcode"].ToString();
            string gldesc = NPLTranfer.Rows[i]["gldesc"].ToString();
            string acsign = NPLTranfer.Rows[i]["acsign"].ToString();
            int crcat = int.Parse(NPLTranfer.Rows[i]["crcat"].ToString());
            InsertProvisionBatchDetails(opDate, TrAmt, refglcode, gldesc, acsign, "OTHR", crcat,0,"NPL");
        }
        int isprocess = checkNPLCredit(opDate);
        if (isprocess > 0)
        {
            NPLCredtDetails = GetNPLCreditData(opDate);
            for (int j = 0; NPLCredtDetails.Rows.Count > j; j++)
            {
                DateTime Trdate = DateTime.Parse(NPLCredtDetails.Rows[j]["Trdate"].ToString());
                double TrAmt = double.Parse(NPLCredtDetails.Rows[j]["TrAmt"].ToString());
                string refglcode = NPLCredtDetails.Rows[j]["refglcode"].ToString();
                string gldesc = NPLCredtDetails.Rows[j]["gldesc"].ToString();
                string acsign = NPLCredtDetails.Rows[j]["acsign"].ToString();
                int crcat = int.Parse(NPLCredtDetails.Rows[j]["crcat"].ToString());
                InsertProvisionBatchDetails(Trdate, TrAmt, refglcode, gldesc, acsign, "OTHR", crcat, 0,"NPL");
            }
            IntProTransfer = GetIntProTransferData(datekey);
            for (int k = 0; IntProTransfer.Rows.Count > k; k++)
            {
                double TrAmt = double.Parse(IntProTransfer.Rows[k]["TrAmt"].ToString());
                string refglcode = IntProTransfer.Rows[k]["refglcode"].ToString();
                string gldesc = IntProTransfer.Rows[k]["gldesc"].ToString();
                string acsign = IntProTransfer.Rows[k]["acsign"].ToString();
                int crcat = int.Parse(IntProTransfer.Rows[k]["crcat"].ToString());
                InsertProvisionBatchDetails(opDate, TrAmt, refglcode, gldesc, acsign, "OTHR", crcat, 0,"NPL");
            }
        } 
    }


    public void SetPerformingProvisionBatch(DateTime opDate)
    {
        fc = new FunctionClass();
        string datekey = fc.GetStringDate(opDate);
        PerformingInt = new DataTable();
        PeformExcess = new DataTable();
        double TotalPerInterest = 0;
        double TotalExcess = 0;
        PerformingInt = GetPeformingIntProvision(datekey);
        PeformExcess = GetExcessProvision(datekey);
        for (int i = 0; PerformingInt.Rows.Count > i; i++)
        {
            double TrAmt = double.Parse(PerformingInt.Rows[i]["TrAmt"].ToString());
            string refglcode = PerformingInt.Rows[i]["refglcode"].ToString();
            string gldesc = PerformingInt.Rows[i]["gldesc"].ToString();
            string acsign = PerformingInt.Rows[i]["acsign"].ToString();
            int crcat = int.Parse(PerformingInt.Rows[i]["crcat"].ToString());
            InsertProvisionBatchDetails(opDate, TrAmt, refglcode, gldesc, acsign, "OTHR", crcat, 1, "INT");
            TotalPerInterest += TrAmt;
        }
        InsertProvisionBatchDetails(opDate, TotalPerInterest, "903087000000015", "GL Code Credit Div. Other Dr.    Adjusting A/C amount receivable",
                                     "DR", "OTHR", 0, 1, "INT");

        for (int j = 0; PeformExcess.Rows.Count > j; j++)
        {
            double ExTrAmt = double.Parse(PeformExcess.Rows[j]["TrAmt"].ToString());
            string refglcode = PeformExcess.Rows[j]["refglcode"].ToString();
            string gldesc = PeformExcess.Rows[j]["gldesc"].ToString();
            int crcat = int.Parse(PeformExcess.Rows[j]["crcat"].ToString());
            InsertProvisionBatchDetails(opDate, ExTrAmt, refglcode, gldesc, "DR", "OTHR", crcat, 1, "INT");
            TotalExcess += ExTrAmt;
        }
        InsertProvisionBatchDetails(opDate, TotalExcess, "903086000000013", "GL Code Credit Div. Other Cr.    Adjusting account amount payable",
                                     "CR", "OTHR", 0, 1, "INT");

    }
    public int checkIntProvision(string opdate) // changed on 26/07/2013
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select count(*) from intprovisionIndividual where datekey = @opdate");
        dw.SetSqlCommandParameters("opdate", opdate);
        return int.Parse(dw.GetSingleData());
    }


    public int checkNPLCredit(DateTime opdate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select count(*) from ProvisionBatchDetails where TrDate = @opdate and acsign='DR'");
        dw.SetSqlCommandParameters("opdate", opdate);
        return int.Parse(dw.GetSingleData());
    }

    public int checkNPLTransfer(DateTime opdate, string ProStatus)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select count(*) from ProvisionBatchDetails where TrDate = @opdate and ProStatus=@ProStatus");
        dw.SetSqlCommandParameters("opdate", opdate);
        dw.SetSqlCommandParameters("ProStatus", ProStatus);
        return int.Parse(dw.GetSingleData());
    }

    private DataTable GetNPLTransferData(string datekey)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select sum(actoutbal) as TrAmt,p.refglcode,gldesc,acsign,i.crcat from intprovisionIndividual I, 
                            ProvisionMaster p,glcode g  where datekey=@datekey
                            and i.statusid not in (1,6) and i.statusid=p.statusid
                            and i.crcat=p.crcat
                            and p.refglcode=g.refglcode
                            group by p.refglcode,gldesc,acsign,i.crcat
                            ");
        dw.SetDataAdapterParameters("datekey", datekey);
        return dw.GetDataTable();
    }

    private DataTable GetPeformingIntProvision(string datekey)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select sum(intprovision) as TrAmt,p.refglcode,gldesc,acsign,i.crcat from intprovisionIndividual I, 
                            ProvisionMaster p,glcode g  where datekey=@datekey
                            and i.statusid in (1,6) and p.statusid=7
                            and i.crcat=p.crcat
                            and p.refglcode=g.refglcode
                            group by p.refglcode,gldesc,acsign,i.crcat
                            ");
        dw.SetDataAdapterParameters("datekey", datekey);
        return dw.GetDataTable();
    }


    private DataTable GetExcessProvision(string datekey)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select sum(exessinterest) as TrAmt,p.refglcode,gldesc,i.crcat from intprovisionIndividual I, 
                            ProvisionMaster p,glcode g  where datekey=@datekey
                            and i.statusid=1 and p.statusid=7
                            and i.crcat=p.crcat
                            and p.refglcode=g.refglcode
                            group by p.refglcode,gldesc,i.crcat
                            ");
        dw.SetDataAdapterParameters("datekey", datekey);
        return dw.GetDataTable();
    }

    private DataTable GetIntProTransferData(string datekey)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select sum(intprovision) as TrAmt,p.refglcode,gldesc,acsign,i.crcat from intprovisionIndividual I, 
                            ProvisionMaster p,glcode g  where datekey=@datekey
                            and i.statusid not in (1,6) and p.statusid=0
                            and i.crcat=p.crcat
                            and p.refglcode=g.refglcode
                            group by p.refglcode,gldesc,acsign,i.crcat
                            ");
        dw.SetDataAdapterParameters("datekey", datekey);
        return dw.GetDataTable();
    }

    private DataTable GetNPLCreditData(DateTime TrDate)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select sum(tramt) as TrAmt,p.refglcode,g.gldesc,p.acsign,b.crcat,TrDate
                            from ProvisionBatchDetails b,glcode g, 
                            ProvisionMaster p where b.crcat=p.crcat
                            and statusid=1  and p.refglcode=g.refglcode
                            and b.TrDate=@Trdate
                            group by p.refglcode,g.gldesc,p.acsign,b.crcat,TrDate
                            ");
        dw.SetDataAdapterParameters("TrDate", TrDate);
        return dw.GetDataTable();
    }

    private void InsertProvisionBatchDetails(DateTime TrDate, double TrAmt, string RefGlcode, 
                                       string GlDesc, string AcSign,
                                       string TaskId, int CrCat, int Status, string ProStatus)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into ProvisionBatchDetails(TrDate, TrAmt,RefGlcode,GlDesc,AcSign, TaskId, CrCat, Status, ProStatus) VALUES 
                        (@TrDate, @TrAmt,@RefGlcode,@GlDesc,@AcSign, @TaskId, @CrCat, @Status, @ProStatus)");
        dw.SetSqlCommandParameters("TrDate", TrDate);
        dw.SetSqlCommandParameters("TrAmt", TrAmt);
        dw.SetSqlCommandParameters("RefGlcode", RefGlcode);
        dw.SetSqlCommandParameters("GlDesc", GlDesc);
        dw.SetSqlCommandParameters("AcSign", AcSign);
        dw.SetSqlCommandParameters("TaskId", TaskId);
        dw.SetSqlCommandParameters("CrCat", CrCat);
        dw.SetSqlCommandParameters("Status", Status);
        dw.SetSqlCommandParameters("ProStatus", ProStatus);
        dw.Insert();
    }

    public DataTable GetNames(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select cm.nicno, rtrim(titledesc) + ' '  + ltrim(rtrim(initials)+ '  ' + rtrim(surname))as name 
                            from customermain cm, title t, crholder ch
                            where cm.nicno = ch.nicno
                            and t.titlecode = cm.titlecode
                            and ch.cracno = @cracno
                            and ch.holdertype = 'P'");
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }

    private void InsertInterestProvision(int datekey, string cracno, double intprovision, double exessinterest, double actoutbal,
                                         double intrate, int crcat, int statusid, int arreasdays, DateTime datedue, double instalment, 
                                         string name, string nicno,double GrantAmount)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into IntProvisionIndividual(datekey, cracno,intprovision,exessinterest,actoutbal, intrate, 
                                                           crcat, statusid, arreasdays, datedue, name, nicno, GrantAmount) VALUES 
                        (@datekey, @cracno,@intprovision,@exessinterest,@actoutbal, @intrate, @crcat, @statusid, @arreasdays, 
                        @datedue,@name,@nicno, @GrantAmount)");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("intprovision", intprovision);
        dw.SetSqlCommandParameters("exessinterest", exessinterest);
        dw.SetSqlCommandParameters("actoutbal", actoutbal);
        dw.SetSqlCommandParameters("datekey", datekey);
        dw.SetSqlCommandParameters("intrate", intrate);
        dw.SetSqlCommandParameters("crcat", crcat);
        dw.SetSqlCommandParameters("statusid", statusid);
        dw.SetSqlCommandParameters("arreasdays", arreasdays);
        dw.SetSqlCommandParameters("datedue", datedue);
        dw.SetSqlCommandParameters("instalment", instalment);
        dw.SetSqlCommandParameters("name", name);
        dw.SetSqlCommandParameters("nicno", nicno);
        dw.SetSqlCommandParameters("GrantAmount", GrantAmount);
        dw.Insert();
    }

    private double GetExcessInterest(string cracno, string trtype, DateTime datedue)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select 
                        (select isnull(sum(tramt), 0) as tramt from transassign 
                        where cracno = @cracno and trstatus != 'c' 
                        and datedue > @datedue
                        AND TASKID = 'INTR' and trtype = @trtype)");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("trtype", trtype);
        dw.SetSqlCommandParameters("datedue", datedue);
        return double.Parse(dw.GetSingleData());
    }

    private DataTable GetIntRate(int crcat)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select distinct intrate as intrate from housprop where crcat = @crcat and intrate is not null");
        dw.SetDataAdapterParameters("crcat", crcat);
        return dw.GetDataTable();
    }

    private DataTable GetCategory()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from CrCategory order by CrCatCode");
        return dw.GetDataTable();
    }

    private void InsertIntProvision(int datekey, int crcat, int statusid, double intprovision, double actoutbaltot, string desc, int LoanCount, double intrate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into IntProvision (datekey,crcat,statusid,intprovision,actoutbaltot, [desc], LoanCount, intrate) VALUES 
                        (@datekey,@crcat,@statusid,@intprovision, @actoutbaltot, @desc, @LoanCount,@intrate)");

        dw.SetSqlCommandParameters("datekey", datekey);
        dw.SetSqlCommandParameters("crcat", crcat);
        dw.SetSqlCommandParameters("statusid", statusid);
        dw.SetSqlCommandParameters("intprovision", intprovision);
        dw.SetSqlCommandParameters("actoutbaltot", actoutbaltot);
        dw.SetSqlCommandParameters("desc", desc);
        dw.SetSqlCommandParameters("LoanCount", LoanCount);
        dw.SetSqlCommandParameters("intrate", intrate);
        dw.Insert();
    }

//    private DataTable GetLoanData(DateTime opDate, int param1, int param2, int statusid, int crcat, double intrate, DateTime trdate)
//    {
//        dw = new DataWorksClass(constring);
//        dw.SetDataAdapter(@"select h.CrAcno, h.instalment,lastcompletedduedate, datedue,
//                        actoutbal, h.intrate, m.grantamt
//                        from housprop h, crmast m
//                        where datediff(day,lastcompletedduedate,@opDate)<= @param2 and
//                        datediff(day,lastcompletedduedate,@opDate)>= @param1
//                        and h.cracno=m.cracno and h.actoutbal!=0 and h.crcat<>9
//                        and h.crcat<>3 and h.crcat<>11 and h.crcat<>12 and m.aprovdamt=grantamt 
//                        and lastcompletedduedate<>'1900-01-01 00:00:00.000'
//                        and lastcompletedduedate<>'1900-02-01 00:00:00.000'
//                        and h.crcat = @crcat
//                        and h.intrate = @intrate
//                        order by lastcompletedduedate");
//        dw.SetDataAdapterParameters("param1", param1);
//        dw.SetDataAdapterParameters("param2", param2);
//        dw.SetDataAdapterParameters("crcat", crcat);
//        dw.SetDataAdapterParameters("intrate", intrate);
//        dw.SetDataAdapterParameters("opDate", opDate);
//        return dw.GetDataTable();
//    }

    private DataTable GetLoanData(DateTime opDate, int param1, int param2, int statusid, int crcat, double intrate, DateTime trdate)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select h.CrAcno, h.instalment,lastcompletedduedate, datedue,
                        actoutbal, h.intrate, m.grantamt, p.purposecode
                        from housprop h, crmast m, CrCatPurpose p
                        where datediff(day,lastcompletedduedate,@opDate)<= @param2 and
                        datediff(day,lastcompletedduedate,@opDate)>= @param1
                        and h.cracno=m.cracno and h.actoutbal!=0 and m.aprovdamt=grantamt 
                        and lastcompletedduedate<>'1900-01-01 00:00:00.000'
                        and lastcompletedduedate<>'1900-02-01 00:00:00.000'
                        and m.CatPurposeId = p.catpurposeid
                        and h.crcat = @crcat
                        and h.intrate = @intrate
                        order by lastcompletedduedate");

        dw.SetDataAdapterParameters("param1", param1);
        dw.SetDataAdapterParameters("param2", param2);
        dw.SetDataAdapterParameters("crcat", crcat);
        dw.SetDataAdapterParameters("intrate", intrate);
        dw.SetDataAdapterParameters("opDate", opDate);
        return dw.GetDataTable();
    }

    private DataTable GetFinalNotReleaseData()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select h.crcat,h.intrate, c.cracno, 
                            Aprovdamt, h.actoutbal, GrantDate,h.lastcompletedduedate,h.instalment,
                            datediff(day,grantdate,getdate()) as NoOfDaysInterest,
                            round((grantamt * datediff(day,grantdate,getdate()) * h.intrate) / (100 * 365),2) as InterestReceivable
                            from crmast c, housprop h
                            where c.cracno=h.cracno --and h.crcat not in (3,9,11,12)
                            and c.aprovdamt!=c.grantamt and h.actoutbal>0
                            order by h.crcat,h.intrate");
        return dw.GetDataTable();
    }

    public double SubstractAmount(double mainamount, double subamount)
    {
        return Math.Round((mainamount - subamount), 2);
    }

    public double AddAmount(double mainamount, double subamount)
    {
        return Math.Round((mainamount + subamount), 2);
    }

    private DataTable GetNPLCategory()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from LoanStatus where statusid != 0");
        return dw.GetDataTable();
    }

    private string GetPenalInt(string ratetype)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand("select rateamt from ratecode where ratetype=@ratetype");
        dw.SetSqlCommandParameters("ratetype", ratetype);
        return dw.GetSingleData();
    }

    private double GetOutBal(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select sum(assignamt-tramt) as diff from transassign where cracno=@cracno
                        and taskid='CAPD' and (trstatus = 'P' or trstatus = 'N')");
        dw.SetSqlCommandParameters("cracno", cracno);
        return double.Parse(dw.GetSingleData());
    }

     //Datedue Removed
    private DataTable GetArreasInstalment(string cracno, DateTime datedue, string taskid)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select refno, assignamt, assignamt-tramt as arreas, taskid, datedue from  transassign 
                            where cracno =  @cracno and (trstatus = 'p' or trstatus='n')
                            and taskid = @taskid and tramt != assignamt");
        dw.SetDataAdapterParameters(@"cracno", cracno);
        dw.SetDataAdapterParameters(@"taskid", taskid);
        return dw.GetDataTable();
    }


    public double RecoveryProcessInt(string cracno, DateTime trdate, double intrate, int crcat,
        double installment, DateTime datedue, DateTime nextdue, double actoutbal)
    {
        fc = new FunctionClass();
        DataTable dt = new DataTable();

        double intamount = 0, capital = 0, inttotal=0;

        double arreasamt;

        double outbal = SubstractAmount(actoutbal, GetOutBal(cracno));

        DataTable arreasanstalmentdata = new DataTable();
        arreasanstalmentdata = GetArreasInstalment(cracno, datedue, "INTR");
        if (arreasanstalmentdata.Rows.Count > 0)
        {

            for (int i = 0; arreasanstalmentdata.Rows.Count > i; i++)
            {
                arreasamt = double.Parse(arreasanstalmentdata.Rows[i]["arreas"].ToString());
                if (arreasamt > 0)
                {
                    inttotal += arreasamt;
                }
            }
        }

        if (outbal > installment)
        {
            if (trdate >= nextdue)
            {
                while (trdate >= nextdue)
                {
                    intamount = CalculateIntAmount(outbal, intrate);
                    capital = CalculateCapital(installment, intamount, crcat, outbal);
                    inttotal += intamount;
                    outbal -= capital;
                    outbal = Math.Round(outbal, 2);

                    //SetPayments Next Due
                    nextdue = fc.SetRecoveryDate(nextdue);
                }
                nextdue = nextdue.AddMonths(-1);
                inttotal += GetDaysInt(outbal, nextdue, trdate, intrate);
            }
            else
            {
                nextdue = nextdue.AddMonths(-1);
                inttotal += GetDaysInt(outbal, nextdue, trdate, intrate);
            }
        }
        else
        {
            if (trdate >= nextdue)
            {
                while (outbal > 0)
                {
                    intamount = CalculateIntAmount(outbal, intrate);
                    capital = CalculateCapital(installment, intamount, crcat, outbal);
                    inttotal += intamount;
                    outbal -= capital;
                    outbal = Math.Round(outbal, 2);

                    //SetPayments Next Due
                    //nextdue = fc.SetRecoveryDate(nextdue);
                }
                nextdue = nextdue.AddMonths(-1);
                inttotal += GetDaysInt(outbal, nextdue, trdate, intrate);
            }
            else
            {
                nextdue = nextdue.AddMonths(-1);
                inttotal += GetDaysInt(outbal, nextdue, trdate, intrate);
            }
        }
        return inttotal;
    }

    private double GetDaysInt(double outbal, DateTime nextdue, DateTime trdate, double intrate)
    {
        int intdays = GetNoDaysForInterest(nextdue, trdate);
        double dayint = Math.Round((outbal * intdays * intrate) / 36500,2);
        return dayint;
    }


    // Get Intest Days       
    public int GetNoDaysForInterest(DateTime intdatedue, DateTime trdate)
    {
        int days = 0;
        fc = new FunctionClass();
        TimeSpan t = trdate.Subtract(intdatedue);
        days = t.Days;
        return days;
    }


    private DateTime GetPenalValidDate(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select case when PenalValidDate is null 
                        then '01/01/1900' 
                        else PenalValidDate end as PenalValidDate 
                        from housprop where cracno =@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return DateTime.Parse(dw.GetSingleData());
    }

    private double CalculatePenal(DateTime workingDate, double penalint, int graceperiod, string cracno, DateTime datedue, double installment, int crcat)
    {
        if ((crcat == 9 || crcat == 11) && (cracno != "603080000215"))
        {
            penalint = 0;
        }
        DataTable basicRec = new DataTable(); //Loan Number Table
        int i = 0; //count of no of loans based on the date due
        //workingDate = workingDate.AddDays(-1);

        int noofdue; // Due Months
        int dayDD; // Due Day
        int dayWD; // Working Day
        int monthDD; // Due Month
        int monthWD; // Working Month
        int yearDD; // Due Year
        int yearWd; // Working Year
        double penal; // Penal Charges

        //Get date and Month From the Working Date and Due Date
        dayDD = datedue.Day;
        dayWD = workingDate.Day;
        monthDD = datedue.Month;
        monthWD = workingDate.Month;
        yearDD = datedue.Year;
        yearWd = workingDate.Year;

        if (dayDD > dayWD)
        {
            noofdue = (yearWd * 12 + monthWD) - (yearDD * 12 + monthDD);
        }
        else
        {
            noofdue = (yearWd * 12 + monthWD) - (yearDD * 12 + monthDD) + 1;
        }

        //Reduce the Grace Period
        noofdue = noofdue - graceperiod;

        // Penal calculation
        return Math.Round((installment * penalint * noofdue) / 1200, 2);

    }

    private double CalculateIntAmount(double outbal, double intrate)
    {
        return Math.Round(outbal * intrate / 1200, 2);
    }

    private double CalculateCapital(double installment, double intAmount, int crcat, double outbal)
    {
        if (crcat != 6)
        {
            if (installment >= outbal)
            {
                return Math.Round(outbal, 2);
            }
            else
            {
                return Math.Round(installment - intAmount, 2);
            }
        }
        else
        {
            return 0;
        }
    }


    private DataTable GetArreasAmount(string cracno, string trstatus1, string trstatus2)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select refno, assignamt, assignamt-tramt as arreas, taskid, datedue from  transassign 
                            where cracno =  @cracno 
                            and tramt != assignamt  and (trstatus = @trstatus1 or trstatus = @trstatus2)");
        dw.SetDataAdapterParameters(@"cracno", cracno);
        dw.SetDataAdapterParameters(@"trstatus1", trstatus1);
        dw.SetDataAdapterParameters(@"trstatus2", trstatus2);
        return dw.GetDataTable();
    }

    //Datedue Removed
    private DataTable GetArreasInstalment(string cracno, DateTime datedue)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select refno, assignamt, assignamt-tramt as arreas, taskid, datedue from  transassign 
                            where cracno =  @cracno and (trstatus = 'p' or trstatus='n')
                            and (taskid = 'capd' or taskid = 'intr') and tramt != assignamt");
        dw.SetDataAdapterParameters(@"cracno", cracno);
        return dw.GetDataTable();
    }

    public void RecoveryProcessTotal(string cracno, DateTime trdate, double intrate, int crcat,
    double installment, DateTime datedue, DateTime nextdue, double actoutbal)
    {
        fc = new FunctionClass();
        DataTable dt = new DataTable();

        double intamount = 0, capital = 0;

        double arreasamt;

        double outbal = SubstractAmount(actoutbal, GetOutBal(cracno));

        DataTable arreasanstalmentdata = new DataTable();
        arreasanstalmentdata = GetArreasInstalment(cracno, datedue, "INTR");
        if (arreasanstalmentdata.Rows.Count > 0)
        {

            for (int i = 0; arreasanstalmentdata.Rows.Count > i; i++)
            {
                arreasamt = double.Parse(arreasanstalmentdata.Rows[i]["arreas"].ToString());
                if (arreasamt > 0)
                {
                    inttotal += arreasamt;
                }
            }
        }

        arreasanstalmentdata = GetArreasInstalment(cracno, datedue, "CAPD");
        if (arreasanstalmentdata.Rows.Count > 0)
        {

            for (int i = 0; arreasanstalmentdata.Rows.Count > i; i++)
            {
                arreasamt = double.Parse(arreasanstalmentdata.Rows[i]["arreas"].ToString());
                if (arreasamt > 0)
                {
                    captotal += arreasamt;
                }
            }
        }

        if (outbal > installment)
        {
            if (trdate >= nextdue)
            {
                while (trdate >= nextdue)
                {
                    intamount = CalculateIntAmount(outbal, intrate);
                    capital = CalculateCapital(installment, intamount, crcat, outbal);
                    inttotal += intamount;
                    captotal += capital;
                    outbal -= capital;
                    outbal = Math.Round(outbal, 2);

                    //SetPayments Next Due
                    nextdue = fc.SetRecoveryDate(nextdue);
                }
                nextdue = nextdue.AddMonths(-1);
                inttotal += GetDaysInt(outbal, nextdue, trdate, intrate);
            }
            else
            {
                nextdue = nextdue.AddMonths(-1);
                inttotal += GetDaysInt(outbal, nextdue, trdate, intrate);
            }
        }
        
    }

	//Nikeshana 2012-01-05 
    public DataTable GetInterestProviionData(string datekey)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select cracno,crcat,actoutbal,intrate,datekey from IntProvisionIndividual where datekey=@datekey
                            and statusid not in (6) order by cracno");
        dw.SetDataAdapterParameters("datekey", datekey);
        return dw.GetDataTable();
    }

    //Nikeshana 2012-01-05 
    public int UpdateArreasData(string cracno, string datekey, decimal arreasCapital, decimal arreasInterest, decimal arreasPenal, decimal arreastotal)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update IntProvisionIndividual set arreasCapital=@arreasCapital,arreasInterest=@arreasInterest,
                        arreasPenal=@arreasPenal,arreastotal=@arreastotal where cracno=@cracno and datekey=@datekey");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("datekey", datekey);
        dw.SetSqlCommandParameters("arreasCapital", arreasCapital);
        dw.SetSqlCommandParameters("arreasInterest", arreasInterest);
        dw.SetSqlCommandParameters("arreasPenal", arreasPenal);
        dw.SetSqlCommandParameters("arreastotal", arreastotal);
        return dw.Update();
    }

    //For Basel-II Requirement
    /************************************************************************************************************************************/
    private double GetPawningGrantedAmount(string NicNo, string datekey)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select ISNULL(SUM(GrantedAmt),0) AS PawnGrantAmount from PawningNPL 
                        where NicNo=@NicNo and DateKey=@datekey");
        dw.SetSqlCommandParameters("NicNo", NicNo);
        dw.SetSqlCommandParameters("datekey", datekey);
        return double.Parse(dw.GetSingleData());
    }

    private double GetPawningNPLBalance(string NicNo, string datekey)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select ISNULL(SUM(OutBal),0) AS PawnNPLBalance from PawningNPL 
                        where NicNo=@NicNo and IsNPA=1 and DateKey=@datekey");
        dw.SetSqlCommandParameters("NicNo", NicNo);
        dw.SetSqlCommandParameters("datekey", datekey);
        return double.Parse(dw.GetSingleData());
    }

    //public DataTable GetPawningNPLBalance()
    //{
    //    dw = new DataWorksClass(constring);
    //    dw.SetDataAdapter(@"select * from PawningNPL where datekey='20171023' and isnpa=1");
    //    //dw.SetDataAdapterParameters("datekey", datekey);
    //    return dw.GetDataTable();
    //}
    
    public DataTable GetNonPerformingLoans(string datekey)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select SUM(actoutbal) as NPLOutBal, SUM(GrantAmount) as NPLGrantAmt,NicNo from IntProvisionIndividual 
                            where DateKey=@datekey and StatusId not in (1,6)
                            and NicNo!='' group by NicNo");
        dw.SetDataAdapterParameters("datekey", datekey);
        return dw.GetDataTable();
    }

    private double GetPerformingGrantAmt(string NicNo, string datekey)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select ISNULL(SUM(GrantAmount),0) AS PLGrantAmount from IntProvisionIndividual 
                        where NicNo=@NicNo and StatusId=1 and DateKey=@datekey");
        dw.SetSqlCommandParameters("NicNo", NicNo);
        dw.SetSqlCommandParameters("datekey", datekey);
        return double.Parse(dw.GetSingleData());
    }

    public int UpdateOtherPerformingLoans(string nicno, string datekey, int statusid)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update IntProvisionIndividual set statusid=@statusid where nicno=@nicno and datekey=@datekey
                        and statusid=1 and crcat not in (9,11,12)");
        dw.SetSqlCommandParameters("nicno", nicno);
        dw.SetSqlCommandParameters("datekey", datekey);
        dw.SetSqlCommandParameters("statusid", statusid);
        return dw.Update();
    }

    public DataTable GetPrevMonthDataforNPL(string currentdatekey, string prevdatekey, DateTime DateDue)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from IntProvisionIndividual where DateKey=@prevdatekey and StatusId not in (1,6)
                            and cracno in (select cracno from IntProvisionIndividual where DateKey=@currentdatekey and
                            StatusId = 1 and DateDue <= @DateDue)");
        dw.SetDataAdapterParameters("prevdatekey", prevdatekey);
        dw.SetDataAdapterParameters("currentdatekey", currentdatekey);
        dw.SetDataAdapterParameters("DateDue", DateDue);
        return dw.GetDataTable();
    }

    private string GetPreviousMonthEndDate(string currentdatekey)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select MAX(datekey) from IntProvisionIndividual where DateKey<@currentdatekey");
        dw.SetSqlCommandParameters("currentdatekey", currentdatekey);
        return dw.GetSingleData();
    }

    public int UpdatePrevNPLtoNPL(string cracno, string datekey, int statusid)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update IntProvisionIndividual set statusid=@statusid where cracno=@cracno and datekey=@datekey
                        and crcat not in (9,11,12)");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("datekey", datekey);
        dw.SetSqlCommandParameters("statusid", statusid);
        return dw.Update();
    }
    /**********************************************************************************************************************************/

   
}