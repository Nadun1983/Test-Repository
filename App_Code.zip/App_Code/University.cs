﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// Summary description for University
/// </summary>
public class University
{
	public University()
	{
		//
		// TODO: Add constructor logic here
		//
	}
        Corrections cs;
    DateTime datedue, nextdue, intdatedue;
    double outbal, actoutbal, exesspayment;
    double mcapital, minterest, mpenal;
    string msg, errorcracno;
    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();
    CrTransClass cc;
    DataWorksClass dw;
    FunctionClass fc;
    Recovery rc;
    Trans t;
    ClosingDataClass cdc;
    DataTable dta;

    public string ErrorCracno
    {
        get
        {
            return this.msg;
        }
    }

    public string Message
    {
        get
        {
            return this.msg;
        }
    }


    public DateTime NextDue
    {
        get
        {
            return this.nextdue;
        }
    }

    public DateTime IntDateDue
    {
        get
        {
            return this.intdatedue;
        }
    }


    public double OutBal
    {
        get
        {
            return this.outbal;
        }
    }


    public double ActOutBal
    {
        get
        {
            return this.actoutbal;
        }
    }


    public double ExessPayment
    {
        get
        {
            return this.exesspayment;
        }
    }



    public DateTime DateDue
    {
        get
        {
            return this.datedue;
        }
    }

    public double MCapital
    {
        get
        {
            return this.mcapital;
        }
    }
    public double MInterest
    {
        get
        {
            return this.minterest;
        }
    }
    public double MPenal
    {
        get
        {
            return this.mpenal;
        }
    }

    public int GetUniShedueRecord(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select count(*) from unishedule where cracno=@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return int.Parse(dw.GetSingleData());
    }

    public DataTable GetUniShedule(string cracno, double grantamt, double intrate, double instalment, int crperiod, DateTime GrantDate)
    {
        DataTable dt = new DataTable();
        dt = SetAmtzDataTable(dt);
        DateTime recoveryProcessDat;
        DateTime ProcessDate;
        fc = new FunctionClass();
        cc = new CrTransClass();
        rc = new Recovery();
        double intamount = 0, capital = 0;
        double actoutbal = 0, outbal = 0, TatalInstalment = 0, TatalInterest = 0;
        int serialno = 0;

        DataTable basicRec = new DataTable(); //Loan Number Table       
        double CustInterest = 0.00, GovtInterest = 0.00, CustCapital = 0.00, CustInstalment = 0.00, GovtInstalment = 0.00;
        int refno = 1;
        ProcessDate = DateTime.Now;
        ProcessDate = GrantDate;

       if  (intrate == 14.00)
        {
       
            instalment = Math.Round(grantamt * (intrate / (12 * 100)) / (1 - (1 / Math.Pow((double)((1 + (intrate / (12 * 100)))), crperiod))), 2);
            double roundinstalment = instalment;
            double custintrate = 9.00;
            int newroundinstalment;
            roundinstalment = instalment % 10;
            if (roundinstalment == 0)
                newroundinstalment = ((int)(instalment / 10)) * 10;
            else
                newroundinstalment = ((int)(instalment / 10) + 1) * 10;

            while (grantamt > 0)
            {
                //instalment = grantamt * (intrate / (12 * 100)) / (1 - (1 / Math.Pow((double)((1 + (intrate / (12 * 100)))), crperiod)));

                intamount = Math.Round(CalculateIntAmount(grantamt, intrate), 2);
                CustInterest = Math.Round(CalculateIntAmount(grantamt, custintrate), 2);
                GovtInterest = Math.Round((intamount - CustInterest), 2);
                capital = Math.Round(CalculateCapital(newroundinstalment, intamount, '1', grantamt), 2);
                CustInstalment = capital + CustInterest;
                GovtInstalment = GovtInterest;
                grantamt -= capital;
                grantamt = Math.Round(grantamt, 2);
                TatalInstalment = CustInstalment + GovtInstalment;
                TatalInterest = CustInterest + GovtInterest;
                //dt = InsertRow(refno.ToString(), capital, intamount, LoanAmt, dt);
                //refno = refno + 1;
                InsertUniShedule(cracno, GrantDate, TatalInterest, CustInterest, GovtInterest, capital, CustInstalment, GovtInstalment, grantamt, TatalInstalment);
                GrantDate = GrantDate.AddMonths(1);
            }
        }
        else
        {

            double custintrate = 7.00;


            instalment = Math.Round(grantamt * (intrate / (12 * 100)) / (1 - (1 / Math.Pow((double)((1 + (intrate / (12 * 100)))), crperiod))), 2);
            double roundinstalment = instalment;
            int newroundinstalment;
            roundinstalment = instalment % 10;
            if (roundinstalment == 0)
                newroundinstalment = ((int)(instalment / 10)) * 10;
            else
                newroundinstalment = ((int)(instalment / 10) + 1) * 10;


            while (grantamt > 0)
            {
                //instalment = grantamt * (intrate / (12 * 100)) / (1 - (1 / Math.Pow((double)((1 + (intrate / (12 * 100)))), crperiod)));

                intamount = Math.Round(CalculateIntAmount(grantamt, intrate), 2);
                CustInterest = Math.Round(CalculateIntAmount(grantamt, custintrate), 2);
                GovtInterest = Math.Round((intamount - CustInterest), 2);
                capital = Math.Round(CalculateCapital(newroundinstalment, intamount, '1', grantamt), 2);
                CustInstalment = capital + CustInterest;
                GovtInstalment = GovtInterest;
                grantamt -= capital;
                grantamt = Math.Round(grantamt, 2);
                TatalInstalment = CustInstalment + GovtInstalment;
                //dt = InsertRow(refno.ToString(), capital, intamount, LoanAmt, dt);
                //refno = refno + 1;
                TatalInterest = CustInterest + GovtInterest;
                InsertUniShedule(cracno, GrantDate, TatalInterest, CustInterest, GovtInterest, capital, CustInstalment, GovtInstalment, grantamt, TatalInstalment);
                GrantDate = GrantDate.AddMonths(1);
            }

        }
        

        return dt;
    }

    private double InsertUniShedule(string cracno, DateTime DateDue, double TatalInterest, double CustInterest, double UniInterest, double CustCapital, double CustInstalment, double UniInstalment, double Outbal, double TatalInstalment)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO UniShedule (cracno,DateDue,TatalInterest,CustInterest,UniInterest,CustCapital,CustInstalment,UniInstalment,Outbal,TatalInstalment) VALUES
                       (@cracno,@DateDue,@TatalInterest,@CustInterest ,@UniInterest,@CustCapital,@CustInstalment,@UniInstalment,@Outbal,@TatalInstalment)");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("DateDue", DateDue);
        dw.SetSqlCommandParameters("TatalInterest", TatalInterest);
        dw.SetSqlCommandParameters("CustInterest", CustInterest);
        dw.SetSqlCommandParameters("UniInterest", UniInterest);
        dw.SetSqlCommandParameters("CustCapital", CustCapital);
        dw.SetSqlCommandParameters("CustInstalment", CustInstalment);
        dw.SetSqlCommandParameters("UniInstalment", UniInstalment);
        dw.SetSqlCommandParameters("Outbal", Outbal);
        dw.SetSqlCommandParameters("TatalInstalment", TatalInstalment);
        return dw.Insert();
    }

    private double CalculateCapital(double installment, double intamount, char crcat, double grantamt)
    {
        if (crcat != 6)
        {
            if (installment >= grantamt)
            {
                return Math.Round(installment, 2);
            }
            else
            {
                return Math.Round(installment - intamount, 2);
            }
        }
        else
        {
            return 0;
        }
    }

    private double CalculateIntAmount(double grantamt, double intrate)
    {
        return Math.Round(grantamt * intrate / 1200, 2);
    }

    private DataTable SetAmtzDataTable(DataTable dt)
    {
        dt = new DataTable();
        DataColumn refno;
        refno = new DataColumn();
        refno.DataType = Type.GetType("System.String");
        refno.ColumnName = "Refno";
        dt.Columns.Add(refno);

        DataColumn cracno;
        cracno = new DataColumn();
        cracno.DataType = Type.GetType("System.String");
        cracno.ColumnName = "Cracno";
        dt.Columns.Add(cracno);

        DataColumn Capd;
        Capd = new DataColumn();
        Capd.DataType = Type.GetType("System.Decimal");
        Capd.ColumnName = "Capd";
        dt.Columns.Add(Capd);

        DataColumn Intr;
        Intr = new DataColumn();
        Intr.DataType = Type.GetType("System.Decimal");
        Intr.ColumnName = "Intr";
        dt.Columns.Add(Intr);

        DataColumn outbal;
        outbal = new DataColumn();
        outbal.DataType = Type.GetType("System.Decimal");
        outbal.ColumnName = "Outbal";
        dt.Columns.Add(outbal);

        return dt;

    }

    public object DispGovtShedule(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select  DateDue, sum(CustCapital),
                                    sum(TatalInterest),sum(CustInterest),sum(CustInstalment),sum(GovtInterest),
                                    sum(TatalInstalment),sum(Outbal) from 
                                    GovtShedule where cracno=@cracno
                                    group by datedue order by datedue");
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }


    public object DispUniShedule(string cracno, DateTime fromdate, DateTime todate)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select DateDue, sum(CustCapital) as CustCapital,
                                    sum(TatalInterest) as TatalInterest,sum(CustInterest) as CustInterest,
                                    sum(CustInstalment) as CustInstalment,sum(UniInterest) as UniInterest,
                                    sum(TatalInstalment) as TatalInstalment ,sum(Outbal) as Outbal from UniShedule
                                    where cracno=@cracno  and datedue >= @fromdate and datedue <= @todate
                                    group by  datedue
                                    order by datedue");
        dw.SetDataAdapterParameters("cracno", cracno);
        dw.SetDataAdapterParameters("fromdate", fromdate);
        dw.SetDataAdapterParameters("todate", todate);
        return dw.GetDataTable();
    }

    public object DispUniShedule(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select  DateDue, sum(CustCapital),
                                    sum(TatalInterest),sum(CustInterest),sum(CustInstalment),sum(UniInterest),
                                    sum(TatalInstalment),sum(Outbal) from 
                                    UniShedule where cracno=@cracno
                                    group by datedue order by datedue");
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }
}
