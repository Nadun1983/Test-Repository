﻿using System;
using System.Collections.Generic;
using System.Web;

/// <summary>
/// Summary description for CancelRecovery
/// </summary>
public class CancelRecovery
{
    DataWorksClass dw; 
	public CancelRecovery()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    ////public GetAssign

   
}
