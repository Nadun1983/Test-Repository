﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

/// <summary>
/// Summary description for DataBaseClass
/// </summary>
public class DataBaseClass
{
    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ToString();
    //string reportString = ConfigurationManager.ConnectionStrings["reportCreditAdmin"].ToString();
    string crmastString = ConfigurationManager.ConnectionStrings["crmastString"].ToString();

    DataWorksClass dw;    
    FunctionClass fc;
    DataTable dt;

	public DataBaseClass()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public bool IsNameExsist(string backUpName)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select actualDateTime from DataBaseBackup where backUpName=@backUpName");
        dw.SetSqlCommandParameters("backUpName", backUpName);
        string tmp = dw.GetSingleData();

        try
        {
            DateTime tmpDate = DateTime.Parse(tmp);
            return true;
        }
        catch (Exception er)
        {
            return false;
        }
    }

    public int InsertBackupRecord(string OperationDate, string BackupName, string UserName, DateTime ActualDateTime)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into DataBaseBackup(OperationDate,BackupName,UserName,ActualDateTime) 
                        values(@OperationDate,@BackupName,@UserName,@ActualDateTime)");
        dw.SetSqlCommandParameters("OperationDate", OperationDate);
        dw.SetSqlCommandParameters("BackupName", BackupName);
        dw.SetSqlCommandParameters("UserName", UserName);
        dw.SetSqlCommandParameters("ActualDateTime", ActualDateTime);
        return dw.Insert();
    }

}
