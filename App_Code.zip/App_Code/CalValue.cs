using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for CalValue
/// </summary>
public class CalValue
{
    private string one, ten, teen;
    public CalValue()
    {

    }

    private string One
    {
        set
        {
            switch (value)
            {
                case "0":
                    one = "Zero";
                    break;
                case "1":
                    one = "One";
                    break;
                case "2":
                    one = "Two";
                    break;
                case "3":
                    one = "Three";
                    break;
                case "4":
                    one = "Four";
                    break;
                case "5":
                    one = "Five";
                    break;
                case "6":
                    one = "Six";
                    break;
                case "7":
                    one = "Seven";
                    break;
                case "8":
                    one = "Eight";
                    break;
                case "9":
                    one = "Nine";
                    break;
                default:
                    one = "Error";
                    break;

            }

        }

        get
        {
            return one;
        }
    }


    private string Teen
    {
        set
        {
            switch (value)
            {
                case "0":
                    teen = "";
                    break;
                case "1":
                    teen = "Eleven";
                    break;
                case "2":
                    teen = "Twelve";
                    break;
                case "3":
                    teen = "Thirteen";
                    break;
                case "4":
                    teen = "Fourteen";
                    break;
                case "5":
                    teen = "Fifteen";
                    break;
                case "6":
                    teen = "Sixteen";
                    break;
                case "7":
                    teen = "Seventeen";
                    break;
                case "8":
                    teen = "Eighteen";
                    break;
                case "9":
                    teen = "Nineteen";
                    break;
                default:
                    teen = "Error";
                    break;

            }
        }

        get
        {
            return teen;
        }
    }


    private string Ten
    {
        set
        {
            switch (value)
            {
                case "1":
                    ten = "Ten";
                    break;
                case "2":
                    ten = "Twenty";
                    break;
                case "3":
                    ten = "Thirty";
                    break;
                case "4":
                    ten = "Forty";
                    break;
                case "5":
                    ten = "Fifty";
                    break;
                case "6":
                    ten = "Sixty";
                    break;
                case "7":
                    ten = "Seventy";
                    break;
                case "8":
                    ten = "Eighty";
                    break;
                case "9":
                    ten = "Ninety";
                    break;
                default:
                    ten = "";
                    break;

            }
        }

        get
        {
            return ten;
        }
    }



    //public String GetHundredValue(string value)
    //{

    //    switch (value)
    //    {
    //        case "0":
    //            value = "Zero";
    //            break;
    //        case "1":
    //            value = "One Hundred";
    //            break;
    //        case "2":
    //            value = "Two Hundred";
    //            break;
    //        case "3":
    //            value = "Three Hundred";
    //            break;
    //        case "4":
    //            value = "Four Hundred";
    //            break;
    //        case "5":
    //            value = "Five Hundred";
    //            break;
    //        case "6":
    //            value = "Six Hundred";
    //            break;
    //        case "7":
    //            value = "Seven Hundred";
    //            break;
    //        case "8":
    //            value = "Eight Hundred";
    //            break;
    //        case "9":
    //            value = "Nine Hundred";
    //            break;
    //        default:
    //            value = "Error";
    //            break;

    //    }
    //    return value;

    //}


    //public String GetThousandValue(string value)
    //{

    //    switch (value)
    //    {
    //        case "0":
    //            value = "";
    //            break;
    //        case "1":
    //            value = "One Thousand";
    //            break;
    //        case "2":
    //            value = "Two Thousand";
    //            break;
    //        case "3":
    //            value = "Three Thousand";
    //            break;
    //        case "4":
    //            value = "Four Thousand";
    //            break;
    //        case "5":
    //            value = "Five Thousand";
    //            break;
    //        case "6":
    //            value = "Six Thousand";
    //            break;
    //        case "7":
    //            value = "Seven Thousand";
    //            break;
    //        case "8":
    //            value = "Eight Thousand";
    //            break;
    //        case "9":
    //            value = "Nine Thousand";
    //            break;
    //        default:
    //            value = "Error";
    //            break;

    //    }
    //    return value;

    //}

    //public String GetTenThousandValue(string value)
    //{

    //    switch (value)
    //    {
    //        case "0":
    //            value = "";
    //            break;
    //        case "1":
    //            value = "Ten Thousand";
    //            break;
    //        case "2":
    //            value = "Twenty Thousand";
    //            break;
    //        case "3":
    //            value = "Thirty Thousand";
    //            break;
    //        case "4":
    //            value = "Fourty Thousand";
    //            break;
    //        case "5":
    //            value = "Fifty Thousand";
    //            break;
    //        case "6":
    //            value = "Sixty Thousand";
    //            break;
    //        case "7":
    //            value = "Seventy Thousand";
    //            break;
    //        case "8":
    //            value = "Eighty Thousand";
    //            break;
    //        case "9":
    //            value = "Ninety Thousand";
    //            break;
    //        default:
    //            value = "Error";
    //            break;

    //    }
    //    return value;

    //}

    //public String GetHundredThousandValue(string value)
    //{

    //    switch (value)
    //    {
    //        case "0":
    //            value = "";
    //            break;
    //        case "1":
    //            value = "Hundred Thousand";
    //            break;
    //        case "2":
    //            value = "Two Hundred Thousand";
    //            break;
    //        case "3":
    //            value = "Three  Thousand";
    //            break;
    //        case "4":
    //            value = "Fourty Thousand";
    //            break;
    //        case "5":
    //            value = "Fifty Thousand";
    //            break;
    //        case "6":
    //            value = "Sixty Thousand";
    //            break;
    //        case "7":
    //            value = "Seventy Thousand";
    //            break;
    //        case "8":
    //            value = "Eighty Thousand";
    //            break;
    //        case "9":
    //            value = "Ninety Thousand";
    //            break;
    //        default:
    //            value = "Error";
    //            break;

    //    }
    //    return value;

    //}

    private string GetTenValue()
    {
        return one;
    }


    //public string GetNumberVal(string text, int decimalplaces)
    //{

    //    switch(decimalplaces)
    //    {
    //        case 0:
    //            string value = "";

    //    switch (text.Length)
    //    { 
    //        case 1:
    //            value = OneFunction(text);
    //            break;
    //        case 2:
    //            value = TeenFunction(text);
    //            break;
    //        case 3:
    //            value = HundredFunction(text);
    //            break;
    //        case 4 :
    //            value = ThousendFunction(text);
    //            break;
    //        case 5:
    //            value = TeenThousandFunction(text);
    //            break;
    //        case 6:
    //            value = HundredThousandFunction(text);
    //            break;
    //        case 7:
    //            value = MilionFunction(text);
    //            break;
    //        case 8:
    //            value = TeenMilionFunction(text);
    //            break;
    //    }
    //            break;

    //        case 1:

    //    return value;
    //}

    public string  NumberIsWords(string stramount)
    {
        string output;
        double amount;
        if (double.TryParse(stramount, out amount))
        {
            stramount = Math.Round(amount, 2).ToString("00.00");

            string fval = stramount.Substring(0, stramount.Length - 3);
            string sval = stramount.Substring(stramount.Length - 2);
            fval = GetNumberVal(fval);
            sval = GetNumberVal(sval);
            if (sval != "")
            {
                output = fval + " Rupees and " + sval + " Cents Only";
            }

            else
            {
                if (fval != "")
                {
                    output = fval + " Rupees Only";
                }
                else
                {
                    output = "";
                }

            }
        }
        else
        {
            output = "";
        }
        return output;
    }

    private string GetNumberVal(string text)
    {
        string value = "";

        switch (text.Length)
        {
            case 1:
                value = OneFunction(text);
                break;
            case 2:
                value = TeenFunction(text);
                break;
            case 3:
                value = HundredFunction(text);
                break;
            case 4:
                value = ThousendFunction(text);
                break;
            case 5:
                value = TeenThousandFunction(text);
                break;
            case 6:
                value = HundredThousandFunction(text);
                break;
            case 7:
                value = MilionFunction(text);
                break;
            case 8:
                value = TeenMilionFunction(text);
                break;
        }

        return value;
    }
    private string TeenMilionFunction(string text)
    {
        string value;
        if ((text.Substring(1, 1) != "0") && (text.Substring(0, 1) == "1"))
        {
            Teen = text.Substring(1, 1);
            value = Teen;
        }
        else
        {
            if (text.Substring(1, 1) != "0")
            {
                Ten = text.Substring(0, 1);
                value = Ten + " " + OneFunction(text.Substring(1, 1));
            }
            else
            {
                Ten = text.Substring(0, 1);
                value = Ten;
            }
        }

        if ((text.Substring(0, 1) != "0") && (text.Substring(1, 1) == "0") && (text.Substring(2, 1) == "0") && (text.Substring(3, 1) == "0") && (text.Substring(4, 1) == "0"))
        {
            value = value + " Million " + HundredFunction(text.Substring(5, 3));
        }
        else
        {
            if ((text.Substring(0, 1) != "0") && ((text.Substring(2, 1) != "0") || (text.Substring(3, 1) != "0") || (text.Substring(4, 1) != "0")))
            {
                value = value + " Million " + HundredFunction(text.Substring(2, 3)) + " Thousand " + HundredFunction(text.Substring(5, 3));
            }
            else
            {
                if ((text.Substring(0,1) != "0") && ((text.Substring(2,1) =="0") || (text.Substring(3,1) =="0") || (text.Substring(4,1) =="0")))
                {
                    value = value + " Million " + HundredFunction(text.Substring(5,3));
                }
                else
                {

                   if ((text.Substring(4, 1) == "0") && (text.Substring(3, 1) == "0") && (text.Substring(2, 1) == "0") && (text.Substring(1, 1) == "0") && (text.Substring(0, 1) == "0"))
                    {
                       value = HundredFunction(text.Substring(5, 3));
                    }
                    else
                    {
                      if ((text.Substring(3, 1) == "0") && (text.Substring(2, 1) == "0") && (text.Substring(1, 1) == "0") && (text.Substring(0, 1) == "0"))
                      {
                            value = TeenFunction(text.Substring(3, 2)) + " Thousand " + HundredFunction(text.Substring(5, 3));
                      }
                      else
                        {
                        if ((text.Substring(2, 1) == "0") && (text.Substring(1, 1) == "0") && (text.Substring(0, 1) == "0"))
                        {
                            value = HundredFunction(text.Substring(2, 3)) + " Thousand " + HundredFunction(text.Substring(5, 3));
                        }
                        else
                        {
                            if ((text.Substring(1, 1) == "0") && (text.Substring(0, 1) == "0"))
                            {
                                value = value + " " + HundredFunction(text.Substring(2, 3)) + " Thousand " + HundredFunction(text.Substring(5, 3));
                            }
                            else
                            {
                                if (((text.Substring(0, 1) == "0") && (text.Substring(2, 1) == "0") && (text.Substring(3, 1) == "0") && (text.Substring(4, 1) == "0")))
                                {
                                    value = value + " Million " + HundredFunction(text.Substring(5, 3));
                                }
                                else
                                {
                                    value = value + " Million " + HundredFunction(text.Substring(2, 3)) + "Thousand " + HundredFunction(text.Substring(5, 3));
                                }
                            }
                        }
                    }
            
                 }
                
              }
         }
   }
   return value;
   }

    private string MilionFunction(string text)
    {
        One = text.Substring(0, 1);
        string value = One;

        if ((text.Substring(0, 1) != "0") && (text.Substring(1, 1) == "0") && (text.Substring(2, 1) == "0") && (text.Substring(3, 1) == "0"))
        {
            value = value + " Million " + HundredFunction(text.Substring(4, 3));
        }
        else
        {
            if ((text.Substring(0, 1) != "0") && ((text.Substring(1, 1) != "0") || (text.Substring(2, 1) != "0") || (text.Substring(3, 1) != "0")))
            {
                value = value + " Million " + HundredFunction(text.Substring(1, 3)) + " Thousand " + HundredFunction(text.Substring(4, 3));
            }
            else
            {
                if ((text.Substring(3, 1) == "0") && (text.Substring(2, 1) == "0") && (text.Substring(1, 1) == "0") && (text.Substring(0, 1) == "0"))
                {
                    value = HundredFunction(text.Substring(4, 3));
                }
                else
                {
                    if ((text.Substring(2, 1) == "0") && (text.Substring(1, 1) == "0") && (text.Substring(0, 1) == "0"))
                    {
                        value = OneFunction(text.Substring(3, 1)) + " Thousand " + HundredFunction(text.Substring(4, 3));
                    }
                    else
                        {
                            if ((text.Substring(1, 1) == "0") && (text.Substring(0, 1) == "0"))
                            {
                                value = TeenFunction(text.Substring(2, 2)) + " Thousand " + HundredFunction(text.Substring(4, 3));
                            }
                            else
                                {
                                    if (text.Substring(0, 1) == "0")
                                    {
                                        value = HundredFunction(text.Substring(1, 3)) + " Thousand " + HundredFunction(text.Substring(4, 3));
                                    }
                            }
                    }
                }
            }
        }
        return value;
    }

    private string HundredThousandFunction(string text)
    {
        One = text.Substring(0, 1);
        string value = One;

        string a = text.Substring(0, 1);
        string b = text.Substring(1, 1);
        string c = text.Substring(2, 1);


        if ((text.Substring(0, 1) != "0") && (text.Substring(1,1) == "0") && (text.Substring(2,1) == "0"))
        {
            value = HundredFunction(text.Substring(0, 3)) + " Thousand " + HundredFunction(text.Substring(3, 3));
        }
        else
        {
            if ((text.Substring(0, 1) != "0") && (text.Substring(1, 1) == "0") && (text.Substring(2,1) !="0"))
            {
                value = value + " Hundred " + TeenFunction(text.Substring(1, 2)) + " Thousand " + HundredFunction(text.Substring(3, 3));
            }
            else
            {
                if ((text.Substring(0, 1) != "0") && (text.Substring(1, 1) != "0"))
                {
                    value = value + " Hundred " + TeenFunction(text.Substring(1, 2)) + " Thousand " + HundredFunction(text.Substring(3, 3));
                }
                else
                {
                    if ((text.Substring(2, 1) == "0") && (text.Substring(1, 1) == "0") && (text.Substring(0, 1) == "0"))
                        value = HundredFunction(text.Substring(3, 3));
                    else
                    {
                        if ((text.Substring(1, 1) == "0") && (text.Substring(0, 1) == "0"))
                            value = value + " Thousand " + HundredFunction(text.Substring(3, 3));
                        else
                        {
                            if (text.Substring(0, 1) == "0")
                                value = TeenFunction(text.Substring(1, 2)) + " Thousand " + HundredFunction(text.Substring(3, 3));
                        }
                    }
                }

            }
        }
        return value;
    }
   
    private string TeenThousandFunction(string text)
    {
       string value;
       if ((text.Substring(1, 1) != "0") && (text.Substring(0,1) == "1"))
       {
       Teen = text.Substring(1, 1);
       value = Teen;
       }
       else
       {
          if (text.Substring(1, 1) != "0")
          {
          Ten = text.Substring(0, 1);
          value = Ten + " " + OneFunction(text.Substring(1, 1));
          }
          else
          {
          Ten = text.Substring(0, 1);
          value = Ten;
          }
       }
              if (text.Substring(0, 1) != "0")
              {
              value = value + " Thousand " + HundredFunction(text.Substring(2, 3));
              }
               else
              {
                  if ((text.Substring(2, 1) == "0") && (text.Substring(1, 1) == "0") && (text.Substring(0, 1) == "0"))
                  value = TeenFunction(text.Substring(3, 2));
                  else
                  {
                     if ((text.Substring(1, 1) == "0") && (text.Substring(0, 1) == "0"))
                     value = HundredFunction(text.Substring(2, 3));
                     else
                     {
                         if (text.Substring(0, 1) == "0")
                         value = value + " Thousand " + HundredFunction(text.Substring(2, 3));
                      }
                 }
              }
        return value;
    }

    private string ThousendFunction(string text)
    {
        One = text.Substring(0, 1);
        string value = One;
        if (text.Substring(0, 1) != "0")
        {
            value = value + " Thousand " + HundredFunction(text.Substring(1, 3));
        }
        else
        {
            if (text.Substring(0, 1) == "0")
            {
                value = HundredFunction(text.Substring(1, 3));
            }
            else
            {
                if (text.Substring(3, 1) == "0")
                {

                    value = value + "Thousand";
                }
                else
                    if ((text.Substring(0, 1)) == "0")
                        value = HundredFunction(text.Substring(1, 3));
                    else
                    {
                    }
                {
                    value = Ten + " Thousand " + OneFunction(text.Substring(3, 1));
                }
            }
        }
        return value;
    }

    private string HundredFunction(string text)
    {
        One = text.Substring(0, 1);
        string value= One;
        
            if ((text.Substring(0, 1) != "0"))
            {
               value = OneFunction(text.Substring(0, 1)) + " Hundred ";
               if ((text.Substring(0, 1) != "0") && (text.Substring(0, 2) != "0"))
               {
                   //One = text.Substring(0, 1);
                   value = value + TeenFunction(text.Substring(1, 2));
                   if ((text.Substring(0, 1) != "0") && (text.Substring(0, 2) != "0") && (text.Substring(0, 3) != "0"))
                   {
                       value = value;
                   }
            }
        }

        else
        {
            if (text.Substring(0, 1) == "0")
            {
                value = TeenFunction(text.Substring(1, 2));
            }
            else
            {
                if (text.Substring(2, 1) == "0")
                {
                    value ="";
                }
                else
                {
                    value = TeenFunction(text.Substring(0,3));                 
                }
            }
        }

        return value;
    }


    private string TeenFunction(string text)
    {
        string value;
        if (text.Substring(1, 1) == "0")
        {
            Ten = text.Substring(0, 1);
            value = Ten;
        }
        else
        {
            if (text.Substring(0, 1) == "1")
            {
                Teen = text.Substring(1, 1);
                value = Teen;
            }
            else
            {
                Ten = text.Substring(0, 1);
                One = text.Substring(1, 1);
                value = Ten + " " + One;
            }
        }
        return value;
    }

    private string OneFunction(string text)
    {
        One = text;
        return One;
    }

   
}
   


