using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// Summary description for AppTrack
/// </summary>
public class AppTrackClass
{

    private SqlConnection sqlConn;
    SqlCommand sqlCmd;
    SqlDataReader sqlDataReader;
    SqlDataAdapter sqldataAdapter;
    DataTable dt;
    DataWorksClass dw;

    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();
    string _errmessage;
	public AppTrackClass()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    //Get Customer Details
    public DataTable GetCustomerRecords(string appno, string holdertype)
    {
        string sqlSelect = @"SELECT distinct m.Nicno as NicNo,
                             RTRIM(Initials) +' ' +RTRIM(Surname) AS FullName,RTRIM(Location)+RTRIM(street)+RTRIM(city) AS fulladdress,
                            RecvDate,
                            case appcat
                            when 'N' then 'Normal'
                            else 'Express' end as AppCategory,
                            cr.crdes as CrDes,
                            case h.IsAdditional
                            WHEN 'Y' then 'Additional Loan'
                            else '' End as AdditionalType, CrAmt
                            FROM crapp cap, crcategory cr,appholder h,customermain m,
                            crpurpose cp WHERE cap.appno=@appno and
                            cap.crcatcode=cr.crcatcode and
                            cap.appno=h.appno and h.nicno=m.nicno
                            and h.holdertype=@holdertype";

        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);

        sqldataAdapter.SelectCommand.Parameters.AddWithValue("appno", appno);
        sqldataAdapter.SelectCommand.Parameters.AddWithValue("holdertype", holdertype);
        dt = new DataTable();

        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return dt;

    }

    //Get Customer Details
    public DataTable GetJobRecords()
    {
        string sqlSelect = @"select JobDesc, jobcode from JobListing order by joborder";

        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);

         dt = new DataTable();

        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return dt;

    }

    //Get Customer Details
    public DataTable GetEmployee()
    {
        string sqlSelect = @"select empno, empname from employee where status='A' order by empname";

        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);

        dt = new DataTable();

        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return dt;

    }


    public int InsertJobRecord(string AppNo, int JobCode, DateTime startDate, int ProcessingOfficer1, string AddUser, DateTime AddDate,
                               string AddRemarks, string NicNo, string bondNo,DateTime bondsigndate,
                               string TransferDeedNo, string Safeno, int loctionid, int insuranceid)
    {
        SqlTransaction sqlTrans;
        string sqlInsert;
        sqlInsert = @"INSERT INTO JobRecord (
                    AppNo,JobCode,startDate,ProcessingOfficer1,AddUser,AddDate,AddRemarks,NicNo,
                    BondNo,BondSignDate,TransDeedNo,SafeNo,LocationID,InsuranceCoID)
            values (@AppNo,@JobCode,@startDate,@ProcessingOfficer1,@AddUser,@AddDate,@AddRemarks,@NicNo,
                    @bondNo,@bondsigndate,@TransferDeedNo,@Safeno,@loctionid,@insuranceid)";

        sqlConn = new SqlConnection(constring);
        sqlCmd = new SqlCommand(sqlInsert, sqlConn);


        sqlCmd.Parameters.AddWithValue("AppNo", AppNo);
        sqlCmd.Parameters.AddWithValue("JobCode", JobCode);
        sqlCmd.Parameters.AddWithValue("startDate", startDate);
        sqlCmd.Parameters.AddWithValue("ProcessingOfficer1", ProcessingOfficer1);
        sqlCmd.Parameters.AddWithValue("AddUser", AddUser);
        sqlCmd.Parameters.AddWithValue("AddDate", AddDate);
        sqlCmd.Parameters.AddWithValue("AddRemarks", AddRemarks);
        sqlCmd.Parameters.AddWithValue("NicNo", NicNo);
        sqlCmd.Parameters.AddWithValue("bondNo", bondNo);
        sqlCmd.Parameters.AddWithValue("bondsigndate", bondsigndate);
        sqlCmd.Parameters.AddWithValue("TransferDeedNo", TransferDeedNo);
        sqlCmd.Parameters.AddWithValue("Safeno", Safeno);
        sqlCmd.Parameters.AddWithValue("loctionid", loctionid);
        sqlCmd.Parameters.AddWithValue("insuranceid", insuranceid);

      
        int rowAdded = 0;
       
        try
        {
            sqlConn.Open();
            rowAdded = sqlCmd.ExecuteNonQuery();
        }

        catch (Exception err)
        {

           //
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return rowAdded;
    }

    public DataSet GetSendDate(string appno, int jobcode)
    {
        string sql = " SELECT * FROM JobRecord J, Employee E " +
                     " WHERE AppNo=" + appno + " " +
                     " AND JobCode=" + jobcode + " " +
                     " AND ProcessingOfficer1=E.EmpNo";

        SqlConnection sqlConn = new SqlConnection(constring);
        DataSet ds = new DataSet();
        SqlDataAdapter da = new SqlDataAdapter(sql, sqlConn);
        try
        {
            sqlConn.Open();
            da.Fill(ds, sql);
        }
        catch (Exception er)
        {

        }
        finally
        {
            da.Dispose();
            sqlConn.Close();
        }

        return ds;

    }

    public DataSet UpdateAppTrackDetails(string appno, int jobcode, DateTime recvDate, 
                                         string editUser, string EditRemarks, DateTime editDate)
    {
        string sql = " UPDATE JobRecord SET EndDate='" + recvDate + "', EditRemarks='" + EditRemarks + "', " +
                     " EditUser='" + editUser + "', EditDate='"+editDate+"' WHERE AppNo=" + appno + "" +
                     " AND JobCode=" + jobcode + "";
        SqlConnection sqlConn = new SqlConnection(constring);
        DataSet ds = new DataSet();
        SqlDataAdapter da = new SqlDataAdapter(sql, sqlConn);
        try
        {
            sqlConn.Open();
            da.Fill(ds, sql);
        }
        catch (Exception er)
        {

        }
        finally
        {
            da.Dispose();
            sqlConn.Close();
        }

        return ds;
    }


    public DataTable GetAllJobs(string AppNo)
    {
        string sqlSelect = @"select jr.startdate AS [Start Date],jr.enddate as [End Date] , 
                             jl.jobdesc as [Job Description], e.empname as [Responsible Person], 
                             addremarks [Assign Reamrks], editremarks as [Completion Remarks], 
                            jr.AddUser AS [TaskAdd User], jr.EditUser AS [Task End User] 
                            from JobRecord jr ,JobListing jl, Employee e
                            where jr.jobcode=jl.jobcode and 
                            e.empno = jr.ProcessingOfficer1 and
                            jr.AppNo=@AppNo";

        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);

        sqldataAdapter.SelectCommand.Parameters.AddWithValue("AppNo", AppNo);

        dt = new DataTable();

        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {

        }
        finally
        {
            sqlConn.Close();
        }

        return dt;
    }

    public DataTable GetIncompletionJobDescription(string AppNo)
    {
        string sqlSelect = @"select jr.startdate,jr.enddate , jl.jobdesc as [Job Description], e.empname as [Employer Name], 
                            addremarks [Assign Reamrks], editremarks as [Completion Remarks]
                            from JobRecord jr ,JobListing jl, Employee e
                            where jr.jobcode=jl.jobcode and 
                            e.empno = jr.ProcessingOfficer1 and
                            jr.AppNo=@AppNo and 
                            enddate is null";

        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);

        sqldataAdapter.SelectCommand.Parameters.AddWithValue("AppNo", AppNo);

        dt = new DataTable();

        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {

        }
        finally
        {
            sqlConn.Close();
        }

        return dt;
    }

    public DataSet UpdateEnteredDetails(string appno, int jobcode, DateTime startDate, DateTime endDate,
                                        int processingOfficer, string editUser, DateTime editDate, 
                                        string bondno, DateTime signdate, string safeno,
                                        string deedno, int locid, int insuranceid)
    {
        string sql = " UPDATE JobRecord SET StartDate='" + startDate + "', EndDate='"+endDate+"', "+
                     " ProcessingOfficer1=" + processingOfficer + ", EditUser='"+editUser+"', "+
                     " EditDate='" + editDate + "', BondNo='"+bondno+"', BondSignDate='"+signdate+"', "+
                     " SafeNo='" + safeno + "', TransDeedNo='" + deedno + "', LocationID="+locid+", " +
                     " InsuranceCoID="+insuranceid+" WHERE AppNo=" + appno + " AND JobCode=" + jobcode + "";
        SqlConnection sqlConn = new SqlConnection(constring);
        DataSet ds = new DataSet();
        SqlDataAdapter da = new SqlDataAdapter(sql, sqlConn);
        try
        {
            sqlConn.Open();
            da.Fill(ds, sql);
        }
        catch (Exception er)
        {

        }
        finally
        {
            da.Dispose();
            sqlConn.Close();
        }

        return ds;
    }

    //Vihanga 2008-11-19

    public DataTable GetJobRecord()
    {
        string Error;
        string SqlSelect;

        SqlSelect = @"select * from JobListing order by JobOrder";

        SqlConnection SqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(SqlSelect, SqlConn);

        dt = new DataTable();

        try
        {
            SqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            Error = er.Message;
        }
        finally
        {
            SqlConn.Close();
        }

        return dt;
    }

    public DataTable GetEmployeeRecord()
    {
        string Error;
        string SqlSelect;

        SqlSelect = @"select * from Employee";

        SqlConnection SqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(SqlSelect, SqlConn);

        dt = new DataTable();

        int a = dt.Rows.Count;

        try
        {
            SqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            Error = er.Message;
        }
        finally
        {
            SqlConn.Close();
        }

        return dt;
    }

    public DataTable GetDetailsAccordingToJob(int JobCode, DateTime sStartDate, DateTime eStartDate)
    {
        string error;
        string SqlSelect;

        SqlSelect = @"select jr.AppNo,jl.JobDesc,e.EmpName As ResponsiblePerson,jr.StartDate,
                        jr.EndDate,BondNo,TransDeedNo,BondSignDate,jr.AddRemarks,jr.EditRemarks,
                        I.InsuranceCompany
                        from JobRecord jr inner join JobListing jl on jl.JobCode=jr.JobCode
                        inner join  Employee e on e.EmpNo=jr.ProcessingOfficer1 left join InsuranceCompany I
                        on jr.InsuranceCoID = I.InsuranceCoID
                        where  jl.JobCode=@JobCode and jr.StartDate >= @sStartDate 
                        and jr.StartDate <= @eStartDate
                        order by jr.AppNo";

        SqlConnection SqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(SqlSelect, SqlConn);

        sqldataAdapter.SelectCommand.Parameters.AddWithValue("JobCode", JobCode);
        sqldataAdapter.SelectCommand.Parameters.AddWithValue("sStartDate", sStartDate);
        sqldataAdapter.SelectCommand.Parameters.AddWithValue("eStartDate", eStartDate);

        dt = new DataTable();

        int a = dt.Rows.Count;

        try
        {
            SqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            error = er.ToString();
        }
        finally
        {
            SqlConn.Close();
        }

        return dt;
    }

    public DataTable GetDetailsAccordingToJobCode(int JobCode, DateTime sStartDate, DateTime eStartDate)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select jr.AppNo,jl.JobDesc,e.EmpName As ResponsiblePerson,jr.StartDate,
                            jr.EndDate,BondNo,TransDeedNo,BondSignDate,jr.AddRemarks,jr.EditRemarks,
                            I.InsuranceCompany
                            from JobRecord jr inner join JobListing jl on jl.JobCode=jr.JobCode
                            inner join Employee e on e.EmpNo=jr.ProcessingOfficer1 left join
                            InsuranceCompany I on jr.InsuranceCoID = I.InsuranceCoID
                            where  jl.JobCode=@JobCode and jr.StartDate >= @sStartDate 
                            and jr.StartDate <= @eStartDate order by e.EmpName");
        dw.SetDataAdapterParameters("JobCode", JobCode);
        dw.SetDataAdapterParameters("sStartDate", sStartDate);
        dw.SetDataAdapterParameters("eStartDate", eStartDate);
        return dw.GetDataTable();
    }



    public DataTable GetDetailsAccordingToEmployee(int EmpNo, DateTime sStartDate, DateTime eStartDate)
    {
        string error;
        string SqlSelect;

        SqlSelect = @"select jr.AppNo,jl.JobDesc,e.EmpName as ResponsiblePerson,jr.StartDate,jr.EndDate,
                        BondNo,TransDeedNo,BondSignDate,jr.AddRemarks,jr.EditRemarks,I.InsuranceCompany
                        from JobRecord jr inner join JobListing jl on jl.JobCode=jr.JobCode
                        inner join  Employee e on e.EmpNo=jr.ProcessingOfficer1 left join 
                        InsuranceCompany I on jr.InsuranceCoID = I.InsuranceCoID
                        where e.EmpNo=@EmpNo and jr.StartDate >= @sStartDate and jr.StartDate <= @eStartDate
                        order by jr.AppNo";

        SqlConnection SqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(SqlSelect, SqlConn);

        sqldataAdapter.SelectCommand.Parameters.AddWithValue("EmpNo", EmpNo);
        sqldataAdapter.SelectCommand.Parameters.AddWithValue("sStartDate", sStartDate);
        sqldataAdapter.SelectCommand.Parameters.AddWithValue("eStartDate", eStartDate);

        dt = new DataTable();

        int a = dt.Rows.Count;

        try
        {
            SqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            error = er.ToString();
        }
        finally
        {
            SqlConn.Close();
        }

        return dt;
    }

    public DataTable LoadInsuranceCompany()
    {
        string Error;
        string sql = " SELECT * FROM InsuranceCompany";
        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sql, sqlConn);

        dt = new DataTable();

        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            Error = er.Message;
        }
        finally
        {
            sqlConn.Close();
        }

        return dt;

    }

    public DataTable LoadLoaction()
    {
        string Error;
        string sql = " SELECT * FROM DocLocation";
        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sql, sqlConn);

        dt = new DataTable();

        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            Error = er.Message;
        }
        finally
        {
            sqlConn.Close();
        }

        return dt;
    }

    public DataTable GetApplicantDetails(string appno)
    {
        string Error;
        string sql = @"SELECT m.NicNo AS NicNo, RTRIM(Initials)+RTRIM(Surname) AS FullName,
                      RTRIM(Location) + RTRIM(Street) + RTRIM(City) As Address 
                      FROM AppHolder a, CustomerMain m WHERE a.appno=@appno 
                      AND a.nicno=m.nicno";
        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sql, sqlConn);

        sqldataAdapter.SelectCommand.Parameters.AddWithValue("appno", appno);

        dt = new DataTable();

        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            Error = er.Message;
        }
        finally
        {
            sqlConn.Close();
        }

        return dt;
    }

    public string JobAccessCode(int JobCode)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select AccessCode from JobListing where JobCode=@JobCode");
        dw.SetSqlCommandParameters("JobCode", JobCode);
        return dw.GetSingleData();
    }

}