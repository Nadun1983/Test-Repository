using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// Summary description for CheckListClass
/// </summary>
public class CheckListClass
{
	public CheckListClass()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    private SqlConnection sqlConn;
    SqlCommand sqlCmd;
    SqlDataReader sqlDataReader;
    SqlDataAdapter sqldataAdapter;
    DataTable dt;

    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString;
    string _errmessage;


    //Get Possible Check List
    public DataTable GetPossibleCheckList(int catpurposeid, string custCat)
    {
        string sqlSelect = @"select distinct cl.chklistno,  cl.[description]  from Checklist cl, 
                            ChkDetails cd
                            where cl.chklistno = cd.chklistno and
	                        cd.catpurposeid = @catpurposeid and 
                            cd.CustomerCategory = @CustomerCategory";
        
        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);

        sqldataAdapter.SelectCommand.Parameters.AddWithValue("catpurposeid", catpurposeid);     
        sqldataAdapter.SelectCommand.Parameters.AddWithValue("CustomerCategory", custCat);

        dt = new DataTable();

        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return dt;

    }

    // Get the Factore of Charge

    public bool CheckIsrecordExsits(string NICNo, int chklistno, bool IsLatest)
    {
        int rowadded = 0;
        string sqlSelect;
        int noofrec = 0;
        bool status;
        sqlSelect = @"select count(*) as noofrec from CustomerCheckList where
                      nicno = @nicno and chklistno = @chklistno and IsLatest = @IsLatest";

        sqlConn = new SqlConnection(constring);

        sqlCmd = new SqlCommand(sqlSelect, sqlConn);
        sqlCmd.Parameters.AddWithValue("nicno", NICNo);
        sqlCmd.Parameters.AddWithValue("chklistno", chklistno);
        sqlCmd.Parameters.AddWithValue("IsLatest", IsLatest);


        try
        {
            sqlConn.Open();
            sqlDataReader = sqlCmd.ExecuteReader();
            sqlDataReader.Read();
            if (sqlDataReader.HasRows == true)
            {
                noofrec = int.Parse(sqlDataReader["noofrec"].ToString());
            }
            else
            {

            }
            sqlDataReader.Close();

        }

        catch (Exception err)
        {
            this._errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
        }

        if (noofrec == 0)
            status = true;
        else
            status = false;

        return status;

    }

    // Insert Cust Check List
    public int InsertPossibleCheckList(string nicno, int chklistno, bool IsLatest, string DocumentStatus)
    {
       string sqlInsert;

       sqlInsert = @"INSERT INTO CustomerCheckList(nicno, chklistno, IsLatest, DocumentStatus)
                      VALUES (@nicno, @chklistno, @IsLatest, @DocumentStatus)";

        sqlConn = new SqlConnection(constring);
        sqlCmd = new SqlCommand(sqlInsert, sqlConn);

        sqlCmd.Parameters.AddWithValue("nicno", nicno);
        sqlCmd.Parameters.AddWithValue("chklistno", chklistno);
        sqlCmd.Parameters.AddWithValue("IsLatest", IsLatest);
        sqlCmd.Parameters.AddWithValue("DocumentStatus", DocumentStatus);

        int rowAdded = 0;


        try
        {
            sqlConn.Open();
            rowAdded = sqlCmd.ExecuteNonQuery();
        }

        catch (Exception err)
        {

         
            //_errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return rowAdded;
    }



    //Get Possible Payments
    public DataTable GetPaymentMade(string appno)
    {
        string sqlSelect = @"select  pm.PaymentTypeID, pt.Description, pm.amount, pm.ConfirmPayment  
                             from paymentmade pm, paymenttype pt
                             where pm.PaymentTypeID = pt.PaymentTypeID and pm.appno = @appno
                             and pm.ispaid = 0 ";

        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);

        sqldataAdapter.SelectCommand.Parameters.AddWithValue("AppNo", appno);

        dt = new DataTable();

        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return dt;

    }


    // Update Payment made with new values
    public int UpdatePaymentMade(string appno, int paymenttypeid, bool ispaid, decimal amount)
    {
        string sqlUpdate;

        sqlUpdate = @"update paymentmade set IsPaid=@IsPaid, Amount = @Amount where 
                       PaymentTypeId=@PaymentTypeId and appno = @OriginalAppNo";

        sqlConn = new SqlConnection(constring);
        sqlCmd = new SqlCommand(sqlUpdate, sqlConn);

        sqlCmd.Parameters.AddWithValue("IsPaid", ispaid);
        sqlCmd.Parameters.AddWithValue("Amount", amount);
        sqlCmd.Parameters.AddWithValue("OriginalAppNo", appno);

        int rowAdded = 0;
        
        try
        {
            sqlConn.Open();

            rowAdded = sqlCmd.ExecuteNonQuery();

        }

        catch (Exception err)
        {


            _errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return rowAdded;
    }


    //Get Possible Payments
    public DataTable GetPaymentMade(string appno, bool ConfirmPayment)
    {
        string sqlSelect = @"select pm.ConfirmPayment, pm.PaymentTypeID, pt.Description, pm.amount, pm.ConfirmPayment  
                             from paymentmade pm, paymenttype pt
                             where pm.PaymentTypeID = pt.PaymentTypeID and pm.appno = @appno
                             and ConfirmPayment = @ConfirmPayment ";

        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);

        sqldataAdapter.SelectCommand.Parameters.AddWithValue("AppNo", appno);
        sqldataAdapter.SelectCommand.Parameters.AddWithValue("ConfirmPayment", ConfirmPayment);
        dt = new DataTable();

        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return dt;

    }

    // Update PaymentType confirmation
    public int UpdateConfirmPayment(string appno, int paymenttypeid, bool confirmPayment)
    {
        string sqlUpdate;

        sqlUpdate = @"update paymentmade set ConfirmPayment=@ConfirmPayment where 
                       appno = @OriginalAppNo and PaymentTypeId = @PaymentTypeId";

        sqlConn = new SqlConnection(constring);
        sqlCmd = new SqlCommand(sqlUpdate, sqlConn);

        sqlCmd.Parameters.AddWithValue("OriginalAppNo", appno);
        sqlCmd.Parameters.AddWithValue("ConfirmPayment", confirmPayment);
        sqlCmd.Parameters.AddWithValue("PaymentTypeId", paymenttypeid);

        int rowAdded = 0;

        try
        {
            sqlConn.Open();

            rowAdded = sqlCmd.ExecuteNonQuery();

        }

        catch (Exception err)
        {


            _errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return rowAdded;
    }



    // Get the Factore of Charge

    public decimal GetFactor(int paymentTypeID, string type, decimal crAmt)
    {
        int rowadded = 0;
        string sqlSelect;
        decimal factor = 0;
        sqlSelect = @"select max(factor) as factor from parameterrange where paymentTypeid =@paymentTypeid
                      and type=@type  and (range < @amount)    ";

        sqlConn = new SqlConnection(constring);

        sqlCmd = new SqlCommand(sqlSelect, sqlConn);
        sqlCmd.Parameters.AddWithValue("paymentTypeid", paymentTypeID);
        sqlCmd.Parameters.AddWithValue("type", type);
        sqlCmd.Parameters.AddWithValue("amount", crAmt);


        try
        {
            sqlConn.Open();
            sqlDataReader = sqlCmd.ExecuteReader();
            sqlDataReader.Read();
            if (sqlDataReader.HasRows == true)
            {
                factor = decimal.Parse(sqlDataReader["factor"].ToString());
            }
            else
            {
                
            }
            sqlDataReader.Close();

        }

        catch (Exception err)
        {
            this._errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
        }

        return factor;

    }


    // Generate A file No
    public decimal GetCrAmt(string appno)
    {
        int rowadded = 0;
        string sqlSelect;
        decimal cramt = 0;
        sqlSelect = @"SELECT CrAmt from CrApp where AppNo = @AppNo";

        sqlConn = new SqlConnection(constring);

        sqlCmd = new SqlCommand(sqlSelect, sqlConn);
        sqlCmd.Parameters.AddWithValue("AppNo", appno);


        try
        {
            sqlConn.Open();
            sqlDataReader = sqlCmd.ExecuteReader();
            sqlDataReader.Read();
            if (sqlDataReader.HasRows == true)
            {
                cramt = decimal.Parse(sqlDataReader["CrAmt"].ToString());
            }
            else
            {

            }
            sqlDataReader.Close();

        }

        catch (Exception err)
        {
            this._errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
        }

        return cramt;

    }

    // Update PaymentType confirmation
    public int UpdatePaymentMade(string appno, int paymenttypeid, bool ispaid)
    {
        string sqlUpdate;

        sqlUpdate = @"update PaymentMade set ispaid=@ispaid where 
                       appno = @OriginalAppNo and PaymentTypeId = @PaymentTypeId";

        sqlConn = new SqlConnection(constring);
        sqlCmd = new SqlCommand(sqlUpdate, sqlConn);

        sqlCmd.Parameters.AddWithValue("OriginalAppNo", appno);
        sqlCmd.Parameters.AddWithValue("ispaid", ispaid);
        sqlCmd.Parameters.AddWithValue("PaymentTypeId", paymenttypeid);

        int rowAdded = 0;

        try
        {
            sqlConn.Open();

            rowAdded = sqlCmd.ExecuteNonQuery();

        }

        catch (Exception err)
        {


            _errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return rowAdded;
    }

    //Get Possible Check List
    public DataTable GetLoanTypes()
    {
        string sqlSelect = @"select * from CrCategory";

        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);

  
        dt = new DataTable();

        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return dt;

    }

    //Get Possible Check List
    public DataTable GetCategory(int crcatcode)
    {
        string sqlSelect = @"select cp.Purposecode, cp.Descrip  
                            from CrPurpose cp, CrCategory cc, CrCatPurpose ccp
                            where cc.crcatcode = ccp.crcatcode and
                            ccp.purposecode = cp.purposecode
                            and cc.crcatcode = @crcatcode
                            order by cp.Purposecode  ";

        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);

        sqldataAdapter.SelectCommand.Parameters.AddWithValue("crcatcode", crcatcode);


        dt = new DataTable();
        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return dt;

    }


    // Generate A file No
    public int GetCatpurPoseId(int crcatcode, int purposecode)
    {
        int rowadded = 0;
        string sqlSelect;
        int catpurposeid = 0;
        sqlSelect = @"select catpurposeid from CrCatPurpose
                        where crcatcode = @crcatcode and purposecode = @purposecode";

        sqlConn = new SqlConnection(constring);

        sqlCmd = new SqlCommand(sqlSelect, sqlConn);
        sqlCmd.Parameters.AddWithValue("crcatcode", crcatcode);
        sqlCmd.Parameters.AddWithValue("purposecode", purposecode);

        try
        {
            sqlConn.Open();
            sqlDataReader = sqlCmd.ExecuteReader();
            sqlDataReader.Read();
            if (sqlDataReader.HasRows == true)
            {
                catpurposeid = int.Parse(sqlDataReader["catpurposeid"].ToString());
            }
            else
            {

            }
            sqlDataReader.Close();

        }

        catch (Exception err)
        {
            this._errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
        }

        return catpurposeid;

    }

    //Select Customer Cat
    public string GetCustCat(string nicno)
    {
        int rowadded = 0;
        string sqlSelect;
        string cuscat = "";
        sqlSelect = @"select CustomerCat from customersub where nicno = @nicno";

        sqlConn = new SqlConnection(constring);

        sqlCmd = new SqlCommand(sqlSelect, sqlConn);
        sqlCmd.Parameters.AddWithValue("nicno", nicno);

        try
        {
            sqlConn.Open();
            sqlDataReader = sqlCmd.ExecuteReader();
            sqlDataReader.Read();
            if (sqlDataReader.HasRows == true)
            {
                cuscat = sqlDataReader["CustomerCat"].ToString();
            }
            else
            {

            }
            sqlDataReader.Close();

        }

        catch (Exception err)
        {
            this._errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
        }

        return cuscat;

    }


   
       
    //Get Assigned Check List
    public DataTable GetCheckList(string nicno, string DocumentStatus)
    {
        string sqlSelect = @" select distinct cl.chklistno, cl.description, cd.NoOfcopies, 
                            rtrim(cm.Initials) + ' '+ rtrim(cm.Surname) as [Name]
                            from CustomerCheckList ccl , Checklist cl, CustomerMain cm, ChkDetails cd
                            where ccl.chklistno = cl.chklistno and
		                    cm.nicno = ccl.nicno and
		                    cd.chklistno = ccl.chklistno and
                            ccl.NicNo = @NicNo and DocumentStatus != @DocumentStatus";

        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);

        sqldataAdapter.SelectCommand.Parameters.AddWithValue("NicNo", nicno);
        sqldataAdapter.SelectCommand.Parameters.AddWithValue("DocumentStatus", DocumentStatus);

        dt = new DataTable();

        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return dt;

    }


    // Insert Application submission
    public int InsertAppSubmission(string nicno, string appno, int chklistno, string DocumentStatus, string NoOfcopies)
    {
        string sqlInsert;

        sqlInsert = @"INSERT INTO CustApplicationSubmission(nicno, appno, chklistno, DocumentStatus, NoOfcopies)
                      VALUES (@nicno, @appno, @chklistno, @DocumentStatus, @NoOfcopies)";

        sqlConn = new SqlConnection(constring);
        sqlCmd = new SqlCommand(sqlInsert, sqlConn);

        sqlCmd.Parameters.AddWithValue("nicno", nicno);
        sqlCmd.Parameters.AddWithValue("appno", appno);
        sqlCmd.Parameters.AddWithValue("chklistno", chklistno);
        sqlCmd.Parameters.AddWithValue("DocumentStatus", DocumentStatus);
            sqlCmd.Parameters.AddWithValue("NoOfcopies", NoOfcopies);
        int rowAdded = 0;


        try
        {
            sqlConn.Open();
            rowAdded = sqlCmd.ExecuteNonQuery();
        }

        catch (Exception err)
        {


            //_errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return rowAdded;
    }


    // Get LoanType
    public string SearchApp(string appno, string nicno)
    {
        string sqlSelect, _errmessage;
        
        sqlSelect = @"SELECT  appno from appholder where appno = @appno and nicno = @nicno";

        sqlConn = new SqlConnection(constring);

        sqlCmd = new SqlCommand(sqlSelect, sqlConn);
        sqlCmd.Parameters.AddWithValue("appno", appno);
        sqlCmd.Parameters.AddWithValue("nicno", nicno);

        try
        {
            sqlConn.Open();
            sqlDataReader = sqlCmd.ExecuteReader();
            sqlDataReader.Read();
            if (sqlDataReader.HasRows == true)
            {
                appno =sqlDataReader["appno"].ToString();
            }
            else
            {
                appno = "";
            }
            sqlDataReader.Close();

        }

        catch (Exception err)
        {
            _errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
        }

        return appno;

    }

    //Get Assigned Check List
    public DataTable GetCustomerCheckList(string nicno, string DocumentStatus) 
    {

        string sqlSelect = @"select distinct cl.chklistno, IsLatest, cl.description, cd.NoOfcopies   from 
                                Checklist cl, chkDetails cd, CustomerCheckList cc
                                where cl.chklistno = cd.chklistno and
                                cc.nicno = @nicno and DocumentStatus = @DocumentStatus";

        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);

        sqldataAdapter.SelectCommand.Parameters.AddWithValue("nicno", nicno);
        sqldataAdapter.SelectCommand.Parameters.AddWithValue("DocumentStatus", DocumentStatus);

        dt = new DataTable();

        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return dt;

    }

    public DataTable GetApplicationSubmission(string nicno, string appno, string DocumentStatus)
    {
        string sqlSelect = @"select distinct cl.chklistno, cl.description, cs.NoOfcopies   from 
                            Checklist cl, CustApplicationSubmission cs
                            where cl.chklistno = cs.chklistno and
                            cs.nicno = @nicno and 
                            cs.appno = @appno and
                            cs.DocumentStatus = @DocumentStatus";

        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);

        sqldataAdapter.SelectCommand.Parameters.AddWithValue("nicno", nicno);
        sqldataAdapter.SelectCommand.Parameters.AddWithValue("appno", appno);
        sqldataAdapter.SelectCommand.Parameters.AddWithValue("DocumentStatus", DocumentStatus);

        dt = new DataTable();

        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return dt;

    }


    public DataTable GetApplicationNo(string nicno)
    {
        string sqlSelect = @"select appno from appholder where nicno = @nicno";

        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);

        sqldataAdapter.SelectCommand.Parameters.AddWithValue("nicno", nicno);
       
        dt = new DataTable();

        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return dt;

    }


    // Update PaymentType confirmation
    public int UpdateDucumentSubmission(string appno, string nicno, string oldDocumentStatus, string newDocumentStatus)
    {
        string sqlUpdate;

        sqlUpdate = @"update  CustApplicationSubmission set DocumentStatus = @DocumentStatus
                        where appno = @OriginalAppNo and nicno = @OriginalNicNo and 
                         DocumentStatus = @OriginalDocumentStatus";

        sqlConn = new SqlConnection(constring);
        sqlCmd = new SqlCommand(sqlUpdate, sqlConn);

        sqlCmd.Parameters.AddWithValue("OriginalAppNo", appno);
        sqlCmd.Parameters.AddWithValue("OriginalNicNo", nicno);
        sqlCmd.Parameters.AddWithValue("DocumentStatus", newDocumentStatus);
        sqlCmd.Parameters.AddWithValue("OriginalDocumentStatus", oldDocumentStatus);

        int rowAdded = 0;

        try
        {
            sqlConn.Open();

            rowAdded = sqlCmd.ExecuteNonQuery();

        }

        catch (Exception err)
        {


            _errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return rowAdded;
    }
  
}
