using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;


/// <summary>
/// Summary description for Trans
/// </summary>
public class Trans
{
    private string constring = ConfigurationManager.ConnectionStrings["housdbString"].ToString();
    string oldconstring = ConfigurationManager.ConnectionStrings["oldhousdbString"].ConnectionString.ToString();
    DataWorksClass dw; // dataworks class
    LastSerialClass ls; // last serial class
    FunctionClass fc; // function class
    Recovery rc;
    string transno = "0";
    #region variables
    //
    string msg = "";
    string description = "";
    //
    private string loanno; // corresponding number
    private string user; // username
    private int paymentmode; // payment mode cash|transaction|...
    private int loancategory; // loancategory housing, auto ....
    private string branchcode; // relevent branch code
    int status; // status performing nonperformeing
    DateTime operationaldate; // operational date
    string time; // relevent time
    #endregion


    public string TransNo
    {
        get
        {
            return this.transno;
        }
    }


    public string Message
    {
        get
        {
            return this.msg;
        }
    }
    public Trans()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    //public void Transaction(string functionname, int loan, int loancategory, int extrafield, int paymentmode, 
    //    string loanno, string user, string branchcode, DateTime operationdate, string time)
    //{
    //    // setting internal variables
    //    this.loancategory = loancategory;
    //    this.loanno = loanno;
    //    this.user = user;
    //    this.paymentmode = paymentmode;
    //    this.operationaldate = operationdate;
    //    this.time = time;
    //    this.branchcode = branchcode;

    //    ls = new LastSerialClass();

    //    DataTable TaskT = new DataTable(); // relevent tasks table
    //    TaskT = GetTask(functionname); // get relevent task

    //    transno = ls.GetMaxNumber("TransNo", true).ToString(); // get the transaction number

    //    if (transno != "0") // transno can be taken
    //    {
    //        DataTable TransDataT = new DataTable(); // assign payments
    //        TransDataT = GetTransData(loanno, "N", "P", true, functionname); // get assigned payments

    //        if (TransDataT.Rows.Count == 0) // no recrds assigned
    //        {
    //            msg = "Error 0011";
    //            description = " | No payments to take";
    //            ls.UpdateLastSerialStatus("TransNo", true);
    //            msg = msg + description;
    //        }
    //        else
    //        {
    //            double totamt = 0;
    //            try
    //            {
    //                for (int i = 0; TransDataT.Rows.Count > i; i++)
    //                {
    //                    string trtype = TransDataT.Rows[i]["trtype"].ToString();
    //                    switch (trtype)
    //                    {
    //                        case "I":

    //                            totamt += double.Parse(TransDataT.Rows[i]["tramt"].ToString());
    //                            break;
    //                        case "E":
    //                            totamt -= double.Parse(TransDataT.Rows[i]["tramt"].ToString());
    //                            break;
    //                    }
    //                }
    //            }
    //            catch (Exception ex)
    //            {
    //                msg = "Error 0002";
    //                description = " | Error in assign amount";
    //                msg = msg + description;
    //            }

    //            string accsign;

    //            if (totamt < 0)
    //            {
    //                accsign = "DR";
    //                totamt = totamt * -1;
    //            }
    //            else
    //            {
    //                accsign = "CR";
    //            }


    //            if (InsertCrTransJrnl(transno, this.operationaldate, "A", loanno, accsign, totamt, this.user, DateTime.Now.TimeOfDay.ToString() /* this.time*/) != 0)
    //            {
    //                //
    //                int lineno = 0;
    //                for (int i = 0; TaskT.Rows.Count > i; i++)
    //                {
    //                    string taskid = TaskT.Rows[i]["taskid"].ToString();
    //                    DataTable TaskTransactionT = new DataTable();
    //                    TaskTransactionT = GetTransData(loanno, "N", "P", taskid, true);
    //                    for (int x = 0; TaskTransactionT.Rows.Count > x; x++)
    //                    {
    //                        if (TaskTransactionT.Rows.Count != 0)
    //                        {
    //                            double tramt = 0;
    //                            double assignamt = 0;
    //                            string refno1 = "0";
    //                            string trstatus = "", trtype = "";
    //                            try
    //                            {
    //                                tramt = double.Parse(TaskTransactionT.Rows[x]["tramt"].ToString());
    //                                assignamt = double.Parse(TaskTransactionT.Rows[x]["assignamt"].ToString());
    //                                trstatus = TaskTransactionT.Rows[x]["TrStatus"].ToString();
    //                                refno1 = TaskTransactionT.Rows[x]["refno"].ToString();
    //                                trtype = TaskTransactionT.Rows[x]["trtype"].ToString();
    //                                switch (loanno.Length)
    //                                {
    //                                    case 13:
    //                                        this.loancategory = GetLoanCategoryCode(loanno);
    //                                        if (taskid == "CAPD")
    //                                        {
    //                                            this.status = 1;//GetLoanStatusCode(loanno);
    //                                        }
    //                                        else
    //                                        {
    //                                            this.status = 0;
    //                                        }
    //                                        break;


    //                                    case 12:
    //                                        this.loancategory = GetLoanCategoryCode(loanno);
    //                                        if (taskid == "CAPD")
    //                                        {
    //                                            this.status = 1;//GetLoanStatusCode(loanno);
    //                                        }
    //                                        else
    //                                        {
    //                                            this.status = 0;
    //                                        }
    //                                        break;

    //                                    case 11:
    //                                        this.loancategory = 0;
    //                                        this.status = 0;
    //                                        break;
    //                                    case 10:
    //                                        this.loancategory = 0;
    //                                        this.status = 0;
    //                                        break;

    //                                }
    //                            }
    //                            catch (Exception ex)
    //                            {
    //                                msg = "Error 0040";
    //                                description = ex.Message;
    //                                ls.UpdateLastSerialStatus("TransNo", true);
    //                                IncativeCrTransJrnl(transno, "R");
    //                                msg = msg + description;
    //                            }

    //                            if (tramt > assignamt)
    //                            {
    //                                msg = "00002";
    //                                description = " | Unauthorised Transaction";
    //                                ls.UpdateLastSerialStatus("TransNo", true);
    //                                IncativeCrTransJrnl(transno, "R");
    //                                msg = msg + description;
    //                            }
    //                            else
    //                            {
    //                                if (tramt != assignamt)
    //                                {
    //                                    tramt = double.Parse(TaskTransactionT.Rows[i]["Amt"].ToString());
    //                                }
    //                                else
    //                                {
    //                                    if (double.Parse(TaskTransactionT.Rows[i]["Amt"].ToString()) != 0)
    //                                    {
    //                                        tramt = double.Parse(TaskTransactionT.Rows[i]["Amt"].ToString());
    //                                    }
    //                                }
    //                                switch (trstatus)
    //                                {
    //                                    case "N":
    //                                        if (tramt == assignamt)
    //                                        {
    //                                            trstatus = "F";
    //                                        }
    //                                        else
    //                                        {
    //                                            trstatus = "P";
    //                                            tramt = tramt;
    //                                        }
    //                                        break;

    //                                    case "P":
    //                                        if (tramt == assignamt)
    //                                        {
    //                                            double transtotal = GetPaidTrAmt(refno1);
    //                                            trstatus = "F";
    //                                            tramt = tramt - transtotal;
    //                                        }
    //                                        else
    //                                        {
    //                                            double transtotal = GetPaidTrAmt(refno1);
    //                                            trstatus = "P";
    //                                            tramt = tramt - transtotal;
    //                                        }
    //                                        break;

    //                                }
    //                                int rowadded = CallTrans(transno, taskid, loan, loancategory, status, paymentmode, tramt, trstatus, refno1, lineno, extrafield, trtype);

    //                                if (rowadded == 0)
    //                                {
    //                                    ls.UpdateLastSerialStatus("TransNo", true);
    //                                    IncativeCrTransJrnl(transno, "R");
    //                                    for (int q = 0; q < TaskTransactionT.Rows.Count; q++)
    //                                    {
    //                                        string refno = TaskTransactionT.Rows[q]["refno"].ToString();
    //                                        UpdateTransAssign(refno, 0, true);
    //                                    }
    //                                    InsertCrTransJrnl(transno, this.operationaldate, "C", loanno, accsign, totamt, this.user, DateTime.Now.TimeOfDay.ToString() /*this.time*/);
    //                                    CancelCrTranJrnl(transno, "C");
    //                                    transno = "0";
    //                                    msg = msg + description;
    //                                    break;
    //                                }
    //                                else
    //                                {
    //                                    lineno++;
    //                                }
    //                            }
    //                        }
    //                        else
    //                        {
    //                            // payment not assigned;
    //                        }
    //                    }
    //                }


    //                if (msg != "0003")
    //                {
    //                    switch (accsign)
    //                    {
    //                        case "CR":
    //                            accsign = "DR";
    //                            break;

    //                        case "DR":
    //                            accsign = "CR";
    //                            break;
    //                    }
    //                    InsertCrTransJrnl(transno, this.operationaldate, "A", loanno, accsign, totamt, this.user, DateTime.Now.TimeOfDay.ToString() /*this.time*/);
    //                    ls.UpdateLastserial("TransNo", long.Parse(transno) + 1);
    //                    msg = "Message 0001";
    //                    description = " | Peyments are completed Transaction Number is: " + transno;
    //                    msg = msg + description;
    //                }
    //                else
    //                {
    //                    msg = "Error in Updateing CrTrans " + dw.ErrMsg;
    //                    ls.UpdateLastSerialStatus("TransNo", true);
    //                    IncativeCrTransJrnl(transno, "R");
    //                }
    //            }
    //            else
    //            {
    //                msg = "Error 0003";
    //                description = "Error in Updateing Transaction jurnal " + dw.ErrMsg;
    //                ls.UpdateLastSerialStatus("TransNo", true);
    //                msg = msg + description;
    //            }
    //        }

    //    }
    //    else
    //    {
    //        msg = "Transaction is already initiate wait for 15 seconds";
    //    }
    //}


    private void SetLoanStatus(string loanno, string taskid, int crcat)
    {
        switch (loanno.Length)
        {
            case 13:
                if (taskid == "PSOC900000")
                {
                    this.loancategory = 0;
                    this.status = 0;
                }
                else
                {
                    this.loancategory = GetLoanCategoryCode(loanno);
                    if (taskid == "CAPD")
                    {
                        this.status = GetLoanStatusCode(loanno);
                    }
                    else
                    {
                        this.status = 0;
                    }
                }
                break;


            case 8:
                this.loancategory = crcat;
                if (taskid == "CAPD")
                {
                    this.status = 1;
                }
                else
                {
                    this.status = 0;
                }
                break;


            case 12:
                if (taskid == "PSOC900000")
                {
                    this.loancategory = 0;
                    this.status = 0;
                }
                else
                {
                    this.loancategory = GetLoanCategoryCode(loanno);
                    if (taskid == "CAPD")
                    {
                        this.status = 1;//GetLoanStatusCode(loanno);
                    }
                    else
                    {
                        this.status = 0;
                    }
                }
                break;

            case 11:
                this.loancategory = 0;
                this.status = 0;
                break;
            case 10:
                this.loancategory = 0;
                this.status = 0;
                break;
        }
    }
    public void Transaction(string functionname, int loan, int extrafield, int paymentmode,
        string user, DateTime operationaldate, string time, long disbrefno, string transno)
    {
        // setting internal variables
        this.loancategory = loancategory;
        this.status = status;
        this.branchcode = user.Substring(0, 4);
        this.user = user.Substring(4);
        this.paymentmode = paymentmode;
        this.operationaldate = operationaldate;
        this.time = time;


        ls = new LastSerialClass();

        DataTable TaskT = new DataTable(); // relevent tasks table
        TaskT = GetTask(functionname); // get relevent task

        //transno = ls.GetMaxNumber("TransNo", true).ToString(); // get the transaction number

        if (transno != "0") // transno can be taken
        {
            DataTable TransDataT = new DataTable(); // assign payments
            TransDataT = GetTransData("N", "P", disbrefno); // get assigned payments

            if (TransDataT.Rows.Count == 0) // no recrds assigned
            {
                msg = "Error 0011";
                description = " | No payments to take";
                ls.UpdateLastSerialStatus("TransNo", true);
                msg = msg + description;
            }
            else
            {



                double totamt = 0;
                try
                {
                    for (int i = 0; TransDataT.Rows.Count > i; i++)
                    {
                        string trtype = TransDataT.Rows[i]["trtype"].ToString();
                        switch (trtype)
                        {
                            case "I":

                                totamt += double.Parse(TransDataT.Rows[i]["tramt"].ToString());
                                break;
                            case "E":
                                totamt -= double.Parse(TransDataT.Rows[i]["tramt"].ToString());
                                break;
                        }
                    }
                }
                catch (Exception ex)
                {
                    msg = "Error 0002";
                    description = " | Error in assign amount";
                    msg = msg + description;
                }

                string accsign;

                if (totamt < 0)
                {
                    accsign = "DR";
                    totamt = totamt * -1;
                }
                else
                {
                    accsign = "CR";
                }


                if (InsertCrTransJrnl(transno, this.operationaldate, "A", disbrefno.ToString(), accsign, totamt, this.user, DateTime.Now.TimeOfDay.ToString() /* this.time*/) != 0)
                {
                    //
                    string batchrefno = "0";
                    int lineno = 0;
                    for (int i = 0; TaskT.Rows.Count > i; i++)
                    {
                        string taskid = TaskT.Rows[i]["taskid"].ToString();
                        if (taskid == "OTHR")
                        {
                            break;
                        }
                        DataTable TaskTransactionT = new DataTable();
                        TaskTransactionT = GetTransData("N", "P", taskid, disbrefno);
                        for (int x = 0; TaskTransactionT.Rows.Count > x; x++)
                        {
                            if (TaskTransactionT.Rows.Count != 0)
                            {

                                double intrate = 0;
                                int crcat = 0;
                                double tramt = 0;
                                double assignamt = 0;
                                string refno1 = "0", cracno = "0";
                                string trstatus = "", trtype = "";
                                try
                                {
                                    tramt = double.Parse(TaskTransactionT.Rows[x]["tramt"].ToString());
                                    assignamt = double.Parse(TaskTransactionT.Rows[x]["assignamt"].ToString());
                                    trstatus = TaskTransactionT.Rows[x]["TrStatus"].ToString();
                                    refno1 = TaskTransactionT.Rows[x]["Refno"].ToString();
                                    trtype = TaskTransactionT.Rows[x]["TrType"].ToString();
                                    this.loanno = TaskTransactionT.Rows[x]["Cracno"].ToString();
                                    intrate = double.Parse(TaskTransactionT.Rows[x]["intrate"].ToString());
                                    crcat = int.Parse(TaskTransactionT.Rows[x]["crcat"].ToString());
                                    batchrefno = TaskTransactionT.Rows[x]["batchrefno"].ToString();
                                    SetLoanStatus(loanno, taskid, crcat); 
                                  
                                }
                                catch (Exception ex)
                                {
                                    msg = "Error 0040";
                                    description = ex.Message;
                                    ls.UpdateLastSerialStatus("TransNo", true);
                                    IncativeCrTransJrnl(transno, "R");
                                    msg = msg + description;
                                }

                                if (tramt > assignamt)
                                {
                                    msg = "00002";
                                    description = " | Unauthorised Transaction";
                                    ls.UpdateLastSerialStatus("TransNo", true);
                                    IncativeCrTransJrnl(transno, "R");
                                    msg = msg + description;
                                }
                                else
                                {
                                    trstatus = GetStatus(trstatus, tramt);
                                    int rowadded = 0;
                                    if (tramt > 0)
                                    {
                                        rowadded = CallTrans(transno, taskid, loan, this.loancategory, status, paymentmode, tramt, trstatus, refno1, lineno, extrafield, trtype, disbrefno, intrate, crcat);
                                        if (rowadded == 0)
                                        {
                                            //ls.UpdateLastSerialStatus("TransNo", true);
                                            IncativeCrTransJrnl(transno, "R");
                                            for (int q = 0; q < TaskTransactionT.Rows.Count; q++)
                                            {
                                                string refno = TaskTransactionT.Rows[q]["refno"].ToString();
                                                UpdateTransAssign(refno, 0, true);
                                            }
                                            msg = msg + description;
                                        }
                                        else
                                        {
                                            lineno++;
                                        }
                                    }
                                   
                                }
                            }
                            else
                            {
                                // payment not assigned;
                            }
                        }
                    }
                    //Transaction(DateTime.Parse("08/04/2009"), disbrefno, user);
                    DataTable dt = new DataTable();
                    dt = GetBatchRec(disbrefno);
                    for (int w = 0; w < dt.Rows.Count; w++)
                    {

                        double tramt = double.Parse(dt.Rows[w]["tramt"].ToString());
                        double assignamt = double.Parse(dt.Rows[w]["assignamt"].ToString());
                        string trstatus = dt.Rows[w]["TrStatus"].ToString();
                        string cracno = dt.Rows[w]["cracno"].ToString();
                        string trtype = dt.Rows[w]["TrType"].ToString();
                        string refno = dt.Rows[w]["refno"].ToString();
                        switch (trtype)
                        {
                            case "I":
                                accsign = "CR";
                                break;
                            case "E":
                                accsign = "DR";
                                break;
                        }
                        double intrate = double.Parse(dt.Rows[w]["intrate"].ToString());
                        int crcat = int.Parse(dt.Rows[w]["crcat"].ToString());
                        trstatus = GetStatus(trstatus, tramt);
                        Module1(cracno, accsign, cracno, transno, tramt, trstatus, refno, lineno, operationaldate, disbrefno,
                            intrate, crcat, user, batchrefno);
                    }


                    if (msg != "0003")
                    {
                        switch (accsign)
                        {
                            case "CR":
                                accsign = "DR";
                                break;

                            case "DR":
                                accsign = "CR";
                                break;
                        }
                        InsertCrTransJrnl(transno, this.operationaldate, "A", disbrefno.ToString(), accsign, totamt, this.user, DateTime.Now.TimeOfDay.ToString() /*this.time*/);
                        //ls.UpdateLastserial("TransNo", long.Parse(transno) + 1);
                        msg = "Message 0001";
                        description = " | Peyments are completed Transaction Number is: " + transno;
                        msg = msg + description;
                    }
                    else
                    {
                        msg = "Error in Updateing CrTrans " + dw.ErrMsg;
                        ls.UpdateLastSerialStatus("TransNo", true);
                        IncativeCrTransJrnl(transno, "R");
                    }
                }
                else
                {
                    msg = "Error 0003";
                    description = "Error in Updateing Transaction jurnal " + dw.ErrMsg;
                    //ls.UpdateLastSerialStatus("TransNo", true);
                    msg = msg + description;
                }
            }

        }
        else
        {
            msg = "Transaction is already initiate wait for 15 seconds";
        }
    }

    private string GetStatus(string trstatus, double tramt)
    {
        if (tramt > 0)
        {
            switch (trstatus)
            {
                case "N":
                    trstatus = "F";
                    break;

                case "P":
                    trstatus = "P";
                    break;
            }
        }
        else
        {
            trstatus = "N";
        }
        return trstatus;
    }


   
    private DataTable GetBatchRec(long disbrefno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select* from transassign where disbrefno = @disbrefno and left(cracno,1) = '9'");
        dw.SetDataAdapterParameters("disbrefno", disbrefno);
        return dw.GetDataTable();
    }
    


    public string InsertCashierTransaction(string TransNo, string UserName, string Cracno, double Amount, string Description, DateTime SysDate,
                              DateTime ActTransDate, string Other, string batchno, string acsign)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO CashierTransaction(TransNo,UserName,Cracno,Amount,Description,SysDate,ActTransDate,Other, batchno, acsign)
					     VALUES (@TransNo,@UserName,@Cracno,@Amount,@Description,@SysDate,@ActTransDate,@Other, @batchno, @acsign) SELECT IDENT_CURRENT('CashierTransaction')");
        dw.SetSqlCommandParameters("TransNo", TransNo);
        dw.SetSqlCommandParameters("UserName", UserName);
        dw.SetSqlCommandParameters("Cracno", Cracno);
        dw.SetSqlCommandParameters("Amount", Amount);
        dw.SetSqlCommandParameters("Description", Description);
        dw.SetSqlCommandParameters("SysDate", SysDate);
        dw.SetSqlCommandParameters("ActTransDate", ActTransDate);
        dw.SetSqlCommandParameters("Other", Other);
        dw.SetSqlCommandParameters("batchno", batchno);
        dw.SetSqlCommandParameters("acsign", acsign);
        return dw.InsertandReturnID();
    }


    private int GetLoanStatusCode(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select LoanStatusCode from housprop where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return int.Parse(dw.GetSingleData());
    }

    //private int GetLoanStatusCodeOld(string cracno)
    //{
    //    dw = new DataWorksClass(oldconstring);
    //    dw.SetCommand(@"select LoanStatusCode from housprop where cracno = @cracno");
    //    dw.SetSqlCommandParameters("cracno", cracno);
    //    return int.Parse(dw.GetSingleData());
    //}


    private int GetLoanCategoryCodeOld(string cracno)
    {
        dw = new DataWorksClass(oldconstring);
        dw.SetCommand(@"select CrCat from crmast where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return int.Parse(dw.GetSingleData());
    }

    private int CancelCrTranJrnl(string transno, string TrStatus)
    {
        dw = new DataWorksClass(oldconstring);
        dw.SetCommand(@"update crtransjrnl set TrStatus=@TrStatus where transno = @transno");
        dw.SetSqlCommandParameters("transno", transno);
        dw.SetSqlCommandParameters("TrStatus", TrStatus);
        return dw.Update();
    }

    private int GetLoanCategoryCode(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select CrCat from housprop where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return int.Parse(dw.GetSingleData());
    }


    //public void Transaction(string functionname, int loan, string branchcode, int extrafield, 
    //    string operationdate, DateTime operationaldate, string user)
    //{
    //    //// setting internal variables
    //    //this.loancategory = loancategory;
    //    //this.status = status;
    //    //this.loanno = loanno;
    //    this.user = user;
    //    //this.paymentmode = paymentmode;
    //    this.operationaldate = operationaldate;
    //    //this.time = time;
    //    this.branchcode = branchcode;

    //    ls = new LastSerialClass();
    //    fc = new FunctionClass();
    //    DataTable TaskT = new DataTable(); // relevent tasks table
    //    TaskT = GetTask(functionname); // get relevent task

    //    transno = ls.GetMaxNumber("TransNo", true).ToString(); // get the transaction number

    //    if (transno != "0") // transno can be taken
    //    {
    //        DataTable TransDataT = new DataTable(); // assign payments
    //        TransDataT = GetTransData(operationdate, "NPLT", "T", true); // get assigned payments

    //        if (TransDataT.Rows.Count == 0) // no records assigned
    //        {
    //            msg = "Error 0011";
    //            description = " | No payments to take";
    //            ls.UpdateLastSerialStatus("TransNo", true);
    //            msg = msg + description;
    //        }
    //        else
    //        {
    //            double totamt = 0;
    //            try
    //            {
    //                for (int i = 0; TransDataT.Rows.Count > i; i++)
    //                {
    //                    string trtype = TransDataT.Rows[i]["trtype"].ToString();
    //                    switch (trtype)
    //                    {
    //                        case "I":

    //                            totamt += double.Parse(TransDataT.Rows[i]["tramt"].ToString());
    //                            break;
    //                        case "E":
    //                            totamt -= double.Parse(TransDataT.Rows[i]["tramt"].ToString());
    //                            break;
    //                    }
    //                }
    //            }
    //            catch (Exception ex)
    //            {
    //                msg = "Error 0002";
    //                description = " | Error in assign amount";
    //                msg = msg + description;
    //            }

    //            string accsign;

    //            if (totamt < 0)
    //            {
    //                accsign = "DR";
    //                totamt = totamt * -1;
    //            }
    //            else
    //            {
    //                accsign = "CR";
    //            }

    //            if (InsertCrTransJrnl(transno, operationaldate, "A", operationdate, accsign, totamt, this.user, fc.GetSystemTime() /* this.time*/) != 0)
    //            {

    //                int lineno = 0;
    //                for (int i = 0; TaskT.Rows.Count > i; i++)
    //                {
    //                    string taskid = TaskT.Rows[i]["taskid"].ToString();
    //                    DataTable TaskTransactionT = new DataTable();
    //                    TaskTransactionT = GetTransData(true, operationdate, taskid, "T");
    //                    for (int x = 0; TaskTransactionT.Rows.Count > x; x++)
    //                    {
    //                        if (TaskTransactionT.Rows.Count != 0)
    //                        {
    //                            double tramt = 0;
    //                            double assignamt = 0;
    //                            string refno1 = "0";
    //                            string trstatus = "", trtype = "";
    //                            int loancategory = 0;
    //                            try
    //                            {
    //                                tramt = double.Parse(TaskTransactionT.Rows[x]["tramt"].ToString());
    //                                assignamt = double.Parse(TaskTransactionT.Rows[x]["assignamt"].ToString());
    //                                trstatus = TaskTransactionT.Rows[x]["TrStatus"].ToString();
    //                                refno1 = TaskTransactionT.Rows[x]["refno"].ToString();
    //                                trtype = TaskTransactionT.Rows[x]["trtype"].ToString();
    //                                loancategory = int.Parse(TaskTransactionT.Rows[x]["cracno"].ToString().Substring(6, 2));
    //                            }
    //                            catch (Exception ex)
    //                            {
    //                                msg = "Error 0040";
    //                                description = ex.Message;
    //                                ls.UpdateLastSerialStatus("TransNo", true);
    //                                IncativeCrTransJrnl(transno, "R");
    //                                msg = msg + description;
    //                            }

    //                            if (tramt > assignamt)
    //                            {
    //                                msg = "00002";
    //                                description = " | Unauthorised Transaction";
    //                                ls.UpdateLastSerialStatus("TransNo", true);
    //                                IncativeCrTransJrnl(transno, "R");
    //                                msg = msg + description;
    //                            }
    //                            else
    //                            {
    //                                switch (trstatus)
    //                                {
    //                                    case "N":
    //                                        if (tramt == assignamt)
    //                                        {
    //                                            trstatus = "F";
    //                                        }
    //                                        else
    //                                        {
    //                                            trstatus = "P";
    //                                            tramt = tramt;
    //                                        }
    //                                        break;

    //                                    case "P":
    //                                        if (tramt == assignamt)
    //                                        {
    //                                            double transtotal = GetPaidTrAmt(refno1);
    //                                            trstatus = "F";
    //                                            tramt = tramt - transtotal;
    //                                        }
    //                                        else
    //                                        {
    //                                            double transtotal = GetPaidTrAmt(refno1);
    //                                            trstatus = "P";
    //                                            tramt = tramt - transtotal;
    //                                        }
    //                                        break;

    //                                    case "T":
    //                                        trstatus = "O";
    //                                        break;
    //                                }

    //                                int rowadded = CallTrans(transno, taskid, loan, loancategory, status, paymentmode, tramt, trstatus, refno1, lineno, extrafield, trtype, disbrefno);

    //                                if (rowadded == 0)
    //                                {
    //                                    ls.UpdateLastSerialStatus("TransNo", true);
    //                                    IncativeCrTransJrnl(transno, "R");
    //                                    msg = msg + description;
    //                                }
    //                                else
    //                                {
    //                                    lineno++;
    //                                }
    //                            }
    //                        }
    //                        else
    //                        {
    //                            // payment not assigned;
    //                        }
    //                    }
    //                }

    //                if (msg != "0003")
    //                {
    //                    switch (accsign)
    //                    {
    //                        case "CR":
    //                            accsign = "DR";
    //                            break;

    //                        case "DR":
    //                            accsign = "CR";
    //                            break;
    //                    }
    //                    InsertCrTransJrnl(transno, this.operationaldate, "A", loanno, accsign, totamt, this.user, DateTime.Now.TimeOfDay.ToString() /*this.time*/);
    //                    ls.UpdateLastserial("TransNo", long.Parse(transno) + 1);
    //                    msg = "Message 0001";
    //                    description = " | Peyments are completed Transaction Number is: " + transno;
    //                    msg = msg + description;
    //                }
    //                else
    //                {
    //                    msg = "Error in Updateing CrTrans " + dw.ErrMsg;
    //                    ls.UpdateLastSerialStatus("TransNo", true);
    //                    IncativeCrTransJrnl(transno, "R");
    //                }
    //            }
    //            else
    //            {
    //                msg = "Error 0003";
    //                description = "Error in Updateing Transaction jurnal " + dw.ErrMsg;
    //                ls.UpdateLastSerialStatus("TransNo", true);
    //                msg = msg + description;
    //            }
    //        }
    //    }
    //    else
    //    {
    //        msg = "Transaction is already initiate wait for 15 seconds";
    //    }
    //}

    private DataTable GetTask(string functionname)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select distinct ft.taskid 
                            from FunctionTask ft, Functions f, transassign ta
                            where f.refid = ft.refid and
                            ta.taskid = ft.taskid and
                            f.transref=@FunctionName");
        dw.SetDataAdapterParameters("FunctionName", functionname);
        return dw.GetDataTable();
    }

    //private DataTable GetTask()
    //{
    //    dw = new DataWorksClass(constring);
    //    dw.SetDataAdapter(@"select ft.taskid from FunctionTask ft, Functions f where f.refid = ft.refid");
    //    return dw.GetDataTable();
    //}


    private DataTable GetTaskData(string taskid)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from TransParam where taskid = @taskid");
        dw.SetDataAdapterParameters("taskid", taskid);
        return dw.GetDataTable();
    }

    //    private DataTable GetTransData(string cracno, string trstatus1, string trstatus2, bool IsReady, string TransRef)
    //    {
    //        dw = new DataWorksClass(constring);
    //        dw.SetDataAdapter(@"select cracno,  assignamt, tramt, refno, trtype from TransAssign 
    //                                where cracno in (select cracno from crmast where appno = @cracno) 
    //                                or  cracno = @cracno and IsReady=@IsReady and (trstatus=@trstatus1 or 
    //                                trstatus=@trstatus2) and TransRef=@TransRef");
    //        dw.SetDataAdapterParameters("cracno", cracno);
    //        dw.SetDataAdapterParameters("trstatus1", trstatus1);
    //        dw.SetDataAdapterParameters("trstatus2", trstatus2);
    //        dw.SetDataAdapterParameters("IsReady", IsReady);
    //        dw.SetDataAdapterParameters("TransRef", TransRef);
    //        return dw.GetDataTable();
    //    }

    private DataTable GetTransData(string cracno, string trstatus1, string trstatus2, bool IsReady, string TransRef)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select cracno,  assignamt, tramt, refno, trtype from TransAssign 
                            where cracno = @cracno and IsReady=@IsReady and (trstatus=@trstatus1 or 
                            trstatus=@trstatus2) and TransRef=@TransRef");
        dw.SetDataAdapterParameters("cracno", cracno);
        dw.SetDataAdapterParameters("trstatus1", trstatus1);
        dw.SetDataAdapterParameters("trstatus2", trstatus2);
        dw.SetDataAdapterParameters("IsReady", IsReady);
        dw.SetDataAdapterParameters("TransRef", TransRef);
        return dw.GetDataTable();
    }

//    private DataTable GetTransData(string OperationDate, string transref, string trstatus, bool isready)
//    {
//        dw = new DataWorksClass(constring);
//        dw.SetDataAdapter(@"select cracno,  trstatus, assignamt, tramt, refno, trtype from TransAssign 
//                            where OperationDate = @OperationDate and IsReady=@IsReady and 
//                            trstatus=@trstatus and TransRef=@TransRef order by disbrefno");
//        dw.SetDataAdapterParameters("OperationDate", OperationDate);
//        dw.SetDataAdapterParameters("TransRef", transref);
//        dw.SetDataAdapterParameters("IsReady", isready);
//        dw.SetDataAdapterParameters("trstatus", trstatus);
//        return dw.GetDataTable();
//    }

//    private DataTable GetTransData(bool isready, string OperationDate, string taskid, string trstatus)
//    {
//        dw = new DataWorksClass(constring);
//        dw.SetDataAdapter(@"select cracno,  trstatus, assignamt, tramt, refno, trtype from TransAssign 
//                            where OperationDate = @OperationDate and IsReady=@IsReady and 
//                            trstatus=@trstatus and taskid=@taskid order by disbrefno");
//        dw.SetDataAdapterParameters("OperationDate", OperationDate);
//        dw.SetDataAdapterParameters("taskid", taskid);
//        dw.SetDataAdapterParameters("trstatus", trstatus);
//        dw.SetDataAdapterParameters("IsReady", isready);
//        return dw.GetDataTable();
//    }

    // Changed for new suggestions 27/07/2009
    //    private DataTable GetTransData(string cracno, string trstatus1, string trstatus2, string taskid, bool IsReady)
    //    {
    //        dw = new DataWorksClass(constring);
    //        dw.SetDataAdapter(@"select distinct  ta.cracno, ta.refno, ta.tramt, ta.AssignAmt, ta.AddDate, 
    //                             ta.TrStatus, ta.datedue, ta.taskid, ta.trtype from 
    //                            TransAssign ta, transCat tc 
    //                            where cracno =@cracno and IsReady=@IsReady
    //                            and (ta.TrStatus=@TrStatus1 or ta.TrStatus=@TrStatus2) 
    //                            and ta.taskid = tc.taskid
    //                            and ta.taskid = @taskid
    //                            order by TrStatus desc");
    //        dw.SetDataAdapterParameters("cracno", cracno);
    //        dw.SetDataAdapterParameters("trstatus1", trstatus1);
    //        dw.SetDataAdapterParameters("trstatus2", trstatus2);
    //        dw.SetDataAdapterParameters("IsReady", IsReady);
    //        dw.SetDataAdapterParameters("taskid", taskid);
    //        return dw.GetDataTable();
    //    }

    // Changed for new disbrefno 27/07/2009
    private DataTable GetTransData(string trstatus1, string trstatus2, string taskid, long disbrefno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select cracno, tramt, AssignAmt, datedue, taskid, trtype, trstatus, adduser, 
                            refno, transref, intrate, crcat, batchrefno
                            from transassign where trstatus = @trstatus1
                            and  disbrefno = @disbrefno and taskid = @taskid
                            union
                            select cracno, tramt, AssignAmt, datedue, taskid, trtype, trstatus, adduser, 
                            refno, transref, intrate, crcat, batchrefno from transassigntmp where 
                            disbrefno = @disbrefno and status != 'I'
                            and refno in (select refno from transassign where disbrefno = @disbrefno 
                            and  trstatus = @trstatus2 and taskid = @taskid) 
                            order by datedue, taskid desc");
        dw.SetDataAdapterParameters("trstatus1", trstatus1);
        dw.SetDataAdapterParameters("trstatus2", trstatus2);
        dw.SetDataAdapterParameters("disbrefno", disbrefno);
        dw.SetDataAdapterParameters("taskid", taskid);
        return dw.GetDataTable();
    }
    // ##
    public DataTable GetTransData(string trstatus1, string trstatus2, long disbrefno, string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select cracno, tramt, AssignAmt, datedue, taskid, trtype, trstatus, adduser, 
                            refno, transref, intrate, crcat, batchrefno
                            from transassign where trstatus = @trstatus1
                            and  disbrefno = @disbrefno and cracno = @cracno
                            union
                            select cracno, tramt, AssignAmt, datedue, taskid, trtype, trstatus, adduser, 
                            refno, transref, intrate, crcat, batchrefno from transassigntmp where 
                            disbrefno = @disbrefno and status != 'I'
                            and refno in (select refno from transassign where disbrefno = @disbrefno 
                            and  trstatus = @trstatus2 and cracno = @cracno) 
                            order by datedue, taskid desc");
        dw.SetDataAdapterParameters("trstatus1", trstatus1);
        dw.SetDataAdapterParameters("disbrefno", disbrefno);
        dw.SetDataAdapterParameters("cracno", cracno);
        dw.SetDataAdapterParameters("trstatus2", trstatus2);
        return dw.GetDataTable();
    }



    //    private DataTable GetTransData(string system, string disbrefno)
    //    {
    //        dw = new DataWorksClass(constring);
    //        dw.SetDataAdapter(@"select cracno, trtype, transref, taskid,  trstatus,
    //                            sum(assignamt) as tramt from TransAssign 
    //                            where disbrefno = @disbrefno AND system = @system 
    //                            group by cracno, trtype, transref, taskid,  trstatus");
    //        dw.SetDataAdapterParameters("system", system);
    //        dw.SetDataAdapterParameters("disbrefno", disbrefno);

    //        return dw.GetDataTable();
    //    }
    //With out Sum 08/06/2009
    private DataTable GetTransData(string system, string disbrefno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from TransAssign 
                            where disbrefno = @disbrefno AND system = @system");
        dw.SetDataAdapterParameters("system", system);
        dw.SetDataAdapterParameters("disbrefno", disbrefno);
        return dw.GetDataTable();
    }

//    //With out Sum 11/06/2009
//    private DataTable GetTransData(string disbrefno)
//    {
//        dw = new DataWorksClass(constring);
//        dw.SetDataAdapter(@"select ta.*,ISNULL(tab1.tramt, 0) as Amt 
//                            from (select tramt,refno from transassigntmp where
//                            transno is null  and disbrefno=@disbrefno) as tab1,
//                            transassign ta where ta.disbrefno=@disbrefno and 
//                            (ta.trstatus ='N' or ta.trstatus ='P')
//                            and ta.refno*=tab1.refno");
//        dw.SetDataAdapterParameters("disbrefno", disbrefno);
//        return dw.GetDataTable();
//    }

    private DataTable GetTransData(string system, string disbrefno, string taskid)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select cracno, trtype, transref, taskid, sum(assignamt) 
                            from TransAssign where disbrefno = @disbrefno AND system = @system
                            and taskid=@taskid
                            group by cracno, trtype, transref, taskid");
        dw.SetDataAdapterParameters("system", system);
        dw.SetDataAdapterParameters("disbrefno", disbrefno);
        dw.SetDataAdapterParameters("taskid", taskid);
        return dw.GetDataTable();
    }


    //    private DataTable GetTransData(long disbrefno, string trstatus1, string trstatus2, string taskid, bool IsReady)
    //    {
    //        dw = new DataWorksClass(constring);
    //        dw.SetDataAdapter(@"select distinct  ta.crcat, ta.cracno, ta.refno, ta.tramt, ta.AssignAmt, ta.AddDate, 
    //                            tc.Description, ta.TrStatus, ta.datedue, ta.taskid, ta.trtype from 
    //                            TransAssign ta, transCat tc 
    //                            where disbrefno =@disbrefno and IsReady=@IsReady
    //                            and (ta.TrStatus=@TrStatus1 or ta.TrStatus=@TrStatus2) 
    //                            and ta.taskid = tc.taskid
    //                            and ta.taskid = @taskid
    //                            order by TrStatus desc");
    //        dw.SetDataAdapterParameters("disbrefno", disbrefno);
    //        dw.SetDataAdapterParameters("trstatus1", trstatus1);
    //        dw.SetDataAdapterParameters("trstatus2", trstatus2);
    //        dw.SetDataAdapterParameters("IsReady", IsReady);
    //        dw.SetDataAdapterParameters("taskid", taskid);
    //        return dw.GetDataTable();
    //    }

    // Corrected for disbrefno
//    private DataTable   GetTransData(string trstatus1, string trstatus2, long disbrefno, string craco)
//    {
//        dw = new DataWorksClass(constring);
//        dw.SetDataAdapter(@"select cracno, tramt, AssignAmt, datedue, taskid, trtype, trstatus, adduser, 
//                            refno, transref, intrate, crcat 
//                            from transassign where trstatus = @trstatus1
//                            and cracno = @cracno and disbrefno = @disbrefno
//                            union
//                            select cracno, tramt, AssignAmt, datedue, taskid, trtype, trstatus, adduser, 
//                            refno, transref, intrate, crcat from transassigntmp where 
//                            cracno = @cracno and disbrefno = @disbrefno
//                            and refno in (select refno from transassign where disbrefno = @disbrefno 
//                            and cracno =@cracno and  trstatus = @trstatus2)");
//        dw.SetDataAdapterParameters("trstatus1", trstatus1);
//        dw.SetDataAdapterParameters("trstatus2", trstatus2);
//        dw.SetDataAdapterParameters("disbrefno", disbrefno);
//        dw.SetDataAdapterParameters("craco", craco);
//        return dw.GetDataTable();
    //}

    private DataTable GetTransData(string trstatus1, string trstatus2, long disbrefno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select cracno, tramt, AssignAmt, datedue, taskid, trtype, trstatus, adduser, 
                            refno, transref, intrate, crcat, batchrefno
                            from transassign where trstatus = @trstatus1
                            and  disbrefno = @disbrefno
                            union
                            select cracno, tramt, AssignAmt, datedue, taskid, trtype, trstatus, adduser, 
                            refno, transref, intrate, crcat, batchrefno from transassigntmp where 
                            disbrefno = @disbrefno and status != 'I'
                            and refno in (select refno from transassign where disbrefno = @disbrefno 
                            and  trstatus = @trstatus2)");
        dw.SetDataAdapterParameters("trstatus1", trstatus1);
        dw.SetDataAdapterParameters("trstatus2", trstatus2);
        dw.SetDataAdapterParameters("disbrefno", disbrefno);
        return dw.GetDataTable();
    }


    private int CallTrans(string transno, string taskid, int loan, int loancategory, int status, int paymentmode, double tramt, 
        string trstatus, string refno, int lineno, int extrafield, string trtype, long disbrefno, double intrate, int crcat)
    {
        DataTable ParamT = new DataTable();
        int rowadded = 0;
        switch (taskid.Length)
        {
            case 4:
                taskid = taskid + loan.ToString("0") + loancategory.ToString("00") + status.ToString("0") + extrafield.ToString("00") + paymentmode.ToString("0") + trtype;
                break;
            case 6:
                taskid = taskid + loan.ToString("0") + loancategory.ToString("00") + extrafield.ToString("00");
                break;

            case 10:
                taskid += paymentmode.ToString("0") + trtype;
                break;

            case 12:
                taskid += paymentmode.ToString("0") + trtype;
                break;
        }

        ParamT = GetTaskData(taskid);

        if (ParamT.Rows.Count != 0)
        {
            switch (ParamT.Rows.Count)
            {
                case 2:
                    rowadded = Module2(ParamT, loancategory.ToString("00"), transno, tramt, trstatus, refno, lineno);
                    if (rowadded == 0)
                    {
                        description = dw.ErrMsg;
                        return 0;
                    }
                    break;
                case 3:

                    rowadded = Module3(taskid, ParamT, this.loanno, transno, tramt, trstatus, refno, lineno, disbrefno, intrate, crcat);
                    if (rowadded == 0)
                    {
                        description = dw.ErrMsg;
                        return 0;
                    }
                    break;

                case 5:

                    rowadded = Module5(ParamT, this.loanno, transno, tramt, trstatus, refno, lineno);
                    if (rowadded == 0)
                    {
                        description = dw.ErrMsg;
                        return 0;
                    }
                    break;

            }
        }
        else
        {
            return 0;
            msg = "Error 0020";
            description = " | No correct function assigned";
        }
        return rowadded;
    }

    private int CallTrans(string transno, string taskid, int loan, int loancategory, int status, int paymentmode, 
        double tramt, string trstatus, string refno, int lineno, int extrafield, string trtype, string cracno, 
        long disbrefno, double intrate, int crcat)
    {
        DataTable ParamT = new DataTable();
        int rowadded = 0;
        switch (taskid.Length)
        {
            case 4:
                taskid = taskid + loan.ToString("0") + loancategory.ToString("00") + status.ToString("0") + extrafield.ToString("00") + paymentmode.ToString("0") + trtype;
                break;
            case 6:
                taskid = taskid + loan.ToString("0") + loancategory.ToString("00") + extrafield.ToString("00");
                break;

            case 10:
                taskid += paymentmode.ToString("0") + trtype;
                break;

            case 12:
                taskid += paymentmode.ToString("0") + trtype;
                break;
        }
        ParamT = GetTaskData(taskid);

        if (ParamT.Rows.Count != 0)
        {
            switch (ParamT.Rows.Count)
            {
                case 3:

                    rowadded = Module3(taskid, ParamT, cracno, transno, tramt, trstatus, refno, lineno, disbrefno, intrate, crcat);
                    if (rowadded == 0)
                    {
                        description = dw.ErrMsg;
                        return 0;
                    }
                    break;

                case 5:

                    rowadded = Module5(ParamT, this.loanno, transno, tramt, trstatus, refno, lineno);
                    if (rowadded == 0)
                    {
                        description = dw.ErrMsg;
                        return 0;
                    }
                    break;

            }
        }
        else
        {
            return 0;
            msg = "Error 0020";
            description = " | No correct function assigned";
        }
        return rowadded;
    }


    private double GetCurrentBalance(string GlCode)
    {
        DataWorksClass dw1 = new DataWorksClass(constring);
        dw1.SetCommand("select CurBal from glcode WHERE RefGlCode = @GlCode");
        dw1.SetSqlCommandParameters("GlCode", GlCode);
        double curbal = double.Parse(dw1.GetSingleData());
        if (curbal == 0)
        {
            //
        }
        return curbal;
    }

    private double GetPaidTrAmt(string TransAssignRefNo)
    {
        DataWorksClass dw1 = new DataWorksClass(constring);
        dw1.SetCommand("select sum(tramt) as tramt from trans WHERE TransAssignRefNo = @TransAssignRefNo");
        dw1.SetSqlCommandParameters("TransAssignRefNo", TransAssignRefNo);
        return double.Parse(dw1.GetSingleData());
    }


    private int Module3(string taskid, DataTable TransParam, string loanno, string transno, double tramt, string trstatus, string refno, int lineno, long disbrefno, double intrate, int crcat)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand();

        foreach (DataRow dr in TransParam.Rows)
        {
            string acref = dr["ACREF"].ToString();
            string accsign = dr["accsign"].ToString();
            string glrefcode;
            if (acref != "GLAC")
            {
                // Trans Paramenters
                glrefcode = GetGlCode(dr);
                dw.SetSqlCommandParameters("CrAcNoT", loanno);
                dw.SetSqlCommandParameters("TrAmtT", tramt);
                dw.SetSqlCommandParameters("TrLineNoT", lineno);
                dw.SetSqlCommandParameters("AccSignT", accsign);
                dw.SetSqlCommandParameters("TrStatusT", trstatus/*need to change*/);
                dw.SetSqlCommandParameters("TrUserT", user);
                dw.SetSqlCommandParameters("TrDateT", this.operationaldate);
                dw.SetSqlCommandParameters("RefGlCodeT", glrefcode);
                dw.SetSqlCommandParameters("transnoT", transno);
                dw.SetSqlCommandParameters("TransAssignRefNoT", refno);
                dw.SetSqlCommandParameters("taskidT", taskid);

                dw.SetSqlCommandParameters("TrStatusTA", trstatus);
                dw.SetSqlCommandParameters("RefNoTA", refno);
                dw.SetSqlCommandParameters("TransNoTA", transno);

            }
            else
            {
                switch (accsign)
                {
                    case "CR":
                        glrefcode = GetGlCode(dr);
                        dw.SetSqlCommandParameters("RefGlCodeG1", glrefcode);
                        dw.SetSqlCommandParameters("TransnoG1", transno);
                        dw.SetSqlCommandParameters("TrLineNoG1", lineno);
                        dw.SetSqlCommandParameters("TrDateG1", this.operationaldate);
                        dw.SetSqlCommandParameters("AcSignG1", accsign);
                        dw.SetSqlCommandParameters("TrAmtG1", tramt);
                        dw.SetSqlCommandParameters("TrStatusGl", trstatus);
                        dw.SetSqlCommandParameters("cracnoG1", loanno);
                        dw.SetSqlCommandParameters("batchnoG1", disbrefno);
                        dw.SetSqlCommandParameters("TransAssignRefNoG1", refno);

                        dw.SetSqlCommandParameters("IntRateG1", intrate);
                        dw.SetSqlCommandParameters("CrCatG1", crcat);
                        dw.SetSqlCommandParameters("truserG1", user);
                        dw.SetSqlCommandParameters("trtimeG1", time);

                        // GL Code Parameteres
                        double currentbalance = GetCurrentBalance(glrefcode);
                        currentbalance += tramt;
                        dw.SetSqlCommandParameters("RefGlCodeGL1", glrefcode);
                        dw.SetSqlCommandParameters("CurBalGL1", currentbalance);
                        dw.SetSqlCommandParameters("LastTrDateGL1", this.operationaldate);
                        break;

                    case "DR":
                        glrefcode = GetGlCode(dr);
                        dw.SetSqlCommandParameters("RefGlCodeG2", glrefcode);
                        dw.SetSqlCommandParameters("transnoG2", transno);
                        dw.SetSqlCommandParameters("TrLineNoG2", lineno);
                        dw.SetSqlCommandParameters("TrDateG2", this.operationaldate);
                        dw.SetSqlCommandParameters("AcSignG2", accsign);
                        dw.SetSqlCommandParameters("TrAmtG2", tramt);
                        dw.SetSqlCommandParameters("TrStatusG2", trstatus);
                        dw.SetSqlCommandParameters("cracnoG2", loanno);
                        dw.SetSqlCommandParameters("batchnoG2", disbrefno);
                        dw.SetSqlCommandParameters("TransAssignRefNoG2", refno);


                        dw.SetSqlCommandParameters("IntRateG2", intrate);
                        dw.SetSqlCommandParameters("CrCatG2", crcat);
                        dw.SetSqlCommandParameters("truserG2", user);
                        dw.SetSqlCommandParameters("trtimeG2", time);

                        // GL Code Parameteres
                        currentbalance = GetCurrentBalance(glrefcode);
                        currentbalance -= tramt;
                        dw.SetSqlCommandParameters("RefGlCodeGL2", glrefcode);
                        dw.SetSqlCommandParameters("CurBalGL2", currentbalance);
                        dw.SetSqlCommandParameters("LastTrDateGL2", this.operationaldate);
                        break;
                }
            }

        }

        string[] commandarray = new string[6];

        commandarray[0] = @"insert into Trans (CrAcNo,TrAmt,TrLineNo,AccSign,TrStatus,TrUser,TrDate,RefGlCode,transno, TransAssignRefNo, taskid)
                       values (@CrAcNoT,@TrAmtT,@TrLineNoT,@AccSignT,@TrStatusT,@TrUserT,@TrDateT,@RefGlCodeT,@transnoT, @TransAssignRefNoT, @taskidT)";
        commandarray[1] = @"INSERT INTO Gltrans(RefGlCode,TransNo,TrLineNo,TrDate,AcSign,TrAmt,TrStatus, cracno, batchno, TransAssignRefNo, IntRate, CrCat,  truser, trtime)
                        values(@RefGlCodeG1,@TransNoG1,@TrLineNoG1,@TrDateG1,@AcSignG1,@TrAmtG1,@TrStatusGl, @cracnoG1, @batchnoG1, @TransAssignRefNoG1, @IntRateG1, @CrCatG1, @truserG1, @trtimeG1)";
        commandarray[2] = @"INSERT INTO Gltrans(RefGlCode,TransNo,TrLineNo,TrDate,AcSign,TrAmt,TrStatus, cracno, batchno, TransAssignRefNo, IntRate, CrCat, truser, trtime)
                        values(@RefGlCodeG2,@TransNoG2,@TrLineNoG2,@TrDateG2,@AcSignG2,@TrAmtG2,@TrStatusG2,@cracnoG2, @batchnoG2, @TransAssignRefNoG2, @IntRateG2, @CrCatG2, @truserG2, @trtimeG2)";
        commandarray[3] = @"UPDATE GlCode SET CurBal = @CurBalGL1, LastTrDate=@LastTrDateGL1 WHERE RefGlCode = @RefGlCodeGL1";
        commandarray[4] = @"UPDATE GlCode SET CurBal = @CurBalGL2, LastTrDate=@LastTrDateGL2 WHERE RefGlCode = @RefGlCodeGL2";
        commandarray[5] = @"UPDATE TransAssign set TrStatus = @TrStatusTA, TransNo=@TransNoTA WHERE RefNo = @RefNoTA";

        return dw.Trans(commandarray);
    }


//    public string InsertCashierTransaction(string TransNo, string UserName, string Cracno, double Amount, string Description, DateTime SysDate,
//                                 DateTime ActTransDate, string Other)
//    {
//        dw = new DataWorksClass(constring);
//        dw.SetCommand(@"INSERT INTO CashierTransaction(TransNo,UserName,Cracno,Amount,Description,SysDate,ActTransDate,Other)
//					     VALUES (@TransNo,@UserName,@Cracno,@Amount,@Description,@SysDate,@ActTransDate,@Other) SELECT IDENT_CURRENT('CashierTransaction')");
//        dw.SetSqlCommandParameters("TransNo", TransNo);
//        dw.SetSqlCommandParameters("UserName", UserName);
//        dw.SetSqlCommandParameters("Cracno", Cracno);
//        dw.SetSqlCommandParameters("Amount", Amount);
//        dw.SetSqlCommandParameters("Description", Description);
//        dw.SetSqlCommandParameters("SysDate", SysDate);
//        dw.SetSqlCommandParameters("ActTransDate", ActTransDate);
//        dw.SetSqlCommandParameters("Other", Other);
//        return dw.InsertandReturnID();
//    }


    private int Module2(DataTable TransParam, string loanno, string transno, double tramt, string trstatus, string refno, int lineno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand();


        dw.SetSqlCommandParameters("TrStatusTA", trstatus);
        dw.SetSqlCommandParameters("RefNoTA", refno);
        dw.SetSqlCommandParameters("TransNoTA", transno);

        foreach (DataRow dr in TransParam.Rows)
        {
            string acref = dr["ACREF"].ToString();
            string accsign = dr["accsign"].ToString();
            string glrefcode;
            switch (accsign)
            {
                case "CR":
                    glrefcode = GetGlCode(dr);
                    dw.SetSqlCommandParameters("RefGlCodeG1", glrefcode);
                    dw.SetSqlCommandParameters("TransnoG1", transno);
                    dw.SetSqlCommandParameters("TrLineNoG1", lineno);
                    dw.SetSqlCommandParameters("TrDateG1", this.operationaldate);
                    dw.SetSqlCommandParameters("AcSignG1", accsign);
                    dw.SetSqlCommandParameters("TrAmtG1", tramt);
                    dw.SetSqlCommandParameters("TrStatusGl", trstatus);

                    // GL Code Parameteres
                    double currentbalance = GetCurrentBalance(glrefcode);
                    currentbalance += tramt;
                    dw.SetSqlCommandParameters("RefGlCodeGL1", glrefcode);
                    dw.SetSqlCommandParameters("CurBalGL1", currentbalance);
                    dw.SetSqlCommandParameters("LastTrDateGL1", this.operationaldate);
                    break;

                case "DR":
                    glrefcode = GetGlCode(dr);
                    dw.SetSqlCommandParameters("RefGlCodeG2", glrefcode);
                    dw.SetSqlCommandParameters("TransnoG2", transno);
                    dw.SetSqlCommandParameters("TrLineNoG2", lineno);
                    dw.SetSqlCommandParameters("TrDateG2", this.operationaldate);
                    dw.SetSqlCommandParameters("AcSignG2", accsign);
                    dw.SetSqlCommandParameters("TrAmtG2", tramt);
                    dw.SetSqlCommandParameters("TrStatusG2", trstatus);

                    // GL Code Parameteres
                    currentbalance = GetCurrentBalance(glrefcode);
                    currentbalance -= tramt;
                    dw.SetSqlCommandParameters("RefGlCodeGL2", glrefcode);
                    dw.SetSqlCommandParameters("CurBalGL2", currentbalance);
                    dw.SetSqlCommandParameters("LastTrDateGL2", this.operationaldate);
                    break;
            }
        }

        string[] commandarray = new string[5];

        commandarray[0] = @"INSERT INTO Gltrans(RefGlCode,TransNo,TrLineNo,TrDate,AcSign,TrAmt,TrStatus)
                        values(@RefGlCodeG1,@TransNoG1,@TrLineNoG1,@TrDateG1,@AcSignG1,@TrAmtG1,@TrStatusGl)";
        commandarray[1] = @"INSERT INTO Gltrans(RefGlCode,TransNo,TrLineNo,TrDate,AcSign,TrAmt,TrStatus)
                        values(@RefGlCodeG2,@TransNoG2,@TrLineNoG2,@TrDateG2,@AcSignG2,@TrAmtG2,@TrStatusG2)";
        commandarray[2] = @"UPDATE GlCode SET CurBal = @CurBalGL1, LastTrDate=@LastTrDateGL1 WHERE RefGlCode = @RefGlCodeGL1";
        commandarray[3] = @"UPDATE GlCode SET CurBal = @CurBalGL2, LastTrDate=@LastTrDateGL2 WHERE RefGlCode = @RefGlCodeGL2";
        commandarray[4] = @"UPDATE TransAssign set TrStatus = @TrStatusTA, TransNo=@TransNoTA WHERE RefNo = @RefNoTA";

        return dw.Trans(commandarray);
    }


    private int Module1(string cracno, string accsign, string refglcode, string transno, double tramt, 
        string trstatus, string refno, int lineno, DateTime operationaldate, long batchno,
        double intrate, int crcat, string truser, string batchrefno)
    {
        fc = new FunctionClass();
        dw = new DataWorksClass(constring);
        dw.SetCommand();
        string trtime = fc.GetSystemTime();

        dw.SetSqlCommandParameters("TrStatusTA", trstatus);
        dw.SetSqlCommandParameters("RefNoTA", refno);
        dw.SetSqlCommandParameters("TransNoTA", transno);
        double currentbalance = 0;

        dw.SetSqlCommandParameters("cracnoGl", cracno);
        dw.SetSqlCommandParameters("RefGlCodeG1", refglcode);
        dw.SetSqlCommandParameters("TransnoG1", transno);
        dw.SetSqlCommandParameters("TrLineNoG1", lineno);
        dw.SetSqlCommandParameters("TrDateG1", operationaldate);
        dw.SetSqlCommandParameters("AcSignG1", accsign);
        dw.SetSqlCommandParameters("TrAmtG1", tramt);
        dw.SetSqlCommandParameters("TrStatusGl", trstatus);
        dw.SetSqlCommandParameters("TransAssignRefNoGl", refno);
        dw.SetSqlCommandParameters("batchnoGl", batchno);

        dw.SetSqlCommandParameters("IntRateGl", intrate);
        dw.SetSqlCommandParameters("CrCatGl", crcat);
        dw.SetSqlCommandParameters("truser", truser);
        dw.SetSqlCommandParameters("trtime", trtime);
        dw.SetSqlCommandParameters("batchrefno", batchrefno);

        switch (accsign)
        {
            case "CR":


                // GL Code Parameteres
                currentbalance = GetCurrentBalance(refglcode);
                currentbalance += tramt;
                dw.SetSqlCommandParameters("RefGlCodeGL1", refglcode);
                dw.SetSqlCommandParameters("CurBalGL1", currentbalance);
                dw.SetSqlCommandParameters("LastTrDateGL1", operationaldate);
                break;

            case "DR":

                // GL Code Parameteres
                currentbalance = GetCurrentBalance(refglcode);
                currentbalance -= tramt;
                dw.SetSqlCommandParameters("RefGlCodeGL1", refglcode);
                dw.SetSqlCommandParameters("CurBalGL1", currentbalance);
                dw.SetSqlCommandParameters("LastTrDateGL1", operationaldate);
                break;
        }

        string[] commandarray = new string[3];

        commandarray[0] = @"INSERT INTO Gltrans(cracno,RefGlCode,TransNo,TrLineNo,TrDate,AcSign,TrAmt,TrStatus, TransAssignRefNo, 
                            batchno,  IntRate, CrCat, truser, trtime, batchrefno)
                        values(@cracnoGl,@RefGlCodeG1,@TransNoG1,@TrLineNoG1,@TrDateG1,@AcSignG1,@TrAmtG1,@TrStatusGl, 
                            @TransAssignRefNoGl, @batchnoGl,  @IntRateGl, @CrCatGl,@truser,@trtime, @batchrefno)";
        commandarray[1] = @"UPDATE GlCode SET CurBal = @CurBalGL1, LastTrDate=@LastTrDateGL1 WHERE RefGlCode = @RefGlCodeGL1";
        commandarray[2] = @"UPDATE TransAssign set TrStatus = @TrStatusTA, TransNo=@TransNoTA WHERE RefNo = @RefNoTA";
        int rowsadded = dw.Trans(commandarray);

        return rowsadded;
    }



    private string GetGlCode(DataRow dr)
    {
        fc = new FunctionClass();
        int loan = int.Parse(dr["loan"].ToString());
        int category = int.Parse(dr["category"].ToString());
        int loancategory = int.Parse(dr["loancategory"].ToString());
        int status = int.Parse(dr["status"].ToString());
        int extrafield = int.Parse(dr["extrafield"].ToString());
        int serialno = int.Parse(dr["serialno"].ToString());
        string refglcode = loan.ToString("0") + this.branchcode.ToString() + category.ToString("0") + loancategory.ToString("00") + status.ToString("0") + extrafield.ToString("00") + serialno.ToString("000");
        return refglcode + fc.GetModuler10(refglcode);
    }



    private int InsertCrTransJrnl(string TransNo, DateTime TrDate, string TrStatus, string CrAcNo,
        string AcSign, double TrAmt, string TrUser, string Time)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO CrTransJrnl (TransNo,TrDate,TrStatus,CrAcNo,AcSign,TrAmt,TrUser,Time) 
                       VALUES (@TransNo,@TrDate,@TrStatus,@CrAcNo,@AcSign,@TrAmt,@TrUser,@Time)");
        dw.SetSqlCommandParameters("TransNo", TransNo);
        dw.SetSqlCommandParameters("TrDate", TrDate);
        dw.SetSqlCommandParameters("TrStatus", TrStatus);
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        dw.SetSqlCommandParameters("AcSign", AcSign);
        dw.SetSqlCommandParameters("TrAmt", TrAmt);
        dw.SetSqlCommandParameters("TrUser", TrUser);
        dw.SetSqlCommandParameters("Time", Time);
        return dw.Insert();

    }

    private int IncativeCrTransJrnl(string transno, string trstatus)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand("update crtransjrnl set trstatus = @trstatus where transno = @transno");
        dw.SetSqlCommandParameters("trstatus", trstatus);
        dw.SetSqlCommandParameters("transno", transno);
        return dw.Insert();
    }




    //Get Possible Payments


    //    public DataTable GetAssignedPaymentsNotMatchToTransRef(string appno, string TrStatus, string TransRef)
    //    {
    //        dw = new DataWorksClass(constring);
    //        dw.SetDataAdapter(@"select ta.cracno, ta.TrCode, ta.refno, ta.AssignAmt, ta.AddDate, tc.TrDesc from TransAssign ta, transCat tc where ta.cracno = @cracno 
    //                            and ta.TrStatus!=@TrStatus and  ta.TransRef = @TransRef and ta.trcode = tc.trcode");
    //        dw.SetDataAdapterParameters("cracno", appno);
    //        dw.SetDataAdapterParameters("TrStatus", TrStatus);
    //        dw.SetDataAdapterParameters("TransRef", TransRef);
    //        return dw.GetDataTable();
    //    }



    #region TransAssign
    // Changed - 27/07/2009
    // public int UpdateIsReady(string refno, double tramt, bool isready)
    //{
    //    dw = new DataWorksClass(constring);
    //    dw.SetCommand(@"update TransAssign set isready=@isready, tramt=@tramt where refno = @refno");
    //    dw.SetSqlCommandParameters("refno", refno);
    //    dw.SetSqlCommandParameters("tramt", tramt);
    //    dw.SetSqlCommandParameters("IsReady", isready);
    //    return dw.Update();
    //}


    public int UpdateIsReady(string refno, string disbrefno, bool isready)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update TransAssign set isready=@isready, disbrefno=@disbrefno where refno = @refno");
        dw.SetSqlCommandParameters("refno", refno);
        dw.SetSqlCommandParameters("IsReady", isready);
        dw.SetSqlCommandParameters("disbrefno", disbrefno);
        return dw.Update();
    }


    public int UpdateIsReady(string refno, double tramt, bool isready)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update TransAssign set isready=@isready, tramt=@tramt where refno = @refno");
        dw.SetSqlCommandParameters("refno", refno);
        dw.SetSqlCommandParameters("tramt", tramt);
        dw.SetSqlCommandParameters("IsReady", isready);
        return dw.Update();
    }

    #endregion



    //#region CrApp
    //public string GetAppNo(string cracno)
    //{
    //    dw = new DataWorksClass(constring);
    //    dw.SetCommand(@"select appno from crmast where cracno=@cracno");
    //    dw.SetSqlCommandParameters("cracno", cracno);
    //    return dw.GetSingleData();
    //}

    //public string GetLoanType(string appno)
    //{
    //    dw = new DataWorksClass(constring);
    //    dw.SetCommand(@"SELECT AppCat from CrApp where AppNo = @AppNo");
    //    dw.SetSqlCommandParameters("AppNo", appno);
    //    return dw.GetSingleData();
    //}   
    //#endregion
    // Application Payment

    public int UpdateTransAssign(string refno, double tramt, bool IsReady)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update TransAssign set tramt=@tramt, IsReady=@IsReady where refno = @refno");
        dw.SetSqlCommandParameters("refno", refno);
        dw.SetSqlCommandParameters("tramt", tramt);
        dw.SetSqlCommandParameters("IsReady", IsReady);
        return dw.Update();
    }

    public int UpdateTransAssign(string refno, long disbrefno, bool IsReady)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update TransAssign set disbrefno=@disbrefno, IsReady=@IsReady where refno = @refno");
        dw.SetSqlCommandParameters("refno", refno);
        dw.SetSqlCommandParameters("IsReady", IsReady);
        dw.SetSqlCommandParameters("disbrefno", disbrefno);
        return dw.Update();
    }


    public int UpdateTransAssign(string refno, double tramt, long disbrefno, bool IsReady)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update TransAssign set disbrefno=@disbrefno, IsReady=@IsReady, tramt=@tramt where refno = @refno");
        dw.SetSqlCommandParameters("refno", refno);
        dw.SetSqlCommandParameters("disbrefno", disbrefno);
        dw.SetSqlCommandParameters("IsReady", IsReady);
        dw.SetSqlCommandParameters("tramt", tramt);
        return dw.Update();
    }

    public int UpdateTransAssign(string refno, double tramt, bool IsReady, DateTime trdate, string disbrefno, string system)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update TransAssign set tramt=@tramt, trdate=@trdate, 
                        disbrefno=@disbrefno, IsReady=@IsReady, system=@system
                        where refno = @refno");
        dw.SetSqlCommandParameters("refno", refno);
        dw.SetSqlCommandParameters("tramt", tramt);
        dw.SetSqlCommandParameters("IsReady", IsReady);
        dw.SetSqlCommandParameters("disbrefno", disbrefno);
        dw.SetSqlCommandParameters("trdate", trdate);
        dw.SetSqlCommandParameters("system", system);
        return dw.Update();
    }

    private int Module5(DataTable TransParam, string loanno, string transno, double tramt, string trstatus, string refno, int lineno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand();

        foreach (DataRow dr in TransParam.Rows)
        {
            string acref = dr["ACREF"].ToString();
            string accsign = dr["accsign"].ToString();
            string glrefcode;
            if (acref != "GLAC")
            {
                // Trans Paramenters
                glrefcode = GetGlCode(dr);
                dw.SetSqlCommandParameters("CrAcNoT", loanno);
                dw.SetSqlCommandParameters("TrAmtT", tramt);
                dw.SetSqlCommandParameters("TrLineNoT", lineno);
                dw.SetSqlCommandParameters("AccSignT", accsign);
                dw.SetSqlCommandParameters("TrStatusT", trstatus/*need to change*/);
                dw.SetSqlCommandParameters("TrUserT", user);
                dw.SetSqlCommandParameters("TrDateT", this.operationaldate);
                dw.SetSqlCommandParameters("RefGlCodeT", glrefcode);
                dw.SetSqlCommandParameters("transnoT", transno);
                dw.SetSqlCommandParameters("TransAssignRefNo", refno);

                dw.SetSqlCommandParameters("TrStatusTA", trstatus);
                dw.SetSqlCommandParameters("RefNoTA", refno);
                dw.SetSqlCommandParameters("TransNoTA", transno);

            }
            else
            {
                switch (accsign)
                {
                    case "CR":
                        glrefcode = GetGlCode(dr);
                        dw.SetSqlCommandParameters("RefGlCodeG1", glrefcode);
                        dw.SetSqlCommandParameters("transnoG1", transno);
                        dw.SetSqlCommandParameters("TrLineNoG1", lineno);
                        dw.SetSqlCommandParameters("TrDateG1", this.operationaldate);
                        dw.SetSqlCommandParameters("AcSignG1", accsign);
                        dw.SetSqlCommandParameters("TrAmtG1", tramt);

                        // GL Code Parameteres
                        double currentbalance = GetCurrentBalance(glrefcode);
                        currentbalance += tramt;
                        dw.SetSqlCommandParameters("RefGlCodeGL1", glrefcode);
                        dw.SetSqlCommandParameters("CurBalGL1", currentbalance);
                        break;

                    case "DR":
                        glrefcode = GetGlCode(dr);
                        dw.SetSqlCommandParameters("RefGlCodeG2", glrefcode);
                        dw.SetSqlCommandParameters("transnoG2", transno);
                        dw.SetSqlCommandParameters("TrLineNoG2", lineno);
                        dw.SetSqlCommandParameters("TrDateG2", this.operationaldate);
                        dw.SetSqlCommandParameters("AcSignG2", accsign);
                        dw.SetSqlCommandParameters("TrAmtG2", tramt);

                        // GL Code Parameteres
                        currentbalance = GetCurrentBalance(glrefcode);
                        currentbalance -= tramt;
                        dw.SetSqlCommandParameters("RefGlCodeGL2", glrefcode);
                        dw.SetSqlCommandParameters("CurBalGL2", currentbalance);
                        break;
                }
            }
        }

        string[] commandarray = new string[6];
        commandarray[0] = @"insert into Trans (CrAcNo,TrAmt,TrLineNo,AccSign,TrStatus,TrUser,TrDate,RefGlCode,transno, TransAssignRefNo)
                       values (@CrAcNoT,@TrAmtT,@TrLineNoT,@AccSignT,@TrStatusT,@TrUserT,@TrDateT,@RefGlCodeT,@transnoT, @TransAssignRefNo)";
        commandarray[1] = @"INSERT INTO Gltrans(RefGlCode,TransNo,TrLineNo,TrDate,AcSign,TrAmt)
                        values(@RefGlCodeG1,@TransNoG1,@TrLineNoG1,@TrDateG1,@AcSignG1,@TrAmtG1)";
        commandarray[2] = @"INSERT INTO Gltrans(RefGlCode,TransNo,TrLineNo,TrDate,AcSign,TrAmt)
                        values(@RefGlCodeG2,@TransNoG2,@TrLineNoG2,@TrDateG2,@AcSignG2,@TrAmtG2)";
        commandarray[3] = @"UPDATE GlCode SET CurBal = @CurBalGL1 WHERE RefGlCode = @RefGlCodeGL1";
        commandarray[4] = @"UPDATE GlCode SET CurBal = @CurBalGL2 WHERE RefGlCode = @RefGlCodeGL2";
        commandarray[5] = @"UPDATE TransAssign set TrStatus = @TrStatusTA, TransNo=@TransNoTA WHERE RefNo = @RefNoTA";

        return dw.Trans(commandarray);
    }

    private DataTable GetBatchHeaderData(string BatchNo, DateTime date)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from BatchHeader where BatchNo=@BatchNo");
        dw.SetDataAdapterParameters("BatchNo", BatchNo);
        dw.SetDataAdapterParameters("BatchDate", date);
        return dw.GetDataTable();
    }

    private double GetBatchTotal(long disbrefno, string trtype)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select sum(tramt) as batchtotal 
                            from Transassign where disbrefno=@disbrefno
                            and trtype = @trtype and transno is null and (trstatus ='N' or trstatus = 'P') ");
        dw.SetSqlCommandParameters("disbrefno", disbrefno);
        dw.SetSqlCommandParameters("trtype", trtype);
        return double.Parse(dw.GetSingleData());
    }

    private double GetBatchTotal(string cracno, long disbrefno, string trtype)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select sum(tramt) as batchtotal 
                            from Transassign where disbrefno=@disbrefno
                            and trtype = @trtype and cracno=@cracno");
        dw.SetSqlCommandParameters("disbrefno", disbrefno);
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("trtype", trtype);
        return double.Parse(dw.GetSingleData());
    }

    // Inter GL Transaction
    public int CallTrans(string batchno, string transno, DateTime operationaldate, DataTable dt)
    {
       
        dw = new DataWorksClass(constring);
        dw.SetCommand();
        int lineno = 0;
        string[] commandarray = new string[dt.Rows.Count * 2 + 2];

        for (int i = 0; i < dt.Rows.Count; i++)
        {
            // parameters
            string refglcode = dt.Rows[i]["cracno"].ToString();
            double tramt = double.Parse(dt.Rows[i]["tramt"].ToString());
            string trtype = dt.Rows[i]["trtype"].ToString();
            double curbal = 0;
            string AcSign = "";
            curbal = GetCurrentBalance(refglcode);
            switch (trtype)
            {
                case "I":
                    AcSign = "DR";
                    curbal += tramt;
                    break;

                case "E":
                    AcSign = "CR";
                    curbal -= tramt;
                    break;
            }

            dw.SetSqlCommandParameters("RefGlCode" + i, refglcode);
            dw.SetSqlCommandParameters("TransNo" + i, transno);
            dw.SetSqlCommandParameters("TrLineNo" + i, lineno);
            dw.SetSqlCommandParameters("TrDate" + i, operationaldate);
            dw.SetSqlCommandParameters("Acsign" + i, AcSign);
            dw.SetSqlCommandParameters("Tramt" + i, tramt);
            dw.SetSqlCommandParameters("TrStatus" + i, "A");
            dw.SetSqlCommandParameters("CurBal" + i, curbal);

            commandarray[i * 2] = "INSERT INTO Gltrans(RefGlCode,TransNo,TrLineNo,TrDate,AcSign,TrAmt,TrStatus) values (@RefGlCode"
                + i + ",@TransNo" + i + ",@TrLineNo" + i +
                ",@TrDate" + i + ",@AcSign" + i + ",@TrAmt" + i + ",@TrStatus" + i + ")";
            commandarray[i * 2 + 1] = "update glcode set curbal = @curbal" + i + " where refglcode=@refglcode" + i;
        }

        dw.SetSqlCommandParameters("TrStatus", "F");
        dw.SetSqlCommandParameters("TransNo", transno);
        dw.SetSqlCommandParameters("DisbRefNo", batchno);
        commandarray[dt.Rows.Count * 2] = @"UPDATE TransAssign set TrStatus = @TrStatus, TransNo=@TransNo WHERE DisbRefNo = @DisbRefNo";

        return dw.Trans(commandarray);

    }

    public int GetCategoryID(string taskid, string transref)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select CategoryID from transcat where taskid = @taskid and transref = @transref");
        dw.SetSqlCommandParameters("transref", transref);
        dw.SetSqlCommandParameters("taskid", taskid);
        return int.Parse(dw.GetSingleData());
    }

    public int CallTrans(DataTable dt, string transno, DateTime operationaldate, long batchno)
    {
        int rows = 0;
        //dw = new DataWorksClass(constring);
        //dw.SetCommand();

        for (int i = 0; i < dt.Rows.Count; i++)
        {
            // parameters
            string cracno = dt.Rows[i]["cracno"].ToString();

            string refglcode = "";
            double tramt = double.Parse(dt.Rows[i]["tramt"].ToString());
            double assignamt = double.Parse(dt.Rows[i]["assignamt"].ToString());
            string trtype = dt.Rows[i]["trtype"].ToString();
            string trstatus = dt.Rows[i]["trstatus"].ToString();
            string adduser = dt.Rows[i]["adduser"].ToString();
            string refno = dt.Rows[i]["refno"].ToString();
            string taskid = dt.Rows[i]["taskid"].ToString();
            string transref = dt.Rows[i]["transref"].ToString();
            double intrate = double.Parse(dt.Rows[i]["intrate"].ToString());
            int crcat = int.Parse(dt.Rows[i]["crcat"].ToString());
            string batchrefno = dt.Rows[i]["batchrefno"].ToString();

          
            if (tramt > 0)
            {
                switch (trstatus)
                {

                    case "N":
                        trstatus = "F";
                        break;

                    case "P":
                        trstatus = "P";
                        break;
                }
            }
            else
            {
                trstatus = "N";
            }
            

            if (cracno.Substring(0, 1) == "6")
            {
                refglcode = GetGlCode(9, 0, taskid, transref, cracno, user);
            }
            else
            {
                refglcode = cracno;
            }

  
            double curbal = 0;
            string AcSign = "";
            curbal = GetCurrentBalance(refglcode);

            switch (trtype)
            {
                case "I":
                    AcSign = "CR";
                    break;

                case "E":
                    AcSign = "DR";
                    break;
            }

            if (tramt > 0)
            {
                rows = Module1(cracno, AcSign, refglcode, transno, tramt, trstatus, refno, i, operationaldate, batchno, intrate, crcat, user, batchrefno);
            }
            else
            {
                msg = "Error in Batch Processing Contact System Admin";
            }

        }
        return rows;
        //return dw.Trans(commandarray);
    }



    public string GetGlCode(int loan, int extrafield, string taskid, string transref, string cracno, string user)
    {
        int loancategory = 0;
        int status = 0;
        int category = GetCategoryID(taskid, transref);
        switch (cracno.Length)
        {
            case 13:
                if ((taskid == "INTR") || (taskid == "CAPD") || (taskid == "PNLR"))
                {
                    loancategory = GetLoanCategoryCode(cracno);
                    if (taskid == "CAPD")
                    {
                        status = 1;//GetLoanStatusCode(cracno);
                    }
                    else
                    {
                        status = 0;
                    }
                }
                else
                {
                    loancategory = 0;
                    status = 0;
                }
                break;
            case 8:
                if ((taskid == "INTR") || (taskid == "CAPD") || (taskid == "PNLR"))
                {
                    loancategory = 1;//int.Parse(TaskTransactionT.Rows[x]["CrCat"].ToString());
                    if (taskid == "CAPD")
                    {
                        status = 1;
                    }
                    else
                    {
                        status = 0;
                    }
                }
                else
                {
                    loancategory = 0;
                    status = 0;
                }
                break;

            case 12:
                if ((taskid == "INTR") || (taskid == "CAPD") || (taskid == "PNLR"))
                {
                    loancategory = GetLoanCategoryCode(cracno);
                    if (taskid == "CAPD")
                    {
                        status = 1;//GetLoanStatusCode(cracno);
                    }
                    else
                    {
                        status = 0;
                    }
                }
                else
                {
                    loancategory = 0;
                    status = 0;
                }
                break;
            case 11:
                loancategory = 0;
                status = 0;
                break;
            case 10:
                loancategory = 0;
                status = 0;
                break;

        }

        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select serialno from loanserial where taskid = @taskid and categoryid = @categoryid 
                        and loancategoryid = @loancategoryid and loanstatus=@loanstatus");
        dw.SetSqlCommandParameters("categoryid", category);
        dw.SetSqlCommandParameters("loancategoryid", loancategory);
        dw.SetSqlCommandParameters("loanstatus", status);
        dw.SetSqlCommandParameters("taskid", taskid);
        int serialno = int.Parse(dw.GetSingleData());
        this.branchcode = "0308"; //int.Parse(user.Substring(0, 4)).ToString("0000"); ;
        fc = new FunctionClass();
        string refglcode = loan.ToString("0") + this.branchcode + category.ToString("0") + loancategory.ToString("00") + status.ToString("0") + extrafield.ToString("00") + serialno.ToString("000");
        return refglcode + fc.GetModuler10(refglcode);
    }



    //// Trans
    //// cracno = refglcode
    //// tramt = tramt
    //// trlineno = lineno
    //// acsign = accsign

    //dw.SetSqlCommandParameters("cracno" + i, refglcode);
    //dw.SetSqlCommandParameters("TrUser" + i, adduser);
    //dw.SetSqlCommandParameters("TrDate" + i, adddate);
    //dw.SetSqlCommandParameters("TransAssignRefNo" + i, refno);
    //dw.SetSqlCommandParameters("taskid" + i, taskid);

    //dw.SetSqlCommandParameters("RefGlCode" + i, refglcode);
    //dw.SetSqlCommandParameters("TransNo" + i, transno);
    //dw.SetSqlCommandParameters("TrLineNo" + i, lineno);
    ////dw.SetSqlCommandParameters("TrDate" + i, operationaldate);
    //dw.SetSqlCommandParameters("AcSign" + i, AcSign);
    //dw.SetSqlCommandParameters("Tramt" + i, tramt);
    ////dw.SetSqlCommandParameters("TrStatus" + i, "A");
    //dw.SetSqlCommandParameters("CurBal" + i, curbal);

    //// Update 
    //dw.SetSqlCommandParameters("refno" + i, refno);
    //dw.SetSqlCommandParameters("trstatus" + i, trstatus);


    //if (refglcode.Substring(0, 1) = "9")
    //{
    //    commandarray[i * 3] = "insert into Trans (CrAcNo,TrAmt,TrLineNo,AccSign,TrStatus,TrUser,TrDate, transno, TransAssignRefNo, taskid) values (@CrAcNo"
    //    + i + ",@TrAmt" + i + ",@TrLineNo" + i + ",@AcSign" + i + ",@TrStatus" + i + ",@TrUser" + i +
    //    ",@TrDate" + i + ",@transno" + i + ", @TransAssignRefNo" + i + ", @taskid" + i + ")";
    //}
    //commandarray[i * 3 + 1] = "INSERT INTO Gltrans(RefGlCode,TransNo,TrLineNo,TrDate,AcSign,TrAmt,TrStatus) values (@RefGlCode"
    //    + i + ",@TransNo" + i + ",@TrLineNo" + i +
    //    ",@TrDate" + i + ",@AcSign" + i + ",@TrAmt" + i + ",@TrStatus" + i + ")";

    //commandarray[i * 3 + 2] = "update glcode set curbal = @curbal" + i + " where refglcode=@refglcode" + i;
    //commandarray[i * 3 + 3] = "UPDATE TransAssign set TrStatus = @TrStatus" + i + ", TransNo=@TransNo" + i + " WHERE refno = @refno" + i;

    //public int CallTransAC(string batchno, string transno, DateTime operationaldate, DataTable dt)
    //{
    //    dw = new DataWorksClass(constring);
    //    dw.SetCommand();
    //    int lineno = 0;
    //    string[] commandarray = new string[dt.Rows.Count * 2 + 1];

    //    for (int i = 0; i < dt.Rows.Count; i++)
    //    {
    //        // parameters
    //        string refglcode = dt.Rows[i]["cracno"].ToString();
    //        string cracno = dt.Rows[i]["cracno"].ToString();
    //        string TrUser = dt.Rows[i]["cracno"].ToString();
    //        double tramt = double.Parse(dt.Rows[i]["tramt"].ToString());
    //        string trtype = dt.Rows[i]["trtype"].ToString();
    //        double curbal = 0;
    //        string AcSign = "";
    //        curbal = GetCurrentBalance(refglcode);
    //        switch (trtype)
    //        {
    //            case "I":
    //                AcSign = "DR";
    //                curbal += tramt;
    //                break;

    //            case "E":
    //                AcSign = "CR";
    //                curbal -= tramt;
    //                break;
    //        }

    //        dw.SetSqlCommandParameters("RefGlCode" + i, refglcode);
    //        dw.SetSqlCommandParameters("TransNo" + i, transno);
    //        dw.SetSqlCommandParameters("TrLineNo" + i, lineno);
    //        dw.SetSqlCommandParameters("TrDate" + i, operationaldate);
    //        dw.SetSqlCommandParameters("Acsign" + i, AcSign);
    //        dw.SetSqlCommandParameters("Tramt" + i, tramt);
    //        dw.SetSqlCommandParameters("TrStatus" + i, "A");
    //        dw.SetSqlCommandParameters("CurBal" + i, curbal);

    //        //3

    //        dw.SetSqlCommandParameters("cracno" + i, cracno);
    //        dw.SetSqlCommandParameters("TrUser" + i, TrUser);

    //        commandarray[i * 2] = "INSERT INTO Gltrans(RefGlCode,TransNo,TrLineNo,TrDate,AcSign,TrAmt,TrStatus) values (@RefGlCode"
    //        + i + ",@TransNo" + i + ",@TrLineNo" + i +
    //        ",@TrDate" + i + ",@AcSign" + i + ",@TrAmt" + i + ",@TrStatus" + i + ")";

    //        commandarray[i * 2 + 1] = "update glcode set curbal = @curbal" + i + " where refglcode=@refglcode" + i;
    //        commandarray[i*2+2]="insert into Trans (CrAcNo,TrAmt,TrLineNo,AccSign,TrStatus,TrUser,TrDate,RefGlCode,transno, TransAssignRefNo)"
    //        + "values (@CrAcNoT" + i + ",@TrAmtT" + i + ",@TrLineNoT" + i + ",@AccSignT" + i + ",@TrStatusT" + i + ",@TrUserT" + i + ",@TrDateT"
    //        + i + ",@RefGlCodeT" + i + ",@transnoT" + i + ", @TransAssignRefNo" + i + ")";


    //    }
    //    dw.SetSqlCommandParameters("TrStatus", "F");
    //    dw.SetSqlCommandParameters("TransNo", transno);
    //    dw.SetSqlCommandParameters("DisbRefNo", batchno);
    //    commandarray[dt.Rows.Count * 2] = @"UPDATE TransAssign set TrStatus = @TrStatus, TransNo=@TransNo WHERE DisbRefNo = @DisbRefNo";

    //    return dw.Trans(commandarray);

    //}

    // For Account TTransactions
    //public void Transaction(string disbrefno, DateTime operationdate, string user)
    //{
    //    int rowadded = 0;
    //    DataTable TransDataT = new DataTable();
    //    //DataTable TaskTransactionT = new DataTable();
    //    TransDataT = GetBatchHeaderData(disbrefno, operationdate);
    //    //TaskTransactionT = GetTransData("B", disbrefno);
    //    ls = new LastSerialClass();
    //    this.transno = ls.GetMaxNumber("TransNo", true).ToString(); // get the transaction number

    //    if (transno != "0") // transno can be taken
    //    {
    //        DataTable TaskTransactionT = new DataTable();
    //        TaskTransactionT = GetTransData("B", disbrefno);

    //        if (TaskTransactionT.Rows.Count == 0) // no recrds assigned
    //        {
    //            msg = "Error 0011";
    //            description = " | No payments to take";
    //            ls.UpdateLastSerialStatus("TransNo", true);
    //            msg = msg + description;
    //        }
    //        else
    //        {
    //            double totamt = double.Parse(TransDataT.Rows[0]["batchtotal"].ToString());

    //            string accsign = "CR";

    //            if (InsertCrTransJrnl(transno, operationdate, "A", disbrefno, accsign, totamt, user, DateTime.Now.TimeOfDay.ToString() /* this.time*/) != 0)
    //            {
    //                rowadded = CallTrans(disbrefno, transno, operationdate, TaskTransactionT);

    //                if (rowadded == 0)
    //                {
    //                    ls.UpdateLastSerialStatus("TransNo", true);
    //                    IncativeCrTransJrnl(transno, "R");
    //                    string refno = TaskTransactionT.Rows[0]["disbrefno"].ToString();
    //                    UpdateTransAssign(refno, 0, true);
    //                    accsign = "DR";
    //                    InsertCrTransJrnl(transno, operationdate, "A", disbrefno, accsign, totamt, user, DateTime.Now.TimeOfDay.ToString() /* this.time*/);
    //                    ls.UpdateLastserial("TransNo", long.Parse(transno) + 1);
    //                    msg = "Transaction Completed Trans Number" + transno;
    //                }
    //                else
    //                {
    //                    transno = "0";
    //                    msg = msg + description;
    //                    ls.UpdateLastSerialStatus("TransNo", true);
    //                }


    //            }
    //            else
    //            {

    //                InsertCrTransJrnl(transno, this.operationaldate, "A", loanno, accsign, totamt, this.user, DateTime.Now.TimeOfDay.ToString() /*this.time*/);
    //                ls.UpdateLastserial("TransNo", long.Parse(transno) + 1);
    //                msg = "Message 0001";
    //                description = " | Peyments are completed Transaction Number is: " + transno;
    //                msg = msg + description;
    //            }
    //        }
    //    }
    //    else
    //    {
    //        msg = "Transaction is already initiate wait for 15 seconds";
    //    }
    //}

    private DateTime GetOffDate(string cracno, string batchno, DateTime offdate)
    {

        if (GetOffDateRec(cracno,  batchno) == 0)
        {
            offdate = GetLastTrdate(cracno);
        }
        return offdate;
    }

    private DateTime GetLastTrdate(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select lsttrdate from housprop where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return DateTime.Parse(dw.GetSingleData());
    }

    private int GetOffDateRec(string cracno, string batchno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select count(*) as [count] from batchtmp where cracno = @cracno and batchno = @batchno 
                        and taskid = 'Normal'");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("batchno", batchno);
        return int.Parse(dw.GetSingleData());
    }

    // Gl Process
    public int Transaction(DateTime operationdate, long disbrefno, string user)
    {
        rc = new Recovery();
        this.user = user;
        int rowadded = 0;
        DataTable TransDataT = new DataTable();
        DataTable TaskTransactionT = new DataTable();
        // = GetBatchTotal(disbrefno); //GetBatchHeaderData(disbrefno, operationdate);
        //TaskTransactionT = GetTransData(disbrefno, op);
        ls = new LastSerialClass();
        this.transno = ls.GetMaxNumber("TransNo", true).ToString(); // get the transaction number

        if (transno != "0") // transno can be taken
        {
            TaskTransactionT = GetTransData("N", "P", disbrefno);
            if (TaskTransactionT.Rows.Count == 0) // no recrds assigned
            {
                msg = "Error 0011";
                description = " | No payments to take";
                ls.UpdateLastSerialStatus("TransNo", true);
                msg = msg + description;
            }
            else
            {
                string accsign = "CR";
                double totamt = GetBatchTotal(disbrefno, "I");
                if (InsertCrTransJrnl(transno, operationdate, "A", disbrefno.ToString(), accsign, totamt, user, DateTime.Now.TimeOfDay.ToString() /* this.time*/) != 0)
                {
                    rowadded = CallTrans(TaskTransactionT, transno, operationdate, disbrefno);

                    if (rowadded != 0)
                    {
                        if (disbrefno != long.Parse(fc.GetDateKeyinDate(operationdate) + "100"))
                        {
                            TaskTransactionT = GetBatchAccounts(disbrefno);
                            for (int i = 0; TaskTransactionT.Rows.Count > i; i++)
                            {
                                string cracno = TaskTransactionT.Rows[i]["cracno"].ToString();
                                DateTime offdate = GetOffDate(cracno, disbrefno.ToString(), DateTime.Parse(TaskTransactionT.Rows[i]["transdate"].ToString()));
                                string recstatus = rc.GetRecstatus(cracno);
                                switch (recstatus)
                                {
                                    case "CR":
                                        rc.UpdateHouspropCaprecovery(cracno, transno, "CAPD",offdate, offdate);
                                        rc.UpdateRecStatus(cracno, disbrefno, "NR");
                                        break;

                                    case "AC":
                                        rc.UpdateActStatusinHousprop(cracno, transno, "CAPD", offdate, offdate);
                                        rc.UpdateRecStatus(cracno, disbrefno, "NR");
                                        break;

                                    default:
                                        rc.UpdateActStatusinHousprop(cracno, transno, "CAPD", offdate, offdate);
                                        break;
                                }
                                //rc.UpdateActHousprop(cracno, disbrefno, "CAPD");
                            }
                            UpdateBatchTmp(transno, disbrefno);
                        }
                        else
                        {
                            UpdateCashTrans("0", transno, disbrefno);
                        }
                        //ls.UpdateLastSerialStatus("TransNo", true);
                        //IncativeCrTransJrnl(transno, "R");
                        // string refno = TaskTransactionT.Rows[0]["disbrefno"].ToString();
                        //UpdateTransAssign(refno, 0, true);
                        accsign = "DR";
                        totamt = GetBatchTotal(disbrefno, "E");
                        InsertCrTransJrnl(transno, operationdate, "A", disbrefno.ToString(), accsign, totamt, user, DateTime.Now.TimeOfDay.ToString() /* this.time*/);
                        ls.UpdateLastserial("TransNo", long.Parse(transno) + 1);
                        msg = "Transaction Completed Trans Number " + transno;
                    }
                    else
                    {
                        InsertCrTransJrnl(transno, operationdate, "C", disbrefno.ToString(), accsign, totamt, user, DateTime.Now.TimeOfDay.ToString() /* this.time*/);
                        transno = "0";
                        msg = msg + description;
                        ls.UpdateLastSerialStatus("TransNo", true);
                    }
                }
                else
                {
                    totamt = GetBatchTotal(disbrefno, "E");
                    InsertCrTransJrnl(transno, this.operationaldate, "C", loanno, accsign, totamt, this.user, DateTime.Now.TimeOfDay.ToString() /*this.time*/);
                    CancelCrTranJrnl(transno, "C");
                    ls.UpdateLastserial("TransNo", long.Parse(transno) + 1);
                    msg = "Message 0001";
                    description = " | Error In Cr Trans Jrnl";
                    msg = msg + description;
                }
            }
        }
        else
        {
            msg = "Transaction is already initiate wait for 15 seconds";
        }
        return rowadded;
    }

    private int UpdateCashTrans(string transno, string newtransno, long batchno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update CashierTransaction set transno = @newtransno where batchno = @batchno 
                        and transno =@transno");
        dw.SetSqlCommandParameters("transno", transno);
        dw.SetSqlCommandParameters("newtransno", newtransno);
        dw.SetSqlCommandParameters("batchno", batchno);
        return dw.Update();
    }

    private int UpdateBatchTmp(string transno, long batchno, string status)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update batchtmp set transno = @transno where batchno = @batchno and status = @status");
        dw.SetSqlCommandParameters("batchno", batchno);
        dw.SetSqlCommandParameters("transno", transno);
        dw.SetSqlCommandParameters("status", status);
        return dw.Update();
    }

    private int UpdateBatchTmp(string transno, long batchno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update batchtmp set transno = @transno where batchno = @batchno");
        dw.SetSqlCommandParameters("batchno", batchno);
        dw.SetSqlCommandParameters("transno", transno);
        return dw.Update();
    }


    private DataTable GetBatchAccounts(long disbrefno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select distinct cracno, max(transdate) as transdate from batchtmp 
                            where batchno = @disbrefno and left(cracno,1) = '6'
                            group by cracno");
        dw.SetDataAdapterParameters("disbrefno", disbrefno);
        return dw.GetDataTable();
    }

    private DataTable GetBatchAccounts(long disbrefno, string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select distinct cracno from transassign where 
                            disbrefno = @disbrefno and left(cracno,1) = '6' and cracno=@cracno");
        dw.SetDataAdapterParameters("disbrefno", disbrefno);
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }

    public int Transaction(long disbrefno, string user, DateTime operationdate, string cracno)
    {

        rc = new Recovery();
        this.user = user;
        int rowadded = 0;
        DataTable TransDataT = new DataTable();
        DataTable TaskTransactionT = new DataTable();
        // = GetBatchTotal(disbrefno); //GetBatchHeaderData(disbrefno, operationdate);
        //TaskTransactionT = GetTransData(disbrefno, op);
        ls = new LastSerialClass();
        this.transno = ls.GetMaxNumber("TransNo", true).ToString(); // get the transaction number

        if (transno != "0") // transno can be taken
        {
            TaskTransactionT = GetTransData("N", "P", disbrefno, cracno);

            if (TaskTransactionT.Rows.Count == 0) // no recrds assigned
            {
                msg = "Error 0011";
                description = " | No payments to take";
                ls.UpdateLastSerialStatus("TransNo", true);
                msg = msg + description;
            }
            else
            {
                string accsign = "CR";
                double totamt = GetBatchTotal(cracno, disbrefno, "I");
                if (InsertCrTransJrnl(transno, operationdate, "A", disbrefno.ToString(), accsign, totamt, user, DateTime.Now.TimeOfDay.ToString() /* this.time*/) != 0)
                {
                    rowadded = CallTrans(TaskTransactionT, transno, operationdate, disbrefno);

                    if (rowadded != 0)
                    {
                        TaskTransactionT = GetBatchAccounts(disbrefno, cracno);
                        for (int i = 0; TaskTransactionT.Rows.Count > i; i++)
                        {
                            cracno = TaskTransactionT.Rows[i]["cracno"].ToString();
                            rc.UpdateActStatusinHousprop(cracno, transno, "CAPD", operationdate, operationdate);
                            //rc.UpdateActHousprop(cracno, disbrefno, "CAPD");
                        }
                        //ls.UpdateLastSerialStatus("TransNo", true);
                        //IncativeCrTransJrnl(transno, "R");
                        // string refno = TaskTransactionT.Rows[0]["disbrefno"].ToString();
                        //UpdateTransAssign(refno, 0, true);
                        accsign = "DR";
                        totamt = GetBatchTotal(disbrefno, "I");
                        InsertCrTransJrnl(transno, operationdate, "A", disbrefno.ToString(), accsign, totamt, user, DateTime.Now.TimeOfDay.ToString() /* this.time*/);
                        UpdateBatchTmp(transno, disbrefno, "Y");
                        ls.UpdateLastserial("TransNo", long.Parse(transno) + 1);
                        msg = "Transaction Completed Trans Number " + transno;
                    }
                    else
                    {
                        InsertCrTransJrnl(transno, operationdate, "C", disbrefno.ToString(), accsign, totamt, user, DateTime.Now.TimeOfDay.ToString() /* this.time*/);
                        transno = "0";
                        msg = msg + description;
                        ls.UpdateLastSerialStatus("TransNo", true);
                    }
                }
                else
                {
                    totamt = GetBatchTotal(disbrefno, "E");
                    InsertCrTransJrnl(transno, this.operationaldate, "C", loanno, accsign, totamt, this.user, DateTime.Now.TimeOfDay.ToString() /*this.time*/);
                    CancelCrTranJrnl(transno, "C");
                    ls.UpdateLastserial("TransNo", long.Parse(transno) + 1);
                    msg = "Message 0001";
                    description = " | Error In Cr Trans Jrnl";
                    msg = msg + description;
                }
            }
        }
        else
        {
            msg = "Transaction is already initiate wait for 15 seconds";
        }
        return rowadded;
    }

}