using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// Summary description for Test
/// </summary>
public class Test
{
    DataWorksClass dw;
    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();
	public Test()
	{
		//
		// TODO: Add constructor logic here
		//
	}


    public void trans1(string cracno, string trcode, string oritrcode)
    {
        dw = new DataWorksClass(constring);
        string statement1 = @"INSERT INTO Temp (CrAcNo,TrCode) VALUES (@CrAcNo, @TrCode)";
        string statement2 = @"update Temp set CrAcNo = 999 where TrCode=@Oritrcode";
        string[] strArray = new string[2];
        strArray[0] = statement1;
        strArray[1] = statement2;

        dw.SetCommand();
        //dw.SetCommand(@"update temp set cracno = 200 where trcode = @Oritrcode");
        dw.SetSqlCommandParameters("CRACNO", cracno);
        dw.SetSqlCommandParameters("trcode", trcode);
        dw.SetSqlCommandParameters("Oritrcode", trcode);
        dw.Trans(strArray);
    }



    public int trans(string statement1, string statement2)
    {

        using (SqlConnection connection =
              new SqlConnection(constring))
        {
            SqlCommand command = connection.CreateCommand();
            SqlTransaction transaction = null;

            try
            {
                // BeginTransaction() Requires Open Connection
                connection.Open();

                transaction = connection.BeginTransaction();

                // Assign Transaction to Command
                command.Transaction = transaction;

                // Execute 1st Command
                command.CommandText = statement1;
                command.ExecuteNonQuery();

                // Execute 2nd Command
                command.CommandText = statement2;
                command.ExecuteNonQuery();

                transaction.Commit();
            }
            catch
            {
                transaction.Rollback();
                throw;
            }
            finally
            {
                connection.Close();
            }
        }
        return 0;
    }

    
}
