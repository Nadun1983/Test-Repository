using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// Summary description for ExistAppNos
/// </summary>
public class ExistAppNos
{
	private SqlDataAdapter da;
    DataSet ds;
    private SqlConnection mycon;
    DataWorksClass dw;
    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();

    public ExistAppNos()
	{
		
        SqlConnection myconnection = new SqlConnection(ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString);
        this.mycon = myconnection;
	}

    public DataTable ExistCustDet(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"SELECT cm.NicNo as NicNo,* from AppHolder ap, CustomerMain cm, CrApp c WHERE
                    C.AppNo=@appno AND C.AppNo=Ap.Appno AND ap.nicno=cm.nicno ORDER BY HolderType");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();
    }

    public DataTable ExistApplication(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"SELECT * from CrApp c WHERE C.AppNo=@appno");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();
    }

    public int UpdateAppHolder(string newnic, string appno, string oldnic)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"UPDATE appholder SET nicno=@newnic where appno=@appno and nicno=@oldnic");
        dw.SetSqlCommandParameters("newnic", newnic);
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("oldnic", oldnic);
        return dw.Update();
    }

    public DataTable GetExistAppDet(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"SELECT *, Crp.CrCatCode AS catCode,apcat.catpurposeid AS CatId, apcat.Intrate AS Rate, cp.descrip AS Descrip, 
                    apcat.Amount as Amount, crp.PurposeCode AS Pcode
                    FROM crapp cap, appcategory apcat, crcatpurpose crp,crcategory cr,
                    crpurpose cp WHERE cap.appno=@appno and cap.appno=apcat.appno and
                     apcat.catpurposeid=crp.catpurposeid and crp.crcatcode=cr.crcatcode and 
                     crp.purposecode=cp.purposecode");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();
    }

    public int UpdateCrAppDet(string appno, DateTime rdate, decimal boqamt,
                                  decimal puramt, int disbursement, int gracep, int maxperiod,
                                  string sectype, string ctype, string loantype, string Isadd, int LoanPeriod)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"UPDATE CrApp SET RecvDate=@rdate,BoqAmount=@boqamt,RedemPurchaseAmt=@puramt, 
                        NoOfDisb=@disbursement,GracePeriod=@gracep,CrPeriod=@maxperiod,SecurityType=@sectype,
                        ClientType=@ctype,AppCat=@loantype,IsAdditional=@Isadd,LoanPeriod=@LoanPeriod WHERE AppNo=@appno");
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("rdate", rdate);
        dw.SetSqlCommandParameters("boqamt", boqamt);
        dw.SetSqlCommandParameters("puramt", puramt);
        dw.SetSqlCommandParameters("disbursement", disbursement);
        dw.SetSqlCommandParameters("gracep", gracep);
        dw.SetSqlCommandParameters("maxperiod", maxperiod);
        dw.SetSqlCommandParameters("sectype", sectype);
        dw.SetSqlCommandParameters("ctype", ctype);
        dw.SetSqlCommandParameters("loantype", loantype);
        dw.SetSqlCommandParameters("Isadd", Isadd);
        dw.SetSqlCommandParameters("LoanPeriod", LoanPeriod);
        return dw.Update();
    }

    public int UpdateCrAmountDet(string appno, string ctype, string loantype)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"UPDATE CrApp SET ClientType=@ctype,AppCat=@loantype WHERE AppNo=@appno");
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("ctype", ctype);
        dw.SetSqlCommandParameters("loantype", loantype);
        return dw.Update();
    }

    public int UpdateOnlyCrAmt(string appno, decimal amount, int CrCatCode)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"UPDATE CrApp SET CrAmt=@amount, CrCatCode=@CrCatCode WHERE AppNo=@appno");
        dw.SetSqlCommandParameters("amount", amount);
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("CrCatCode", CrCatCode);
        return dw.Update();
    }

    public int UpdateAppCategory(string appno, decimal oldrate, int oldcategory, 
                                     decimal intrate, decimal amount, int category, decimal oldamount)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"UPDATE AppCategory SET Amount=@amount,IntRate=@intrate,CatPurposeId=@category 
                      WHERE AppNo=@appno AND IntRate=@oldrate AND CatPurposeId=@oldcategory AND Amount=@oldamount");
        dw.SetSqlCommandParameters("amount", amount);
        dw.SetSqlCommandParameters("intrate", intrate);
        dw.SetSqlCommandParameters("category", category);
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("oldrate", oldrate);
        dw.SetSqlCommandParameters("oldcategory", oldcategory);
        dw.SetSqlCommandParameters("oldamount", oldamount);
        return dw.Update();
    }

    public DataTable GetShareDetails(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"SELECT ShareType,ShareDetail,ShareAmt,CASE ShareType WHEN 'B' THEN 'BOQ' 
                            ELSE 'Purchasing/Redemption' END AS Details FROM AppShare WHERE AppNo=@appno");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();
        
    }

    public DataSet DeleteApplicationHolder(string nicno, string appno)
    {
        string sql = "DELETE FROM AppHolder WHERE AppNo="+appno+" AND NicNo='"+nicno+"'";
        da = new SqlDataAdapter(sql, mycon);
        ds = new DataSet();
        try
        {
            mycon.Open();
            da.Fill(ds, sql);
        }
        catch (Exception er)
        {

        }
        finally
        {
            da.Dispose();
            mycon.Close();
        }
        return ds;
    }

    public DataSet DeleteAppCategory(string appno, decimal IntRate, int CatId)
    {
        string sql = "DELETE FROM AppCategory WHERE AppNo="+appno+" AND IntRate="+IntRate+" AND CatPurposeId="+CatId+"";
        da = new SqlDataAdapter(sql, mycon);
        ds = new DataSet();
        try
        {
            mycon.Open();
            da.Fill(ds, sql);
        }
        catch (Exception er)
        {

        }
        finally
        {
            da.Dispose();
            mycon.Close();
        }
        return ds;
    }

    public DataTable ChangeAppCategory(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"SELECT Descrip,A.CatPurposeId AS CatId, IntRate, Amount FROM AppCategory A, 
                      CrCatPurpose Cr, CrCategory Cat, CrPurpose Cp WHERE A.AppNo=@appno AND 
                      A.CatPurposeId=Cr.CatPurposeId AND Cr.CrCatCode=Cat.CrCatCode AND
                        Cr.PurposeCode=Cp.PurposeCode");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();

    }

    public int UpdateShareDetails(string appno, string sharetype, string sharedet, decimal amount,
                                     string oldtype, string olddetail)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"UPDATE AppShare SET ShareType=@sharetype, ShareDetail=@sharedet,ShareAmt=@amount 
                      WHERE AppNo=@appno AND ShareType=@oldtype AND ShareDetail=@olddetail");
        dw.SetSqlCommandParameters("sharetype", sharetype);
        dw.SetSqlCommandParameters("sharedet", sharedet);
        dw.SetSqlCommandParameters("amount", amount);
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("oldtype", oldtype);
        dw.SetSqlCommandParameters("olddetail", olddetail);
        return dw.Update();
    }

    public DataTable GetRedemptionDetails(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"SELECT * FROM AppRedemption WHERE AppNo=@appno");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();
    }

    public int UpdateRedemptionDetails(string appno, string bankname, string amount, string accno, 
                                           string gdate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"UPDATE AppRedemption SET BankName=@bankname, GrantedAmt=@amount, AccountNo=@accno, 
                        GrantedDate=@gdate WHERE AppNo=@appno");
        dw.SetSqlCommandParameters("bankname", bankname);
        dw.SetSqlCommandParameters("amount", amount);
        dw.SetSqlCommandParameters("accno", accno);
        dw.SetSqlCommandParameters("gdate", gdate);
        dw.SetSqlCommandParameters("appno", appno);
        return dw.Update();
    }

    public int GetRedeemRecord(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"SELECT Cp.PurposeCode AS Pcode FROM AppCategory A, CrCatPurpose Cp 
                     WHERE AppNo=@appno AND A.CatPurposeId=Cp.CatPurposeId AND Cp.PurposeCode IN(3)");
        dw.SetSqlCommandParameters("appno", appno);
        return int.Parse(dw.GetSingleData());
    }

    public decimal getNewAmount(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"SELECT SUM(Amount) AS Amount FROM AppCategory WHERE AppNo=@appno");
        dw.SetSqlCommandParameters("appno", appno);
        return decimal.Parse(dw.GetSingleData());
    }

    public string GetPrimaryNicNo(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"SELECT NicNo FROM AppHolder WHERE AppNo=@appno AND HolderType='P'");
        dw.SetSqlCommandParameters("appno", appno);
        return dw.GetSingleData();
    }


    public DataTable GetApprovedAppNo(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"SELECT * FROM ApprovalStatus WHERE AppNo=@appno AND Status='A'");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();
    }

    public DataTable GetApprovedNic(string nic)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"SELECT * FROM AppHolder A, CrApp C WHERE A.NicNo=@nic AND A.AppNo=C.AppNo AND 
                            C.Status='A' AND C.IsApproved='Y'");
        dw.SetDataAdapterParameters("nic", nic);
        return dw.GetDataTable();
    }

    public DataTable GetPowerOfAttorneyDet(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"SELECT C.NicNo AS NicNo,RTRIM(Initials) AS Initials, RTRIM(Surname) AS Surname,
                            RTRIM(Location) AS Location, RTRIM(Street) AS Street,
                            RTRIM(City) AS City FROM PowerOfAttonery P, CustomerMain C 
                            WHERE P.AppNo=@appno AND P.NicNo=C.NicNo");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();
    }

    public DataSet DeletePowerOfAttorney(string appno, string nicno)
    {
        string sql = " DELETE FROM PowerOfAttonery WHERE AppNo="+appno+" AND NicNo='"+nicno+"'";
        da = new SqlDataAdapter(sql, mycon);
        ds = new DataSet();
        try
        {
            mycon.Open();
            da.Fill(ds, sql);
        }
        catch (Exception er)
        {

        }
        finally
        {
            da.Dispose();
            mycon.Close();
        }
        return ds;
    }

    public DataSet DeleteApplicantShare(string appno, string sharetype, string sharedetail)
    {
        string sql = " DELETE FROM AppShare WHERE AppNo=" + appno + " AND ShareType='"+sharetype+"' AND "+
                     " ShareDetail='"+sharedetail+"'";
        da = new SqlDataAdapter(sql, mycon);
        ds = new DataSet();
        try
        {
            mycon.Open();
            da.Fill(ds, sql);
        }
        catch (Exception er)
        {

        }
        finally
        {
            da.Dispose();
            mycon.Close();
        }
        return ds;
    }

    //To show Gurantor Details 2012/04/10
    //-------------------------------------------------------------------------------------------------------
    public DataTable GetGurantorDetails(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"SELECT C.NicNo AS NicNo,RTRIM(Initials) AS Initials, RTRIM(Surname) AS Surname,
                            RTRIM(Location) AS Location, RTRIM(Street) AS Street,
                            RTRIM(City) AS City FROM AppSecGarant G, CustomerMain C 
                            WHERE G.AppNo=@appno AND G.NicNo=C.NicNo");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();
    }

    public int DeleteGurantor(string nicno, string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"DELETE FROM AppSecGarant WHERE AppNo=@appno AND Nicno=@nicno");
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("nicno", nicno);
        return dw.Delete();
    }
    //--------------------------------------------------------------------------------------------------------

    public DataTable GetFloatingRateDetails(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"SELECT * FROM FloatingRateApps WHERE AppNo=@appno");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();
    }

    public DataTable GetTopUpPurposeDetails(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select distinct T.CatPurposeId as CatPurposeId, R.Descrip as Descrip, T.CrAcNo as CrAcNo
                            from TopUpLoans T, CrCatPurpose P, CrPurpose R
                            where T.CatPurposeId = P.catpurposeid and P.purposecode = R.PurposeCode
                            and T.AppNo = @appno");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();
    }

    public DataTable GetExistTopUpDetails(string nicno, string CrAcNo)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select M.Appno, H.CrAcNo,M.GrantAmt,H.ActOutBal,M.GrantDate,S.PlanNo,S.LotNo, R.CrDes 
                            from CrHolder C, CrMast M, HousProp H, Hpsec S, CrCategory R
                            where C.NicNo = @nicno and C.CrAcNo = M.CrAcNo and M.CrAcNo = H.CrAcNo
                            and C.HolderType = 'P' and H.ActOutBal > 0 and H.CrCat not in (9,11,19)
                            and C.AppNo = S.AppNo and H.CrCat = R.CrCatCode and H.CrAcNo in (select CrAcNo
                            from TopUpLoans where CrAcNo=@CrAcNo)");
        dw.SetDataAdapterParameters("nicno", nicno);
        dw.SetDataAdapterParameters("CrAcNo", CrAcNo);
        return dw.GetDataTable();
    }

    public string GetLECOMeterNo(string AppNo)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select MeterNo From NSBEcoMeterDetails where AppNo=@AppNo");
        dw.SetSqlCommandParameters("AppNo", AppNo);
        return dw.GetSingleData();
    }

    public int UpdateEcoLoan(string AppNo, string NicNo, string MeterNo)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"UPDATE NSBEcoMeterDetails SET NicNo=@NicNo,MeterNo=@MeterNo WHERE AppNo=@AppNo");
        dw.SetSqlCommandParameters("AppNo", AppNo);
        dw.SetSqlCommandParameters("NicNo", NicNo);
        dw.SetSqlCommandParameters("MeterNo", MeterNo);
        return dw.Update();
    }

    public int DeleteTopUpLoan(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"DELETE FROM topuploans WHERE AppNo=@appno");
        dw.SetSqlCommandParameters("appno", appno);
        return dw.Delete();
    }
}
