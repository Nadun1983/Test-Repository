﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Data.SqlClient;

/// <summary>
/// Summary description for RescheduleClass
/// </summary>
public class RescheduleClass
{
    private string constring = ConfigurationManager.ConnectionStrings["housdbString"].ToString();
    DataWorksClass dw;
    CrTransClass ctc;
    ExsistLoanDetails eld;
	public RescheduleClass()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public int GetArreasMonths(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select datediff(month, LastCompletedDueDate,DateDue) as ArreasMonths
                        from housprop where cracno=@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return int.Parse(dw.GetSingleData());
    }

    public double GetArreasInterest(string cracno, string taskid)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select sum(AssignAmt) from transassign where taskid=@taskid and
                        cracno=@cracno and (transref='N' or transref='P')");
        dw.SetSqlCommandParameters("cracno", cracno);
        return double.Parse(dw.GetSingleData());
    }

    public DataTable GetRescheduleData(DateTime date, double intrate)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select c.crcat,r.crdes, h.intrate, h.cracno, h.actoutbal, 
                            h.lastcompletedduedate,  h.crperiod, h.Instalment 
                            from housprop h, crmast c, crcategory r
                            where h.cracno = c.cracno and
                            lastcompletedduedate >= @date
                            and h.intrate >= @intrate and h.actoutbal >  0 
                            and c.crcat = r.crcatcode
			    and c.grantdate <= '20091031'
                            and h.ResheduleDate is null  and r.crcatcode <> 3
                            order by c.crcat , h.intrate");
        dw.SetDataAdapterParameters("date", date);
        dw.SetDataAdapterParameters("intrate", intrate);
        return dw.GetDataTable();
    }


    public DataTable GetCtCat()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select cracno, crcat 
                            from crmast");
        return dw.GetDataTable();
    }
    //(||||)
    public int UpdateCrCat(string cracno, int crcat)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update housprop set crcat = @crcat where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("crcat", crcat);
        return dw.Update();
    }
    //Dilanka
    public double GetNewIntRate(double ExistingRate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select RevisedRate from InterestRateChanges where ExistingRate=@ExistingRate ");
        dw.SetSqlCommandParameters("ExistingRate", ExistingRate);
        return double.Parse(dw.GetSingleData());
    }
    //Dilanka
    public double UpdateResheduleIntRate(string cracno, double newIntrate, string ResheduleDate)
    {
        int RowAdded = 0;
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update housprop set IntRate=@newIntrate,ResheduleDate=@ResheduleDate where cracno=@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("newIntrate", newIntrate);
        dw.SetSqlCommandParameters("ResheduleDate", ResheduleDate);
        RowAdded = dw.Update();
        return RowAdded;
    }


    public void InsertHouspropHistry(string cracno, double NewIntRate, int NewCrPeriod, double NewOutBal,
        int NewCrCat, double NewInstalment, DateTime TrDate, string ChangeUser)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into HouspropHistry 
	                        SELECT @TrDate,CrAcNo
	                          ,@TrDate
	                          ,IntRate,Instalment
                              ,OutBal,DateDue,GracePeriod
                              ,LstTrDate,LstPaiddate,LstReptdate,RecptPeriod,YearBeginbal
                              ,AddUser,Adddate,LastCompletedDueDate,IsDisbursed
                              ,CrPeriod,LoanStatusCode,PaidInstalments,ActOutBal,penalvaliddate
                              ,recstatus,disbrefno
                              ,@ChangeUser
                              ,@NewIntRate
                              ,@NewCrPeriod
                              ,@NewOutBal, @NewCrCat,@NewInstalment
                          FROM Housprop where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("NewIntRate", NewIntRate);
        dw.SetSqlCommandParameters("NewCrPeriod", NewCrPeriod);
        dw.SetSqlCommandParameters("NewOutBal", NewOutBal);
        dw.SetSqlCommandParameters("NewCrCat", NewCrCat);
        dw.SetSqlCommandParameters("TrDate", TrDate);
        dw.SetSqlCommandParameters("ChangeUser", ChangeUser);
        dw.SetSqlCommandParameters("NewInstalment", NewInstalment);
        dw.Insert();
    }


    public void InsertHouspropHistry(string cracno, double NewIntRate, int NewCrPeriod, double NewOutBal, int CrCat,
        int NewCrCat, double NewInstalment, DateTime TrDate, string ChangeUser, DateTime NewLastCompletedDueDate, string PrevCracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into HouspropHistry 
	                        SELECT @TrDate,CrAcNo
	                          ,@TrDate
	                          ,IntRate,Instalment
                              ,OutBal,DateDue,GracePeriod
                              ,LstTrDate,LstPaiddate,LstReptdate,RecptPeriod,YearBeginbal
                              ,AddUser,Adddate,LastCompletedDueDate,IsDisbursed
                              ,CrPeriod,LoanStatusCode,PaidInstalments,ActOutBal,penalvaliddate
                              ,recstatus,disbrefno
                              ,@ChangeUser
                              ,@NewIntRate
                              ,@NewCrPeriod
                              ,@NewOutBal, @CrCat,@NewCrCat,@NewLastCompletedDueDate,@NewInstalment,@PrevCracno
                          FROM Housprop where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("NewIntRate", NewIntRate);
        dw.SetSqlCommandParameters("NewCrPeriod", NewCrPeriod);
        dw.SetSqlCommandParameters("NewOutBal", NewOutBal);
        dw.SetSqlCommandParameters("CrCat", CrCat);
        dw.SetSqlCommandParameters("NewCrCat", NewCrCat);
        dw.SetSqlCommandParameters("TrDate", TrDate);
        dw.SetSqlCommandParameters("ChangeUser", ChangeUser);
        dw.SetSqlCommandParameters("NewLastCompletedDueDate", NewLastCompletedDueDate);
        dw.SetSqlCommandParameters("NewInstalment", NewInstalment);
        dw.SetSqlCommandParameters("PrevCracno", PrevCracno);
        dw.Insert();
    }
    //(||||)
    public void UpDateHouspropIntRateandInstallment(string cracno, double newIntrate, double newinstlmnt, int crcat, int crperiod, string ResheduleDate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update housprop set intrate = @newIntrate , instalment = @newinstlmnt,
                                crcat = @crcat, crperiod = @crperiod,ResheduleDate = @ResheduleDate where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("newIntrate", newIntrate);
        dw.SetSqlCommandParameters("newinstlmnt", newinstlmnt);
        dw.SetSqlCommandParameters("crcat", crcat);
        dw.SetSqlCommandParameters("crperiod", crperiod);
        dw.SetSqlCommandParameters("ResheduleDate", ResheduleDate);
        dw.Update();
    }

    public void UpdateHouspropDateDue(string cracno, DateTime LastCompletedDueDate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update housprop set LastCompletedDueDate = @LastCompletedDueDate,datedue = @LastCompletedDueDate 
                                where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("LastCompletedDueDate", LastCompletedDueDate);
        dw.Update();
    }

    public void UpDateHouspropInstalment(string cracno, double newinstlmnt)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update housprop set instalment = @newinstlmnt where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("newinstlmnt", newinstlmnt);
        dw.Update();
    }

    public void UpDateHouspropInstalment(string cracno, double newinstlmnt, string ResheduleDate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update housprop set instalment = @newinstlmnt,ResheduleDate = @ResheduleDate  where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("newinstlmnt", newinstlmnt);
        dw.SetSqlCommandParameters("ResheduleDate", ResheduleDate);
        dw.Update();
    }

    //Predeep
    public DataTable GetHouspropData()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select h.cracno,h.crperiod,c.grantdate,h.datedue from housprop h, crmast c where h.cracno = c.cracno ");
        //dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }
    //Predeep
    public void UpDateHousprop(string cracno, int PaidInstalments)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update housprop set PaidInstalments = @PaidInstalments where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("PaidInstalments", PaidInstalments);
        dw.Update();
    }
    //Predeep
    public void UpDateHouspropIntRate(string cracno, double newIntrate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update housprop set intrate = @newIntrate where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("newIntrate", newIntrate);
        dw.Update();
    }

    public string GetAppNo(string cracno)
    {
        DataTable dt = new DataTable();
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select appno from crmast where cracno =  @cracno ");
        dw.SetDataAdapterParameters("cracno", cracno);
        dt = dw.GetDataTable();

        return dt.Rows[0]["appno"].ToString();
    }

    public DataTable GetCrHolderData(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select appno,holdertype,holdercount,nicno,custno,holdrelation,isadditional from crholder where cracno =   @cracno ");
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }


    public DataTable GetRevisedInterestRate(DateTime date)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select cracno,intrate,newintrate from housprophistry where changedate = @date");
        dw.SetDataAdapterParameters("date", date);
        return dw.GetDataTable();
    }
    //Pradeep
    public void UpdateHousprop(string cracno,DateTime DateDue,DateTime LastCompletedDueDate,DateTime penalvaliddate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update housprop set DateDue = @DateDue ,LastCompletedDueDate = @LastCompletedDueDate,
	                         penalvaliddate = @penalvaliddate,recstatus = 'NR' where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("DateDue", DateDue);
        dw.SetSqlCommandParameters("LastCompletedDueDate", LastCompletedDueDate);
        dw.SetSqlCommandParameters("penalvaliddate", penalvaliddate);
        dw.Update();
    }

    public bool validateNIC(string nicno)
    {
        bool validation = false;

        if (nicno.Length != 10)
        {
            validation = false;
        }
        else if (nicno.Substring(9, 1) != "V" && nicno.Substring(9, 1) != "X" && nicno.Substring(9, 1) != "v" && nicno.Substring(9, 1) != "x")
        {
            validation = false;
        }
        else
        {
            try
            {
                int.Parse(nicno.Substring(0, 9));
                int dob = int.Parse(nicno.Substring(2, 3));
                if (dob > 366)
                {
                    dob = dob - 500;
                }
                if (dob > 0)
                {
                    if (dob < 367)
                    {
                        validation = true;
                    }
                    else
                    {
                        validation = false;
                    }
                }
                else
                {
                    validation = false;
                }
            }
            catch
            {
                validation = false;
            }
        }

        return validation;
    }
    
    public DataTable GetCustDetails(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@" select ti.titledesc,rtrim (cm.initials) +' '+  rtrim (cm.surname) as Name,
                            cm.location,cm.street,cm.city
                            from title ti,Customermain cm,crholder cr
                            where ti.titlecode=cm.titlecode and cm.nicno=cr.nicno and 
                            cr.holdertype='P' and cracno=@cracno");
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }



    public void GetNIC(string cracno)
    {
        ctc = new CrTransClass();
        eld = new ExsistLoanDetails();
        string appno = ctc.GetAppNo(cracno);
        string nicno;


        //string appno = eld.Getappno(cracno);
        DataTable existcrholder = new DataTable();
        DataTable existsappholder = new DataTable();

        DataTable oldcrhdetails = new DataTable();
        DataTable oldaphdetails = new DataTable();

        existsappholder = eld.GetExistAppHolder(appno, "P");
        existcrholder = eld.GetExistCrHolder(appno, "P");

        //Insert Data to CrApp
        if (eld.GetExistAppno(appno) == "0")
        {
            eld.InsertDataToCrApp(appno);
        }

        //Insert Data to AppHolder
        if (existsappholder.Rows.Count > 0)
        {
            for (int i = 0; i < existsappholder.Rows.Count; i++)
            {
                nicno = existsappholder.Rows[i]["nicno"].ToString();
                if (nicno.Trim() == "" || nicno == null)
                {
                    //
                }
            }
        }
        else
        {
            oldaphdetails = eld.GetOldAppHolder(appno);
            for (int i = 0; i < oldaphdetails.Rows.Count; i++)
            {
                nicno = oldaphdetails.Rows[i]["nicno"].ToString();
                bool nicvalidate = validateNIC(nicno);
                if (nicvalidate == true)
                {
                    eld.InsertDataToAppHolder(appno);
                }
                else
                {
                    //
                }
            }


        }

        //Insert Data to CrHolder
        if (existcrholder.Rows.Count > 0)
        {
            for (int i = 0; i < existcrholder.Rows.Count; i++)
            {
                nicno = existcrholder.Rows[i]["nicno"].ToString();
                bool nicvalidate = validateNIC(nicno);

                if (nicno.Trim() == "" || nicno == null)
                {
                    //
                }
            }
        }
        else
        {
            oldcrhdetails = eld.GetOldCrHolder(appno);
            for (int i = 0; i < oldcrhdetails.Rows.Count; i++)
            {
                nicno = oldcrhdetails.Rows[i]["nicno"].ToString();
                bool nicvalidate = validateNIC(nicno);
                if (nicvalidate == true)
                {
                    eld.InsertDataToCrHolder(cracno, appno);

                }
                else
                {

                }
            }
        }


        //Insert Data to CustomerMain
        DataTable nic515 = new DataTable();
        nic515 = eld.GetNICFrom515(appno);
        if (nic515.Rows.Count > 0)
        {
            for (int i = 0; i < nic515.Rows.Count; i++)
            {
                string nicnum = nic515.Rows[i]["nicno"].ToString().Trim();
                string custno = nic515.Rows[i]["custno"].ToString().Trim();

                bool nicvalidate = validateNIC(nicnum);
                if (nicvalidate == true)
                {
                    if (eld.GetExistCustomerMain(nicnum) == "0")
                    {
                        eld.InsertCustomerMain(nicnum, custno);
                        eld.InsertCustomerSub(nicnum, custno);
                    }
                }
                else
                {

                }

            }
        }
    }

   //vihanga 2010-12-14
    public DataTable GetLoanDetailsToeditAprovdGrantAmount(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select c.Cracno,c.AppNo,c.GrantAmt,c.AprovdAmt,
	rtrim(rtrim(cm.initials) +' '+rtrim(cm.surname)) as [Name], GrantDate, h.instalment, h.intrate, h.crperiod
	from crmast c , housprop h,crholder ch,customermain cm
	where c.cracno=@cracno and c.cracno=h.cracno and h.actoutbal>0 and ch.cracno=h.cracno
	and cm.nicno=ch.nicno");
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }

    //vihanga 2010-12-14
    public int EnterIntocrMastHistryReshedule(string cracno, double OldGrantAmount, double OldApprovedAmount,
                double NewApprovedAmount, double NewGrantAmount, string operationdate, DateTime ActualDate,
                string userName, string appno, DateTime OldGrantDate, DateTime NewGrantDate, double OldInstalment, double NewInstalment)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO crMastHistryReshedule
                        (cracno,OldGrantAmount,OldApprovedAmount,NewApprovedAmount,NewGrantAmount
                        ,operationdate,ActualDate,userName,appno, OldGrantDate, NewGrantDate, OldInstalment, NewInstalment)
                        VALUES(@cracno,@OldGrantAmount,@OldApprovedAmount,@NewApprovedAmount,@NewGrantAmount
                        ,@operationdate,@ActualDate,@userName,@appno, @OldGrantDate, @NewGrantDate, @OldInstalment, 
                        @NewInstalment)");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("OldGrantAmount", OldGrantAmount);
        dw.SetSqlCommandParameters("OldApprovedAmount", OldApprovedAmount);
        dw.SetSqlCommandParameters("NewGrantAmount", NewGrantAmount);
        dw.SetSqlCommandParameters("NewApprovedAmount", NewApprovedAmount);
        dw.SetSqlCommandParameters("operationdate", operationdate);
        dw.SetSqlCommandParameters("ActualDate", ActualDate);
        dw.SetSqlCommandParameters("userName", userName);
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("OldGrantDate", OldGrantDate);
        dw.SetSqlCommandParameters("NewGrantDate", NewGrantDate);
        dw.SetSqlCommandParameters("OldInstalment", OldInstalment);
        dw.SetSqlCommandParameters("NewInstalment", NewInstalment);
        return dw.Insert();
    }

    //vihanga 2010-12-14 // Edit by Bimali for the purpose of ratechange on 16/07/2012
    public int Updatecrmast(string cracno, string appno, double GrantAmt, double AprovdAmt, DateTime GrantDate, double OriginalGrantAmt)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update crmast set GrantAmt=@GrantAmt, AprovdAmt=@AprovdAmt, GrantDate=@GrantDate, OriginalGrantAmt=@OriginalGrantAmt where 
                        cracno=@cracno and appno=@appno");
        dw.SetSqlCommandParameters("cracno",cracno);
        dw.SetSqlCommandParameters("appno",appno);
        dw.SetSqlCommandParameters("GrantAmt",GrantAmt);
        dw.SetSqlCommandParameters("AprovdAmt", AprovdAmt);
        dw.SetSqlCommandParameters("GrantDate", GrantDate);
        dw.SetSqlCommandParameters("OriginalGrantAmt", OriginalGrantAmt);
        return dw.Update();
    }

    //Bimali 10/07/2012 for Interest Rate Change
    //--------------------------------------------------------------------------------------------------------------------------------------
    public DataTable GetInterestRateChangeDetails()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from IntRateChangeJuly");
        return dw.GetDataTable();
    }

    public int InsertHouspropHistryForRateChange(string cracno, double NewIntRate, int NewCrPeriod, double NewOutBal,
        int NewCrCat, double NewInstalment, DateTime TrDate, string ChangeUser)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into HouspropHistry 
	                        SELECT @TrDate,CrAcNo
	                          ,@TrDate
	                          ,IntRate,Instalment
                              ,OutBal,DateDue,GracePeriod
                              ,LstTrDate,LstPaiddate,LstReptdate,RecptPeriod,YearBeginbal
                              ,AddUser,Adddate,LastCompletedDueDate,IsDisbursed
                              ,CrPeriod,LoanStatusCode,PaidInstalments,ActOutBal,penalvaliddate
                              ,recstatus,disbrefno
                              ,@ChangeUser
                              ,@NewIntRate
                              ,@NewCrPeriod
                              ,@NewOutBal, CrCat,CrCat, LastCompletedDueDate,@NewInstalment,CrAcNo
                          FROM Housprop where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("NewIntRate", NewIntRate);
        dw.SetSqlCommandParameters("NewCrPeriod", NewCrPeriod);
        dw.SetSqlCommandParameters("NewOutBal", NewOutBal);
        dw.SetSqlCommandParameters("NewCrCat", NewCrCat);
        dw.SetSqlCommandParameters("TrDate", TrDate);
        dw.SetSqlCommandParameters("ChangeUser", ChangeUser);
        dw.SetSqlCommandParameters("NewInstalment", NewInstalment);
        return dw.Insert();
    }

    public void UpDateHouspropIntRateForRateChange(string cracno, double newIntrate, double newinstlmnt, string ResheduleDate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update housprop set intrate = @newIntrate , instalment = @newinstlmnt,
                         ResheduleDate = @ResheduleDate where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("newIntrate", newIntrate);
        dw.SetSqlCommandParameters("newinstlmnt", newinstlmnt);
        dw.SetSqlCommandParameters("ResheduleDate", ResheduleDate);
        dw.Update();
    }

    public void UpDateStatus(string cracno, string status, DateTime RateChangeDate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update IntRateChangeJuly set status = @status, RateChangeDate=@RateChangeDate where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("status", status);
        dw.SetSqlCommandParameters("RateChangeDate", RateChangeDate);
        dw.Update();
    }

    //----------------------------------------------------------------------------------------------------------------------------------


    public void updateOldCracno(string oldcracno, string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update housprop set OldCracNo = @oldcracno where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("OldCracNo", oldcracno);
        dw.Update();
    }

    public int insertResheduledata(string cracno, string oldcracno, string appno, DateTime ReSheduleDate, string AddUser, double actoutbal, double IntRate, int CrCat)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into NPLReshedule 
	                        (oldcracno,cracno,appno,ReSheduleDate,AddUser,actoutbal,IntRate,CrCat)
                        VALUES(@OldCracno,@cracno,@appno,@ReSheduleDate,@AddUser,@actoutbal,@IntRate,@CrCat)");
        dw.SetSqlCommandParameters("OldCracno", oldcracno);
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("ReSheduleDate", ReSheduleDate);
        dw.SetSqlCommandParameters("AddUser", AddUser);
        dw.SetSqlCommandParameters("actoutbal", actoutbal);
        dw.SetSqlCommandParameters("IntRate", IntRate);
        dw.SetSqlCommandParameters("CrCat", CrCat);
        return dw.Insert();
    }
}
