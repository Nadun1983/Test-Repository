using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using System.Data.SqlClient;

/// <summary>
/// Summary description for ValuerClass
/// </summary>
public class ValuerClass
{
    DataWorksClass dw;
    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();

	public ValuerClass()
	{
        //
		// TODO: Add constructor logic here
		//
	}

    
    SqlConnection myconnection = new SqlConnection(ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString);
    private SqlDataAdapter sqlAdapter;    
    private SqlCommand sqlCmd;
    private DataTable dt;

    public DataTable GetDistictList()
    {
        string sqlselect;
        sqlselect = "select  Distcode, DistName from District ";
        sqlAdapter = new SqlDataAdapter(sqlselect, myconnection);

        dt = new DataTable();

        try
        {
            myconnection.Open();
            sqlAdapter.Fill(dt);
        }

        catch (Exception err)
        {
            int a = 5;
        }

        finally
        {
            myconnection.Close();
        }

        return dt;
    } 

   
    //check exsisting appno
    public bool checkexisappno(string APPNO)
    {
        string sqlSelect;

        sqlSelect = @"select APPNO from valuation where APPNO=@APPNO and status='A' and updatelevel=-100";


        // sqlConn = new SqlConnection(conStringServer);
        sqlAdapter = new SqlDataAdapter(sqlSelect, myconnection);

        sqlAdapter.SelectCommand.Parameters.AddWithValue("APPNO", APPNO);

        dt = new DataTable();

        try
        {
            myconnection.Open();
            sqlAdapter.Fill(dt);
        }
        catch (Exception err)
        {
            //
        }

        finally
        {
            myconnection.Close();
        }

        int length = dt.Rows.Count;
        if (length > 0)
        {
            return true;
        }

        else
        {
            return false;
        }
    }

    //insert valuation send details
    public int InsertValersDetails(string APPNO, int VALUERID, DateTime SENDDATE, string HIDE, string STATUS,
                                    string AddUser, DateTime Adddatetime, int UpdateLevel, string IsTrPortPd, string IsValuerPd,
                                    string IsCommisPaid, string IsGovtPaid, string IsExpTrPaid, string IsExpValuerPd,
                                    decimal ValuerFee, decimal TrportFee, decimal CommisFee, string type, string valuerType)
    {
        string _errmessage;
        string sqlInsert;

        //Assing to the others 0
        decimal TranFee = 0;
        decimal ValFee = 0;

        if (type == "VALN900000")
        {

            sqlInsert = @"INSERT INTO VALUATION 
                     (APPNO,VALUERID,SENDDATE,HIDE,STATUS,AddUser,Adddatetime,UpdateLevel,IsTrPortPd,IsValuerPd,IsCommisPaid,IsGovtPaid,IsExpTrPaid,IsExpValuerPd,ValuerFee,TrportFee,ExpValuerFee,ExpressTrPort,CommisFee,valuerType) 
                      VALUES (@APPNO,@VALUERID,@SENDDATE,@HIDE,@STATUS,@AddUser,@Adddatetime,@UpdateLevel,@IsTrPortPd,@IsValuerPd,@IsCommisPaid,@IsGovtPaid,@IsExpTrPaid,@IsExpValuerPd,@ValuerFee,@TrportFee,@TranFee,@ValFee,@CommisFee,@valuerType)";
        }
        else
        {
            sqlInsert = @"INSERT INTO VALUATION 
                     (APPNO,VALUERID,SENDDATE,HIDE,STATUS,AddUser,Adddatetime,UpdateLevel,IsTrPortPd,IsValuerPd,IsCommisPaid,IsGovtPaid,IsExpTrPaid,IsExpValuerPd,ExpValuerFee,ExpressTrPort,ValuerFee,TrportFee,CommisFee,valuerType) 
                      VALUES (@APPNO,@VALUERID,@SENDDATE,@HIDE,@STATUS,@AddUser,@Adddatetime,@UpdateLevel,@IsTrPortPd,@IsValuerPd,@IsCommisPaid,@IsGovtPaid,@IsExpTrPaid,@IsExpValuerPd,@ValuerFee,@TrportFee,@TranFee,@ValFee,@CommisFee,@valuerType)";
        }
        //sqlConn = new SqlConnection(myconnection);
        sqlCmd = new SqlCommand(sqlInsert, myconnection);

        //

        sqlCmd.Parameters.AddWithValue("APPNO", APPNO);
        sqlCmd.Parameters.AddWithValue("VALUERID", VALUERID);
        sqlCmd.Parameters.AddWithValue("SENDDATE", SENDDATE);
        sqlCmd.Parameters.AddWithValue("HIDE", HIDE);
        sqlCmd.Parameters.AddWithValue("STATUS", STATUS);
        sqlCmd.Parameters.AddWithValue("AddUser", AddUser);
        sqlCmd.Parameters.AddWithValue("Adddatetime", Adddatetime);
        sqlCmd.Parameters.AddWithValue("UpdateLevel", UpdateLevel);
        sqlCmd.Parameters.AddWithValue("IsTrPortPd", IsTrPortPd);
        sqlCmd.Parameters.AddWithValue("IsValuerPd", IsValuerPd);
        sqlCmd.Parameters.AddWithValue("IsCommisPaid", IsCommisPaid);
        sqlCmd.Parameters.AddWithValue("IsGovtPaid", IsGovtPaid);
        sqlCmd.Parameters.AddWithValue("IsExpTrPaid", IsExpTrPaid);
        sqlCmd.Parameters.AddWithValue("IsExpValuerPd", IsExpValuerPd);
        sqlCmd.Parameters.AddWithValue("ValuerFee", ValuerFee);
        sqlCmd.Parameters.AddWithValue("TrportFee", TrportFee);
        sqlCmd.Parameters.AddWithValue("CommisFee", CommisFee);
        sqlCmd.Parameters.AddWithValue("type", type);
        sqlCmd.Parameters.AddWithValue("TranFee", TranFee);
        sqlCmd.Parameters.AddWithValue("ValFee", ValFee);
        sqlCmd.Parameters.AddWithValue("valuerType", valuerType);
               
        int rowAdded = 0;

        try
        {
            myconnection.Open();
            rowAdded = sqlCmd.ExecuteNonQuery();
        }

        catch (Exception err)
        {
            _errmessage = err.Message;
        }

        finally
        {
            myconnection.Close();
        }

        return rowAdded;

    }

    //select the appropriate valuers names when user select the distric
    public DataTable GetValuer(int distcode)
    {
        string sqlSelect;

        sqlSelect = @"SELECT v.ValuerId AS valuerid, RTRIM(v.SurName) +' ' + RTRIM(v.Initial) AS ValuerName
                        FROM ValuerArea AS a INNER JOIN Valuer AS v ON a.ValuerId = v.ValuerId
                        WHERE (a.distcode = @distcode) order by v.SurName";


       // sqlConn = new SqlConnection(conStringServer);
        sqlAdapter = new SqlDataAdapter(sqlSelect, myconnection);

        sqlAdapter.SelectCommand.Parameters.AddWithValue("distcode", distcode);
        

        dt = new DataTable();

        try
        {
            myconnection.Open();
            sqlAdapter.Fill(dt);
        }
        catch (Exception err)
        {
            //
        }

        finally
        {
            myconnection.Close();
        }

        return dt;
        
    }

  
    public DataTable allValuersdetails(DateTime frmdate , DateTime todate)
    {
        string sqlSelect;

        sqlSelect = @"select vt.APPNO , (rtrim(v.SurName) + ' ' + rtrim(v.Initial)) as Fullname , (vt.ValuerFee + vt.ExpValuerFee) as ValuerFee , 
                      (vt.TrportFee + vt.ExpValuerFee) as Valuer_Tranport_Fee ,((vt.ValuerFee + vt.ExpValuerFee +  vt.TrportFee + vt.ExpValuerFee))
                       as Total_Payment 
                       from VALUATION vt , Valuer v
                       where vt.VALUERID = v.ValuerId and vt.SENDDATE > @frmdate and vt.SENDDATE < @todate and vt.updatelevel=-100 and vt.hide='U'
                       order by vt.APPNO";


        // sqlConn = new SqlConnection(conStringServer);
        sqlAdapter = new SqlDataAdapter(sqlSelect, myconnection);

        sqlAdapter.SelectCommand.Parameters.AddWithValue("frmdate", frmdate);
        sqlAdapter.SelectCommand.Parameters.AddWithValue("todate", todate);
        
        dt = new DataTable();

        try
        {
            myconnection.Open();
            sqlAdapter.Fill(dt);
        }
        catch (Exception err)
        {
            //
        }

        finally
        {
            myconnection.Close();
        }

        return dt;
    }

    public DataTable GetAllValuersName()
    {
        string sqlSelect;

        sqlSelect = @"select (rtrim(SurName) + ' ' + rtrim(Initial)) as FullName , ValuerId from Valuer";


        sqlAdapter = new SqlDataAdapter(sqlSelect, myconnection);

        //sqlAdapter.SelectCommand.Parameters.AddWithValue("frmdate", frmdate);

        dt = new DataTable();

        try
        {
            myconnection.Open();
            sqlAdapter.Fill(dt);
        }
        catch (Exception err)
        {
            //
        }

        finally
        {
            myconnection.Close();
        }

        return dt;
    }

    public DataTable GetValuersDepartments()
    {
        string sqlSelect;

        sqlSelect = @"select AName , AuthorityId from ValuationAuthorities";

        sqlAdapter = new SqlDataAdapter(sqlSelect, myconnection);
        //sqlAdapter.SelectCommand.Parameters.AddWithValue("frmdate", frmdate);

        dt = new DataTable();

        try
        {
            myconnection.Open();
            sqlAdapter.Fill(dt);
        }
        catch (Exception err)
        {
            //
        }
        finally
        {
            myconnection.Close();
        }
        return dt;
    }
    public DataTable CheckPayedForValuation(long APPNO)
    {
        string SQlSelect;
        SQlSelect = @"select taskid,tramt from transassign where cracno=@APPNO and 
                    ((taskid='VALN900000' or taskid='VALE900000') or
                    (taskid='VTRN900000' or taskid='VTRE900000') or
                    (taskid='VAHE900000' or taskid='VAHN900000') or (taskid='VATN900000' or taskid='VATE900000')) and trstatus='F'";

        sqlAdapter = new SqlDataAdapter(SQlSelect, myconnection);
        sqlAdapter.SelectCommand.Parameters.AddWithValue("APPNO", APPNO);

        dt = new DataTable();
        try
        {
            myconnection.Open();
            sqlAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }
        finally
        {
            myconnection.Close();
        }
        return dt;
    }

    public DataTable GetUnhideVauer(string appno, string hide)
    {
        string SQlSelect;
        SQlSelect = @"select (rtrim(val.surname) + ' ' + rtrim(val.Initial)) as fullname , v.senddate , v.appno 
                        from valuation v , valuer val 
                        where v.valuerid = val.valuerid and v.appno=@appno and v.hide=@hide";

        sqlAdapter = new SqlDataAdapter(SQlSelect, myconnection);

        sqlAdapter.SelectCommand.Parameters.AddWithValue("appno", appno);
        sqlAdapter.SelectCommand.Parameters.AddWithValue("hide", hide);

        dt = new DataTable();
        try
        {
            myconnection.Open();
            sqlAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }
        finally
        {
            myconnection.Close();
        }
        return dt;
    }

    public int SetTrueApprovalstatus(long appno)
    {
        string sqlErr;
        string sqlUpdate;

        sqlUpdate = @"update approvalstatus set IsValuationOK=1 where appno=@Appno";

        sqlCmd = new SqlCommand(sqlUpdate, myconnection);

        sqlCmd.Parameters.AddWithValue("appno", appno);

        int rowadd = 0;

        try
        {
            myconnection.Open();
            rowadd = sqlCmd.ExecuteNonQuery();
        }
        catch (Exception err)
        {
            sqlErr = err.Message;
        }
        finally
        {
            myconnection.Close();
        }

        return rowadd;
    }

    public int SetFalseApprovalstatus(long appno)
    {
        string sqlErr;
        string sqlUpdate;

        sqlUpdate = @"update approvalstatus set IsValuationOK=0 where appno=@Appno";

        sqlCmd = new SqlCommand(sqlUpdate, myconnection);

        sqlCmd.Parameters.AddWithValue("appno", appno);

        int rowadd = 0;

        try
        {
            myconnection.Open();
            rowadd = sqlCmd.ExecuteNonQuery();
        }
        catch (Exception err)
        {
            sqlErr = err.Message;
        }
        finally
        {
            myconnection.Close();
        }

        return rowadd;
    }

    //vihanga 2008-12-18

    public DataTable ValuationLedger(DateTime datefrom, DateTime dateto)
    {
        string SqlSelect;
        string error;

        SqlSelect = @"select distinct cast(day(tab3.trdate) as char(2)) + '/' + cast(month(tab3.trdate) as char(2)) + '/' + cast(Year(tab3.trdate) 
                        as char(4)) as  trdate,
                        tab1.cracno,cm.surname,cm.initials,
                        cr.cramt,
                        case tab3.trstatus
                        when 'F' then 'Paid'
                        else 'Not Paid'end as Ispaid,
                        tab2.ValuationFee ,tab4.ValTransport , tab1.InspecFee , tab5.InspecTransport
                        from 
                        (select cracno,sum(tramt) as InspecFee
                        from transassign 
                        where taskid IN ('INSN900000','INSE900000') group by cracno ) as tab1 ,
                        (select cracno,sum(tramt) as InspecTransport
                        from transassign 
                        where taskid IN ('ITRN900000','ITRE900000') group by cracno ) as tab5 ,
                        (select cracno,sum(tramt) as ValuationFee
                        from transassign 
                        where taskid IN ('VALN900000','VALN900000') group by cracno ) as tab2 ,
                        (select cracno,sum(tramt) as ValTransport
                        from transassign 
                        where taskid IN ('VTRN900000','VTRE900000') group by cracno ) as tab4 ,
                        (select distinct cracno,trstatus,adddate,trdate from transassign ) as tab3 ,
                        customermain cm , appholder ah, Crapp Cr, CrCategory p 
                        where tab1.cracno=tab2.cracno and cm.nicno=ah.nicno and ah.appno=tab1.cracno and tab1.cracno=tab4.cracno
                         and ah.holdertype='P'
                        and ah.appno=cr.appno and cr.crcatcode=p.crcatcode and tab3.cracno=tab1.cracno and tab1.cracno=tab5.cracno and
                        tab3.trdate > @datefrom and tab3.trdate < @dateto 
                        order by tab3.trdate";

        sqlAdapter = new SqlDataAdapter(SqlSelect, myconnection);

        sqlAdapter.SelectCommand.Parameters.AddWithValue("datefrom", datefrom);
        sqlAdapter.SelectCommand.Parameters.AddWithValue("dateto", dateto);

        dt = new DataTable();

        try
        {
            myconnection.Open();
            sqlAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }
        finally
        {
            myconnection.Close();
        }

        return dt;

    }

    public DataTable CheckPayed(string cracno, string Trstatus, string TaskId)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select TrAmt from transassign where cracno=@cracno and Trstatus=@Trstatus and TaskId=@TaskId");
        dw.SetDataAdapterParameters("cracno", cracno);
        dw.SetDataAdapterParameters("Trstatus", Trstatus);
        dw.SetDataAdapterParameters("TaskId", TaskId);
        return dw.GetDataTable();
    }


    public decimal GetTrAmt(string cracno, string Trstatus, string TaskId)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select TrAmt from transassign where cracno=@cracno and Trstatus=@Trstatus and TaskId=@TaskId");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("Trstatus", Trstatus);
        dw.SetSqlCommandParameters("TaskId", TaskId);
        return Convert.ToDecimal(dw.GetSingleData());
    }


    public string getValuerType(string valuerid)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select valuertype from valuer where valuerid=@valuerid");
        dw.SetSqlCommandParameters("valuerid", valuerid);
        return dw.GetSingleData();
    }

    /**************************************** 2012/11/30 - Auto Loan valuers ******************************************************/
    public DataTable GetAutoLoanValuers(string valuername)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from AutoLoanValuers where ValuerName like '%" + valuername + @"%'");
        dw.SetDataAdapterParameters("valuername", valuername);
        return dw.GetDataTable();
    }

    public int InsertToAutoLoanValuers(int ValuerNo, string ValuerName)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO AutoLoanValuers (ValuerNo,ValuerName) VALUES
                       (@ValuerNo,@ValuerName)");
        dw.SetSqlCommandParameters("ValuerNo", ValuerNo);
        dw.SetSqlCommandParameters("ValuerName", ValuerName);
        return dw.Insert();
    }

    public int GetAutoLoanValuerid()
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select max(ValuerNo) as MaxNo from AutoLoanValuers");
        return int.Parse(dw.GetSingleData());
    }

    public DataTable GetAllAutoLoanValuer()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from AutoLoanValuers order by valuername");
        return dw.GetDataTable();
    }
    /***************************************************************************************************************************/

    public DataTable CheckPayed(string _appno)
    {
        string SQlSelect;
        SQlSelect = @"select taskid,tramt from transassign where cracno=@APPNO and 
                    ((taskid='INSN900000' or taskid='ITRN900000') or
                    (taskid='INSE900000' or taskid='ITRE900000') or
                    (taskid='INHN900000' or taskid='INTN900000') or (taskid='INHE900000' or taskid='INTE900000')) and trstatus='F'";

        sqlAdapter = new SqlDataAdapter(SQlSelect, myconnection);
        sqlAdapter.SelectCommand.Parameters.AddWithValue("APPNO", _appno);

        dt = new DataTable();
        try
        {
            myconnection.Open();
            sqlAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }
        finally
        {
            myconnection.Close();
        }
        return dt;
    }
}
