using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;


/// <summary>
/// Summary description for inspection
/// </summary>
public class Inspection
{
    public Inspection()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    DataWorksClass dw;
    SqlConnection sqlCon;
    private SqlDataAdapter sqlAdapter;    private SqlCommand sqlCmd;
    private DataTable dt;
    private SqlDataReader sqldatareader;
    
    //private SqlConnection sqlCon;
    string conString = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();


    public DataTable GetInspectorDeatails()
    {
        string sqlSelect;
        sqlSelect = @"select rtrim(SURNAME) + ' ' + rtrim( INITIALS) as [Name], inspectid
                        from inspector i
                        where i.surname is not null and inspectorstatus = 'A'
                        order by i.surname";


        sqlCon = new SqlConnection(conString);

        sqlAdapter = new SqlDataAdapter(sqlSelect, sqlCon);
        dt = new DataTable();
        //Reader = new SqlDataReader();
        try
        {
            sqlCon.Open();
            sqlAdapter.Fill(dt);
        }

        catch (Exception ex)
        {
            // Error
        }

        finally
        {
            sqlCon.Close();
            sqlCon.Dispose();
        }

        return dt;
    }

    public int InspectorAssign(string appno, int inspectid, decimal InspecFee, string adduser, string InspectionStatus, DateTime AddDateTime, string UpdateLevel, string InspecCatogory)
    {
        
        string sqlinsert;
        sqlinsert = @"insert into InspectMast (appno,InspectId,InspecFee,adduser,InspectionStatus,AddDateTime,UpdateLevel,InspecCatogory) 
                      values (@appno,@InspectId,@InspecFee,@adduser,@InspectionStatus,@AddDateTime,@UpdateLevel,@InspecCatogory)";

        sqlCon = new SqlConnection(conString);
        sqlCmd = new SqlCommand(sqlinsert, sqlCon);

        sqlCmd.Parameters.AddWithValue("appno", appno);
        sqlCmd.Parameters.AddWithValue("InspectId", inspectid);
        sqlCmd.Parameters.AddWithValue("InspecFee", InspecFee);
        sqlCmd.Parameters.AddWithValue("adduser", adduser);
        sqlCmd.Parameters.AddWithValue("InspectionStatus", InspectionStatus);
        sqlCmd.Parameters.AddWithValue("AddDateTime", AddDateTime);
        sqlCmd.Parameters.AddWithValue("UpdateLevel", UpdateLevel);
        sqlCmd.Parameters.AddWithValue("InspecCatogory", InspecCatogory);

        int addesdata = 0;

        try
        {
            sqlCon.Open();
            addesdata = sqlCmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            //
        }

        finally
        {
            sqlCon.Close();
        }

        return addesdata;
    }


    public string GetPaidStatus(string appno, string IsInspecPd)
    {
        string sqlSelect, paidStatus;
        sqlSelect = @"select IsInspecPd from  CreditAdmin.InspectMast";

        sqlCon = new SqlConnection(conString);

        sqlCmd = new SqlCommand(sqlSelect, sqlCon);
        sqlCmd.Parameters.AddWithValue("PaidStatus", IsInspecPd);

        try
        {
            sqlCon.Open();
            sqldatareader = sqlCmd.ExecuteReader();
            sqldatareader.Read();
            if (sqldatareader != null)
            {
                paidStatus = sqldatareader["PaidStatus"].ToString();
            }
            sqldatareader.Close();
        }

        catch (Exception ex)
        {
            // error massage
        }

        finally
        {
            sqlCon.Close();
            sqlCon.Dispose();
        }

        return IsInspecPd;
    }


    public int GetInspectionStatus(string remarks, DateTime DateRtn, string appno)
    {
        string sqlupdate;
        sqlupdate = @"UPDATE InspectMast
                    SET Remarks = @remarks, DateRtn = @DateRtn 
                    WHERE appno=@appno and  updatelevel=-100";

        sqlCon = new SqlConnection(conString);
        sqlCmd = new SqlCommand(sqlupdate, sqlCon);
        sqlCmd.Parameters.AddWithValue("remarks", remarks);
        sqlCmd.Parameters.AddWithValue("DateRtn", DateRtn);
        sqlCmd.Parameters.AddWithValue("appno", appno);

        int addesdata = 0;

        try
        {
            sqlCon.Open();
            addesdata = sqlCmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            //
        }

        finally
        {
            sqlCon.Close();
        }

        return addesdata;
    }

    public DataTable GetPaymentInspector()
    {
        string sqlSelect;
        sqlSelect = @"select rtrim(SURNAME) + ' ' + rtrim( INITIALS) as [Name], inspectid
                        from inspector i
                        where i.surname is not null and inspectorstatus = 'A'
                        order by i.surname";


        sqlCon = new SqlConnection(conString);

        sqlAdapter = new SqlDataAdapter(sqlSelect, sqlCon);
        dt = new DataTable();
        //Reader = new SqlDataReader();
        try
        {
            sqlCon.Open();
            sqlAdapter.Fill(dt);
        }

        catch (Exception ex)
        {
            // Error
        }

        finally
        {
            sqlCon.Close();
            sqlCon.Dispose();
        }

        return dt;
    }


    public int GetInspectorpayment(bool IsInspecPd, string appno)
    {


        string sqlupdate;
        sqlupdate = @"UPDATE InspectMast
                    SET IsInspecPd = @IsInspecPd
                    WHERE appno=@appno and  updatelevel=-100";

        sqlCon = new SqlConnection(conString);
        sqlCmd = new SqlCommand(sqlupdate, sqlCon);

        sqlCmd.Parameters.AddWithValue("IsInspecPd", IsInspecPd);
        sqlCmd.Parameters.AddWithValue("appno", appno);


        int addesdata = 0;
       

        try
        {
            string paidStatus;
            sqlCon.Open();
            sqldatareader = sqlCmd.ExecuteReader();
            sqldatareader.Read();
            if (sqldatareader != null)
            {
                paidStatus = sqldatareader["PaidStatus"].ToString();
               
            }
            sqldatareader.Close();
        }

        catch (Exception ex)
        {
            // error massage
        }

        finally
        {
            sqlCon.Close();
            sqlCon.Dispose();
        }

        return addesdata;

       
    }

    public decimal GetInspectorFee(string appno)
    {
        string sqlSelect;
        decimal amount = 0 ;
        sqlSelect = @"select Amount from PaymentMade where appno=@appno and 
                      (paymentTypeId=2 or paymentTypeId=8)";


        sqlCon = new SqlConnection(conString);

        sqlCmd = new SqlCommand(sqlSelect, sqlCon);
        sqlCmd.Parameters.AddWithValue("appno", appno);

        try
        {
            sqlCon.Open();
            sqldatareader = sqlCmd.ExecuteReader();
            sqldatareader.Read();
            if (sqldatareader != null)
            {
                amount = decimal.Parse(sqldatareader[0].ToString());
            }
            sqldatareader.Close();
        }

        catch (Exception ex)
        {
            // error massage
        }

        finally
        {
            sqlCon.Close();
            sqlCon.Dispose();
        }

        return amount;
    }

    public DataTable GetPaymentSumary(int inspectid,  DateTime DateRtnFrom, DateTime DateRtnTo)
    {
        DateTime DateRtn;
        string sqlSelect;
        decimal totinsfee;

        sqlSelect = @"select appno,inspecfee,(rtrim (t.TITLEDESC) + ' ' + (rtrim( i.INITIALS)+ ' ' + rtrim( i.SURNAME))) 
                      as [Name] from InspectMast im,inspector i,title t where i.InspectId = im.InspectId and 
                      i.titlecode = t.titlecode and im.DateRecv is not null and im.DateRecv > @DateRtnFrom and 
                      im.DateRecv  < @DateRtnTo and i.InspectId=@inspectid";


        sqlCon = new SqlConnection(conString);

        sqlAdapter = new SqlDataAdapter(sqlSelect, sqlCon);

        sqlAdapter.SelectCommand.Parameters.AddWithValue("inspectid", inspectid);
             sqlAdapter.SelectCommand.Parameters.AddWithValue("DateRtnTo", DateRtnTo);
        sqlAdapter.SelectCommand.Parameters.AddWithValue("DateRtnFrom", DateRtnFrom);
        dt = new DataTable();
        //Reader = new SqlDataReader();
        try
        {
            sqlCon.Open();
            sqlAdapter.Fill(dt);
        }

        catch (Exception ex)
        {
            // Error
        }

        finally
        {
            sqlCon.Close();
            sqlCon.Dispose();
        }

        return dt;
    }

    public int UpdateInspectionStatus(string appno, int InspectId, string exstingstatus, string newstatus, DateTime DateRecv)
    {
        
        string sqlupdate;
        sqlupdate = @"UPDATE InspectMast
                     SET InspectionStatus = @newstatus, DateRecv=@DateRecv
                     WHERE appno=@appno and InspectId =@InspectId and InspectionStatus = @exstingstatus";

        sqlCon = new SqlConnection(conString);
        sqlCmd = new SqlCommand(sqlupdate, sqlCon);
        sqlCmd.Parameters.AddWithValue("appno", appno);
        sqlCmd.Parameters.AddWithValue("InspectId", InspectId);
        sqlCmd.Parameters.AddWithValue("exstingstatus", exstingstatus);
        sqlCmd.Parameters.AddWithValue("newstatus", newstatus);
        sqlCmd.Parameters.AddWithValue("DateRecv", DateRecv);
        //sqlCmd.Parameters.AddWithValue("PaidDate", PaidDate);
      

        int addesdata = 0;

        try
        {
            sqlCon.Open();
            addesdata = sqlCmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            //
        }

        finally
        {
            sqlCon.Close();
        }

        return addesdata;
    }


    public int UpdateRemarks(string appno, int InspectId, string exstingstatus, string AmtWorkDone, string Remarks)
    //public int UpdateRemarks(string appno, int InspectId, string exstingstatus, string AmtWorkDone, string Remarks)
    {

        string sqlupdate;
        sqlupdate = @"UPDATE InspectMast
                     SET AmtWorkDone = @AmtWorkDone, Remarks=@Remarks
                     WHERE appno=@appno and InspectId =@InspectId and InspectionStatus = @exstingstatus";

        sqlCon = new SqlConnection(conString);
        sqlCmd = new SqlCommand(sqlupdate, sqlCon);
        sqlCmd.Parameters.AddWithValue("appno", appno);
        sqlCmd.Parameters.AddWithValue("InspectId", InspectId);
        sqlCmd.Parameters.AddWithValue("exstingstatus", exstingstatus);
        sqlCmd.Parameters.AddWithValue("AmtWorkDone", AmtWorkDone);
        sqlCmd.Parameters.AddWithValue("Remarks", Remarks);


        int addesdata = 0;

        try
        {
            sqlCon.Open();
            addesdata = sqlCmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            //
        }

        finally
        {
            sqlCon.Close();
        }

        return addesdata;
    }

//    public DataTable GetInspectionSumary(string appno, string InspectionStatus)
//    {
//        //DateTime daterecv;
//        //string inspecCatogory;
//        string sqlSelect;
//        string Name;
//        sqlSelect = @"select im.InspectId, (rtrim (t.TITLEDESC) + ' ' + (rtrim( i.INITIALS)+ ' ' + rtrim( i.SURNAME))) as [Name],datertn,inspecCatogory
//                    from inspectmast im, inspector i,title t
//                    where t.titlecode=i.titlecode and im.InspectId=i.InspectId and appno=@appno and InspectionStatus!=@InspectionStatus";


//        sqlCon = new SqlConnection(conString);
//        sqlAdapter = new SqlDataAdapter(sqlSelect, sqlCon);
//        sqlAdapter.SelectCommand.Parameters.AddWithValue("appno", appno);
//        sqlAdapter.SelectCommand.Parameters.AddWithValue("InspectionStatus", InspectionStatus);
//        dt = new DataTable();
//        //Reader = new SqlDataReader();
//        try
//        {
//            sqlCon.Open();
//            sqlAdapter.Fill(dt);
//        }

//        catch (Exception ex)
//        {
//            // Error
//        }

//        finally
//        {
//            sqlCon.Close();
//            sqlCon.Dispose();
//        }

//        return dt;
//    }

    public int CancelInspection(string appno, int InspectId, string exstingstatus, string newstatus)
    {
        string sqlupdate;
        sqlupdate = @"UPDATE InspectMast
                     SET InspectionStatus = @newstatus 
                     WHERE appno=@appno and InspectId =@InspectId and InspectionStatus = @exstingstatus";

        sqlCon = new SqlConnection(conString);
        sqlCmd = new SqlCommand(sqlupdate, sqlCon);
        sqlCmd.Parameters.AddWithValue("appno", appno);
        sqlCmd.Parameters.AddWithValue("InspectId", InspectId);
        sqlCmd.Parameters.AddWithValue("exstingstatus", exstingstatus);
        sqlCmd.Parameters.AddWithValue("newstatus", newstatus);
        //sqlCmd.Parameters.AddWithValue("AddDateTime", AddDateTime);

        int addesdata = 0;

        try
        {
            sqlCon.Open();
            addesdata = sqlCmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            //
        }

        finally
        {
            sqlCon.Close();
        }

        return addesdata;
    }

    public int GetPaidCount(string appno)
    {
        string sqlSelect;
        int paidcount = 0;
        sqlSelect = @"select count(*) from transassign where cracno=@appno and 
                    ((taskid='INSN900000' or taskid='ITRN900000') or
                    (taskid='INSE900000' or taskid='ITRE900000') or (taskid='INHE900000' or taskid='INHN900000')) and trstatus='F'";
                      
        sqlCon = new SqlConnection(conString);

        sqlCmd = new SqlCommand(sqlSelect, sqlCon);
        sqlCmd.Parameters.AddWithValue("appno", appno);
        int addesdata = 0;
        try
        {
            sqlCon.Open();
            sqldatareader = sqlCmd.ExecuteReader();
            sqldatareader.Read();
            if (sqldatareader != null)
            {
                paidcount = int.Parse(sqldatareader[0].ToString());
            }
            sqldatareader.Close();
        }

        catch (Exception ex)
        {
            // error massage
        }

        finally
        {
            sqlCon.Close();
            sqlCon.Dispose();
        }

        return paidcount;
    }

    public int GetInspectID(string appno, string InspectionStatus)
    {
        string sqlSelect;
        int inspectid = 0;
        sqlSelect = @"select InspectId from inspectmast where appno = @appno and InspectionStatus=@InspectionStatus";

        sqlCon = new SqlConnection(conString);

        sqlCmd = new SqlCommand(sqlSelect, sqlCon);
        sqlCmd.Parameters.AddWithValue("appno", appno);
        sqlCmd.Parameters.AddWithValue("InspectionStatus", InspectionStatus);
       
        try
        {
            sqlCon.Open();
            sqldatareader = sqlCmd.ExecuteReader();
            sqldatareader.Read();
            if (sqldatareader != null)
            {
                inspectid = int.Parse(sqldatareader[0].ToString());
            }
            sqldatareader.Close();
        }

        catch (Exception ex)
        {
            // error massage
        }

        finally
        {
            sqlCon.Close();
            sqlCon.Dispose();
        }

        return inspectid;
    }


    public DataTable GetAssignInspectorDetails(string appno, string InspectionStatus)
    {
        string sqlSelect;
        sqlSelect = @"SELECT RTRIM(RTRIM(i.INITIALS) + ' ' + RTRIM(i.SURNAME)) AS Name, 
                        im.InspectId as InspectId, im.AddDateTime AS AssignDate, im.DateRecv AS RevieveDate, 
                        im.InspecCatogory AS InspecCatogory, AmtWorkDone, Remarks
                        FROM  InspectMast im, INSPECTOR i  
                        WHERE im.InspectId = i.INSPECTID AND
                        im.AppNo = @AppNo AND 
                        im.InspectionStatus = @InspectionStatus ";


        sqlCon = new SqlConnection(conString);

        sqlAdapter = new SqlDataAdapter(sqlSelect, sqlCon);
        sqlAdapter.SelectCommand.Parameters.AddWithValue("appno", appno);
        sqlAdapter.SelectCommand.Parameters.AddWithValue("InspectionStatus", InspectionStatus);
        dt = new DataTable();
        //Reader = new SqlDataReader();
        try
        {
            sqlCon.Open();
            sqlAdapter.Fill(dt);
        }

        catch (Exception ex)
        {
            // Error
        }

        finally
        {
            sqlCon.Close();
            sqlCon.Dispose();
        }

        return dt;
    }

    public int UpdateApprovalStatus(string appno, bool IsInspectionOK)
    {

        string sqlupdate;
        sqlupdate = @"UPDATE ApprovalStatus
                     SET IsInspectionOK = @IsInspectionOK WHERE appno=@appno";
                     

        sqlCon = new SqlConnection(conString);
        sqlCmd = new SqlCommand(sqlupdate, sqlCon);
        sqlCmd.Parameters.AddWithValue("appno", appno);
        sqlCmd.Parameters.AddWithValue("IsInspectionOK", IsInspectionOK);
       
        int addesdata = 0;

        try
        {
            sqlCon.Open();
            addesdata = sqlCmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            //
        }

        finally
        {
            sqlCon.Close();
        }

        return addesdata;
    }


    //2008-10-14
    public string GetLoanAmount(long Appno)
    {
        string sqlSelect;
        sqlSelect = @"select cramt from crapp where appno=@appno";

        sqlCon = new SqlConnection(conString);
        sqlAdapter = new SqlDataAdapter(sqlSelect, sqlCon);
        sqlAdapter.SelectCommand.Parameters.AddWithValue("Appno", Appno);
        dt = new DataTable();
        string amount = "0";

        try
        {
            sqlCon.Open();
            sqlAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }
        finally
        {
            sqlCon.Close();
        }

        if (dt.Rows.Count > 0)
            amount = dt.Rows[0][0].ToString();

        return amount;
    }
 //2010-01-28 vihanga
    public DataTable GetCustomerDetail(string appno)
    {
        dw = new DataWorksClass(conString);
        dw.SetDataAdapter(@"select distinct a.Appno,rtrim(c.initials) + ' ' + rtrim(c.surname) as CustName ,
                            rtrim(location)+' , '+rtrim(street)+' , '+rtrim(city) as Address
                            from appholder a , customermain c , transassign t 
                            where c.nicno=a.nicno and t.cracno=a.appno and a.appno=@appno");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();
    }

    //2010-01-28 vihanga
    public string GetApplicationPaymentTransNo(string appno)
    {
        dw = new DataWorksClass(conString);
        dw.SetCommand(@"select distinct transno from transassign where cracno=@appno and transno is not null");
        dw.SetSqlCommandParameters("appno", appno);
        return dw.GetSingleData();
    }

    //2010-01-28 vihanga
    public int WaveoffInspectionFee(string appno, string transno, string status)
    {
        dw = new DataWorksClass(conString);
        dw.SetCommand(@"update transassign set trstatus=@status,transno=@transno where cracno=@appno and assignamt=0 and
                          (taskid='INSN900000' or taskid='ITRN900000' or taskid='INSE900000' or taskid='ITRE900000')");
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("transno", transno);
        dw.SetSqlCommandParameters("status", status);
        return dw.Update();
    }

    //2010-01-28 vihanga
    public int InsertDeatils(string operationdate, DateTime actualDate, string userid, string appno, string transno, int noofupdatedrecords,
                               string changeStatus)
    {
        dw = new DataWorksClass(conString);
        dw.SetCommand(@"insert into inspectionWaveOff(operationdate, actualDate, userid, appno, transno, noofupdatedrecords, changeStatus)
                        values(@operationdate, @actualDate, @userid, @appno, @transno, @noofupdatedrecords, @changeStatus)");
        dw.SetSqlCommandParameters("operationdate", operationdate);
        dw.SetSqlCommandParameters("actualDate", actualDate);
        dw.SetSqlCommandParameters("userid", userid);
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("transno", transno);
        dw.SetSqlCommandParameters("noofupdatedrecords", noofupdatedrecords);
        dw.SetSqlCommandParameters("changeStatus", changeStatus);
        return dw.Insert();
    }

}

