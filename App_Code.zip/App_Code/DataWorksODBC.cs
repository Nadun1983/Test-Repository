﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.Odbc;

/// <summary>
/// Summary description for DataWorksODBC
/// </summary>
public class DataWorksODBC
{
    public DataWorksODBC(string constring)
    {
        this.constring = constring;
    }

    // private data fields

    private OdbcConnection odbcConn;
    private OdbcDataAdapter odbcAdapter;
    private OdbcDataReader odbcdatareader;
    private OdbcCommand odbcCmd;

    //private OdbcConnection odbcConn;
    //OdbcCommand odbcCmd;
    //SqlDataReader sqlDataReader;
    //SqlDataAdapter odbcAdapter;
    DataTable dt;
    DataSet ds;
    string constring;
    string _errmessage = "";
    //SqlTransaction sqlTrans = null;

    public string ConnString
    {
        set
        {
            this.constring = value;
        }
    }

    public OdbcConnection ODBCConn
    {
        get
        {
            return this.odbcConn;
        }

        set
        {
            this.odbcConn = value;
        }
    }




    public string ErrMsg
    {
        get
        {
            return this._errmessage;
        }
    }

    #region Select Statement
    public void SetDataAdapter(string sqlselect)
    {
        odbcConn = new OdbcConnection(constring);
        this.odbcAdapter = new OdbcDataAdapter(sqlselect, odbcConn);
    }

    public void SetCommand(string stringCommand)
    {
        odbcConn = new OdbcConnection(constring);
        this.odbcCmd = new OdbcCommand(stringCommand, odbcConn);
    }

    public void SetCommand()
    {
        odbcConn = new OdbcConnection(constring);
        this.odbcCmd = new OdbcCommand();
        this.odbcCmd.Connection = odbcConn;
    }

    public void SetConection(string stringCommand)
    {
        odbcConn = new OdbcConnection(constring);
    }

    public void SetCommand(OdbcConnection sqlcon, string stringCommand)
    {
        this.odbcCmd = new OdbcCommand(stringCommand, sqlcon);
    }


    #endregion

    #region Set Data Adapter Parameters
    public void SetDataAdapterParameters(string paramName, string ParamVal)
    {
        this.odbcAdapter.SelectCommand.Parameters.AddWithValue(paramName, ParamVal);
    }

    public void SetDataAdapterParameters(string paramName, int ParamVal)
    {
        this.odbcAdapter.SelectCommand.Parameters.AddWithValue(paramName, ParamVal);
    }


    public void SetDataAdapterParameters(string paramName, DateTime ParamVal)
    {
        this.odbcAdapter.SelectCommand.Parameters.AddWithValue(paramName, ParamVal);
    }


    public void SetDataAdapterParameters(string paramName, long ParamVal)
    {
        this.odbcAdapter.SelectCommand.Parameters.AddWithValue(paramName, ParamVal);
    }

    public void SetDataAdapterParameters(string paramName, decimal ParamVal)
    {
        this.odbcAdapter.SelectCommand.Parameters.AddWithValue(paramName, ParamVal);
    }

    public void SetDataAdapterParameters(string paramName, double ParamVal)
    {
        this.odbcAdapter.SelectCommand.Parameters.AddWithValue(paramName, ParamVal);
    }

    public void SetDataAdapterParameters(string paramName, bool ParamVal)
    {
        this.odbcAdapter.SelectCommand.Parameters.AddWithValue(paramName, ParamVal);
    }

    public void SetDataAdapterParameters(string paramName, short ParamVal)
    {
        this.odbcAdapter.SelectCommand.Parameters.AddWithValue(paramName, ParamVal);
    }

    public void SetDataAdapterParameters(string paramName, float ParamVal)
    {
        this.odbcAdapter.SelectCommand.Parameters.AddWithValue(paramName, ParamVal);
    }


    #endregion

    #region Select Methods


    //Get DataTable
    public DataTable GetDataTable()
    {

        this.dt = new DataTable();

        try
        {

            this.odbcConn.Open();
            this.odbcAdapter.Fill(this.dt);
        }
        catch (Exception er)
        {
            this._errmessage = er.Message;
            return null;
        }

        finally
        {
            odbcConn.Close();
            odbcConn.Dispose();
        }

        return dt;

    }

    public DataSet GetDataSet()
    {

        this.ds = new DataSet();

        try
        {

            this.odbcConn.Open();
            this.odbcAdapter.Fill(this.ds, "TestTrans");
        }
        catch (Exception er)
        {
            this._errmessage = er.Message;
            return null;
        }

        finally
        {
            odbcConn.Close();
            odbcConn.Dispose();
        }

        return ds;

    }

    //Get Data from a command
    public string[] GetDataArray()
    {
        string[] strArr = null;
        try
        {
            odbcConn.Open();
            odbcdatareader = odbcCmd.ExecuteReader();
            odbcdatareader .Read();
            // Array size of output column
            strArr = new string[odbcdatareader .FieldCount];
            for (int i = 0; i < odbcdatareader .FieldCount; i++)
            {
                if (odbcdatareader .HasRows == true)
                {
                    strArr[i] = odbcdatareader [i].ToString();
                }
            }

            odbcdatareader .Close();

        }

        catch (Exception err)
        {
            this._errmessage = err.Message;
            return null;
        }

        finally
        {
            odbcConn.Close();
        }

        return strArr;

    }

    // Get Single Value
    public string GetSingleData()
    {
        // string output
        string value = "0";
        try
        {
            odbcConn.Open();
            odbcdatareader = odbcCmd.ExecuteReader();
            odbcdatareader .Read();

            if (odbcdatareader .HasRows == true)
            {
                try
                {
                    value = odbcdatareader [0].ToString();
                    if (value == "")
                    {
                        value = "0";
                    }
                }
                catch
                {
                    value = "0";
                }
            }

            odbcdatareader .Close();

        }

        catch (Exception err)
        {
            this._errmessage = err.Message;
            return null;
        }

        finally
        {
            odbcConn.Close();
        }

        return value;
    }

    #endregion

    #region Set OdbcCommand Parameters
    public void SetOdbcCommandParameters(string paramName, string ParamVal)
    {
        this.odbcCmd.Parameters.AddWithValue(paramName, ParamVal);
    }

    public void SetOdbcCommandParameters(string paramName, int ParamVal)
    {
        this.odbcCmd.Parameters.AddWithValue(paramName, ParamVal);
    }


    public void SetOdbcCommandParameters(string paramName, DateTime ParamVal)
    {
        this.odbcCmd.Parameters.AddWithValue(paramName, ParamVal);
    }


    public void SetOdbcCommandParameters(string paramName, long ParamVal)
    {
        this.odbcCmd.Parameters.AddWithValue(paramName, ParamVal);
    }

    public void SetOdbcCommandParameters(string paramName, decimal ParamVal)
    {
        this.odbcCmd.Parameters.AddWithValue(paramName, ParamVal);
    }

    public void SetOdbcCommandParameters(string paramName, double ParamVal)
    {
        this.odbcCmd.Parameters.AddWithValue(paramName, ParamVal);
    }

    public void SetOdbcCommandParameters(string paramName, bool ParamVal)
    {
        this.odbcCmd.Parameters.AddWithValue(paramName, ParamVal);
    }

    public void SetOdbcCommandParameters(string paramName, short ParamVal)
    {
        this.odbcCmd.Parameters.AddWithValue(paramName, ParamVal);
    }

    public void SetOdbcCommandParameters(string paramName, float ParamVal)
    {
        this.odbcCmd.Parameters.AddWithValue(paramName, ParamVal);
    }


    #endregion

    #region Insert Methods



    public int Insert()
    {
        int rowAdded = 0;

        try
        {
            odbcConn.Open();
            rowAdded = odbcCmd.ExecuteNonQuery();
        }

        catch (Exception err)
        {
            _errmessage = err.Message;
        }

        finally
        {
            odbcConn.Close();
            odbcConn.Dispose();
        }

        return rowAdded;
    }


    //public void InsertBulk(DataTable dt, string tablename)
    //{
    //    // connect to SQL
    //    using (OdbcConnection connection =
    //            new OdbcConnection(this.constring))
    //    {
    //        // make sure to enable triggers
    //        // more on triggers in next post 
    //        SqlBulkCopy bulkCopy =
    //            new SqlBulkCopy
    //            (
    //            connection,
    //            SqlBulkCopyOptions.TableLock |
    //            SqlBulkCopyOptions.FireTriggers |
    //            SqlBulkCopyOptions.UseInternalTransaction |
    //            SqlBulkCopyOptions.KeepIdentity,
    //            null
    //            );

    //        // set the destination table name
    //        bulkCopy.DestinationTableName = tablename;
    //        connection.Open();

    //        // write the data in the "dataTable"
    //        bulkCopy.WriteToServer(dt);
    //        connection.Close();
    //    }
    //    // reset
    //    dt.Clear();
    //}

    public string InsertandReturnID()
    {
        string id = "0";
        try
        {
            odbcConn.Open();
            id = odbcCmd.ExecuteScalar().ToString();
        }

        catch (Exception err)
        {
            _errmessage = err.Message;
        }

        finally
        {
            odbcConn.Close();
            odbcConn.Dispose();
        }

        return id;
    }


    //public string Insert(OdbcConnection sqlcon)
    //{
    //    int rowAdded = 0;
    //    this.odbcConn = sqlcon;

    //    try
    //    {
    //        this.odbcConn.Open();
    //        rowAdded = odbcCmd.ExecuteNonQuery();
    //        sqlTrans.Commit();
    //    }

    //    catch (Exception err)
    //    {
    //        _errmessage = err.Message;
    //        this.sqlTrans.Rollback();
    //    }

    //    finally
    //    {
    //        sqlTrans.Dispose();
    //        odbcConn.Close();
    //        odbcConn.Dispose();
    //    }

    //    _errmessage += rowAdded.ToString();
    //    return _errmessage;
    //}


    //public int Insert(OdbcConnection sqlCon)
    //{

    //    int rowAdded = 0;
    //    this.sqlTrans = sqlCon.BeginTransaction();
    //    try
    //    {
    //        odbcConn.Open();
    //        rowAdded = odbcCmd.ExecuteNonQuery();
    //    }

    //    catch (Exception err)
    //    {
    //        _errmessage = err.Message;
    //    }

    //    finally
    //    {
    //        odbcConn.Close();
    //        odbcConn.Dispose();
    //    }

    //    return rowAdded;
    //}


    #endregion

    #region Update Methods
    // Update Method
    public int Update()
    {
        int rowAdded = 0;

        try
        {
            odbcConn.Open();
            rowAdded = odbcCmd.ExecuteNonQuery();
        }

        catch (Exception err)
        {
            _errmessage = err.Message;
        }

        finally
        {
            odbcConn.Close();
            odbcConn.Dispose();
        }

        return rowAdded;
    }

    // Update Method
    public int Delete()
    {
        int rowAdded = 0;

        try
        {
            odbcConn.Open();
            rowAdded = odbcCmd.ExecuteNonQuery();
        }

        catch (Exception err)
        {
            _errmessage = err.Message;
        }

        finally
        {
            odbcConn.Close();
            odbcConn.Dispose();
        }

        return rowAdded;
    }
    //public int ProperUpdate()
    //{
    //    SqlTransaction sqlTrans;

    //    int rowAdded = 0;

    //    odbcConn.Open();
    //    sqlTrans = odbcConn.BeginTransaction();
    //    odbcCmd.Connection = odbcConn;
    //    odbcCmd.Transaction = sqlTrans;

    //    try
    //    {
    //        rowAdded = odbcCmd.ExecuteNonQuery();
    //        sqlTrans.Commit();
    //    }

    //    catch (Exception err)
    //    {

    //        try
    //        {
    //            sqlTrans.Rollback();
    //        }
    //        catch (Exception ex2)
    //        {
    //            _errmessage = ex2.Message;
    //        }
    //        _errmessage += err.Message;
    //    }

    //    finally
    //    {
    //        odbcConn.Close();
    //        sqlTrans.Dispose();
    //        odbcConn.Dispose();
    //    }

    //    return rowAdded;
    //}
    #endregion



    #region Transactions
    //public int Trans(string[] statement)
    //{
    //    int rows = 0;
    //    try
    //    {
    //        // BeginTransaction() Requires Open Connection
    //        odbcConn.Open();

    //        this.sqlTrans = odbcConn.BeginTransaction();

    //        // Assign Transaction to Command
    //        odbcCmd.Transaction = sqlTrans;

    //        for (int i = 0; i < statement.Length; i++)
    //        {
    //            // Execute 1st Command
    //            this.odbcCmd.CommandText = statement[i];
    //            rows = odbcCmd.ExecuteNonQuery();
    //            if (rows == 0)
    //            {
    //                throw new NotImplementedException("Error in GL Accounts");
    //            }
    //        }
    //        _errmessage = "Transaction Completed ";
    //        sqlTrans.Commit();
    //    }
    //    catch (Exception ex)
    //    {
    //        sqlTrans.Rollback();
    //        //throw;
    //        rows = 0;
    //        _errmessage = ex.Message + " | " + ex.Source + " | " + ex.Data + " | " + ex.InnerException + " | " + ex.HelpLink;
    //    }

    //    finally
    //    {

    //        odbcConn.Close();
    //    }
    //    return rows;
    //}

    //public int Trans(string statement)
    //{
    //    int rows = 0;
    //    try
    //    {
    //        // BeginTransaction() Requires Open Connection
    //        odbcConn.Open();

    //        this.sqlTrans = odbcConn.BeginTransaction();

    //        // Assign Transaction to Command
    //        odbcCmd.Transaction = sqlTrans;

    //        // Execute 1st Command
    //        odbcCmd.CommandText = statement;
    //        rows = odbcCmd.ExecuteNonQuery();
    //        if (rows == 0)
    //        {
    //            throw new NotImplementedException("Error in GL Accounts");
    //        }
    //        //Start Transsaction
    //        sqlTrans.Commit();
    //    }
    //    catch (Exception ex)
    //    {
    //        sqlTrans.Rollback();
    //        _errmessage = ex.Message + " | " + ex.Source + " | " + ex.Data + " | " + ex.InnerException + " | " + ex.HelpLink;
    //    }

    //    finally
    //    {
    //        odbcConn.Close();
    //    }
    //    return rows;
    //}

    #endregion
}
