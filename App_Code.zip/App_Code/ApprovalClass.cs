using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// Summary description for ApprovalClass
/// </summary>
public class ApprovalClass
{
    private SqlConnection sqlConn;
    SqlCommand sqlCmd;
    SqlDataReader sqlDataReader;
    SqlDataAdapter sqldataAdapter;
    DataWorksClass dw;

    DataTable dt;

    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();
    //string oldhousdbString = ConfigurationManager.ConnectionStrings["oldhousdbString"].ConnectionString.ToString();
    string _errmessage;

    public ApprovalClass()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    //Get Possible Payments
    public DataTable GetApprovalStatus(string appno, bool IsToDisburse)
    {
        string sqlSelect = @"select IsValuationOK as [Valuation Status],
                                    IsInspectionOK as [Inspection Status],
                                    IsLegalOK as [Legal Status],
                                    IsPaymentOK as [Payment Status],
                                    IsIncomeOK as [Income Confirmation Status],
                                    IsSecurityOK as [Security Confirmation Status],
                                    Status as [Approval Status],
                                    ApprovedDate as [Date Approved]
                                    from ApprovalStatus where appno = @appno and IsToDisburse =@IsToDisburse";

        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);

        sqldataAdapter.SelectCommand.Parameters.AddWithValue("appno", appno);
        sqldataAdapter.SelectCommand.Parameters.AddWithValue("IsToDisburse", IsToDisburse);

        dt = new DataTable();

        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return dt;

    }

    // Get the Factore of Charge
    public string IsApproved(string appno)
    {
        int rowadded = 0;
        string sqlSelect;
        string status = "";
        sqlSelect = @"select Status from ApprovalStatus where
                        IsValuationOK = 1 and 
                        IsInspectionOK = 1 and 
                        IsLegalOK = 1 and 
                        IsPaymentOK = 1 and 
                        IsIncomeOK = 1 and
                        appno = @appno";

        sqlConn = new SqlConnection(constring);

        sqlCmd = new SqlCommand(sqlSelect, sqlConn);
        sqlCmd.Parameters.AddWithValue("appno", appno);

        try
        {
            sqlConn.Open();
            sqlDataReader = sqlCmd.ExecuteReader();
            sqlDataReader.Read();
            if (sqlDataReader.HasRows == true)
            {
                status = sqlDataReader["Status"].ToString();
            }
            else
            {
                status = "";
            }
            sqlDataReader.Close();

        }

        catch (Exception err)
        {
            this._errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
        }

        return status;
    }

    public bool IsDisbursed(string appno)
    {
        int rowadded = 0;
        string sqlSelect;
        bool IsToDisburse = false;
        sqlSelect = @"select IsToDisburse from ApprovalStatus where
                        IsValuationOK = 1 and 
                        IsInspectionOK = 1 and 
                        IsLegalOK = 1 and 
                        IsPaymentOK = 1 and 
                        IsIncomeOK = 1 and
                        appno = @appno";

        sqlConn = new SqlConnection(constring);

        sqlCmd = new SqlCommand(sqlSelect, sqlConn);
        sqlCmd.Parameters.AddWithValue("appno", appno);

        try
        {
            sqlConn.Open();
            sqlDataReader = sqlCmd.ExecuteReader();
            sqlDataReader.Read();
            if (sqlDataReader.HasRows == true)
            {
                IsToDisburse = bool.Parse(sqlDataReader["IsToDisburse"].ToString());
            }
            else
            {
                IsToDisburse = false;
            }
            sqlDataReader.Close();

        }

        catch (Exception err)
        {
            this._errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
        }

        return IsToDisburse;
    }


    // Get the Factore of Charge
    public int HolderCount(string appno)
    {
        int rowadded = 0;
        string sqlSelect;
        int holdercount = 0;
        sqlSelect = @"select count(*)  as holdercount from AppHolder where
                        appno = @appno";

        sqlConn = new SqlConnection(constring);

        sqlCmd = new SqlCommand(sqlSelect, sqlConn);
        sqlCmd.Parameters.AddWithValue("appno", appno);

        try
        {
            sqlConn.Open();
            sqlDataReader = sqlCmd.ExecuteReader();
            sqlDataReader.Read();
            if (sqlDataReader.HasRows == true)
            {
                holdercount = int.Parse(sqlDataReader["holdercount"].ToString());
            }
            else
            {
                holdercount = 0;
            }
            sqlDataReader.Close();

        }

        catch (Exception err)
        {
            this._errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
        }

        return holdercount;
    }

    
    // Update Apprval Status
    public int UpdateApprovalStatus(string status, string appno, DateTime ApprovedDate, string ApprovedUser)
    {
        string sqlUpdate;


        sqlUpdate = @"update ApprovalStatus set status = @status, ApprovedDate = @ApprovedDate, ApprovedUser=@ApprovedUser where appno = @appno";

        sqlConn = new SqlConnection(constring);
        sqlCmd = new SqlCommand(sqlUpdate, sqlConn);

        sqlCmd.Parameters.AddWithValue("status", status);
        sqlCmd.Parameters.AddWithValue("appno", appno);
        sqlCmd.Parameters.AddWithValue("ApprovedDate", ApprovedDate);
        sqlCmd.Parameters.AddWithValue("ApprovedUser", ApprovedUser);
       
        int rowAdded = 0;

        try
        {
            sqlConn.Open();

            rowAdded = sqlCmd.ExecuteNonQuery();

        }

        catch (Exception err)
        {


            _errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return rowAdded;
    }


    // Update Apprval Status
    public int UpdateCrApp(string appno, int ConfEpf, DateTime ConfDate)
    {
        string sqlUpdate;


        sqlUpdate = @"update CrApp set ConfDate = @ConfDate, ConfEpf = @ConfEpf where appno = @appno";

        sqlConn = new SqlConnection(constring);
        sqlCmd = new SqlCommand(sqlUpdate, sqlConn);

        sqlCmd.Parameters.AddWithValue("ConfDate", ConfDate);
        sqlCmd.Parameters.AddWithValue("appno", appno);
        sqlCmd.Parameters.AddWithValue("ConfEpf", ConfEpf);

        int rowAdded = 0;

        try
        {
            sqlConn.Open();

            rowAdded = sqlCmd.ExecuteNonQuery();

        }

        catch (Exception err)
        {


            _errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return rowAdded;
    }

    // Get the Factore of Charge
    public long GetCrAcNo(string SerialDesc, bool status)
    {
        int rowadded = 0;
        string sqlSelect;
        long cracno = 0;
        sqlSelect = @"Select SerialNo from LastSerial where SerialDesc = @SerialDesc and status = @status";

        sqlConn = new SqlConnection(constring);

        sqlCmd = new SqlCommand(sqlSelect, sqlConn);
       sqlCmd.Parameters.AddWithValue("SerialDesc", SerialDesc);
       sqlCmd.Parameters.AddWithValue("status", status);
        try
        {
            sqlConn.Open();
            sqlDataReader = sqlCmd.ExecuteReader();
            sqlDataReader.Read();
            if (sqlDataReader.HasRows == true)
            {

                cracno = long.Parse(sqlDataReader["SerialNo"].ToString());
                if (cracno != 0)
                {
                    UpdateCracStatus(SerialDesc, false);
                }
                
            }
            else
            {
                cracno = 0;
            }
            sqlDataReader.Close();

        }

        catch (Exception err)
        {
            this._errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
        }

        return cracno;
    }

    // Update Apprval Status
    public int UpdateCrAcNo(string SerialDesc, long SerialNo)
    {
        string sqlUpdate;


        sqlUpdate = @"update LastSerial set SerialNo = @SerialNo where SerialDesc = @SerialDesc";

        sqlConn = new SqlConnection(constring);
        sqlCmd = new SqlCommand(sqlUpdate, sqlConn);

        sqlCmd.Parameters.AddWithValue("SerialDesc", SerialDesc);
        sqlCmd.Parameters.AddWithValue("SerialNo", SerialNo);

        int rowAdded = 0;

        try
        {
            sqlConn.Open();
            
            rowAdded = sqlCmd.ExecuteNonQuery();
            if(rowAdded!=0)
            {
                UpdateCracStatus(SerialDesc, true);
            }

        }

        catch (Exception err)
        {


            _errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return rowAdded;
    }

    // Update Apprval Status
    public int UpdateCracStatus(string SerialDesc, bool status)
    {
        string sqlUpdate;


        sqlUpdate = @"update LastSerial set status = @status where SerialDesc = @SerialDesc";

        sqlConn = new SqlConnection(constring);
        sqlCmd = new SqlCommand(sqlUpdate, sqlConn);

        sqlCmd.Parameters.AddWithValue("SerialDesc", SerialDesc);
        sqlCmd.Parameters.AddWithValue("status", status);


        int rowAdded = 0;

        try
        {
            sqlConn.Open();

            rowAdded = sqlCmd.ExecuteNonQuery();

        }

        catch (Exception err)
        {


            _errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return rowAdded;
    }


    #region InsertMethods

//    public int InsertCrDisbMast(DateTime AcOpenDate, string AcStatus, string AppNo, string CocStatus, int DisbTimes,
//         string IsFinalRelease, int NoofDisb, double TotAppAmt, decimal TotDisbursed, DateTime GrantLstDate)
//    {
//        SqlTransaction sqlTrans;
//        string sqlInsert;

//        sqlInsert = @"INSERT INTO CrDisbMast(AcOpenDate , AcStatus , AppNo , CocStatus , DisbTimes ,
//                        IsFinalRelease , NoofDisb , TotAppAmt , TotDisbursed,GrantLstDate)
//                      VALUES (@AcOpenDate , @AcStatus , @AppNo , @CocStatus , @DisbTimes , 
//                      @IsFinalRelease , @NoofDisb , @TotAppAmt , @TotDisbursed, @GrantLstDate)";

//        sqlConn = new SqlConnection(oldhousdbString);
//        sqlCmd = new SqlCommand(sqlInsert, sqlConn);

//        sqlCmd.Parameters.AddWithValue("AcOpenDate", AcOpenDate);
//        sqlCmd.Parameters.AddWithValue("AcStatus", AcStatus);
//        sqlCmd.Parameters.AddWithValue("AppNo", AppNo);
//        sqlCmd.Parameters.AddWithValue("CocStatus", CocStatus);
//        sqlCmd.Parameters.AddWithValue("DisbTimes", DisbTimes);

//        sqlCmd.Parameters.AddWithValue("IsFinalRelease", IsFinalRelease);
//        sqlCmd.Parameters.AddWithValue("NoofDisb", NoofDisb);
//        sqlCmd.Parameters.AddWithValue("TotAppAmt", TotAppAmt);
//        sqlCmd.Parameters.AddWithValue("TotDisbursed", TotDisbursed);

//        sqlCmd.Parameters.AddWithValue("GrantLstDate", GrantLstDate);

//        int rowAdded = 0;

//        sqlConn.Open();
//        sqlTrans = sqlConn.BeginTransaction();
//        sqlCmd.Connection = sqlConn;
//        sqlCmd.Transaction = sqlTrans;

//        try
//        {
//            rowAdded = sqlCmd.ExecuteNonQuery();
//            sqlTrans.Commit();
//        }

//        catch (Exception err)
//        {


//            // Attempt to roll back the transaction.
//            try
//            {
//                sqlTrans = sqlConn.BeginTransaction();
//                sqlTrans.Rollback();
//            }
//            catch (Exception ex2)
//            {
//                // This catch block will handle any errors that may have occurred
//                // on the server that would cause the rollback to fail, such as
//                // a closed connection
//            }
//            _errmessage = err.Message;
//        }

//        finally
//        {
//            sqlConn.Close();
//            sqlTrans.Dispose();
//            sqlConn.Dispose();
//        }

//        return rowAdded;
//    }

//    public int InsertInspectMast(string AppNo, int InspectId,DateTime DateRecv,DateTime DateRtn, double InspecFee, double AmtWorkDone, 
//        string Remarks,string AddUser,string Status, string IsInspecPd)
//    {
//        SqlTransaction sqlTrans;
//        string sqlInsert;

//        sqlInsert = @"INSERT INTO InspectMast (AppNo,InspectId,DateRecv,DateRtn,InspecFee,AmtWorkDone,Remarks,AddUser,Status,IsInspecPd)
//                        VALUES (@AppNo,@InspectId,@DateRecv,@DateRtn,@InspecFee,@AmtWorkDone,@Remarks,@AddUser,@Status,@IsInspecPd)";
          

//        sqlConn = new SqlConnection(oldhousdbString);
//        sqlCmd = new SqlCommand(sqlInsert, sqlConn);

//        sqlCmd.Parameters.AddWithValue("AppNo", AppNo);
//        sqlCmd.Parameters.AddWithValue("InspectId", InspectId);
//        sqlCmd.Parameters.AddWithValue("DateRecv", DateRecv);
//        sqlCmd.Parameters.AddWithValue("DateRtn", DateRtn);
//        sqlCmd.Parameters.AddWithValue("InspecFee", InspecFee);
//        sqlCmd.Parameters.AddWithValue("AmtWorkDone", AmtWorkDone);
//        sqlCmd.Parameters.AddWithValue("Remarks", Remarks);
//        sqlCmd.Parameters.AddWithValue("AddUser", AddUser);
//        sqlCmd.Parameters.AddWithValue("Status", Status);
//        sqlCmd.Parameters.AddWithValue("IsInspecPd", IsInspecPd);

       

//        int rowAdded = 0;

//        sqlConn.Open();
//        sqlTrans = sqlConn.BeginTransaction();
//        sqlCmd.Connection = sqlConn;
//        sqlCmd.Transaction = sqlTrans;

//        try
//        {
//            rowAdded = sqlCmd.ExecuteNonQuery();
//            sqlTrans.Commit();
//        }

//        catch (Exception err)
//        {


//            // Attempt to roll back the transaction.
//            try
//            {
//                sqlTrans = sqlConn.BeginTransaction();
//                sqlTrans.Rollback();
//            }
//            catch (Exception ex2)
//            {
//                // This catch block will handle any errors that may have occurred
//                // on the server that would cause the rollback to fail, such as
//                // a closed connection
//            }
//            _errmessage = err.Message;
//        }

//        finally
//        {
//            sqlConn.Close();
//            sqlTrans.Dispose();
//            sqlConn.Dispose();
//        }

//        return rowAdded;
//    }

    //2008-10-13
    public int InsertCrHolder(string Appno, string CrAcNo, int CustNo, int HolderCount, string HolderType, string HoldRelation, string IsAdditional)
    {
        SqlTransaction sqlTrans;
        string sqlInsert;

        sqlInsert = @"INSERT INTO CrHolder(Appno,CrAcNo,CustNo,HolderCount,HolderType,HoldRelation,IsAdditional)
                      VALUES (@Appno,@CrAcNo,@CustNo,@HolderCount,@HolderType,@HoldRelation,@IsAdditional)";

        sqlConn = new SqlConnection(constring);
        sqlCmd = new SqlCommand(sqlInsert, sqlConn);

        sqlCmd.Parameters.AddWithValue("Appno", Appno);
        sqlCmd.Parameters.AddWithValue("CrAcNo", CrAcNo);
        sqlCmd.Parameters.AddWithValue("CustNo", CustNo);
        sqlCmd.Parameters.AddWithValue("HolderCount", HolderCount);
        sqlCmd.Parameters.AddWithValue("HolderType", HolderType);
        sqlCmd.Parameters.AddWithValue("HoldRelation", HoldRelation);
        sqlCmd.Parameters.AddWithValue("IsAdditional", IsAdditional);

        int rowAdded = 0;

        sqlConn.Open();
        sqlTrans = sqlConn.BeginTransaction();
        sqlCmd.Connection = sqlConn;
        sqlCmd.Transaction = sqlTrans;

        try
        {
            rowAdded = sqlCmd.ExecuteNonQuery();
            sqlTrans.Commit();
        }

        catch (Exception err)
        {
            // Attempt to roll back the transaction.
            try
            {
                sqlTrans = sqlConn.BeginTransaction();
                sqlTrans.Rollback();
            }
            catch (Exception ex2)
            {
                // This catch block will handle any errors that may have occurred
                // on the server that would cause the rollback to fail, such as
                // a closed connection
            }
            _errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
            sqlTrans.Dispose();
            sqlConn.Dispose();
        }

        return rowAdded;
    }

    //2009-01-20

    public int InsertIntoNewCrHolder(string Appno, string CrAcNo, int CustNo, string NicNo, 
        int HolderCount, string HolderType, string HoldRelation, string IsAdditional)
    {
        SqlTransaction sqlTrans;
        string sqlInsert;

        sqlInsert = @"INSERT INTO CrHolder(Appno,CrAcNo,CustNo,NicNo,HolderCount,HolderType,HoldRelation,IsAdditional)
                      VALUES (@Appno,@CrAcNo,@CustNo,@NicNo,@HolderCount,@HolderType,@HoldRelation,@IsAdditional)";

        sqlConn = new SqlConnection(constring);
        sqlCmd = new SqlCommand(sqlInsert, sqlConn);

        sqlCmd.Parameters.AddWithValue("Appno", Appno);
        sqlCmd.Parameters.AddWithValue("CrAcNo", CrAcNo);
        sqlCmd.Parameters.AddWithValue("CustNo", CustNo);
        sqlCmd.Parameters.AddWithValue("NicNo", NicNo);
        sqlCmd.Parameters.AddWithValue("HolderCount", HolderCount);
        sqlCmd.Parameters.AddWithValue("HolderType", HolderType);
        sqlCmd.Parameters.AddWithValue("HoldRelation", HoldRelation);
        sqlCmd.Parameters.AddWithValue("IsAdditional", IsAdditional);

        int rowAdded = 0;

        sqlConn.Open();
        sqlTrans = sqlConn.BeginTransaction();
        sqlCmd.Connection = sqlConn;
        sqlCmd.Transaction = sqlTrans;

        try
        {
            rowAdded = sqlCmd.ExecuteNonQuery();
            sqlTrans.Commit();
        }

        catch (Exception err)
        {
            // Attempt to roll back the transaction.
            try
            {
                sqlTrans = sqlConn.BeginTransaction();
                sqlTrans.Rollback();
            }
            catch (Exception ex2)
            {
                // This catch block will handle any errors that may have occurred
                // on the server that would cause the rollback to fail, such as
                // a closed connection
            }
            _errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
            sqlTrans.Dispose();
            sqlConn.Dispose();
        }

        return rowAdded;
    }


    //2008-10-13
    public int InsertAppHolder(string appno, int CustNo, int HolderCount, string HolderType, string HoldRelation, string IsAdditional)
    {
        SqlTransaction sqlTrans;
        string sqlInsert;

        sqlInsert = @"INSERT INTO AppHolder(Appno,CustNo,HolderCount,HolderType,HoldRelation,IsAdditional)
                      VALUES (@Appno,@CustNo,@HolderCount,@HolderType,@HoldRelation,@IsAdditional)";

        sqlConn = new SqlConnection(constring);
        sqlCmd = new SqlCommand(sqlInsert, sqlConn);

        sqlCmd.Parameters.AddWithValue("Appno", appno);
        sqlCmd.Parameters.AddWithValue("CustNo", CustNo);
        sqlCmd.Parameters.AddWithValue("HolderCount", HolderCount);
        sqlCmd.Parameters.AddWithValue("HolderType", HolderType);
        sqlCmd.Parameters.AddWithValue("HoldRelation", HoldRelation);
        sqlCmd.Parameters.AddWithValue("IsAdditional", IsAdditional);

        int rowAdded = 0;

        sqlConn.Open();
        sqlTrans = sqlConn.BeginTransaction();
        sqlCmd.Connection = sqlConn;
        sqlCmd.Transaction = sqlTrans;

        try
        {
            rowAdded = sqlCmd.ExecuteNonQuery();
            sqlTrans.Commit();
        }

        catch (Exception err)
        {
            // Attempt to roll back the transaction.
            try
            {
                sqlTrans = sqlConn.BeginTransaction();
                sqlTrans.Rollback();
            }
            catch (Exception ex2)
            {
                // This catch block will handle any errors that may have occurred
                // on the server that would cause the rollback to fail, such as
                // a closed connection
            }
            _errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
            sqlTrans.Dispose();
            sqlConn.Dispose();
        }

        return rowAdded;
    }

    //2008-10-13
    public int InsertCrMast(string AcChanges, string AcStatus, string Appno, double Aprovdamt, string CrAcNo, int CrCat, int CrPeriod,
                            double GrantAmt,  double instalment, int SchemNo)
    {
        SqlTransaction sqlTrans;
        string sqlInsert;

        sqlInsert = @"INSERT INTO CrMast(AcChanges,AcStatus,Appno,Aprovdamt,CrAcNo,CrCat,CrPeriod,GrantAmt,instalment,SchemNo)
                      VALUES (@AcChanges,@AcStatus,@Appno,@Aprovdamt,@CrAcNo,@CrCat,@CrPeriod,@GrantAmt,@instalment,@SchemNo)";

        sqlConn = new SqlConnection(constring);
        sqlCmd = new SqlCommand(sqlInsert, sqlConn);

        sqlCmd.Parameters.AddWithValue("AcChanges", AcChanges);
        sqlCmd.Parameters.AddWithValue("AcStatus", AcStatus);
        sqlCmd.Parameters.AddWithValue("Appno", Appno);
        sqlCmd.Parameters.AddWithValue("Aprovdamt", Aprovdamt);
        sqlCmd.Parameters.AddWithValue("CrAcNo", CrAcNo);
        sqlCmd.Parameters.AddWithValue("CrCat", CrCat);
        sqlCmd.Parameters.AddWithValue("CrPeriod", CrPeriod);
        sqlCmd.Parameters.AddWithValue("GrantAmt", GrantAmt);
        sqlCmd.Parameters.AddWithValue("instalment", instalment);
        sqlCmd.Parameters.AddWithValue("SchemNo", SchemNo);

        int rowAdded = 0;

        sqlConn.Open();
        sqlTrans = sqlConn.BeginTransaction();
        sqlCmd.Connection = sqlConn;
        sqlCmd.Transaction = sqlTrans;

        try
        {
            rowAdded = sqlCmd.ExecuteNonQuery();
            sqlTrans.Commit();
        }

        catch (Exception err)
        {


            // Attempt to roll back the transaction.
            try
            {
                sqlTrans = sqlConn.BeginTransaction();
                sqlTrans.Rollback();
            }
            catch (Exception ex2)
            {
                // This catch block will handle any errors that may have occurred
                // on the server that would cause the rollback to fail, such as
                // a closed connection
            }
            _errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
            sqlTrans.Dispose();
            sqlConn.Dispose();
        }

        return rowAdded;
    }
    //insert crmast details to NewCrediT 18/12/2008
    public int InsertIntoNewCreMast(string AcChanges, string AcStatus, string Appno, double Aprovdamt, string CrAcNo, int CrCat, int CrPeriod,
                            double GrantAmt, double instalment, int SchemNo)
    {
        SqlTransaction sqlTrans;
        string sqlInsert;

        sqlInsert = @"INSERT INTO CrMast(AcChanges,AcStatus,Appno,Aprovdamt,CrAcNo,CrCat,CrPeriod,GrantAmt,instalment,SchemNo)
                      VALUES (@AcChanges,@AcStatus,@Appno,@Aprovdamt,@CrAcNo,@CrCat,@CrPeriod,@GrantAmt,@instalment,@SchemNo)";

        sqlConn = new SqlConnection(constring);
        sqlCmd = new SqlCommand(sqlInsert, sqlConn);

        sqlCmd.Parameters.AddWithValue("AcChanges", AcChanges);
        sqlCmd.Parameters.AddWithValue("AcStatus", AcStatus);
        sqlCmd.Parameters.AddWithValue("Appno", Appno);
        sqlCmd.Parameters.AddWithValue("Aprovdamt", Aprovdamt);
        sqlCmd.Parameters.AddWithValue("CrAcNo", CrAcNo);
        sqlCmd.Parameters.AddWithValue("CrCat", CrCat);
        sqlCmd.Parameters.AddWithValue("CrPeriod", CrPeriod);
        sqlCmd.Parameters.AddWithValue("GrantAmt", GrantAmt);
        sqlCmd.Parameters.AddWithValue("instalment", instalment);
        sqlCmd.Parameters.AddWithValue("SchemNo", SchemNo);

        int rowAdded = 0;

        sqlConn.Open();
        sqlTrans = sqlConn.BeginTransaction();
        sqlCmd.Connection = sqlConn;
        sqlCmd.Transaction = sqlTrans;

        try
        {
            rowAdded = sqlCmd.ExecuteNonQuery();
            sqlTrans.Commit();
        }

        catch (Exception err)
        {


            // Attempt to roll back the transaction.
            try
            {
                sqlTrans = sqlConn.BeginTransaction();
                sqlTrans.Rollback();
            }
            catch (Exception ex2)
            {
                // This catch block will handle any errors that may have occurred
                // on the server that would cause the rollback to fail, such as
                // a closed connection
            }
            _errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
            sqlTrans.Dispose();
            sqlConn.Dispose();
        }

        return rowAdded;
    }

    //2008-10-13 doesnot use
    public int InsertHousProp(DateTime Adddate, string AddUser, string CrAcNo, int GracePeriod, int InstallmentNo, double Instalment,
                              DateTime LstPaiddate, DateTime LstTrDate, double OutBal, int RecptPeriod, DateTime DateDue, string IsPenal)
    {
        SqlTransaction sqlTrans;
        string sqlInsert;

        sqlInsert = @"INSERT INTO HousProp(Adddate,AddUser,CrAcNo,GracePeriod,InstallmentNo,Instalment,LstPaiddate,LstTrDate,OutBal,RecptPeriod, DateDue, IsPenal)
                      VALUES (@Adddate,@AddUser,@CrAcNo,@GracePeriod,@InstallmentNo,@Instalment,@LstPaiddate,@LstTrDate,@OutBal,@RecptPeriod, @DateDue, @IsPenal)";

        sqlConn = new SqlConnection(constring);
        sqlCmd = new SqlCommand(sqlInsert, sqlConn);

        sqlCmd.Parameters.AddWithValue("Adddate", Adddate);
        sqlCmd.Parameters.AddWithValue("AddUser", AddUser);
        sqlCmd.Parameters.AddWithValue("CrAcNo", CrAcNo);
        sqlCmd.Parameters.AddWithValue("GracePeriod", GracePeriod);
        sqlCmd.Parameters.AddWithValue("InstallmentNo", InstallmentNo);
        sqlCmd.Parameters.AddWithValue("Instalment", Instalment);
        sqlCmd.Parameters.AddWithValue("LstPaiddate", LstPaiddate);
        sqlCmd.Parameters.AddWithValue("LstTrDate", LstTrDate);
        sqlCmd.Parameters.AddWithValue("OutBal", OutBal);
        sqlCmd.Parameters.AddWithValue("RecptPeriod", RecptPeriod);
        sqlCmd.Parameters.AddWithValue("DateDue", DateDue);
        sqlCmd.Parameters.AddWithValue("IsPenal", IsPenal);

        int rowAdded = 0;

        sqlConn.Open();
        sqlTrans = sqlConn.BeginTransaction();
        sqlCmd.Connection = sqlConn;
        sqlCmd.Transaction = sqlTrans;

        try
        {
            rowAdded = sqlCmd.ExecuteNonQuery();
            sqlTrans.Commit();
        }

        catch (Exception err)
        {


            // Attempt to roll back the transaction.
            try
            {
                sqlTrans = sqlConn.BeginTransaction();
                sqlTrans.Rollback();
            }
            catch (Exception ex2)
            {
                // This catch block will handle any errors that may have occurred
                // on the server that would cause the rollback to fail, such as
                // a closed connection
            }
            _errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
            sqlTrans.Dispose();
            sqlConn.Dispose();
        }

        return rowAdded;
    }

    //2008-10-13
    public int InsertMiscRates(string CrAcNo, int RateCode, string RateStatus, string RateType)
    {
        SqlTransaction sqlTrans;
        string sqlInsert;

        sqlInsert = @"INSERT INTO MiscRates(CrAcNo,RateCode,RateStatus,RateType)
                      VALUES (@CrAcNo,@RateCode,@RateStatus,@RateType)";

        sqlConn = new SqlConnection(constring);
        sqlCmd = new SqlCommand(sqlInsert, sqlConn);

        sqlCmd.Parameters.AddWithValue("CrAcNo", CrAcNo);
        sqlCmd.Parameters.AddWithValue("RateCode", RateCode);
        sqlCmd.Parameters.AddWithValue("RateStatus", RateStatus);
        sqlCmd.Parameters.AddWithValue("RateType", RateType);

        int rowAdded = 0;

        sqlConn.Open();
        sqlTrans = sqlConn.BeginTransaction();
        sqlCmd.Connection = sqlConn;
        sqlCmd.Transaction = sqlTrans;

        try
        {
            rowAdded = sqlCmd.ExecuteNonQuery();
            sqlTrans.Commit();
        }

        catch (Exception err)
        {


            // Attempt to roll back the transaction.
            try
            {
                sqlTrans = sqlConn.BeginTransaction();
                sqlTrans.Rollback();
            }
            catch (Exception ex2)
            {
                // This catch block will handle any errors that may have occurred
                // on the server that would cause the rollback to fail, such as
                // a closed connection
            }
            _errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
            sqlTrans.Dispose();
            sqlConn.Dispose();
        }

        return rowAdded;
    }

//    public int InsertCrapp(string AppNo, DateTime RecvDate, int SchemNo, string Status, double CrAmt, double BoqAmount, double RedemPurchaseAmt, int NoOfDisb,
//                    int GracePeriod, double ApprovedAmt, int ConfEpf, DateTime ConfDate, string IsApproved, DateTime ApprovDate, string ClientType,
//                    string AddUser, DateTime AddDate, string IsDisbTr, string AppCat, string SecurityType, string IsIncomeConf)
//    {
//        string _errmessage;
//        string sqlInsert;
//        sqlInsert = @"insert into crapp (AppNo,RecvDate, SchemNo,Status,CrAmt,BoqAmount,RedemPurchaseAmt,NoOfDisb,GracePeriod,ApprovedAmt,ConfEpf,
//                         ConfDate,IsApproved,ApprovDate,ClientType,AddUser,AddDate,IsDisbTr,AppCat,SecurityType, IsIncomeConf) 
//                         values (@AppNo,@RecvDate,@SchemNo,@Status,@CrAmt,@BoqAmount,@RedemPurchaseAmt,
//                         @NoOfDisb,@GracePeriod,@ApprovedAmt,@ConfEpf,@ConfDate,@IsApproved,@ApprovDate,@ClientType,@AddUser,@AddDate,@IsDisbTr,
//                         @AppCat,@SecurityType, @IsIncomeConf)";


//        sqlConn = new SqlConnection(oldhousdbString);
//        sqlCmd = new SqlCommand(sqlInsert, sqlConn);


//        sqlCmd.Parameters.AddWithValue("AppNo", AppNo);
//        sqlCmd.Parameters.AddWithValue("RecvDate", RecvDate);
//        sqlCmd.Parameters.AddWithValue("Status", Status);
//        sqlCmd.Parameters.AddWithValue("CrAmt", CrAmt);
//        sqlCmd.Parameters.AddWithValue("BoqAmount", BoqAmount);
//        sqlCmd.Parameters.AddWithValue("SchemNo", SchemNo);


//        sqlCmd.Parameters.AddWithValue("RedemPurchaseAmt", RedemPurchaseAmt);
//        sqlCmd.Parameters.AddWithValue("NoOfDisb", NoOfDisb);
//        sqlCmd.Parameters.AddWithValue("GracePeriod", GracePeriod);
//        sqlCmd.Parameters.AddWithValue("ApprovedAmt", ApprovedAmt);
//        sqlCmd.Parameters.AddWithValue("ConfEpf", ConfEpf);

//        sqlCmd.Parameters.AddWithValue("ConfDate", ConfDate);
//        sqlCmd.Parameters.AddWithValue("IsApproved", IsApproved);
//        sqlCmd.Parameters.AddWithValue("ApprovDate", ApprovDate);
//        sqlCmd.Parameters.AddWithValue("ClientType", ClientType);
//        sqlCmd.Parameters.AddWithValue("AddUser", AddUser);

//        sqlCmd.Parameters.AddWithValue("AddDate", AddDate);
//        sqlCmd.Parameters.AddWithValue("IsDisbTr", IsDisbTr);
//        sqlCmd.Parameters.AddWithValue("AppCat", AppCat);
//        sqlCmd.Parameters.AddWithValue("SecurityType", SecurityType);
//        sqlCmd.Parameters.AddWithValue("IsIncomeConf", IsIncomeConf);




//        int rowAdded = 0;

//        try
//        {
//            sqlConn.Open();
//            rowAdded = sqlCmd.ExecuteNonQuery();
//        }

//        catch (Exception err)
//        {
//            _errmessage = err.Message;
//        }

//        finally
//        {
//            sqlConn.Close();
//        }

//        return rowAdded;

//    }



    public int InsertAppScheme(string AppNo, int SchCount, int SchemeNo, double CrAmt, double ApprovedAmt)
    {
        string _errmessage;
        string sqlInsert;
        sqlInsert = @"INSERT INTO AppScheme (AppNo,SchCount,SchemeNo,CrAmt,ApprovedAmt)
                    VALUES (@AppNo,@SchCount,@SchemeNo,@CrAmt,@ApprovedAmt)";


        sqlConn = new SqlConnection(constring);
        sqlCmd = new SqlCommand(sqlInsert, sqlConn);


        sqlCmd.Parameters.AddWithValue("AppNo", AppNo);
        sqlCmd.Parameters.AddWithValue("SchCount", SchCount);
        sqlCmd.Parameters.AddWithValue("SchemeNo", SchemeNo);
        sqlCmd.Parameters.AddWithValue("CrAmt", CrAmt);
        sqlCmd.Parameters.AddWithValue("ApprovedAmt", ApprovedAmt);

       

        int rowAdded = 0;

        try
        {
            sqlConn.Open();
            rowAdded = sqlCmd.ExecuteNonQuery();
        }

        catch (Exception err)
        {
            _errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
        }

        return rowAdded;

    }

//    public int InsertValuation(string appno, string status, double forceval, DateTime SENDDATE, int valuerid)
//    {
//        string _errmessage;
//        string sqlInsert;
//        sqlInsert = @"INSERT INTO Valuation(appno,status, forceval, SENDDATE, valuerid)
//                    VALUES (@appno,@status,@forceval,@SENDDATE, @valuerid)";


//        sqlConn = new SqlConnection(oldhousdbString);
//        sqlCmd = new SqlCommand(sqlInsert, sqlConn);


//        sqlCmd.Parameters.AddWithValue("appno", appno);
//        sqlCmd.Parameters.AddWithValue("status", status);
//        sqlCmd.Parameters.AddWithValue("forceval", forceval);
//        sqlCmd.Parameters.AddWithValue("SENDDATE", SENDDATE);
//        sqlCmd.Parameters.AddWithValue("valuerid", valuerid);

//        int rowAdded = 0;

//        try
//        {
//            sqlConn.Open();
//            rowAdded = sqlCmd.ExecuteNonQuery();
//        }

//        catch (Exception err)
//        {
//            _errmessage = err.Message;
//        }

//        finally
//        {
//            sqlConn.Close();
//        }

//        return rowAdded;

//    }

    #endregion

    //Data Colection Methods
    public DataTable GetNewData(string appno)
    {
        string sqlSelect = @"SELECT C.AppNo AS AppNo, A.Amount AS ApprovedAmt, C.CrCatCode As CrCatCode, c.RecvDate, c.AppCat,
                            c.BoqAmount, c.RedemPurchaseAmt, GracePeriod, IntRate, cp.purposecode, c.NoOfDisb, 
                            CrPeriod AS [No of Instalments], c.ConfEpf, c.ConfDate, C.IsAdditional AS Additional, c.ClientType, c.SecurityType
                            FROM CrApp C, AppCategory A, CrCatPurpose Cp
                            WHERE C.AppNo=@appno
                            AND C.AppNo=A.AppNo
                            AND A.CatPurposeId=Cp.CatPurposeId";

        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);

        sqldataAdapter.SelectCommand.Parameters.AddWithValue("appno", appno);

        dt = new DataTable();

        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return dt;

    }




    //Data Colection Methods
    public DataTable GetCrApp(string appno)
    {
        string sqlSelect = @"SELECT appno, Status, CrAmt,  from CrApp Where appno = @appno";

        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);

        sqldataAdapter.SelectCommand.Parameters.AddWithValue("appno", appno);

        dt = new DataTable();

        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return dt;

    }

    public DataTable GetHolderData(string appno, string status, string inspectionstat)
    {
        string sqlSelect = @"SELECT distinct  HolderType,HoldRelation, NicNo, forceval, senddate, v.valuerid, 
                            im.inspectid, im.DateRecv, inspecfee, im.AmtWorkDone
                            FROM CrApp C, AppHolder A, Valuation v, inspectmast im
                            WHERE C.AppNo=@appno
                            AND C.AppNo=a.appno
							and im.appno =  a.appno 
							and a.appno = v.appno and v.status =@status
                            and im.inspectionstatus=@inspectionstat";

        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);

        sqldataAdapter.SelectCommand.Parameters.AddWithValue("appno", appno);
        sqldataAdapter.SelectCommand.Parameters.AddWithValue("status", status);
        sqldataAdapter.SelectCommand.Parameters.AddWithValue("inspectionstat", inspectionstat);

        dt = new DataTable();

        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return dt;

    }


    //Data Colection Methods
    public DataTable GetSheme(int intcode, int purposcode, int crperiod)
    {
        string sqlSelect = @"select schemno, maxamt, intrate, crdes, descrip, clienttype from creditscheme c,
                             crcategory cr, crpurpose cp, interestcode i
                            where c.maxperd=@maxperd and c.purposcode=cp.purposecode and c.purposcode=@purposcode
                            and c.creditcat=cr.crcatcode and i.intcode= @intcode and i.intcode=c.intcode";


        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);

        sqldataAdapter.SelectCommand.Parameters.AddWithValue("intcode", intcode);
        sqldataAdapter.SelectCommand.Parameters.AddWithValue("purposcode", purposcode);
        sqldataAdapter.SelectCommand.Parameters.AddWithValue("maxperd", crperiod);


        dt = new DataTable();

        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return dt;

    }

    //// Get LoanType
    //public double GetForcesaleValue(double intrate)
    //{
    //    int rowadded = 0;
    //    string sqlSelect;
    //    int intCode = 0;
    //    sqlSelect = @"select intcode from interestcode where intrate = @intrate";

    //    sqlConn = new SqlConnection(oldhousdbString);

    //    sqlCmd = new SqlCommand(sqlSelect, sqlConn);
    //    sqlCmd.Parameters.AddWithValue("intrate", intrate);


    //    try
    //    {
    //        sqlConn.Open();
    //        sqlDataReader = sqlCmd.ExecuteReader();
    //        sqlDataReader.Read();
    //        if (sqlDataReader.HasRows == true)
    //        {
    //            intCode = int.Parse(sqlDataReader["intcode"].ToString());
    //        }
    //        else
    //        {

    //        }
    //        sqlDataReader.Close();

    //    }

    //    catch (Exception err)
    //    {
    //        this._errmessage = err.Message;
    //    }

    //    finally
    //    {
    //        sqlConn.Close();
    //    }

    //    return intCode;

    //}


    // Get LoanType
    public int GetIntCodes(double intrate)
    {
        int rowadded = 0;
        string sqlSelect;
        int intCode = 0;
        sqlSelect = @"select intcode from interestcode where intrate = @intrate and adduser is not null";

        sqlConn = new SqlConnection(constring);

        sqlCmd = new SqlCommand(sqlSelect, sqlConn);
        sqlCmd.Parameters.AddWithValue("intrate", intrate);


        try
        {
            sqlConn.Open();
            sqlDataReader = sqlCmd.ExecuteReader();
            sqlDataReader.Read();
            if (sqlDataReader.HasRows == true)
            {
                intCode = int.Parse(sqlDataReader["intcode"].ToString());
            }
            else
            {

            }
            sqlDataReader.Close();

        }

        catch (Exception err)
        {
            this._errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
        }

        return intCode;

    }

    public int RollBackTransactions(string appno, string cracno, int custno)
    {
        SqlTransaction sqlTrans;
        string sqlInsert;

        sqlInsert = @"delete from crmast where appno = @appno
                    delete from CrDisbMast where appno = @appno
                    delete from CrHolder where cracno = @cracno
                    delete from Appscheme where appno = @appno
                    delete from HousProp where cracno = @cracno
                    delete from MiscRates where cracno = @cracno
                    delete from AppHolder where appno = @appno
                    delete from crapp where appno = @cracno
                    delete from Valuation where appno = @appno
                    delete from Valuation where appno = @appno
                    delete from customermain where custno = @custno";

        sqlConn = new SqlConnection(constring);
        sqlCmd = new SqlCommand(sqlInsert, sqlConn);

        sqlCmd.Parameters.AddWithValue("appno", appno);
        sqlCmd.Parameters.AddWithValue("cracno", cracno);
        sqlCmd.Parameters.AddWithValue("custno", custno);

        int rowAdded = 0;

        sqlConn.Open();
        sqlTrans = sqlConn.BeginTransaction();
        sqlCmd.Connection = sqlConn;
        sqlCmd.Transaction = sqlTrans;

        try
        {
            rowAdded = sqlCmd.ExecuteNonQuery();
            sqlTrans.Commit();
        }

        catch (Exception err)
        {


            // Attempt to roll back the transaction.
            try
            {
                sqlTrans = sqlConn.BeginTransaction();
                sqlTrans.Rollback();
            }
            catch (Exception ex2)
            {
                // This catch block will handle any errors that may have occurred
                // on the server that would cause the rollback to fail, such as
                // a closed connection
            }
            _errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
            sqlTrans.Dispose();
            sqlConn.Dispose();
        }

        return rowAdded;
    }

    //Get CracNumber from CrMast Methods
    public DataTable GetCrAcNoFromCrMast(string appno)
    {
        string sqlSelect = @"SELECT cracno from crmast where appno = @appno";

        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);

        sqldataAdapter.SelectCommand.Parameters.AddWithValue("appno", appno);

        dt = new DataTable();

        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return dt;

    }


    //Get CustomerInfo from New credit Db
    public DataTable GetCustomerMain(string nicno)
    {
        string sqlSelect = @"SELECT * from customerMain where nicno = @nicno";

        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);

        sqldataAdapter.SelectCommand.Parameters.AddWithValue("nicno", nicno);

        dt = new DataTable();

        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return dt;

    }

    // InsertCustomerMain
    public int InsertCustomerMain(int CustNo, int TitleCode, string Surname, string Initials, string Othername,
               string NicNo, string Location, string Street, string City, string TeleNo,
               DateTime DoBirth, string TNIC)
    {
        string Error;
        string sqlInsert;
        sqlInsert = @"insert into CustomerMain(CustNo,TitleCode,Surname,Initials,Othername,NicNo,Location,Street,
                      City,TeleNo,DoBirth,TNIC)
                      values(@CustNo,@TitleCode,@Surname,@Initials,@Othername,@NicNo,@Location,@Street,@City,
                      @TeleNo,@DoBirth,@TNIC)";

        sqlConn = new SqlConnection(constring);
        sqlCmd = new SqlCommand(sqlInsert, sqlConn);

        int rowadded = 0;

        sqlCmd.Parameters.AddWithValue("CustNo", CustNo);
        sqlCmd.Parameters.AddWithValue("TitleCode", TitleCode);
        sqlCmd.Parameters.AddWithValue("Surname", Surname.Trim());
        sqlCmd.Parameters.AddWithValue("Initials", Initials.Trim());
        sqlCmd.Parameters.AddWithValue("Othername", Othername.Trim());

        sqlCmd.Parameters.AddWithValue("NicNo", NicNo);
        sqlCmd.Parameters.AddWithValue("Location", Location.Trim());
        sqlCmd.Parameters.AddWithValue("Street", Street.Trim());
        sqlCmd.Parameters.AddWithValue("City", City.Trim());

        sqlCmd.Parameters.AddWithValue("TeleNo", TeleNo.Trim());

        sqlCmd.Parameters.AddWithValue("DoBirth", DoBirth);

        sqlCmd.Parameters.AddWithValue("TNIC", TNIC);

        try
        {
            sqlConn.Open();
            rowadded = sqlCmd.ExecuteNonQuery();
        }
        catch (Exception er)
        {
            Error = er.ToString();
        }
        finally
        {
            sqlConn.Close();
        }

        return rowadded;
    }

    // Update Apprval Status
    public int UpdateIsToDisburce(string appno, bool IsToDisburse)
    {
        string sqlUpdate;


        sqlUpdate = @"update ApprovalStatus set IsToDisburse = @IsToDisburse where appno = @appno";

        sqlConn = new SqlConnection(constring);
        sqlCmd = new SqlCommand(sqlUpdate, sqlConn);

        sqlCmd.Parameters.AddWithValue("appno", appno);
        sqlCmd.Parameters.AddWithValue("IsToDisburse", IsToDisburse);


        int rowAdded = 0;

        try
        {
            sqlConn.Open();

            rowAdded = sqlCmd.ExecuteNonQuery();

        }

        catch (Exception err)
        {


            _errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return rowAdded;
    }

    // Update CrApp
    public int UpdateCrApp(string Status, double ApprovedAmt, string IsApproved, DateTime ApprovDate, string ApproveUser, string appno)
    {
        string sqlUpdate;


        sqlUpdate = @"UPDATE CrApp
                        SET Status=@Status, ApprovedAmt=@ApprovedAmt,
                        IsApproved=@IsApproved, ApprovDate=@ApprovDate, 
                        ApproveUser=@ApproveUser
                        WHERE appno = @appno";

        sqlConn = new SqlConnection(constring);
        sqlCmd = new SqlCommand(sqlUpdate, sqlConn);

        sqlCmd.Parameters.AddWithValue("Status", Status);
        sqlCmd.Parameters.AddWithValue("ApprovedAmt", ApprovedAmt);
        sqlCmd.Parameters.AddWithValue("IsApproved", IsApproved);
        sqlCmd.Parameters.AddWithValue("ApprovDate", ApprovDate);
        sqlCmd.Parameters.AddWithValue("ApproveUser", ApproveUser);
        sqlCmd.Parameters.AddWithValue("appno", appno);

        int rowAdded = 0;

        try
        {
            sqlConn.Open();

            rowAdded = sqlCmd.ExecuteNonQuery();

        }

        catch (Exception err)
        {


            _errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return rowAdded;
    }

    public int UpdateReverseApplicatin(string appno, string status, DateTime appdate)
    {
        string sqlUpdate;


        sqlUpdate = @"UPDATE ApprovalStatus
                        SET Status=@status, ApprovedDate=@appdate WHERE Appno = @appno";

        sqlConn = new SqlConnection(constring);
        sqlCmd = new SqlCommand(sqlUpdate, sqlConn);

        sqlCmd.Parameters.AddWithValue("status", status);
        sqlCmd.Parameters.AddWithValue("appno", appno);
        sqlCmd.Parameters.AddWithValue("appdate", appdate);

        int rowAdded = 0;

        try
        {
            sqlConn.Open();

            rowAdded = sqlCmd.ExecuteNonQuery();

        }

        catch (Exception err)
        {


            _errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return rowAdded;
    }

    public DataTable GetPreviousArreasLoanDetails(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select m.cracno,m.grantamt,m.grantdate,t.assignamt AS ArreasAmount 
                            from appholder a, crholder c, crmast m, transassign t
                            where a.appno=@appno and a.nicno=c.nicno and
                            c.cracno=m.cracno and m.cracno=t.cracno and
                            (t.trstatus='N') and t.taskid<>'DISB'");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();
    }

    public DataTable GetApprovedPersonalDetails(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select c.AppNo,upper(rtrim(initials) + ' ' + rtrim(surname)) as CustomerName,
                            upper(rtrim(location) + ' ' + rtrim(street) + ' ' + rtrim(city)) as CustomerAddress,
                            amount as LoanAmount, IntRate, cramt as TotalCrAmount,
                            crdes as LoanCategory,descrip as Purpose
                            from appcategory a, appholder h, crapp c, crcategory r,
                            crpurpose p, crcatpurpose cp, customermain m
                            where c.appno=@appno and c.appno=a.appno
                            and c.appno=h.appno and h.nicno=m.nicno 
                            and a.catpurposeid=cp.catpurposeid and cp.purposecode=p.purposecode
                            and cp.crcatcode=r.crcatcode and h.holdertype='P'");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();
    }

    public double GetApprovdAmt(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select cramt from crapp where appno=@appno");
        dw.SetSqlCommandParameters("appno", appno);
        return double.Parse(dw.GetSingleData());
    }


    public int GetCrcat(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select crcatcode from crapp where appno=@appno");
        dw.SetSqlCommandParameters("appno", appno);
        return int.Parse(dw.GetSingleData());
    }

    public int PurposeCode(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select purposecode from appcategory a, crcatpurpose c where appno=@appno
                        and c.catpurposeid=a.catpurposeid");
        dw.SetSqlCommandParameters("appno", appno);
        return int.Parse(dw.GetSingleData());
    }

    public string GetReceivedAppUser(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select adduser from crapp where appno=@appno");
        dw.SetSqlCommandParameters("appno", appno);
        return dw.GetSingleData();
    }

    public int InsertintoSpecialApproval(string AppNo, string AddUser, string ApprovedUser, 
                                         DateTime ApprovedDate, DateTime SystemDate,
                                         double Amount, string Remark)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO SpecialAppLoans (AppNo,AddUser,ApprovedUser,ApprovedDate,SystemDate,Amount,Remark)
                       values (@AppNo,@AddUser,@ApprovedUser,@ApprovedDate,@SystemDate,@Amount,@Remark)");
        dw.SetSqlCommandParameters("AppNo", AppNo);
        dw.SetSqlCommandParameters("AddUser", AddUser);
        dw.SetSqlCommandParameters("ApprovedUser", ApprovedUser);
        dw.SetSqlCommandParameters("ApprovedDate", ApprovedDate);
        dw.SetSqlCommandParameters("SystemDate", SystemDate);
        dw.SetSqlCommandParameters("Amount", Amount);
        dw.SetSqlCommandParameters("Remark", Remark);
        return dw.Insert();
    }

    public int InsertintoMiddleIncomeReg(string AppNo, string RegNo, string BranchCode,
                                        string AddUser, DateTime OperationDate,DateTime AddDate)

    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO MiddleIncomeRegDetails (AppNo,RegNo,BranchCode,AddUser,OperationDate,AddDate)
                       values (@AppNo,@RegNo,@BranchCode,@AddUser,@OperationDate,@AddDate)");
        dw.SetSqlCommandParameters("AppNo", AppNo);
        dw.SetSqlCommandParameters("RegNo", RegNo);
        dw.SetSqlCommandParameters("BranchCode", BranchCode);
        dw.SetSqlCommandParameters("AddUser", AddUser);
        dw.SetSqlCommandParameters("OperationDate", OperationDate);
        dw.SetSqlCommandParameters("AddDate", AddDate);
        return dw.Insert();
    }
    public DateTime GetReceivedDate(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select RecvDate from crapp where appno=@appno");
        dw.SetSqlCommandParameters("appno", appno);
        return DateTime.Parse(dw.GetSingleData());
    }

    public int GetCatPurposeId(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select P.purposecode from Appcategory A, CrCatPurpose P where A.AppNo=@appno
                        and A.CatPurposeId = P.catpurposeid");
        dw.SetSqlCommandParameters("appno", appno);
        return int.Parse(dw.GetSingleData());
    }

    public int GetRowCount(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select count(*) as rowdet from MiddleIncomeRegDetails where appno=@appno");
        dw.SetSqlCommandParameters("appno", appno);
        return int.Parse(dw.GetSingleData());
    }

    public int GetPaymentRowCount(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select count(*) as rowdet from ApprovalStatus where appno=@appno and IsPaymentOK=1 and ApprovedDate is NULL
                        and ApprovedUser is NULL and Status='N'");
        dw.SetSqlCommandParameters("appno", appno);
        return int.Parse(dw.GetSingleData());
    }
}