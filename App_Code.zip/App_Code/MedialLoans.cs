﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Data;
using System.Configuration;


/// <summary>
/// Summary description for MedialLoans
/// </summary>
public class MedialLoans
{
        string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();
        DataWorksClass dw;


    public System.Data.DataTable germedialoandata(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select cr.Cracno as LoanNumber ,rTrim(titledesc)+ ' ' + rTrim(c.INitials) + ' ' + rTrim(c.Surname)
                                as [Name],c.Location,c.Street,c.City,cr.GrantAmt,
                                (cr.GrantAmt/h.crperiod) as 
                                customerContribution,(cr.Instalment-(cr.GrantAmt/h.crperiod)) as 
                                GovernmentContribution,
                                cr.Instalment,cr.IntRate,
                                h.datedue as DateDue,
                                cr.GrantDate as GrantDate,DATEADD(MONTH,h.crperiod,cr.GrantDate) as 
                                ClosingDate,
                                h.crperiod from 
                                customermain c, appholder a , Crmast cr, title t,
                                housprop h
                                where c.nicno = a.nicno and a.appno = cr.appno
                                and c.titlecode=t.titlecode and cr.cracno=@cracno
                                and  cr.cracno=h.cracno and Holdertype='P' 
                                order by holdertype");
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }

    public double insertmedialoandata(string cracno, string savingsNo, string Name, double GrantAmt, double IntRate, 
        int crperiod, double Instalment, double customerContribution, double GovernmentContribution, DateTime GrantDate, 
        DateTime DateDue, DateTime ClosingDate, string branchno, string branchname, string address2)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO MediaLoans (CracNo,SavingsNo,Name,GrantAmt,IntRate,Crperiod,Instalment,CustomerContribution
			            ,GovernmentContribution,Grantdate,DateDue,ClosingDate,BranchNo,BranchName,Department)
                        VALUES (@cracno,@savingsNo,@Name,@GrantAmt,@IntRate,@crperiod,@Instalment,@customerContribution
                       ,@GovernmentContribution,@GrantDate,@DateDue,@ClosingDate,@branchno,@branchname,@Department)");
        dw.SetSqlCommandParameters("CracNo", cracno);
        dw.SetSqlCommandParameters("SavingsNo", savingsNo);
        dw.SetSqlCommandParameters("Name", Name);
        dw.SetSqlCommandParameters("GrantAmt", GrantAmt);
        dw.SetSqlCommandParameters("IntRate", IntRate);
        dw.SetSqlCommandParameters("Crperiod", crperiod);
        dw.SetSqlCommandParameters("Instalment", Instalment);
        dw.SetSqlCommandParameters("CustomerContribution", customerContribution);
        dw.SetSqlCommandParameters("GovernmentContribution", GovernmentContribution);
        dw.SetSqlCommandParameters("Grantdate", GrantDate);
        dw.SetSqlCommandParameters("DateDue", DateDue);
        dw.SetSqlCommandParameters("ClosingDate", ClosingDate);
        dw.SetSqlCommandParameters("BranchNo", branchno);
        dw.SetSqlCommandParameters("BranchName", branchname);
        dw.SetSqlCommandParameters("Department", address2);
        return double.Parse(dw.GetSingleData());
       
    }

    public DataTable getmedialoandetails(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from MediaLoans where cracno = @cracno");
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }

    public DataTable getoldmedialoandetails(DateTime fromdate1, DateTime todate1)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from MediaLoans where grantdate < @todate1 and grantdate >@fromdate1 ");
        dw.SetDataAdapterParameters("todate1", todate1);
        dw.SetDataAdapterParameters("fromdate1", fromdate1);
        return dw.GetDataTable();
    }
}
