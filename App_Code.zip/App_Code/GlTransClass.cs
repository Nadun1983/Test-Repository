﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Data;
using System.Configuration;

/// <summary>
/// Summary description for GlTransClass
/// </summary>
public class GlTransClass
{
    private string constring = ConfigurationManager.ConnectionStrings["housdbString"].ToString();
    DataWorksClass dw;
    LastSerialClass ls;
    FunctionClass fc;
	
    public GlTransClass()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public DataTable GetGlCodes()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from glcode");
        return dw.GetDataTable();
    }

    public DataTable GetGlCodes(string glcode)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from glcode where refglcode=@glcode");
        dw.SetDataAdapterParameters("glcode",glcode);
        return dw.GetDataTable();
    }

    
}
