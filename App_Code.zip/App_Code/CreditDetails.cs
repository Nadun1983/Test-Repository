﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

/// <summary>
/// Summary description for CreditDetails
/// </summary>
public class CreditDetails
{

    DataWorksClass dw;
    DataTable dt;

    string Branchconstring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();

	public CreditDetails()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public DataTable GetCategory()
    {
        dw = new DataWorksClass(Branchconstring);
        dw.SetDataAdapter(@"select crcatcode,crdes from crcategory");
        return dw.GetDataTable();
    }

    //2012-01-25 Nikeshana
    public DataTable GetPurpose()
    {
        dw = new DataWorksClass(Branchconstring);
        dw.SetDataAdapter(@"select purposecode,descrip from crpurpose");
        return dw.GetDataTable();
    }

    //2012-01-25 Nikeshana
    public DataTable GetIntRates()
    {
        dw = new DataWorksClass(Branchconstring);
        dw.SetDataAdapter(@"select distinct intrate from interestcode order by intrate");
        return dw.GetDataTable();
    }

    public DataTable GetMISDetails(DateTime fromDate, DateTime toDate, int crcatcode, int purposecode, double Intrate)
    {
        dw = new DataWorksClass(Branchconstring);
        dt = new DataTable();

        if ((crcatcode == 0) && (purposecode == 0) && (Intrate == 0))
            dw.SetDataAdapter(@"select c.Cracno,h.instalment,cm.nicno,rtrim(t.titledesc+cm.initials+cm.surname) as CustName,cm.location,cm.street,cm.city,
                                c.Intrate,c.Aprovdamt,c.Grantamt,convert(varchar, c.GrantDate, 111) as GrantDate,h.ActOutBal,h.crPeriod as Period
                                from crmast c, Housprop h,crholder cr, customermain cm,title t
                                where cm.titlecode=t.titlecode and c.cracno=h.cracno and cr.cracno=c.cracno and c.catpurposeid in 
                                (select catpurposeid from crcatpurpose) 
                                and cm.nicno=cr.nicno and c.grantdate>=@fromDate and c.grantdate<=@toDate
                                and cr.holdertype='P' order by c.GrantDate");

        else if ((crcatcode == 0) && (purposecode == 0))
            dw.SetDataAdapter(@"select c.Cracno,h.instalment,cm.nicno,rtrim(t.titledesc+cm.initials+cm.surname) as CustName,cm.location,cm.street,cm.city,
                                c.Intrate,c.Aprovdamt,c.Grantamt,convert(varchar, c.GrantDate, 111) as GrantDate,h.ActOutBal,h.crPeriod as Period
                                from crmast c, Housprop h,crholder cr, customermain cm,title t
                                where cm.titlecode=t.titlecode and c.cracno=h.cracno and cr.cracno=c.cracno and c.catpurposeid in 
                                (select catpurposeid from crcatpurpose) 
                                and cm.nicno=cr.nicno and c.intrate=@Intrate and 
                                c.grantdate>=@fromDate and c.grantdate<=@toDate 
                                and cr.holdertype='P' order by c.GrantDate");

        else if ((crcatcode == 0) && (Intrate == 0))
            dw.SetDataAdapter(@"select c.Cracno,h.instalment,cm.nicno,rtrim(t.titledesc+cm.initials+cm.surname) as CustName,cm.location,cm.street,cm.city,
                                c.Intrate,c.Aprovdamt,c.Grantamt,convert(varchar, c.GrantDate, 111) as GrantDate,h.ActOutBal,h.crPeriod as Period
                                from crmast c, Housprop h,crholder cr, customermain cm,title t
                                where cm.titlecode=t.titlecode and c.cracno=h.cracno and cr.cracno=c.cracno and c.catpurposeid in 
                                (select catpurposeid from crcatpurpose where purposecode=@purposecode) 
                                and cm.nicno=cr.nicno and c.grantdate>=@fromDate and c.grantdate<=@toDate 
                                and cr.holdertype='P' order by c.GrantDate");

        else if ((purposecode == 0) && (Intrate == 0))
            dw.SetDataAdapter(@"select c.Cracno,h.instalment,cm.nicno,rtrim(t.titledesc+cm.initials+cm.surname) as CustName,cm.location,cm.street,cm.city,
                                c.Intrate,c.Aprovdamt,c.Grantamt,convert(varchar, c.GrantDate, 111) as GrantDate,h.ActOutBal,h.crPeriod as Period
                                from crmast c, Housprop h,crholder cr, customermain cm,title t
                                where cm.titlecode=t.titlecode and c.cracno=h.cracno and cr.cracno=c.cracno and c.catpurposeid in 
                                (select catpurposeid from crcatpurpose where crcatcode=@crcatcode) 
                                and cm.nicno=cr.nicno and c.grantdate>=@fromDate and c.grantdate<=@toDate
                                and cr.holdertype='P' order by c.GrantDate");

        else if (crcatcode == 0)
            dw.SetDataAdapter(@"select c.Cracno,h.instalment,cm.nicno,rtrim(t.titledesc+cm.initials+cm.surname) as CustName,cm.location,cm.street,cm.city,
                                c.Intrate,c.Aprovdamt,c.Grantamt,convert(varchar, c.GrantDate, 111) as GrantDate,h.ActOutBal,h.crPeriod as Period
                                from crmast c, Housprop h,crholder cr, customermain cm,title t
                                where cm.titlecode=t.titlecode and c.cracno=h.cracno and cr.cracno=c.cracno and c.catpurposeid in 
                                (select catpurposeid from crcatpurpose where purposecode=@purposecode) 
                                and cm.nicno=cr.nicno and c.intrate=@Intrate and 
                                c.grantdate>=@fromDate and c.grantdate<=@toDate
                                and cr.holdertype='P' order by c.GrantDate");

        else if (purposecode == 0)
            dw.SetDataAdapter(@"select c.Cracno,h.instalment,cm.nicno,rtrim(t.titledesc+cm.initials+cm.surname) as CustName,cm.location,cm.street,cm.city,
                                c.Intrate,c.Aprovdamt,c.Grantamt,convert(varchar, c.GrantDate, 111) as GrantDate,h.ActOutBal,h.crPeriod as Period
                                from crmast c, Housprop h,crholder cr, customermain cm,title t
                                where cm.titlecode=t.titlecode and c.cracno=h.cracno and cr.cracno=c.cracno and c.catpurposeid in 
                                (select catpurposeid from crcatpurpose where crcatcode=@crcatcode) 
                                and cm.nicno=cr.nicno and c.intrate=@Intrate and 
                                c.grantdate>=@fromDate and c.grantdate<=@toDate
                                and cr.holdertype='P' order by c.GrantDate");


        else if (Intrate == 0)
            dw.SetDataAdapter(@"select c.Cracno,h.instalment,cm.nicno,rtrim(t.titledesc+cm.initials+cm.surname) as CustName,cm.location,cm.street,cm.city,
                                c.Intrate,c.Aprovdamt,c.Grantamt,convert(varchar, c.GrantDate, 111) as GrantDate,h.ActOutBal,h.crPeriod as Period
                                from crmast c, Housprop h,crholder cr, customermain cm,title t
                                where cm.titlecode=t.titlecode and c.cracno=h.cracno and cr.cracno=c.cracno and c.catpurposeid in 
                                (select catpurposeid from crcatpurpose where purposecode=@purposecode and crcatcode=@crcatcode) 
                                and cm.nicno=cr.nicno and c.grantdate>=@fromDate and c.grantdate<=@toDate
                                and cr.holdertype='P' order by c.GrantDate");

        else
            dw.SetDataAdapter(@"select c.Cracno,h.instalment,cm.nicno,rtrim(t.titledesc+cm.initials+cm.surname) as CustName,cm.location,cm.street,cm.city,
                                c.Intrate,c.Aprovdamt,c.Grantamt,convert(varchar, c.GrantDate, 111) as GrantDate,h.ActOutBal,h.crPeriod as Period
                                from crmast c, Housprop h,crholder cr, customermain cm,title t
                                where cm.titlecode=t.titlecode and c.cracno=h.cracno and cr.cracno=c.cracno and c.catpurposeid in 
                                (select catpurposeid from crcatpurpose where purposecode=@purposecode and crcatcode=@crcatcode) 
                                and cm.nicno=cr.nicno and c.intrate=@Intrate and 
                                c.grantdate>=@fromDate and c.grantdate<=@toDate
                                and cr.holdertype='P' order by c.GrantDate");

        dw.SetDataAdapterParameters("crcatcode", crcatcode);
        dw.SetDataAdapterParameters("purposecode", purposecode);
        dw.SetDataAdapterParameters("Intrate", Intrate);
        dw.SetDataAdapterParameters("fromDate", fromDate);
        dw.SetDataAdapterParameters("toDate", toDate);
        return dw.GetDataTable();

    }
}
