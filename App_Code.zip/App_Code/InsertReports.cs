using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// Summary description for InsertReptors
/// </summary>
public class InsertReports
{
    int recordCount;
    DataWorksClass dw;
    DataTable dt;
    static DataTable dailyproof;
    Recovery rc;
    LastSerialClass lsc;
    CrTransClass ctc;
    PrintClass p;
    FunctionClass fc;
    RecoveryProcesClass rpc;
    static DataTable disbSummery;
    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();
    string oldconstring = ConfigurationManager.ConnectionStrings["TestOld"].ConnectionString.ToString();
    string reportconstring = ConfigurationManager.ConnectionStrings["reporTString"].ConnectionString.ToString();
    public InsertReports()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    //public static void BulkTableInsert(DataSet objDS,
    //                         SqlConnection objCon, string tablename)
    //{
    //    //Change the column mapping first.

    //    System.Text.StringBuilder sb = new System.Text.StringBuilder(1000);
    //    System.IO.StringWriter sw = new System.IO.StringWriter(sb);
    //    foreach (DataColumn col in objDS.Tables[tablename].Columns)
    //    {
    //        col.ColumnMapping = System.Data.MappingType.Attribute;
    //    }
    //    objDS.WriteXml(sw, System.Data.XmlWriteMode.WriteSchema);
    //    string sqlText = buildBulkUpdateSql(sb.ToString(), objDS.Tables[tablename]);
    //    execSql(objCon, sqlText);

    //}


    //static string buildBulkUpdateSql(string dataXml, DataTable table)
    //{
    //    System.Text.StringBuilder sb = new System.Text.StringBuilder();
    //    dataXml = dataXml.Replace(Environment.NewLine, "");
    //    dataXml = dataXml.Replace("\"", "''");
    //    //init the xml doc

    //    sb.Append(" SET NOCOUNT ON");
    //    sb.Append(" DECLARE @hDoc INT");
    //    sb.AppendFormat(" EXEC sp_xml_preparedocument @hDoc OUTPUT, '{0}'", dataXml);
    //    //This code deletes old data based on PK.

    //    sb.AppendFormat(" DELETE {0} FROM {0} INNER JOIN ", table.TableName);
    //    sb.AppendFormat(" (SELECT * FROM OPENXML (@hdoc, '/NewDataSet/{0}', 1)",
    //    table.TableName);
    //    sb.AppendFormat(" WITH {0}) xmltable ON 1 = 1", table.TableName);
    //    foreach (DataColumn col in table.PrimaryKey)
    //    {
    //        sb.AppendFormat(" AND {0}.{1} = xmltable.{1}", table.TableName,
    //        col.ColumnName);
    //    }
    //    //This code inserts new data.

    //    sb.AppendFormat(" INSERT INTO {0} SELECT *", table.TableName);
    //    sb.AppendFormat(" FROM OPENXML (@hdoc, '/NewDataSet/{0}', 1) WITH {0}",
    //    table.TableName);
    //    //clear the xml doc

    //    sb.Append(" EXEC sp_xml_removedocument @hDoc");
    //    return sb.ToString();
    //}

    //static void execSql(SqlConnection objCon, string sqlText)
    //{
    //    SqlCommand objCom = new SqlCommand();
    //    objCom.Connection = objCon;
    //    objCom.CommandType = CommandType.Text;
    //    objCom.CommandText = sqlText;
    //    objCom.ExecuteNonQuery();
    //}



   
    // Bimali - edit 21/07/2009 
    //vihanga 2009-07-27
    private DataTable GetTransactions(DateTime date, string transref1, string transref2, string transref3)
    {
        dw = new DataWorksClass(constring);
        
        //dw.SetDataAdapter(@"select distinct transno from crtransjrnl where trdate=@trdate and TrStatus='A'");       

        dw.SetDataAdapter(@" select distinct g.transno, t.cracno as cracno,t.transref from transassign t, gltrans g
                            where t.refno=g.transassignrefno and g.trstatus<>'C' and g.trdate=@trdate
                            and (t.transref=@transref1 or t.transref=@transref2 or t.transref=@transref3) 
                            order by g.transno,t.cracno");   
               
        dw.SetDataAdapterParameters("trdate", date);
        dw.SetDataAdapterParameters("transref1", transref1);
        dw.SetDataAdapterParameters("transref2", transref2);
        dw.SetDataAdapterParameters("transref3", transref3);
        return dw.GetDataTable();
    }

    private DataTable GetTransactionsForDisbursement(DateTime date, string transref)
    {
        dw = new DataWorksClass(constring);

        //dw.SetDataAdapter(@"select distinct transno from crtransjrnl where trdate=@trdate and TrStatus='A'");       

        dw.SetDataAdapter(@" select distinct t.transno from transassign t where 
			t.transno in (select distinct transno from gltrans where trdate=@trdate and TrStatus<>'C') and
			t.transref=@transref");

        dw.SetDataAdapterParameters("trdate", date);
        dw.SetDataAdapterParameters("transref", transref);
        return dw.GetDataTable();
    }


    //// Bimali
    //public void GetDailyProof(DateTime date)
    //{
    //    fc = new FunctionClass();
    //    DataTable transT = new DataTable();
    //    transT = GetTransactions(date);
    //    foreach (DataRow dr in transT.Rows)
    //    {
    //        string transno = dr["transno"].ToString();
    //        InsertDailyProof(transno, fc.GetStringDate(date));
    //    }
    //}



    // Bimali
    //vihanga 2009-07-27
    public void GetDailyProof(DateTime date, string transref1, string transref2, string transref3)
    {
        dt = new DataTable();
        fc = new FunctionClass();
        dt = GetTransactions(date, transref1, transref2, transref3);

        foreach (DataRow dr in dt.Rows)
        {
            string transno = dr["transno"].ToString();
            string cracno = dr["cracno"].ToString();
            string transref = dr["transref"].ToString();
            GetDailyProofData(transno, date, cracno, transref);
        }

        //dw = new DataWorksClass(reportconstring);
        //dw.SetCommand();
        //dw.InsertBulk(dailyproof, "DailyProofSheetReportRecovery");
    }

    // Bimali
    private void GetDailyProofData(string transno, DateTime trdate, string cracno, string transref)
    {
        dailyproof = new DataTable();
        dailyproof = AddColumsToDailyProofSheet(dailyproof);
        DataRow rowDescription;
        rowDescription = dailyproof.NewRow();

        fc = new FunctionClass();

         double instalment = 0, penal = 0, capital = 0, interest = 0, intrate = 0, outbal = 0,
            tramt = 0, othercut = 0, totcap = 0;

        string BranchCode = "0308", TransNo, CrDes, acsign, TrDetail;  //change this to int
        double totAmt = 0;
        int CrCatcode;
        DateTime datedue;

        DateTime duedate = new DateTime();
        DateTime nextduedate = new DateTime();
        dt = new DataTable();
        
        TrDetail = GetBatchTempDescriptions(cracno, transno);
        switch (transref)
        {
            case "RECV":
                dt = GetTransactions(transno, cracno, trdate);
                break;

            case "OTHR":

                if (cracno.Substring(0, 1) == "6")
                {

                    dt = GetTransactions(transno, cracno, trdate);
                }
                if (cracno.Substring(0, 1) == "9")
                {
                    dt = GetDirectGLTransactions(transno, cracno, trdate);
                }
                break;

            case "DISB":
                if (cracno.Substring(0, 1) == "6")
                {
                    dt = GetTransactions(transno, cracno, trdate);
                }
                break;
        }

        //BranchCode = Session["brcode"].ToString();
        if (dt.Rows.Count > 0)
        {
            //TransNo = dt.Rows[0]["transno"].ToString();
            CrCatcode = int.Parse(dt.Rows[0]["CrCat"].ToString());
            CrDes = dt.Rows[0]["CrDes"].ToString();
            
            //cracno = dt.Rows[0]["cracno"].ToString();
            instalment = double.Parse(dt.Rows[0]["instalment"].ToString());
            intrate = double.Parse(dt.Rows[0]["intrate"].ToString());
            outbal = double.Parse(dt.Rows[0]["outbal"].ToString());
            try
            {
                nextduedate = DateTime.Parse(dt.Rows[0]["Nextdatedue"].ToString());
                datedue = DateTime.Parse(dt.Rows[0]["datedue"].ToString());
            }
            catch
            {
                datedue = DateTime.Parse("01/01/1900");
                nextduedate = DateTime.Parse("01/01/1900");
            }
           
            //nextduedate 


            foreach (DataRow dr in dt.Rows)
            {
                string taskid = dr["taskid"].ToString();
                acsign = dr["acsign"].ToString();
                tramt = double.Parse(dr["tramt"].ToString());
                if (acsign == "CR")
                {
                    switch (taskid)
                    {
                        case "PNLR":
                            penal += tramt;
                            break;

                        case "INTR":
                            interest += tramt;
                            break;

                        case "CAPD":
                            capital += tramt;
                            break;

                        case "PSOC900000":
                            othercut += tramt;
                            break;

                        default:
                            othercut += tramt;
                            break;
                    }
                    totAmt += tramt;
                }
                else
                {
                    switch (taskid)
                    {
                        case "PNLR":
                            penal -= tramt;
                            break;

                        case "INTR":
                            interest -= tramt;
                            break;

                        case "CAPD":
                            capital -= tramt;
                            break;

                        case "PSOC900000":
                            othercut -= tramt;
                            break;
                        default:
                            othercut -= tramt;
                            break;
                    }
                    totAmt -= tramt;
                }

            }
            totAmt = Math.Round(totAmt, 2);
            interest = Math.Round(interest, 2);
            penal = Math.Round(penal, 2);
            capital = Math.Round(capital, 2);
            string datekey = fc.GetDateKeyinDate(trdate).ToString();

            InsertRecoveryDFailyProofSheet(datekey, "01", 308, transno, cracno, instalment, intrate,
                                           datedue, outbal, totAmt, penal, interest, capital, othercut, nextduedate, 0, CrCatcode, CrDes,TrDetail);
        }
    }

    private string GetBatchTempDescriptions(string cracno, string transno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select TrDetail from batchtmp where cracno=@cracno and transno=@transno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("transno", transno);
        return dw.GetSingleData();
    }

    private DataTable AddColumsToDailyProofSheet(DataTable dt)
    {
        // Create Description
        DataColumn CurrentDate = new DataColumn();
        CurrentDate.DataType = System.Type.GetType("System.String");
        CurrentDate.ColumnName = "CurrentDate";
        CurrentDate.DefaultValue = "CurrentDate";
        dt.Columns.Add(CurrentDate);

        // Create Description
        DataColumn ReportID = new DataColumn();
        ReportID.DataType = System.Type.GetType("System.String");
        ReportID.ColumnName = "ReportID";
        ReportID.DefaultValue = "ReportID";
        dt.Columns.Add(ReportID);

        // Create Description
        DataColumn BranchCode = new DataColumn();
        BranchCode.DataType = System.Type.GetType("System.String");
        BranchCode.ColumnName = "BranchCode";
        BranchCode.DefaultValue = "BranchCode";
        dt.Columns.Add(BranchCode);

        // Create Description
        DataColumn TransNo = new DataColumn();
        TransNo.DataType = System.Type.GetType("System.String");
        TransNo.ColumnName = "TransNo";
        TransNo.DefaultValue = "TransNo";
        dt.Columns.Add(TransNo);

        // Create Description
        DataColumn CrAcNo = new DataColumn();
        CrAcNo.DataType = System.Type.GetType("System.String");
        CrAcNo.ColumnName = "CrAcNo";
        CrAcNo.DefaultValue = "CrAcNo";
        dt.Columns.Add(CrAcNo);

        // Create Description
        DataColumn Instalment = new DataColumn();
        Instalment.DataType = System.Type.GetType("System.String");
        Instalment.ColumnName = "Instalment";
        Instalment.DefaultValue = "Instalment";
        dt.Columns.Add(Instalment);

        // Create Description
        DataColumn IntRate = new DataColumn();
        IntRate.DataType = System.Type.GetType("System.String");
        IntRate.ColumnName = "IntRate";
        IntRate.DefaultValue = "IntRate";
        dt.Columns.Add(IntRate);

        // Create Description
        DataColumn DateDue = new DataColumn();
        DateDue.DataType = System.Type.GetType("System.String");
        DateDue.ColumnName = "DateDue";
        DateDue.DefaultValue = "DateDue";
        dt.Columns.Add(DateDue);

        // Create Description
        DataColumn OutBal = new DataColumn();
        OutBal.DataType = System.Type.GetType("System.String");
        OutBal.ColumnName = "OutBal";
        OutBal.DefaultValue = "OutBal";
        dt.Columns.Add(OutBal);

        // Create Description
        DataColumn TrAmt = new DataColumn();
        TrAmt.DataType = System.Type.GetType("System.String");
        TrAmt.ColumnName = "TrAmt";
        TrAmt.DefaultValue = "TrAmt";
        dt.Columns.Add(TrAmt);


        // Create Description
        DataColumn Penal = new DataColumn();
        Penal.DataType = System.Type.GetType("System.String");
        Penal.ColumnName = "Penal";
        Penal.DefaultValue = "Penal";
        dt.Columns.Add(Penal);

        // Create Description
        DataColumn Interest = new DataColumn();
        Interest.DataType = System.Type.GetType("System.String");
        Interest.ColumnName = "Interest";
        Interest.DefaultValue = "Interest";
        dt.Columns.Add(Interest);

        // Create Description
        DataColumn Capital = new DataColumn();
        Capital.DataType = System.Type.GetType("System.String");
        Capital.ColumnName = "Capital";
        Capital.DefaultValue = "Capital";
        dt.Columns.Add(Capital);


        // Create Description
        DataColumn OtherCut = new DataColumn();
        OtherCut.DataType = System.Type.GetType("System.String");
        OtherCut.ColumnName = "OtherCut";
        OtherCut.DefaultValue = "OtherCut";
        dt.Columns.Add(OtherCut);

        // Create Description
        DataColumn NextDue = new DataColumn();
        NextDue.DataType = System.Type.GetType("System.String");
        NextDue.ColumnName = "Nextdatedue";
        NextDue.DefaultValue = "Nextdatedue";
        dt.Columns.Add(NextDue);

        // Create Description
        DataColumn CurBal = new DataColumn();
        CurBal.DataType = System.Type.GetType("System.String");
        CurBal.ColumnName = "CurBal";
        CurBal.DefaultValue = "CurBal";
        dt.Columns.Add(CurBal);


        DataColumn CrCat = new DataColumn();
        CrCat.DataType = System.Type.GetType("System.String");
        CrCat.ColumnName = "CrCat";
        CurBal.DefaultValue = "CrCat";
        dt.Columns.Add(CrCat);


        DataColumn CrDes = new DataColumn();
        CrDes.DataType = System.Type.GetType("System.String");
        CrDes.ColumnName = "CrDes";
        CrDes.DefaultValue = "CrDes";
        dt.Columns.Add(CrDes);


        // Create an array for DataColumn objects.
        DataColumn[] keys = new DataColumn[1];
        keys[0] = TransNo;
        //analysis.PrimaryKey = keys;
        // Return the new DataTable.
        return dt;
    }

    // Bimali
    private DataTable GetTransactions(string transno, string cracno, DateTime trdate)
    {
       
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"SELECT DISTINCT T.CrCat AS CrCat,M.IntRate as intrate,T.TaskId,g.TransNo as transno,M.CrAcNo AS CrAcNo, g.gltransno,
                            M.Instalment,G.TrAmt As TrAmt,hp.lastcompletedduedate as datedue,
                            hp.ActOutBal as outbal,
                            h.lastcompletedduedate as Nextdatedue,C.CrDes,G.Acsign as AcSign
                            FROM TDB.CreditAdmin.CrMast M, TDB.CreditAdmin.HousProp Hp,
                            TDB.CreditAdmin.TransAssign T, TDB.CreditAdmin.GLtrans G,
                            TDB.CreditAdmin.HousProp H,TDB.CreditAdmin.CrCategory C
                            WHERE M.CrAcNo=Hp.CrAcNo AND 
                            M.CrAcNo=T.CrAcNo AND
                            T.RefNo=G.TransAssignRefNo 
                            AND M.CrAcNo=H.CrAcNo AND T.CrCat=C.CrCatCode and g.transno = @transno
                            AND T.CrACNo=@CrACNo and right(left(refglcode,8),2) <> '00' 
							and g.trdate = @trdate
                            ORDER BY M.CrACno,T.DateDue, T.Taskid desc");
        dw.SetDataAdapterParameters("transno", transno);
        dw.SetDataAdapterParameters("cracno", cracno);
        dw.SetDataAdapterParameters("trdate", trdate);
        return dw.GetDataTable();

    }

    private DataTable GetDirectGLTransactions(string transno, string cracno, DateTime trdate)
    {

        dw = new DataWorksClass(oldconstring);
        dw.SetDataAdapter(@"SELECT DISTINCT T.CrCat AS CrCat,0.0 as intrate,T.TaskId,g.TransNo as transno,T.CrAcNo AS CrAcNo,
                            0.0 as Instalment,G.TrAmt As TrAmt,'1900/01/01' as datedue,
                            0.0 as outbal,
                            '1900/01/01' as Nextdatedue,C.CrDes,G.Acsign as AcSign
                            FROM TDB.CreditAdmin.TransAssign T, TDB.CreditAdmin.GLtrans G,
                            TDB.CreditAdmin.CrCategory C
                            WHERE T.RefNo=G.TransAssignRefNo AND T.Transref='OTHR' AND g.TransNo=@transno
                            AND T.CrCat=C.CrCatCode
                            AND T.CrACNo=@cracno AND left(T.CrAcno,1)=9  and right(left(T.cracno,8),2)!= '00'
                            and g.trdate = @trdate
                            ORDER BY M.CrACno,T.DateDue, T.Taskid desc");
        dw.SetDataAdapterParameters("transno", transno);
        dw.SetDataAdapterParameters("cracno", cracno);
        dw.SetDataAdapterParameters("trdate", trdate);
        return dw.GetDataTable();

    }

    //BranchCode-000001

    private int InsertCompleteDisbursement(DateTime Date, string ReportID, int BranchCode, string CrAcNo, string Appno,
                                         DateTime GrantDate, DateTime DateDue, double GrantAmt, double Instalment)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into CompleteDisbursement (Date,ReportID,BranchCode,CrAcNo,Appno,GrantDate,DateDue,GrantAmt,Instalment)
                        values(@Date,@ReportID,@BranchCode,@CrAcNo,@Appno,@GrantDate,@DateDue,@GrantAmt,@Instalment)");
        dw.SetSqlCommandParameters("Date", Date);
        dw.SetSqlCommandParameters("ReportID", ReportID);
        dw.SetSqlCommandParameters("BranchCode", BranchCode);
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        dw.SetSqlCommandParameters("Appno", Appno);
        dw.SetSqlCommandParameters("GrantDate", GrantDate);
        dw.SetSqlCommandParameters("DateDue", DateDue);
        dw.SetSqlCommandParameters("GrantAmt", GrantAmt);
        dw.SetSqlCommandParameters("Instalment", Instalment);
        return dw.Insert();
    }

    private int InsertDailyGLTransaction(string Date, string BranchCode, string RefGlCode, string GlDesc,
                                        double OpenBal, double Debit, double Credit, double CloseBal)
    {
        dw = new DataWorksClass(reportconstring);
        dw.SetCommand(@"insert into DailyGLTransaction(Date,BranchCode,RefGlCode,GlDesc,OpenBal,Debit,Credit,CloseBal)
                        values(@Date,@BranchCode,@RefGlCode,@GlDesc,@OpenBal,@Debit,@Credit,@CloseBal)");
        dw.SetSqlCommandParameters("Date", Date);
        dw.SetSqlCommandParameters("BranchCode", BranchCode);
        dw.SetSqlCommandParameters("RefGlCode", RefGlCode);
        dw.SetSqlCommandParameters("GlDesc", GlDesc);
        dw.SetSqlCommandParameters("OpenBal", OpenBal);
        dw.SetSqlCommandParameters("Debit", Debit);
        dw.SetSqlCommandParameters("Credit", Credit);
        dw.SetSqlCommandParameters("CloseBal", CloseBal);
        return dw.Insert();
    }

    private int InsertRecoveryDFailyProofSheet(string CurrentDate, string ReportID, int BranchCode, string TransNo, string CrAcNo, double Instalment,
                                              double IntRate, DateTime DateDue, double OutBal, double TrAmt, double Penal, double Interest,
                                              double Capital, double OtherCut, DateTime NextDue, double CurBal, int CrCat, string CrDes,
                                              string TrDetail)
    {
        dw = new DataWorksClass(reportconstring);
        dw.SetCommand(@"insert into DailyProofSheetReportRecovery(CurrentDate,ReportID,BranchCode,TransNo,CrAcNo,Instalment,IntRate,
                      DateDue,OutBal,TrAmt,Penal,Interest,Capital,OtherCut,NextDue,CurBal,CrCat,CrDes,TrDetail) values
                      (@CurrentDate,@ReportID,@BranchCode,@TransNo,@CrAcNo,@Instalment,@IntRate,@DateDue,
                      @OutBal,@TrAmt,@Penal,@Interest,@Capital,@OtherCut,@NextDue,@CurBal,@CrCat,@CrDes,@TrDetail)");
        dw.SetSqlCommandParameters("CurrentDate", CurrentDate);
        dw.SetSqlCommandParameters("ReportID", ReportID);
        dw.SetSqlCommandParameters("BranchCode", BranchCode);
        dw.SetSqlCommandParameters("TransNo", TransNo);
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        dw.SetSqlCommandParameters("Instalment", Instalment);
        dw.SetSqlCommandParameters("IntRate", IntRate);
        dw.SetSqlCommandParameters("DateDue", DateDue);
        dw.SetSqlCommandParameters("OutBal", OutBal);
        dw.SetSqlCommandParameters("TrAmt", TrAmt);
        dw.SetSqlCommandParameters("Penal", Penal);
        dw.SetSqlCommandParameters("Interest", Interest);
        dw.SetSqlCommandParameters("Capital", Capital);
        dw.SetSqlCommandParameters("OtherCut", OtherCut);
        dw.SetSqlCommandParameters("NextDue", NextDue);
        dw.SetSqlCommandParameters("CurBal", CurBal);
        dw.SetSqlCommandParameters("CrCat", CrCat);
        dw.SetSqlCommandParameters("CrDes", CrDes);
        dw.SetSqlCommandParameters("TrDetail", TrDetail);
        return dw.Insert();
    }

    private int InsertDisbDailyProofCapital(DateTime Date, string ReportID, int BranchCode, int TransNo, string CrAcNo, string AppNo,
                                           double PreviousOutstanding, double Capital, double PresentOutstanding, double ErrorInBal,
                                           double ApprovedAmt, DateTime DateDue, string IsFinelRelease, int ChqNo)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into DisbDailyProofCapital(Date,ReportID,BranchCode,TransNo,CrAcNo,AppNo,PreviousOutstanding,Capital,
                        PresentOutstanding,ErrorInBal,ApprovedAmt,DateDue,IsFinelRelease,ChqNo) values(@Date,@ReportID,@BranchCode,
                        @TransNo,@CrAcNo,@AppNo,@PreviousOutstanding,@Capital,@PresentOutstanding,@ErrorInBal,@ApprovedAmt,
                        @DateDue,@IsFinelRelease,@ChqNo)");
        dw.SetSqlCommandParameters("Date", Date);
        dw.SetSqlCommandParameters("ReportID", ReportID);
        dw.SetSqlCommandParameters("BranchCode", BranchCode);
        dw.SetSqlCommandParameters("TransNo", TransNo);
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        dw.SetSqlCommandParameters("AppNo", AppNo);
        dw.SetSqlCommandParameters("PreviousOutstanding", PreviousOutstanding);
        dw.SetSqlCommandParameters("Capital", Capital);
        dw.SetSqlCommandParameters("PresentOutstanding", PresentOutstanding);
        dw.SetSqlCommandParameters("ErrorInBal", ErrorInBal);
        dw.SetSqlCommandParameters("ApprovedAmt", ApprovedAmt);
        dw.SetSqlCommandParameters("DateDue", DateDue);
        dw.SetSqlCommandParameters("IsFinelRelease", IsFinelRelease);
        dw.SetSqlCommandParameters("ChqNo", ChqNo);
        return dw.Insert();
    }

    private int InsertDisbursementSummery(string Date, string ReportID, string BranchCode, int NoofACs, string Appno, double Boc,
                                          double Interest, double Inspection, double Legal, double FireInsu,
                                          double Retain, double Penal, double Others, double Total)
    {
        dw = new DataWorksClass(reportconstring);
        dw.SetCommand(@"insert into DisbursementSummery(Date,ReportID,BranchCode,NoofACs,Appno,Boc,Interest,Inspection,Legal,
                        FireInsu,Retain,Penal,Others,Total) values(@Date,@ReportID,@BranchCode,@NoofACs,@Appno,@Boc,@Interest,
                        @Inspection,@Legal,@FireInsu,@Retain,@Penal,@Others,@Total)");
        dw.SetSqlCommandParameters("Date", Date);
        dw.SetSqlCommandParameters("ReportID", ReportID);
        dw.SetSqlCommandParameters("BranchCode", BranchCode);
        dw.SetSqlCommandParameters("NoofACs", NoofACs);
        dw.SetSqlCommandParameters("Appno", Appno);
        dw.SetSqlCommandParameters("Boc", Boc);
        dw.SetSqlCommandParameters("Interest", Interest);
        dw.SetSqlCommandParameters("Inspection", Inspection);
        dw.SetSqlCommandParameters("Legal", Legal);
        dw.SetSqlCommandParameters("FireInsu", FireInsu);
        dw.SetSqlCommandParameters("Retain", Retain);
        dw.SetSqlCommandParameters("Penal", Penal);
        dw.SetSqlCommandParameters("Others", Others);
        dw.SetSqlCommandParameters("Total", Total);
        return dw.Insert();
    }

    private int InsertReportsHeaderInfo(int ReportId, string ReportName)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into ReportsHeaderInfo(ReportId,ReportName) values(@ReportId,@ReportName)");
        dw.SetSqlCommandParameters("ReportId", ReportId);
        dw.SetSqlCommandParameters("ReportName", ReportName);
        return dw.Insert();
    }

    private int InsertTrialBalanceInfo(DateTime Date, string ReportID, int BranchCode, int NoofACs, double IntRate,
                                      double OutBal, double GrantAmt)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into TrialBalanceInfo(Date,ReportID,BranchCode,NoofACs,IntRate,OutBal,GrantAmt) 
                        values(@Date,@ReportID,@BranchCode,@NoofACs,@IntRate,@OutBal,@GrantAmt)");
        dw.SetSqlCommandParameters("Date", Date);
        dw.SetSqlCommandParameters("ReportID", ReportID);
        dw.SetSqlCommandParameters("BranchCode", BranchCode);
        dw.SetSqlCommandParameters("NoofACs", NoofACs);
        dw.SetSqlCommandParameters("IntRate", IntRate);
        dw.SetSqlCommandParameters("OutBal", OutBal);
        dw.SetSqlCommandParameters("GrantAmt", GrantAmt);
        return dw.Insert();
    }

    private double GetGlAmountCredit(string refglcode, string date, string branchcode)
    {
        dw = new DataWorksClass(reportconstring);
        dw.SetCommand(@"select Credit from DailyGLTransaction where branchcode = @branchcode and 
                        date=@date and refglcode=@refglcode");
        dw.SetSqlCommandParameters("branchcode", branchcode);
        dw.SetSqlCommandParameters("date", date);
        dw.SetSqlCommandParameters("refglcode", refglcode);
        return double.Parse(dw.GetSingleData());
    }

    private double GetGlAmountDebit(string refglcode, string date, string branchcode)
    {
        dw = new DataWorksClass(reportconstring);
        dw.SetCommand(@"select Debit from DailyGLTransaction where branchcode = @branchcode and 
                        date=@date and refglcode=@refglcode");
        dw.SetSqlCommandParameters("branchcode", branchcode);
        dw.SetSqlCommandParameters("date", date);
        dw.SetSqlCommandParameters("refglcode", refglcode);
        return double.Parse(dw.GetSingleData());
    }

        private double GetGlBal(string date, string branchcode)
    {
        dw = new DataWorksClass(reportconstring);
        dw.SetCommand(@"select sum(openbal + credit - debit - closebal) as glbal  
                        from DailyGLTransaction where branchcode = @branchcode and 
                        date=@date");
        dw.SetSqlCommandParameters("branchcode", branchcode);
        dw.SetSqlCommandParameters("date", date);
        return double.Parse(dw.GetSingleData());
    }

    private int UpdateGLTransactionCredits(string refglcode, string date, string branchcode, double amount)
    {
        dw = new DataWorksClass(reportconstring);
        dw.SetCommand(@"update DailyGLTransaction set credit = @Credit where branchcode = @branchcode and 
                        date=@date and refglcode=@refglcode");
        dw.SetSqlCommandParameters("Credit", amount);
        dw.SetSqlCommandParameters("branchcode", branchcode);
                dw.SetSqlCommandParameters("date", date);
                dw.SetSqlCommandParameters("refglcode", refglcode);

        return dw.Update();
    }

     private int UpdateGLTransactionDebit(string refglcode, string date, string branchcode, double amount)
    {
        dw = new DataWorksClass(reportconstring);
        dw.SetCommand(@"update DailyGLTransaction set Debit = @Debit where branchcode = @branchcode and 
                        date=@date and refglcode=@refglcode");
        dw.SetSqlCommandParameters("Debit", amount);
        dw.SetSqlCommandParameters("branchcode", branchcode);
                dw.SetSqlCommandParameters("date", date);
                dw.SetSqlCommandParameters("refglcode", refglcode);

        return dw.Update();
    }

    //public string GetGLTransactionSummery(string branchcode, string date)
    //{
    //    string status;
    //    dt = new DataTable();
    //    dt = GetUpdatedGLRecords(branchcode,date);
    //    //dw = new DataWorksClass(reportconstring);
    //    //dw.InsertBulk(dt, "DailyGLTransaction"); 

    //    dt = GetGLTransaction(branchcode, date);
    //    fc = new FunctionClass();
    //    DateTime trdate = fc.GetDateinDateKey(date);
    //    dt = GetGLTransData(trdate);
    //    int noofrec = dt.Rows.Count;
    //    foreach (DataRow dr in dt.Rows)
    //    {
    //        string accsign = dr["acsign"].ToString();
    //        string refglcode = dr["refglcode"].ToString();
    //        double tramt = double.Parse(dr["tramt"].ToString());
    //        switch (accsign)
    //        {
    //            case "CR":
    //                tramt += GetGlAmountCredit(refglcode, date, branchcode);
    //                UpdateGLTransactionCredits(refglcode, date, branchcode, tramt);
    //                break;
    //            case "DR":
    //                tramt += GetGlAmountDebit(refglcode, date, branchcode);
    //                UpdateGLTransactionDebit(refglcode, date, branchcode, tramt);
    //                break;
    //        }
    //    }


    //    if (GetGlBal(date, branchcode) == 0)
    //    {
    //        if (noofrec == UpdateSystemAudit(trdate, true))
    //        {
    //            status = "OK";
    //        }
    //        else
    //        {
    //            status = "";
    //        }
    //    }
    //    else
    //    {
    //        UpdateSystemAudit(trdate, false);
    //        status = "";
    //    }

    //    return status;
        
    //}

    private int UpdateSystemAudit(DateTime trdate, bool SystemAudit)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update gltrans set SystemAudit=@SystemAudit where TrDate=@TrDate");
        dw.SetSqlCommandParameters("SystemAudit", SystemAudit);
        dw.SetSqlCommandParameters("TrDate", trdate);
        return dw.Update();
    }

    private DataTable GetUpdatedGLRecords(string branchcode, string date)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select refglcode, glcode, gldesc, cast(lastcurbal as decimal(18,2)) as OpenBal, 
                            cast(curbal as decimal(18,2)) as CloseBal, @BranchCode as BranchCode, @Date as Date, 
                            @Credit as Credit, @Debit as Debit 
                            from glcode");
        dw.SetDataAdapterParameters("BranchCode",branchcode);
        dw.SetDataAdapterParameters("Date", date);
        dw.SetDataAdapterParameters("Credit", "0");
        dw.SetDataAdapterParameters("Debit", "0");
        return dw.GetDataTable();
    }

    private DataTable GetGLTransData(DateTime trdate)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from gltrans where trdate = @trdate");
        dw.SetDataAdapterParameters("trdate", trdate);
        return dw.GetDataTable();
    }

    public void GetGlAbstact(string startdate, string enddate)
    {
        double tramt;
        dt = new DataTable();
        dt = GetGLAbstractRecords(startdate);
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            double openingbal = double.Parse(dt.Rows[i]["curbal"].ToString());
            string refglcode = dt.Rows[i]["refglcode"].ToString();
            string glcode = dt.Rows[i]["glcode"].ToString();
            string gldesc = dt.Rows[i]["gldesc"].ToString();
            
            tramt = GetSumTransactions(refglcode, enddate, "CR");
            openingbal += tramt;
            tramt = GetSumTransactions(refglcode, enddate, "DR");
            openingbal -= tramt;
            InsertGLAbstract(DateKey(enddate), refglcode, glcode, gldesc, openingbal);
            InsertGLAbstractT(DateKey(enddate), refglcode, glcode, gldesc, openingbal);
        }
    }

    private string DateKey(string date)
    {
        return date.Substring(4, 4) + date.Substring(2, 2) + date.Substring(0, 2);
    }

    private void InsertGLAbstract(string OperationDate, string RefGlCode, string GlCode, string GlDesc, double CurBal)
    {
        dw = new DataWorksClass(reportconstring);
        dw.SetCommand(@"INSERT INTO GLAbstract (OperationDate,RefGlCode,GlCode,GlDesc,CurBal)
                        VALUES (@OperationDate,@RefGlCode,@GlCode, @GlDesc,@CurBal)");
        dw.SetSqlCommandParameters("OperationDate", OperationDate);
        dw.SetSqlCommandParameters("RefGlCode", RefGlCode);
        dw.SetSqlCommandParameters("GlCode", GlCode);
        dw.SetSqlCommandParameters("GlDesc", GlDesc);
        dw.SetSqlCommandParameters("CurBal", CurBal);
        dw.Insert();
    }

    private void InsertGLAbstractT(string OperationDate, string RefGlCode, string GlCode, string GlDesc, double CurBal)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO GLAbstract (OperationDate,RefGlCode,GlCode,GlDesc,CurBal)
                        VALUES (@OperationDate,@RefGlCode,@GlCode, @GlDesc,@CurBal)");
        dw.SetSqlCommandParameters("OperationDate", OperationDate);
        dw.SetSqlCommandParameters("RefGlCode", RefGlCode);
        dw.SetSqlCommandParameters("GlCode", GlCode);
        dw.SetSqlCommandParameters("GlDesc", GlDesc);
        dw.SetSqlCommandParameters("CurBal", CurBal);
        dw.Insert();
    }

    private double GetSumTransactions(string refglcode, string enddate, string acsign)
    {
        fc = new FunctionClass();
        DateTime trdate = fc.GetDateinDateKey(enddate);
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select isnull(sum(tramt),0) as tramt from gltrans where trdate = @trdate and 
                        refglcode = @refglcode and acsign = @acsign and trstatus !='C'");
        dw.SetSqlCommandParameters("trdate", trdate);
        dw.SetSqlCommandParameters("refglcode", refglcode);
        dw.SetSqlCommandParameters("acsign", acsign);
        return double.Parse(dw.GetSingleData());
    }
    //2009-03-12 vihanga
    public void GetGLAbstract(string branchcode, string OperationDate)
    {
        dt = new DataTable();
        dt = GetGLAbstractRecords(branchcode, OperationDate);
        dw = new DataWorksClass(reportconstring);
        dw.InsertBulk(dt, "GLAbstract");
    }
    
    //2009-03-12 vihanga
    private DataTable GetGLAbstractRecords(string BranchCode, string OperationDate)
    {
        dw = new DataWorksClass(oldconstring);
        dw.SetDataAdapter(@"select @OperationDate as OperationDate, RefGlCode , GlCode,GlDesc, 
                            curbal  from glcode where right(left(refglcode, 5),4) =  @BranchCode");
        dw.SetDataAdapterParameters("BranchCode", BranchCode);
        dw.SetDataAdapterParameters("OperationDate", OperationDate);
        return dw.GetDataTable();
    }

    private DataTable GetGLAbstractRecords(string OperationDate)
    {
        dw = new DataWorksClass(reportconstring);
        dw.SetDataAdapter(@"select RefGlCode, curbal, glcode, gldesc  from 
                            GLAbstract1 where OperationDate=@OperationDate");
        dw.SetDataAdapterParameters("OperationDate", OperationDate);
        return dw.GetDataTable();
    }

    //2009-03-12 vihanga
    public void GetTrialBalanceCheck()
    {
        int Branchcode = 308;
        dt = new DataTable();
        dt = GetTrialBalanceCheckRecords(Branchcode);
        dw = new DataWorksClass(reportconstring);
        dw.InsertBulk(dt, "TrialBalanceInfo");
    }
    //2009-03-12 vihanga
    private DataTable GetTrialBalanceCheckRecords(int BranchCode)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select year(getdate()) as Systemdate,@BranchCode as BranchCode ,
                            l.Description , count(c.cracno) as NoOfLoans ,c.intrate , sum(c.aprovdamt) as ApprovedAmt , 
                            sum(c.grantamt) as GrantAmt from crmast c, CrCategory l
                            where c.crcat=l.CrCatCode and substring(cast(c.cracno as nvarchar(20)),3,3) = @BranchCode 
                            group by c.intrate , l.Description");
        dw.SetDataAdapterParameters("BranchCode", BranchCode);
        return dw.GetDataTable();
    }  

    private void InsertDisbursementSummeryDetails(string transno, DateTime date)
    {
        fc = new FunctionClass();
        string cracno = "0";
        decimal tramt = 0, BOC = 0, Interest = 0, Inspecsion = 0, Legal = 0, FireInsu = 0, Retain = 0, Penal = 0, Others = 0;
        dt = GetTrAmt(transno);
        decimal totAmt = 0;
        foreach (DataRow dr in dt.Rows)
        {
            string taskid = dr["taskid"].ToString();
            tramt = decimal.Parse(dr["tramt"].ToString());
            switch (taskid)
            {

                case "BOCA":
                    BOC += tramt;
                    break;

                case "INTR":
                    Interest += tramt;
                    break;

                case "INSN":
                    Inspecsion += tramt;
                    break;

                case "INSE":
                    Inspecsion += tramt;
                    break;

                case "LCHN":
                    Legal += tramt;
                    break;

                case "LCHE":
                    Legal += tramt;
                    break;

                case "LCCN":
                    Legal += tramt;
                    break;

                case "LCCE":
                    Legal += tramt;
                    break;

                case "FJSE":
                    FireInsu += tramt;
                    break;

                case "FSLE":
                    FireInsu += tramt;
                    break;

                case "FCEE":
                    FireInsu += tramt;
                    break;

                case "FUAE":
                    FireInsu += tramt;
                    break;

                case "FEIE":
                    FireInsu += tramt;
                    break;

                case "RTAI":
                    Retain += tramt;
                    break;

                case "PNLR":
                    Penal += tramt;
                    break;

                default:
                    Others += tramt;
                    break;

            }

            transno = dr["transno"].ToString();
            cracno = dr["cracno"].ToString();
            totAmt += tramt;

        }

        //fc.GetStrDate(date);

        //string a = fc.GetStrDate(date);
        //fc.GetShortDate(date);

        //InsertDisbursementSummery(fc.GetStringDate(date), "01", "0308", 01, cracno, BOC, Interest, Inspecsion,
                //Legal, FireInsu, Retain, Penal, Others, totAmt);


    }

    public DataTable LoadReportDetails()
    {
        dw = new DataWorksClass(reportconstring);
        dw.SetDataAdapter(@"select * from reportsheaderinfo where ReportStatus='A' order by reportid");
        return dw.GetDataTable();
    }

    public DataTable LoadMonthlyReportDetails()
    {
        dw = new DataWorksClass(reportconstring);
        dw.SetDataAdapter(@"select * from ReportsHeaderInfoForMothly where Status='A'");
        return dw.GetDataTable();
    }

    //edit bimali 06/05/2009
    //vihanga 2009-07-27
    public void GetDailyDusburseSummary(DateTime date)
    {
        dt = new DataTable();
        fc = new FunctionClass();
        string transno;
        
        //vihanga 2009-07-27
        dt = GetTransactionsForDisbursement(date, "DISB");
        disbSummery = new DataTable();
        disbSummery = AddColumsToDailyDisbSummery(disbSummery);
        foreach (DataRow dr in dt.Rows)
        {
            transno = dr["transno"].ToString();
            GetDisbursementSummeryDetails(transno, fc.GetDateKeyinDate(date).ToString());
        }

        dw = new DataWorksClass(reportconstring);
        dw.SetCommand();
        dw.InsertBulk(disbSummery, "DisbursementSummery");
    }

    //edit bimali 06/05/2009
    private void GetDisbursementSummeryDetails(string transno, string date)
    {
        fc = new FunctionClass();
        
        string cracno = "0";
        decimal tramt = 0, BOC = 0, title = 0, Interest = 0, Inspecsion = 0, Legal = 0, FireInsu = 0, Retain = 0, Penal = 0, Others = 0;
        dt = GetTrAmt(transno);
        decimal totAmt = 0;
        foreach (DataRow dr in dt.Rows)
        {
            string taskid = dr["taskid"].ToString();
            tramt = decimal.Parse(dr["tramt"].ToString());
            switch (taskid)
            {
                case "CAPD":
                    totAmt += tramt;
                    BOC += tramt;
                    break;

               case "INTR":
                    Interest += tramt;
                    BOC -= tramt;
                    break;

                case "INSN900000":
                    Inspecsion += tramt;
                    BOC -= tramt;
                    break;

                case "INSE900000":
                    Inspecsion += tramt;
                    BOC -= tramt;
                    break;


                case "INSD900000":
                    Inspecsion += tramt;
                    BOC -= tramt;
                    break;
                case "LCHN":
                    Legal += tramt;
                    BOC -= tramt;
                    break;

                case "LCHN900000":
                    Legal += tramt;
                    BOC -= tramt;
                    break;

                case "LCHE900000":
                    Legal += tramt;
                    BOC -= tramt;
                    break;

                case "LCHD900000":
                    Legal += tramt;
                    BOC -= tramt;
                    break;

                case "LCCN":
                    Legal += tramt;
                    BOC -= tramt;
                    break;

                case "LCCE":
                    Legal += tramt;
                    BOC -= tramt;
                    break;

                case "FSLD900000":
                    FireInsu += tramt;
                    BOC -= tramt;
                    break;

                case "FJSD900000":
                    FireInsu += tramt;
                    BOC -= tramt;
                    break;

                case "FUAD900000":
                    FireInsu += tramt;
                    BOC -= tramt;
                    break;

                case "FCED900000":
                    FireInsu += tramt;
                    BOC -= tramt;
                    break;

                case "FEID900000":
                    FireInsu += tramt;
                    BOC -= tramt;
                    break;

                case "RTAI900000":
                    Retain += tramt;
                    BOC -= tramt;
                    break;

                case "TCEE900000":
                    title += tramt;
                    BOC -= tramt;
                    break;

                case "TCEN900000":
                    title += tramt;
                    BOC -= tramt;
                    break;
                case "TEIE900000":
                    title += tramt;
                    BOC -= tramt;
                    break;
                case "TEIN900000":
                    title += tramt;
                    BOC -= tramt;
                    break;
                case "TJSE900000":
                    title += tramt;
                    BOC -= tramt;
                    break;

                case "TJSN900000":
                    title += tramt;
                    BOC -= tramt;
                    break;


                case "TSLE900000":
                    title += tramt;
                    BOC -= tramt;
                    break;


                case "TSLN900000":
                    title += tramt;
                    BOC -= tramt;
                    break;


                case "TUAN900000":
                    title += tramt;
                    BOC -= tramt;
                    break;

                case "TUAE900000":
                    title += tramt;
                    BOC -= tramt;
                    break;

                case "PNLR":
                    Penal += tramt;
                    BOC -= tramt;
                    break;

                default:
                    Others += tramt;
                    BOC -= tramt;
                    break;

            }


           

        }

        DataRow rowDescription;
        rowDescription = disbSummery.NewRow();
        rowDescription["Date"] = date;
        rowDescription["ReportID"] = "02";
        rowDescription["BranchCode"] = "0308";
        rowDescription["NoofACs"] = "1";
        cracno = dt.Rows[0]["cracno"].ToString();
        if ((cracno.Length == 12) || (cracno.Length == 13))
        {
            cracno = GetAppNo(cracno);
        }
        rowDescription["Appno"] = cracno;
        rowDescription["BOC"] = Math.Round(BOC,2);
        rowDescription["Interest"] =  Math.Round(Interest,2);
        rowDescription["Inspection"] =  Math.Round(Inspecsion,2);
        rowDescription["Legal"] =  Math.Round(Legal,2);
        rowDescription["FireInsu"] =  Math.Round(FireInsu,2);
        rowDescription["Retain"] =  Math.Round(Retain,2);
        rowDescription["Penal"] =  Math.Round(Penal,2);
        rowDescription["Others"] =  Math.Round(Others,2);
        rowDescription["Total"] = Math.Round(totAmt, 2);
        rowDescription["Title"] = Math.Round(title, 2);

        disbSummery.Rows.Add(rowDescription);

        //fc.GetStrDate(date);

        //string a = fc.GetStrDate(date);
        //fc.GetShortDate(date);

        //InsertDisbursementSummery(fc.GetStringDate(date), "01", "0308", 01, cracno, BOC, Interest, Inspecsion,
        //Legal, FireInsu, Retain, Penal, Others, totAmt);


    }
        private string GetAppNo(string cracno)
        {
            dw = new DataWorksClass(constring);
            dw.SetCommand(@"select appno from crmast where cracno = @cracno");
            dw.SetSqlCommandParameters("cracno",cracno);
            return dw.GetSingleData();
        }
    //new bimali 06/05/2009
    private DataTable AddColumsToDailyDisbSummery(DataTable dt)
    {
        // Create Description
        DataColumn Date = new DataColumn();
        Date.DataType = System.Type.GetType("System.String");
        Date.ColumnName = "Date";
        Date.DefaultValue = "Date";
        dt.Columns.Add(Date);

        // Create Description
        DataColumn ReportID = new DataColumn();
        ReportID.DataType = System.Type.GetType("System.String");
        ReportID.ColumnName = "ReportID";
        ReportID.DefaultValue = "ReportID";
        dt.Columns.Add(ReportID);

        // Create Description
        DataColumn BranchCode = new DataColumn();
        BranchCode.DataType = System.Type.GetType("System.String");
        BranchCode.ColumnName = "BranchCode";
        BranchCode.DefaultValue = "BranchCode";
        dt.Columns.Add(BranchCode);

        // Create Description
        DataColumn NoofACs = new DataColumn();
        NoofACs.DataType = System.Type.GetType("System.String");
        NoofACs.ColumnName = "NoofACs";
        NoofACs.DefaultValue = "NoofACs";
        dt.Columns.Add(NoofACs);

        // Create Description
        DataColumn Appno = new DataColumn();
        Appno.DataType = System.Type.GetType("System.String");
        Appno.ColumnName = "Appno";
        Appno.DefaultValue = "Appno";
        dt.Columns.Add(Appno);

        // Create Description
        DataColumn BOC = new DataColumn();
        BOC.DataType = System.Type.GetType("System.String");
        BOC.ColumnName = "BOC";
        BOC.DefaultValue = "BOC";
        dt.Columns.Add(BOC);

        // Create Description
        DataColumn Interest = new DataColumn();
        Interest.DataType = System.Type.GetType("System.String");
        Interest.ColumnName = "Interest";
        Interest.DefaultValue = "Interest";
        dt.Columns.Add(Interest);

        // Create Description
        DataColumn Inspection = new DataColumn();
        Inspection.DataType = System.Type.GetType("System.String");
        Inspection.ColumnName = "Inspection";
        Inspection.DefaultValue = "Inspection";
        dt.Columns.Add(Inspection);

        // Create Description
        DataColumn Legal = new DataColumn();
        Legal.DataType = System.Type.GetType("System.String");
        Legal.ColumnName = "Legal";
        Legal.DefaultValue = "Legal";
        dt.Columns.Add(Legal);

        // Create Description
        DataColumn FireInsu = new DataColumn();
        FireInsu.DataType = System.Type.GetType("System.String");
        FireInsu.ColumnName = "FireInsu";
        FireInsu.DefaultValue = "FireInsu";
        dt.Columns.Add(FireInsu);


        // Create Description
        DataColumn Retain = new DataColumn();
        Retain.DataType = System.Type.GetType("System.String");
        Retain.ColumnName = "Retain";
        Retain.DefaultValue = "Retain";
        dt.Columns.Add(Retain);

        // Create Description
        DataColumn Penal = new DataColumn();
        Penal.DataType = System.Type.GetType("System.String");
        Penal.ColumnName = "Penal";
        Penal.DefaultValue = "Penal";
        dt.Columns.Add(Penal);

        // Create Description
        DataColumn Others = new DataColumn();
        Others.DataType = System.Type.GetType("System.String");
        Others.ColumnName = "Others";
        Others.DefaultValue = "Others";
        dt.Columns.Add(Others);


        // Create Description
        DataColumn Title = new DataColumn();
        Title.DataType = System.Type.GetType("System.String");
        Title.ColumnName = "Title";
        Title.DefaultValue = "Title";
        dt.Columns.Add(Title);


        // Create Description
        DataColumn Total = new DataColumn();
        Total.DataType = System.Type.GetType("System.String");
        Total.ColumnName = "Total";
        Total.DefaultValue = "Total";
        dt.Columns.Add(Total);



        // Create an array for DataColumn objects.
        //DataColumn[] keys = new DataColumn[1];
       // keys[0] = Appno;
        //analysis.PrimaryKey = keys;
        // Return the new DataTable.
        return dt;
    }
    //edit bimali 06/05/2009
    private DataTable GetTrAmt(string transno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select taskid, transno, tramt, cracno from TransAssign 
                             where transno=@transno and (trstatus='F' or trstatus='P')");
        dw.SetDataAdapterParameters("transno", transno);
        return dw.GetDataTable();

    }
    public void GetGLTransactionSummeryReport(string branchcode, string opendate, string closedate)
    {
        fc=new FunctionClass();
        dt = new DataTable();
       
        dt = GetGLAbstractRecords(opendate);

        string datekey = fc.GetDateKeyinDate(fc.GetDateinDateKey(closedate)).ToString();
        for(int i=0;i<dt.Rows.Count;i++)
        {
            double creditamt = 0, debitamt = 0;
            string refglcode = dt.Rows[i]["refglcode"].ToString();
            string gldes = dt.Rows[i]["gldesc"].ToString();
            double openingbal = double.Parse(dt.Rows[i]["curbal"].ToString());
            double tramt = GetSumTransactions(refglcode, closedate, "CR");
            creditamt += tramt;
            tramt = GetSumTransactions(refglcode, closedate, "DR");
            debitamt -= tramt;
            double closingbal = openingbal + creditamt + debitamt;
            
            InsertDailyGLTransaction(datekey, branchcode, refglcode, gldes, openingbal, debitamt, creditamt, closingbal);
        }

   
    }
    public void GetHousProp(string dateky)
    {

        DataTable temp = new DataTable();
        temp = SetDataTableHP(temp);
        fc = new FunctionClass();
        dt = new DataTable();   
        DateTime trdate = fc.GetDateinDateKey(dateky);
        dt = GetHouspropData(trdate);
        for (int i = 0; dt.Rows.Count > i; i++)        
        {
            DateTime predatedue = DateTime.Parse(dt.Rows[i]["LastCompletedDueDate"].ToString());
            DateTime LastCompletedDueDate;
            string cracno = dt.Rows[i]["cracno"].ToString();
            string OperationDate = DateKey(dateky);
            double preoutbal = double.Parse(dt.Rows[i]["actoutbal"].ToString());
            DateTime datedue = DateTime.Parse(dt.Rows[i]["DateDue"].ToString());
            int LoanStatusCode = int.Parse(dt.Rows[i]["LoanStatusCode"].ToString());
            double IntRate = double.Parse(dt.Rows[i]["IntRate"].ToString());
            double Instalment = double.Parse(dt.Rows[i]["Instalment"].ToString());
            int GracePeriod = int.Parse(dt.Rows[i]["GracePeriod"].ToString());
            int CrPeriod = int.Parse(dt.Rows[i]["CrPeriod"].ToString());
            int CrCat = int.Parse(dt.Rows[i]["CrCat"].ToString());
            double actoutbal = double.Parse(dt.Rows[i]["actoutbal"].ToString());
            double cramt = GetSumTrans("CAPD", cracno, "CR", trdate);
            double dramt = GetSumTrans("CAPD", cracno, "DR", trdate);
            bool IsTrans;

            if (cramt != 0 || dramt != 0)
            {
                IsTrans = true;
                try
                {
                    LastCompletedDueDate = GetDatedue(cracno);
                }
                catch
                {
                    LastCompletedDueDate = DateTime.Parse(dt.Rows[i]["LastCompletedDueDate"].ToString());
                }
                actoutbal = actoutbal - cramt + dramt;
            }
            else
            {
                LastCompletedDueDate = DateTime.Parse(dt.Rows[i]["LastCompletedDueDate"].ToString());
                IsTrans = false;
            }

            temp = InsertDailyHousProp(OperationDate, cracno, LastCompletedDueDate, LoanStatusCode, IntRate, Instalment, actoutbal,
                GracePeriod, CrPeriod, CrCat, IsTrans, preoutbal, predatedue, datedue, temp);
            //InsertDailyHousProp(OperationDate, cracno, LastCompletedDueDate, LoanStatusCode, IntRate, Instalment, actoutbal,
            //    GracePeriod, CrPeriod, CrCat, IsTrans, preoutbal, predatedue,datedue);
        }
        dw = new DataWorksClass(reportconstring);
        dw.SetCommand();
        dw.InsertBulk(temp, "DailyHousProp");
    }

    private DataTable SetDataTableHP(DataTable dt)
    {
        dt = new DataTable();
        DataColumn OperationDate;
        OperationDate = new DataColumn();
        OperationDate.DataType = Type.GetType("System.String");
        OperationDate.ColumnName = "OperationDate";
        dt.Columns.Add(OperationDate);

        DataColumn cracno;
        cracno = new DataColumn();
        cracno.DataType = Type.GetType("System.String");
        cracno.ColumnName = "cracno";
        dt.Columns.Add(cracno);


        DataColumn LastCompletedDueDate;
        LastCompletedDueDate = new DataColumn();
        LastCompletedDueDate.DataType = Type.GetType("System.DateTime");
        LastCompletedDueDate.ColumnName = "LastCompletedDueDate";
        dt.Columns.Add(LastCompletedDueDate);


        DataColumn LoanStatusCode;
        LoanStatusCode = new DataColumn();
        LoanStatusCode.DataType = Type.GetType("System.String");
        LoanStatusCode.ColumnName = "LoanStatusCode";
        dt.Columns.Add(LoanStatusCode);


        DataColumn IntRate;
        IntRate = new DataColumn();
        IntRate.DataType = Type.GetType("System.String");
        IntRate.ColumnName = "IntRate";
        dt.Columns.Add(IntRate);

        DataColumn Instalment;
        Instalment = new DataColumn();
        Instalment.DataType = Type.GetType("System.String");
        Instalment.ColumnName = "Instalment";
        dt.Columns.Add(Instalment);


        DataColumn actoutbal;
        actoutbal = new DataColumn();
        actoutbal.DataType = Type.GetType("System.String");
        actoutbal.ColumnName = "actoutbal";
        dt.Columns.Add(actoutbal);
        DataColumn datedue;
        datedue = new DataColumn();
        datedue.DataType = Type.GetType("System.DateTime");
        datedue.ColumnName = "datedue";
        dt.Columns.Add(datedue);


        DataColumn GracePeriod;
        GracePeriod = new DataColumn();
        GracePeriod.DataType = Type.GetType("System.String");
        GracePeriod.ColumnName = "GracePeriod";
        dt.Columns.Add(GracePeriod);


        DataColumn CrPeriod;
        CrPeriod = new DataColumn();
        CrPeriod.DataType = Type.GetType("System.String");
        CrPeriod.ColumnName = "CrPeriod";
        dt.Columns.Add(CrPeriod);

        DataColumn CrCat;
        CrCat = new DataColumn();
        CrCat.DataType = Type.GetType("System.String");
        CrCat.ColumnName = "CrCat";
        dt.Columns.Add(CrCat);

        DataColumn IsTrans;
        IsTrans = new DataColumn();
        IsTrans.DataType = Type.GetType("System.String");
        IsTrans.ColumnName = "IsTrans";
        dt.Columns.Add(IsTrans);


        DataColumn preoutbal;
        preoutbal = new DataColumn();
        preoutbal.DataType = Type.GetType("System.String");
        preoutbal.ColumnName = "preoutbal";
        dt.Columns.Add(preoutbal);


        DataColumn predatedue;
        predatedue = new DataColumn();
        predatedue.DataType = Type.GetType("System.DateTime");
        predatedue.ColumnName = "predatedue";
        dt.Columns.Add(predatedue);

        return dt;


    }

    private DataTable InsertDailyHousProp(string OperationDate, string cracno, DateTime LastCompletedDueDate,
                         int LoanStatusCode, double IntRate, double Instalment, double actoutbal, int GracePeriod,
                         int CrPeriod, int CrCat, bool IsTrans, double preoutbal, DateTime predatedue, DateTime datedue, DataTable dt)
    {
        DataRow dr;
        dr = dt.NewRow();
        dr["OperationDate"] = OperationDate;
        dr["cracno"] = cracno;
        dr["LastCompletedDueDate"] = LastCompletedDueDate;
        dr["LoanStatusCode"] = LoanStatusCode;
        dr["IntRate"] = IntRate;
        dr["Instalment"] = Instalment;
        dr["actoutbal"] = actoutbal;
        dr["datedue"] = datedue;
        dr["GracePeriod"] = GracePeriod;
        dr["CrPeriod"] = CrPeriod;
        dr["CrCat"] = CrCat;
        dr["IsTrans"] = IsTrans;
        dr["preoutbal"] = preoutbal;
        dr["predatedue"] = predatedue;

        dt.Rows.Add(dr);
        return dt;
    }




    //private DataTable InsertDailyHousProp(string OperationDate,string cracno, DateTime LastCompletedDueDate,
    //                   int LoanStatusCode, double IntRate, double Instalment, double actoutbal, int GracePeriod,
    //                   int CrPeriod, int CrCat, bool IsTrans, double preoutbal, DateTime predatedue,DateTime datedue, DataTable dt)
    //{
    //    DataRow dr;
    //    dr = dt.NewRow();
    //    dr["OperationDate"] = OperationDate;
    //    dr["cracno"] = cracno;
    //    dr["LastCompletedDueDate"] = LastCompletedDueDate;
    //    dr["LoanStatusCode"] = LoanStatusCode;
    //    dr["IntRate"] = IntRate;
    //    dr["Instalment"] = Instalment;
    //    dr["actoutbal"] = actoutbal;
    //    dr["GracePeriod"] = GracePeriod;
    //    dr["CrPeriod"] = CrPeriod;
    //    dr["CrCat"] = CrCat;
    //    dr["IsTrans"] = IsTrans;
    //    dr["preoutbal"] = preoutbal;
    //    dr["predatedue"] = predatedue;
    //    dr["datedue"] = datedue;
    //    dt.Rows.Add(dr);
    //    return dt;
    //}

    //private DataTable SetDataTable(DataTable dt)
    //{
    //    dt = new DataTable();
    //    DataColumn OperationDate;
    //    OperationDate = new DataColumn();
    //    OperationDate.DataType = Type.GetType("System.String");
    //    OperationDate.ColumnName = "OperationDate";
    //    dt.Columns.Add(OperationDate);

    //    DataColumn cracno;
    //    cracno = new DataColumn();
    //    cracno.DataType = Type.GetType("System.String");
    //    cracno.ColumnName = "cracno";
    //    dt.Columns.Add(cracno);


    //    DataColumn LastCompletedDueDate;
    //    LastCompletedDueDate = new DataColumn();
    //    LastCompletedDueDate.DataType = Type.GetType("System.DateTime");
    //    LastCompletedDueDate.ColumnName = "LastCompletedDueDate";
    //    dt.Columns.Add(LastCompletedDueDate);


    //    DataColumn LoanStatusCode;
    //    LoanStatusCode = new DataColumn();
    //    LoanStatusCode.DataType = Type.GetType("System.String");
    //    LoanStatusCode.ColumnName = "LoanStatusCode";
    //    dt.Columns.Add(LoanStatusCode);


    //    DataColumn IntRate;
    //    IntRate = new DataColumn();
    //    IntRate.DataType = Type.GetType("System.String");
    //    IntRate.ColumnName = "IntRate";
    //    dt.Columns.Add(IntRate);

    //    DataColumn Instalment;
    //    Instalment = new DataColumn();
    //    Instalment.DataType = Type.GetType("System.String");
    //    Instalment.ColumnName = "Instalment";
    //    dt.Columns.Add(Instalment);


    //    DataColumn actoutbal;
    //    actoutbal = new DataColumn();
    //    actoutbal.DataType = Type.GetType("System.String");
    //    actoutbal.ColumnName = "actoutbal";
    //    dt.Columns.Add(actoutbal);


    //    DataColumn GracePeriod;
    //    GracePeriod = new DataColumn();
    //    GracePeriod.DataType = Type.GetType("System.String");
    //    GracePeriod.ColumnName = "GracePeriod";
    //    dt.Columns.Add(GracePeriod);


    //    DataColumn CrPeriod;
    //    CrPeriod = new DataColumn();
    //    CrPeriod.DataType = Type.GetType("System.String");
    //    CrPeriod.ColumnName = "CrPeriod";
    //    dt.Columns.Add(CrPeriod);

    //    DataColumn CrCat;
    //    CrCat = new DataColumn();
    //    CrCat.DataType = Type.GetType("System.String");
    //    CrCat.ColumnName = "CrCat";
    //    dt.Columns.Add(CrCat);

    //    DataColumn IsTrans;
    //    IsTrans = new DataColumn();
    //    IsTrans.DataType = Type.GetType("System.String");
    //    IsTrans.ColumnName = "IsTrans";
    //    dt.Columns.Add(IsTrans);


    //    DataColumn preoutbal;
    //    preoutbal = new DataColumn();
    //    preoutbal.DataType = Type.GetType("System.String");
    //    preoutbal.ColumnName = "preoutbal";
    //    dt.Columns.Add(preoutbal);


    //    DataColumn predatedue;
    //    predatedue = new DataColumn();
    //    predatedue.DataType = Type.GetType("System.DateTime");
    //    predatedue.ColumnName = "predatedue";
    //    dt.Columns.Add(predatedue);


    //    DataColumn datedue;
    //    datedue = new DataColumn();
    //    datedue.DataType = Type.GetType("System.DateTime");
    //    datedue.ColumnName = "datedue";
    //    dt.Columns.Add(datedue);
    //    return dt;
    //}

    public void GetHousProp(string startDate, string endDate)
    {
        DataTable temp = new DataTable();
        temp = SetDataTableHP(temp);
        fc = new FunctionClass();
        dt = new DataTable();
        string startd = DateKey(startDate);
        DateTime trdate = fc.GetDateinDateKey(endDate);
        dt = GetPreviousHouspropData(startd,trdate);
        
        for (int i = 0; dt.Rows.Count > i; i++)
        {
            
            DateTime predatedue = DateTime.Parse(dt.Rows[i]["LastCompletedDueDate"].ToString());
            DateTime LastCompletedDueDate;
            string cracno = dt.Rows[i]["cracno"].ToString();

            if (cracno == "603080385967")
            {

            }
            string OperationDate = DateKey(endDate);
            double preoutbal = double.Parse(dt.Rows[i]["actoutbal"].ToString());
            int LoanStatusCode = int.Parse(dt.Rows[i]["LoanStatusCode"].ToString());
            double IntRate = double.Parse(dt.Rows[i]["IntRate"].ToString());
            double Instalment = double.Parse(dt.Rows[i]["Instalment"].ToString());
            int GracePeriod = int.Parse(dt.Rows[i]["GracePeriod"].ToString());
            int CrPeriod = int.Parse(dt.Rows[i]["CrPeriod"].ToString());
            int CrCat = int.Parse(dt.Rows[i]["CrCat"].ToString());
            double actoutbal = double.Parse(dt.Rows[i]["actoutbal"].ToString());
            double cramt = GetSumTrans("CAPD", cracno, "CR", trdate);
            double dramt = GetSumTrans("CAPD", cracno, "DR", trdate);
            DateTime datedue = DateTime.Parse(dt.Rows[i]["datedue"].ToString());
            bool IsTrans;
           
            if (cramt != 0 || dramt != 0)
            {
                IsTrans = true;
                try
                {
                    LastCompletedDueDate = GetDatedue(cracno);
                }
                catch
                {
                    LastCompletedDueDate = DateTime.Parse(dt.Rows[i]["LastCompletedDueDate"].ToString());
                }
                actoutbal = actoutbal - cramt + dramt;
            }
            else
            {
                LastCompletedDueDate = DateTime.Parse(dt.Rows[i]["LastCompletedDueDate"].ToString());
                IsTrans = false;
            }

            //InsertDailyHousProp(OperationDate, cracno, LastCompletedDueDate, LoanStatusCode, IntRate, Instalment, actoutbal,
             //   GracePeriod, CrPeriod, CrCat, IsTrans, preoutbal, predatedue, datedue);

            temp = InsertDailyHousProp(OperationDate, cracno, LastCompletedDueDate, LoanStatusCode, IntRate, Instalment, actoutbal,
            GracePeriod, CrPeriod, CrCat, IsTrans, preoutbal, predatedue, datedue, temp);
        }
            //InsertDailyHousProp(OperationDate, cracno, LastCompletedDueDate, LoanStatusCode, IntRate, Instalment, actoutbal,
            //    GracePeriod, CrPeriod, CrCat, IsTrans, preoutbal, predatedue,datedue);

        dw = new DataWorksClass(reportconstring);
        dw.SetCommand();
        dw.InsertBulk(temp, "DailyHousProp");
        
    }

    private double GetArreasAmount(string cracno, DateTime operationdate)
    {
        rpc = new RecoveryProcesClass();
        //ls = new LastSerialClass();
        fc = new FunctionClass();
        dt = new DataTable();
        rc = new Recovery();
        //dc = new DisbursementClass();
        DataTable datat = new DataTable();
        p = new PrintClass();
        ctc = new CrTransClass();

        DataTable setclosingdata = new DataTable();
        DateTime today = fc.GetSystemDate("A");
        today = fc.GetSystemDate("A");

        
        today = fc.GetSystemDate("A");
        datat = rc.GetnormalDetails(cracno);

        double intrate = double.Parse(datat.Rows[0]["InterestRate"].ToString());
        int crcat = int.Parse(datat.Rows[0]["crcat"].ToString());
        setclosingdata = SetDataTableHP(setclosingdata);

        double recoutbal = double.Parse(datat.Rows[0]["OutstandBal"].ToString());

        double execesspayment = rpc.ExessPayment;
        dt = rpc.RecoveryProcessTemp(cracno, today, today, setclosingdata);

        double outbal = rpc.OutBal;

        fc.GetTotal(dt, crcat);
        string arreasamount = fc.Total.ToString();
        return double.Parse(arreasamount);
    }

    //private DataTable SetDataTableHousprop(DataTable dt)
    //{
    //    dt = new DataTable();
    //    DataColumn cracno;
    //    cracno = new DataColumn();
    //    cracno.DataType = Type.GetType("System.String");
    //    cracno.ColumnName = "cracno";
    //    dt.Columns.Add(cracno);

    //    DataColumn TrStatus;
    //    TrStatus = new DataColumn();
    //    TrStatus.DataType = Type.GetType("System.String");
    //    TrStatus.ColumnName = "trstatus";
    //    dt.Columns.Add(TrStatus);


    //    DataColumn datedue;
    //    datedue = new DataColumn();
    //    datedue.DataType = Type.GetType("System.String");
    //    datedue.ColumnName = "datedue";
    //    dt.Columns.Add(datedue);

    //    DataColumn tramt;
    //    tramt = new DataColumn();
    //    tramt.DataType = Type.GetType("System.String");
    //    tramt.ColumnName = "tramt";
    //    dt.Columns.Add(tramt);

    //    //DataColumn dcDescription;
    //    //dcDescription = new DataColumn();
    //    //dcDescription.DataType = Type.GetType("System.String");
    //    //dcDescription.ColumnName = "Description";
    //    //dt.Columns.Add(dcDescription);

    //    //DataColumn dcOthers;
    //    //dcOthers = new DataColumn();
    //    //dcOthers.DataType = Type.GetType("System.String");
    //    //dcOthers.ColumnName = "RefNo";
    //    //dt.Columns.Add(dcOthers);

    //    DataColumn dcTaskId;
    //    dcTaskId = new DataColumn();
    //    dcTaskId.DataType = Type.GetType("System.String");
    //    dcTaskId.ColumnName = "TaskId";
    //    dt.Columns.Add(dcTaskId);

    //    return dt;
    //}

    private DateTime GetDatedue(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select max(datedue) from transassign 
                        where cracno = @cracno and trstatus != 'C' 
                        and tramt = assignamt and taskid = 'CAPD' and transref<>'DISB'");
        dw.SetSqlCommandParameters("cracno", cracno);
        return DateTime.Parse(dw.GetSingleData());
    }

    private double GetSumTrans(string taskid, string cracno, string acsign, DateTime trdate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select isnull(sum(distinct g.tramt),0) as tramt from transassign t, gltrans g
                        where t.refno = g.transassignrefno
                        and  t.cracno = @cracno
                        and g.trstatus != 'c' and g.acsign = @acsign
                        and t.taskid =@taskid and g.trdate=@trdate and right(g.refglcode,3)<'870' and t.transref<>'DISB'");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("acsign", acsign);
        dw.SetSqlCommandParameters("taskid", taskid);
        dw.SetSqlCommandParameters("trdate", trdate);
        return double.Parse(dw.GetSingleData());
    }

    private DataTable GetHouspropData(DateTime GrantDate)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select LastCompletedDueDate,H.cracno, actoutbal,LoanStatusCode,H.IntRate,C.Instalment,
                            GracePeriod,C.CrPeriod,CrCat,datedue
                            from TDBOld.CreditAdmin.Housprop H, TDBOld.CreditAdmin.CrMast C
                            where h.cracno=c.cracno and actOutBal != 0 and C.cracno not in
                            (select cracno from disbbalsum where grantdate=@GrantDate) 
                            union
                            select d.grantdate as LastCompletedDueDate,d.cracno, d.transamt + isnull(h.actoutbal,0) as actoutbal,0 as LoanStatusCode,
                            c.IntRate,c.Instalment,
                            1 as GracePeriod,c.CrPeriod,c.CrCat,
                            dateadd(month,1,d.grantdate) as datedue
                            from disbbalsum d, CrMast c, CreditReportsDb.ReportUser.DailyHousProp h
                            where d.grantdate=@GrantDate
                            and d.cracno=c.cracno
                            and d.cracno*=h.cracno");
        dw.SetDataAdapterParameters("GrantDate", GrantDate);
        return dw.GetDataTable();
    }

    private DataTable GetPreviousHouspropData(string OperationDate, DateTime GrantDate)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select LastCompletedDueDate,cracno, actoutbal,LoanStatusCode,IntRate,Instalment,
                            GracePeriod,CrPeriod,CrCat,datedue
                            from CreditReportsDb.ReportUser.DailyHousProp
                            where actOutBal != 0 and OperationDate=@OperationDate and cracno not in
                            (select cracno from disbbalsum where grantdate=@GrantDate) 
                            union
                            select d.grantdate as LastCompletedDueDate,d.cracno, d.transamt + isnull(h.actoutbal,0) as actoutbal,0 as LoanStatusCode,
                            c.IntRate,c.Instalment,
                            1 as GracePeriod,c.CrPeriod,c.CrCat,
                            dateadd(month,1,d.grantdate) as datedue
                            from disbbalsum d, CrMast c, CreditReportsDb.ReportUser.DailyHousProp h
                            where d.grantdate=@GrantDate
                            and d.cracno=c.cracno
                            and d.cracno*=h.cracno
                            and h.operationdate=@OperationDate order by cracno desc");
        dw.SetDataAdapterParameters("OperationDate", OperationDate);
        dw.SetDataAdapterParameters("GrantDate", GrantDate);
        return dw.GetDataTable();
    }

    private int InsertDailyHousProp(string OperationDate,string CrAcNo,DateTime LastCompletedDueDate,int LoanStatusCode,
                                    double IntRate,double Instalment,double OutBal,int GracePeriod,
                                    int CrPeriod, int CrCat, bool IsTrans, double preoutbal, DateTime predatedue, DateTime DateDue)
    {
        dw = new DataWorksClass(reportconstring);
        dw.SetCommand(@"INSERT INTO DailyHousProp(OperationDate,CrAcNo,LastCompletedDueDate,
                        LoanStatusCode,IntRate,Instalment,OutBal,CrPeriod,CrCat,IsTrans,preoutbal,
                        predatedue,GracePeriod,DateDue)
                        VALUES (@OperationDate,@CrAcNo,@LastCompletedDueDate,@LoanStatusCode,@IntRate,@Instalment,@OutBal,
                        @CrPeriod,@CrCat,@IsTrans,@preoutbal,@predatedue,@GracePeriod,@DateDue)");
        dw.SetSqlCommandParameters("OperationDate", OperationDate);
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        dw.SetSqlCommandParameters("LastCompletedDueDate", LastCompletedDueDate);
        dw.SetSqlCommandParameters("LoanStatusCode", LoanStatusCode);
        dw.SetSqlCommandParameters("IntRate", IntRate);
        dw.SetSqlCommandParameters("Instalment", Instalment);
        dw.SetSqlCommandParameters("OutBal", OutBal);
        dw.SetSqlCommandParameters("GracePeriod", GracePeriod);
        dw.SetSqlCommandParameters("CrPeriod", CrPeriod);
        dw.SetSqlCommandParameters("CrCat", CrCat);
        dw.SetSqlCommandParameters("IsTrans", IsTrans);
        dw.SetSqlCommandParameters("preoutbal", preoutbal);
        dw.SetSqlCommandParameters("predatedue", predatedue);
        dw.SetSqlCommandParameters("DateDue", DateDue);
        return dw.Insert();
    }

    public void SetGL()
    {
        dt = new DataTable();
        dt = GetGLCode();

        for (int i = 0; i < dt.Rows.Count; i++)
        {
            string refglcode = dt.Rows[i]["refglcode"].ToString();
            double tramt = GetTransactionsSum(refglcode);
            double outbal = GetCurBal(refglcode);
            outbal += tramt;
            UpdateOutBal(outbal, refglcode);
        }
    }

    private DataTable GetGLCode()
    {
        dw = new DataWorksClass(oldconstring);
        dw.SetDataAdapter(@"select refglcode from glcode");
        return dw.GetDataTable();
    }

    private int UpdateOutBal(double outbal, string refglcode)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update glcode set curbal=@curbal where refglcode=@refglcode");
        dw.SetSqlCommandParameters("refglcode", refglcode);
        dw.SetSqlCommandParameters("curbal", outbal);
        return dw.Update();
    }

    private double GetCurBal(string refglcode)
    {
        dw = new DataWorksClass(oldconstring);
        dw.SetCommand(@"select curbal from glcode where refglcode=@refglcode");
        dw.SetSqlCommandParameters("refglcode", refglcode);
        return double.Parse(dw.GetSingleData());
    }

    private double GetTransactionsSum(string refglcode)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"SELECT ((select isnull(sum(tramt),0) as tramt from gltrans where trstatus != 'C' 
                                 and  refglcode=@refglcode and acsign='CR')
                                    -
                                    (select isnull(sum(tramt),0) as tramt from gltrans where trstatus != 'C' 
                                                                and  refglcode=@refglcode and acsign='DR'))
                                    AS tramt");
        dw.SetSqlCommandParameters("refglcode", refglcode);
        return double.Parse(dw.GetSingleData());
    }

    //Dilanka 08/03/2010
    public DataTable GetNewLoans(string GrantDate)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select c.cracno,rtrim(t.titledesc + ' '+ rtrim(cm.initials) + ' '+ rtrim(cm.surname)) as Name,
                                cr.crdes as LoanCatogory,c.intrate,h.actoutbal as OutBal,c.instalment,CONVERT(VARCHAR(10),h.lastcompletedduedate,111) as LastCompletedduedate,
                                datediff(month,lastcompletedduedate, @GrantDate) as ArriasMonths
                                from housprop h,crmast c,CrCategory cr,customermain cm, crholder ch, title t
                                where c.cracno=h.cracno and c.aprovdamt=c.grantAmt and
                                c.grantdate=h.lastcompletedduedate and c.grantamt > 0.00 and c.crcat <> 9 and c.crcat <> 16
                                and h.actoutbal > 0.00 and t.titlecode=cm.titlecode 
                                and cm.nicno=ch.nicno and ch.holdertype='P' and ch.cracno=c.cracno
                                and cr.crcatcode=c.crcat and h.paidinstalments=0.00 
                                and c.grantdate < @GrantDate order by c.crcat,c.grantdate");
        dw.SetDataAdapterParameters("GrantDate", GrantDate);
        return dw.GetDataTable();
    }

    public DataTable LoadBranchReportDetails()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from BranchReportsHeader");
        return dw.GetDataTable();
    }

    public string PreviousMonthEndDate(string datekey)
    {
        dw = new DataWorksClass(reportconstring);
        dw.SetCommand(@"select max(dateKey) from valProvision where dateKey < @datekey");
        dw.SetSqlCommandParameters("datekey", datekey);
        return dw.GetSingleData();
    }
}
