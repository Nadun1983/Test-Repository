using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for DayEndClass
/// </summary>
public class DayEndClass
{
    DataWorksClass dw;
    DataTable dt;
    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();
	public DayEndClass()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    //public int NPLTranasaction(DateTime date)
    //{
    //    GetNPLLoans(date, 0);
    //    foreach (DataRow dr in dt.Rows)
    //    {

    //    }
    //}

    private DataTable GetNPLLoans(DateTime date, int statuscode)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select cracno from housprop where LastCompletedDueDate=@LastCompletedDueDate and LoanStatusCode=@LoanStatusCode");
        dw.SetDataAdapterParameters("LoanStatusCode", statuscode);
        dw.SetDataAdapterParameters("LastCompletedDueDate", date);
        return dw.GetDataTable();
    }

    //public string GetUserMode(DateTime OperationDate, int BranchCode)
    //{
    //    dw = new DataWorksClass(constring);
    //    dw.SetCommand(@"select UserMode from OperationCalendarBranch where OperationDate=@OperationDate and BranchCode=@BranchCode");
    //    dw.SetSqlCommandParameters("OperationDate", OperationDate);
    //    dw.SetSqlCommandParameters("BranchCode", BranchCode);
    //    return dw.GetSingleData();
    //}

    public string GetUserModeFromUser(string UserId, string PasWd)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select UserMode from Users where UserId=@UserId and PasWd=@PasWd");
        dw.SetSqlCommandParameters("UserId", UserId);
        dw.SetSqlCommandParameters("PasWd", PasWd);
        return dw.GetSingleData();
    }

    //BranchCode-000001

    public string GetUserMode1(string OperationDate,int BranchCode)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select UserMode from OperationCalendarBranch where OperationDate=@OperationDate and BranchCode=@BranchCode");
        dw.SetSqlCommandParameters("OperationDate", OperationDate);
        dw.SetSqlCommandParameters("BranchCode", BranchCode);
        return dw.GetSingleData();
    }


    //BranchCode-000001
    public int UpdateUserModeInCalander(string OperationDate, int BranchCode,string UserMode)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update OperationCalendarBranch set UserMode=@UserMode where OperationDate=@OperationDate and BranchCode=@BranchCode");
        dw.SetSqlCommandParameters("UserMode", UserMode);
        dw.SetSqlCommandParameters("OperationDate", OperationDate);
        dw.SetSqlCommandParameters("BranchCode", BranchCode);
        return dw.Update();
    }

    public int ChangeOpeartionCalenderStatus(string oldStatus, string newStatus)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update OperationCalendar set currentstatus=@newStatus where currentstatus=@oldStatus");
        dw.SetSqlCommandParameters("oldStatus", oldStatus);
        dw.SetSqlCommandParameters("newStatus", newStatus);
        return dw.Update();
    }

    public int InsertEndDayProcess(string workDate, bool CloseCurrentOperationDate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into EndDayProcess(WorkDate,CloseCurrentOperationDate)
                        values (@WorkDate,@CloseCurrentOperationDate)");
        dw.SetSqlCommandParameters("workDate", workDate);
        dw.SetSqlCommandParameters("CloseCurrentOperationDate", CloseCurrentOperationDate);
        return dw.Insert();
    }

    public string GetNextOperationDate()
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select min(operationdate) as NextDate from OperationCalendar where currentstatus is null");
        return dw.GetSingleData();
    }

    public int SetOperationCalenderNextDate(string currentStatus)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update OperationCalendar set currentstatus=@currentStatus where operationdate=
                       (select min(operationdate)  as NextDate from OperationCalendar where currentstatus is null)");
        dw.SetSqlCommandParameters("currentStatus", currentStatus);
        return dw.Update();
    }

    public int UpdateEndDayProcessSetNextOperationDate(string workDate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update EndDayProcess set SetNextOperationDate=1 where WorkDate=@WorkDate");
        dw.SetSqlCommandParameters("workDate", workDate);
        return dw.Update();
    }
}
