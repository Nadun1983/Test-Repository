﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

/// <summary>
/// Summary description for ClosingInsuranceReports
/// </summary>
public class ClosingInsuranceReports
{
    DataWorksClass dw;
    private string constring = ConfigurationManager.ConnectionStrings["housdbString"].ToString();

	public ClosingInsuranceReports()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public DataTable GetInsuranceCompanyDetails()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select refglcode,gldesc from glcode where gldesc like '%insurance%' and gldesc like '%GL Code Credit Div. Other Cr.%'");
        return dw.GetDataTable();
    }

    public string GetOldGlno(string refglcode)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select oldglcode from glcode where refglcode = @refglcode");
        dw.SetSqlCommandParameters("refglcode", refglcode);
        return dw.GetSingleData();
    }

}
