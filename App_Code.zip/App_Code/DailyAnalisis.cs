﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

/// <summary>
/// Summary description for DailyAnalisis
/// </summary>
public class DailyAnalisis
{

    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();
    string brnchconstring = ConfigurationManager.ConnectionStrings["TDBBranchesConString"].ConnectionString.ToString();
    private DataTable dt;
    DataWorksClass dw;

	public DailyAnalisis()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public DataTable getDailyAnalisisData(string datekey)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select @datekey,SUM(h.ActOutBal) as Actoutbal,SUM(c.GrantAmt) as GrantAmt,SUM(c.Aprovdamt) as Aprovdamt,
                            SUM(a.CrAmt) as CrAmt,SUM((c.Aprovdamt)-(c.GrantAmt)) as ApprovednotGranted, c.CatPurposeId From HousProp h, crmast c, Crapp a where 
                            h.CrAcNo=c.CrAcNo and h.ActOutBal > 0.00 and c.Appno= a.AppNo
                            group by c.CatPurposeId
                            order by c.CatPurposeId");
        dw.SetDataAdapterParameters("datekey", datekey);
        dt = dw.GetDataTable();
        return dt;
    }

    public DataTable getdailybalance(string datekey)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select @datekey,cr.CrDes as 'LoanCategory' ,SUM(d.CrAmt) as CrAmt,SUM(AprovedAmt) as Aprovdamt ,
                                SUM(ApprovednotGranted) as ApprovednotGranted,
                                SUM(d.GrantAmt) as GrantAmt,SUM(ActOutBal) as ActOutBal From 
                                DailyAnalisis d, CrCatPurpose c, CrCategory cr
                                where d.Datekey=@Datekey and c.CatPurposeId=d.catpurposeid-- and c.crcatcode =5
                                and c.crcatcode=cr.CrCatCode
                                group by cr.CrDes
                                --order by cr.CrDes
                                union
                                select @datekey,cr.Descrip as 'LoanCategory',SUM(d.CrAmt) as CrAmt,SUM(AprovedAmt) as Aprovdamt ,
                                SUM(ApprovednotGranted) as ApprovednotGranted,
                                SUM(d.GrantAmt) as GrantAmt,SUM(ActOutBal) as ActOutBal From 
                                DailyAnalisis d, CrCatPurpose c, CrPurpose cr
                                where d.Datekey=@Datekey and c.CatPurposeId=d.catpurposeid and c.crcatcode =19
                                and c.purposecode=cr.PurposeCode and cr.PurposeCode in (48)
                                group by cr.Descrip
                                --order by cr.Descrip
                                union
                                select @datekey,'Other Personal Loans' as 'LoanCategory',SUM(d.CrAmt) as CrAmt,SUM(AprovedAmt) as Aprovdamt ,
                                SUM(ApprovednotGranted) as ApprovednotGranted,
                                SUM(d.GrantAmt) as GrantAmt,SUM(ActOutBal) as ActOutBal From 
                                DailyAnalisis d, CrCatPurpose c, CrPurpose cr
                                where d.Datekey=@Datekey and c.CatPurposeId=d.catpurposeid and c.crcatcode =19
                                and c.purposecode=cr.PurposeCode and cr.PurposeCode not in (48)");
        dw.SetDataAdapterParameters("datekey", datekey);
        dt = dw.GetDataTable();
        return dt;
        
    }

    public DataTable getAnalisis(string fromdate, string todate)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select A.LoanCategory,A.ActOutBal as Balance,(A.ActOutBal-tab1.ActOutBal) as ForTheDaydiff,
                            A.CrAmt as CrAmount,A.Aprovdamt as ApprovedAmt,A.ApprovednotGranted as ApprovednotGrantedAmt,A.GrantAmt as GrantedAmount from 
                            (select LoanCategory,ActOutBal,CrAmt,Aprovdamt,ApprovednotGranted,GrantAmt From Dailybalance 
                            where datekey=@fromdate)  tab1,Dailybalance as A
                            where tab1.LoanCategory = A.LoanCategory and datekey=@todate");
        dw.SetDataAdapterParameters("fromdate", fromdate);
        dw.SetDataAdapterParameters("todate", todate);
        dt = dw.GetDataTable();
        return dt;
        
    }

    public int getcount(string datekey)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select COUNT(*) from DailyAnalisis where Datekey =@Datekey");
        dw.SetSqlCommandParameters("datekey", datekey);
        return int.Parse(dw.GetSingleData());
    }

//    public DataTable GetLoanData(DateTime fromdate, DateTime todate)
//    {
//        dw = new DataWorksClass(constring);
//        dw.SetDataAdapter(@"select distinct RTRIM(T.TITLEDESC)+' '+RTRIM(M.Initials)+' '+
//                            RTRIM(M.Surname) as FullName,M.Location,M.Street,M.City,M.NicNo
//                            from CrMast C, HousProp H, CrCatPurpose P, CrHolder R, Customermain M, TITLE T 
//                            where C.CrAcNo = H.CrAcNo
//                            and H.ActOutBal > 0 and C.GrantDate >= @fromdate and C.GrantDate <= @todate 
//                            and H.CrCat in (1,4) and
//                            C.CatPurposeId = P.catpurposeid and P.purposecode in (1,2,3) and C.Aprovdamt = C.GrantAmt
//                            and H.CrAcNo = R.CrAcNo and R.HolderType='P' and R.NicNo = M.NicNo and M.TitleCode = T.TITLECODE");
//        dw.SetDataAdapterParameters("fromdate", fromdate);
//        dw.SetDataAdapterParameters("todate", todate);
//        dt = dw.GetDataTable();
//        return dt;

//    }

//    public string GetLoanNumber(string NicNo, DateTime fromdate, DateTime todate)
//    {
//        dw = new DataWorksClass(constring);
//        dw.SetCommand(@"select top 1 H.cracno
//                        from CrMast C, HousProp H, CrCatPurpose P, CrHolder R
//                        where C.CrAcNo = H.CrAcNo
//                        and H.ActOutBal > 0 and C.GrantDate >= @fromdate and C.GrantDate <= @todate 
//                        and H.CrCat in (1,4) and
//                        C.CatPurposeId = P.catpurposeid and P.purposecode in (1,2,3) and C.Aprovdamt = C.GrantAmt
//                        and H.CrAcNo = R.CrAcNo and R.HolderType='P' 
//                        and R.NicNo = @NicNo");
//        dw.SetSqlCommandParameters("NicNo", NicNo);
//        dw.SetSqlCommandParameters("fromdate", fromdate);
//        dw.SetSqlCommandParameters("todate", todate);
//        return dw.GetSingleData();
//    }

    public DataTable LoadBranchDetails()
    {
        dw = new DataWorksClass(brnchconstring);
        dw.SetDataAdapter(@"select branchno, RTRIM(BranchName) as BranchName from nsb_branch order by branchname");
        dt = dw.GetDataTable();
        return dt;

    }
}
