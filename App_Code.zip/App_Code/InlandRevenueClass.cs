﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// Summary description for InlandRevenueClass
/// </summary>
public class InlandRevenueClass
{

    private double captotal, inttotal, penaltotal;
	public InlandRevenueClass()
	{
        
		//
		// TODO: Add constructor logic here
		//
	}

    Corrections cs;
    DateTime datedue, nextdue, intdatedue;
    double outbal, actoutbal, exesspayment;
    string msg, errorcracno;
    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();
    string reporTString = ConfigurationManager.ConnectionStrings["reporTString"].ConnectionString.ToString();
    CrTransClass cc;
    DataWorksClass dw;
    FunctionClass fc;
    Recovery rc;
    Trans t;
    DataTable dt;


    public double CapTotal
    {
        get
        {
            return this.captotal;
        }
    }



    public string ErrorCracno
    {
        get
        {
            return this.msg;
        }
    }

    public string Message
    {
        get
        {
            return this.msg;
        }
    }

    public double CapitalTotal
    {
        get
        {
            return this.captotal;
        }
    }

    public DateTime NextDue
    {
        get
        {
            return this.nextdue;
        }
    }

    public DateTime IntDateDue
    {
        get
        {
            return this.intdatedue;
        }
    }



    public double IntTotal
    {
        get
        {
            return this.inttotal;
        }
    }


    public double PenalTotal
    {
        get
        {
            return this.penaltotal;
        }
    }


    public double OutBal
    {
        get
        {
            return this.outbal;
        }
    }


    public double ActOutBal
    {
        get
        {
            return this.actoutbal;
        }
    }


    public double ExessPayment
    {
        get
        {
            return this.exesspayment;
        }
    }



    public DateTime DateDue
    {
        get
        {
            return this.datedue;
        }
    }


    // Get Loans base onthe Due Dates
    public DataTable GetBaseRecords(DateTime datedue, string acstatus, string IsDisbursed)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select h.outbal, h.cracno, h.datedue, h.intrate, h.instalment, h.OutBal,
                            h.graceperiod, h.crperiod-h.PaidInstalments as RemainingInstalment,
                            h.LastCompletedDueDate  
                            from housprop h, crmast c where h.datedue=@datedue and c.acstatus = @acstatus and
                            c.cracno = h.cracno and h.IsDisbursed=@IsDisbursed");
        dw.SetDataAdapterParameters("datedue", datedue);
        dw.SetDataAdapterParameters("acstatus", acstatus);
        dw.SetDataAdapterParameters("IsDisbursed", IsDisbursed);
        return dw.GetDataTable();
    }


    //    public DataTable GetBaseRecords(string acstatus, string IsDisbursed, string cracno)
    //    {
    //        dw = new DataWorksClass(constring);
    //        dw.SetDataAdapter(@"select h.outbal, h.cracno, h.datedue, h.intrate, h.instalment, 
    //                            h.LastCompletedDueDate, h.graceperiod, h.crperiod-h.paidInstalments as RemainingInstalment,
    //                            h.LastCompletedDueDate 
    //                            from housprop h, crmast c where h.cracno =@cracno and c.acstatus =@acstatus and
    //                            c.cracno = h.cracno and h.IsDisbursed=@IsDisbursed");
    //        dw.SetDataAdapterParameters("acstatus", acstatus);
    //        dw.SetDataAdapterParameters("IsDisbursed", IsDisbursed);
    //        dw.SetDataAdapterParameters("cracno", cracno);
    //        return dw.GetDataTable();
    //    }

    //2009-06-01 Isdisbursed not check
    public DataTable GetBaseRecords(string acstatus, string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select h.outbal,  h.actoutbal, h.cracno, h.datedue, h.intrate, h.instalment, 
                            h.LastCompletedDueDate, h.graceperiod, h.crperiod-h.paidInstalments as RemainingInstalment,
                            h.LastCompletedDueDate, h.crcat
                            from housprop h, crmast c where h.cracno =@cracno and c.acstatus =@acstatus and
                            c.cracno = h.cracno");
        dw.SetDataAdapterParameters("acstatus", acstatus);
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }


    private DataTable GetPrevRecoveries(string cracno, bool ispaid)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter("select transamt from RecvTrans where ispaid=@ispaid and cracno=@cracno");
        dw.SetDataAdapterParameters("cracno", cracno);
        dw.SetDataAdapterParameters("ispaid", ispaid);
        return dw.GetDataTable();
    }

    //ExcessPayment
    private string GetExcessPayment(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand("select excesspayment from HousProp where cracno=@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return dw.GetSingleData();
    }

    private string GetPenalInt(string ratetype, DateTime datedue)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select rateamt from ratecode where ratetype='PEN' 
                        and (DateFrom<=@datedue and DateTo>=@datedue)");
        dw.SetSqlCommandParameters("ratetype", ratetype);
        dw.SetSqlCommandParameters("datedue", datedue);
        if (dw.GetSingleData() != "20")
        { }
        return dw.GetSingleData();
    }

    private int UpdateDisbRefNo(long disbrefno, string refno, DateTime trdate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update transassign set disbrefno=@disbrefno, trdate=@trdate where refno=@refno");
        dw.SetSqlCommandParameters("disbrefno", disbrefno);
        dw.SetSqlCommandParameters("trdate", trdate);
        dw.SetSqlCommandParameters("refno", refno);
        return dw.Update();
    }

    private int UpdateDisbRefNo(long disbrefno, string refno, double tramt)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update transassign set disbrefno=@disbrefno, tramt=@tramt where refno=@refno");
        dw.SetSqlCommandParameters("disbrefno", disbrefno);
        dw.SetSqlCommandParameters("refno", refno);
        dw.SetSqlCommandParameters("tramt", tramt);
        return dw.Update();
    }

    private int UpdateDisbRefNoTemp(long disbrefno, string refno, DateTime trdate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update transassigntemp set disbrefno=@disbrefno, trdate=@trdate where refno=@refno");
        dw.SetSqlCommandParameters("disbrefno", disbrefno);
        dw.SetSqlCommandParameters("trdate", trdate);
        dw.SetSqlCommandParameters("refno", refno);
        return dw.Update();
    }

    public void BatchProcess(DataTable dt)
    {
        cs = new Corrections();
        AccountPosition ap = new AccountPosition();
        cc = new CrTransClass();
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            double tramt = double.Parse(dt.Rows[i]["tramt"].ToString());
            string cracno = dt.Rows[i]["cracno"].ToString();
            string taskid = dt.Rows[i]["taskid"].ToString();
            string trtype = dt.Rows[i]["acsign"].ToString();
            long batchno = long.Parse(dt.Rows[i]["batchno"].ToString());
            DateTime batchdate = DateTime.Parse(dt.Rows[i]["batchdate"].ToString());
            DateTime transdate = DateTime.Parse(dt.Rows[i]["trdate"].ToString());
            string batchrefno = dt.Rows[i]["refno"].ToString();
            string desc = dt.Rows[i]["TrDetail"].ToString();
            string batchusr = "0308Trans";
            int closingmode = 0;
            if (trtype == "CR")
            {
                trtype = "I";
            }
            else
            {
                trtype = "E";
            }


            string refglcode;
            if (cracno.Substring(0, 1) == "9" || cracno.Substring(0, 1) == "0")
            {
                //2010-01-30
                refglcode = cracno;
                //refglcode = cc.GetRefGLCode(cracno);
                if (refglcode == "0")
                {
                    refglcode = cracno;
                }
                cc.InsertTransAssign(refglcode, taskid, tramt, tramt, "N", batchusr, batchdate, "OTHR", trtype, 0, 1, batchno, transdate, desc, batchdate, 0, batchrefno);
            }
            else
            {
                if (taskid == "Normal")
                {
                    DataTable tdt = new DataTable();
                    tdt = GetActOutBal(cracno);
                    double tempoutbal = double.Parse(tdt.Rows[0]["actoutbal"].ToString());
                    if (tempoutbal > 0)
                    {
                        if (batchno == GetBatchNo(cracno))
                        {
                            ap = new AccountPosition();
                            DataTable houspropdata = new DataTable();
                            houspropdata = ap.GetnormalDetails(cracno);
                            double actoutbal = double.Parse(houspropdata.Rows[0]["OutstandBal"].ToString());
                            double intrate = double.Parse(houspropdata.Rows[0]["InterestRate"].ToString());
                            int crcat = int.Parse(houspropdata.Rows[0]["crcat"].ToString());
                            DateTime nextdue = DateTime.Parse(houspropdata.Rows[0]["datedue"].ToString());
                            DateTime datedue = DateTime.Parse(houspropdata.Rows[0]["lastcompletedduedate"].ToString());

                            //if (CheckDueDateinTrans(cracno) == true)
                            //{
                            //    cs.SetTransDateDue(cracno);
                            //    SetDateDue(cracno, nextdue, datedue);
                            //}

                            ap.InsertRecords(cracno, transdate, batchdate, actoutbal, intrate, batchno, crcat, tramt, batchusr, batchrefno, closingmode);
                        }
                        else
                        {
                            DataTable houspropdata = new DataTable();
                            houspropdata = ap.GetnormalDetails(cracno);
                            DateTime nextdue = DateTime.Parse(houspropdata.Rows[0]["datedue"].ToString());
                            DateTime datedue = DateTime.Parse(houspropdata.Rows[0]["lastcompletedduedate"].ToString());

                            //if (CheckDueDateinTrans(cracno) == true)
                            //{
                            //    cs.SetTransDateDue(cracno);
                            //    SetDateDue(cracno, nextdue, datedue);
                            //}
                            ap.GetRecoveryData(cracno, tramt, transdate, batchdate, batchno, batchusr, batchrefno, closingmode);
                            //RecoveryProcess(batchusr, cracno, tramt, transdate, batchno);
                        }
                    }
                    else
                    {
                        cc.InsertTransAssign("903080000000000", "OTHR", tramt, tramt, "N", batchusr, batchdate, "OTHR", "I", 0, 1,
                                   batchno, transdate, cracno + "| Error Entry Account is already closed ", transdate, 0, batchrefno);

                        cc.InsertTransAssign("903081000000987", "OTHR", tramt, tramt, "N", batchusr, batchdate, "OTHR", "I", 0, 1,
                                batchno, transdate, cracno + " Account is already closed Customer return", transdate, 0, batchrefno);

                        cc.InsertTransAssign("903080000000000", "OTHR", tramt, tramt, "N", batchusr, batchdate, "OTHR", "E",
                            0, 1, batchno, transdate, cracno + "|  Error Entry Account is already closed ", transdate, 0, batchrefno);
                    }
                }
                else
                {
                    DataTable temp = new DataTable();
                    temp = GetBaseRecords(cracno);
                    int crcat = int.Parse(temp.Rows[0]["crcat"].ToString());
                    double intrate = double.Parse(temp.Rows[0]["intrate"].ToString());
                    DateTime nextdue = DateTime.Parse(temp.Rows[0]["datedue"].ToString());
                    DateTime datedue = DateTime.Parse(temp.Rows[0]["lastcompletedduedate"].ToString());

                    //if (CheckDueDateinTrans(cracno) == true)
                    //{
                    //    cs.SetTransDateDue(cracno);
                    //    SetDateDue(cracno, nextdue, datedue);
                    //}

                    cc.InsertTransAssign(cracno, taskid, tramt, tramt, "N", batchusr, batchdate, "OTHR", trtype, intrate, 1, batchno, transdate, desc, batchdate, crcat, batchrefno);
                }
            }
        }
    }

    private DataTable SetDataTableTmp(DataTable dt)
    {
        dt = new DataTable();
        DataColumn acsign;
        acsign = new DataColumn();
        acsign.DataType = Type.GetType("System.String");
        acsign.ColumnName = "acsign";
        dt.Columns.Add(acsign);

        DataColumn tramt;
        tramt = new DataColumn();
        tramt.DataType = Type.GetType("System.String");
        tramt.ColumnName = "tramt";
        dt.Columns.Add(tramt);
        return dt;
    }

    public DataTable BatchProcessTmp(DataTable dt)
    {
        double tempBal = 0, temptrBal = 0;
        double cramt = 0, dramt = 0;
        string acsign;
        DataTable tempdata = new DataTable();
        tempdata = SetDataTableTmp(tempdata);
        cs = new Corrections();
        AccountPosition ap = new AccountPosition();
        cc = new CrTransClass();

        for (int i = 0; i < dt.Rows.Count; i++)
        {
            double tramt = double.Parse(dt.Rows[i]["tramt"].ToString());
            string cracno = dt.Rows[i]["cracno"].ToString();
            string taskid = dt.Rows[i]["taskid"].ToString();
            string trtype = dt.Rows[i]["acsign"].ToString();
            long batchno = long.Parse(dt.Rows[i]["batchno"].ToString());
            DateTime batchdate = DateTime.Parse(dt.Rows[i]["batchdate"].ToString());
            DateTime transdate = DateTime.Parse(dt.Rows[i]["trdate"].ToString());
            string batchrefno = dt.Rows[i]["refno"].ToString();
            string desc = dt.Rows[i]["TrDetail"].ToString();
            string batchusr = "0308Trans";
            int closingmode = 0;

            if (cracno == "603080256235")
            {
            }

            if (trtype == "CR")
            {
                trtype = "I";
                tempBal += tramt;
            }
            else
            {
                trtype = "E";
                tempBal -= tramt;
            }
            string refglcode;
            if (cracno.Substring(0, 1) == "9" || cracno.Substring(0, 1) == "0")
            {
                // refglcode = cracno;
                refglcode = cc.GetRefGLCode(cracno);
                if (refglcode == "0")
                {
                    refglcode = cracno;
                }
                switch (trtype)
                {
                    case "I":
                        cramt += tramt;
                        break;

                    case "E":
                        dramt += tramt;
                        break;
                }
            }
            else
            {
                if (taskid == "Normal")
                {
                    DataTable tdt = new DataTable();
                    tdt = GetActOutBal(cracno);
                    double tempoutbal = double.Parse(tdt.Rows[0]["actoutbal"].ToString());
                    if (tempoutbal > 0)
                    {
                        if (batchno == GetBatchNo(cracno))
                        {
                            ap = new AccountPosition();
                            DataTable houspropdata = new DataTable();
                            houspropdata = ap.GetnormalDetails(cracno);
                            double actoutbal = double.Parse(houspropdata.Rows[0]["OutstandBal"].ToString());
                            double intrate = double.Parse(houspropdata.Rows[0]["InterestRate"].ToString());
                            int crcat = int.Parse(houspropdata.Rows[0]["crcat"].ToString());
                            DateTime nextdue = DateTime.Parse(houspropdata.Rows[0]["datedue"].ToString());
                            DateTime datedue = DateTime.Parse(houspropdata.Rows[0]["lastcompletedduedate"].ToString());

                            //if (CheckDueDateinTrans(cracno) == true)
                            //{
                            //    cs.SetTransDateDue(cracno);
                            //    SetDateDue(cracno, nextdue, datedue);

                            //}

                            ap.InsertRecords(cracno, transdate, batchdate, actoutbal, intrate, batchno, crcat, tramt, batchusr,
                                batchrefno, closingmode, cramt, dramt);
                            cramt = ap.CrAmt;
                            dramt = ap.DrAmt;
                        }
                        else
                        {
                            DataTable houspropdata = new DataTable();
                            houspropdata = ap.GetnormalDetails(cracno);
                            DateTime nextdue = DateTime.Parse(houspropdata.Rows[0]["datedue"].ToString());
                            DateTime datedue = DateTime.Parse(houspropdata.Rows[0]["lastcompletedduedate"].ToString());

                            //if (CheckDueDateinTrans(cracno) == true)
                            //{
                            //    cs.SetTransDateDue(cracno);
                            //    SetDateDue(cracno, nextdue, datedue);

                            //}
                            ap.GetRecoveryData(cracno, tramt, transdate, batchdate, batchno, batchusr, batchrefno, closingmode, cramt, dramt);
                            cramt = ap.CrAmt;
                            dramt = ap.DrAmt;
                            //RecoveryProcess(batchusr, cracno, tramt, transdate, batchno);
                        }
                    }
                    else
                    {
                        switch (trtype)
                        {
                            case "I":
                                cramt += tramt;
                                break;

                            case "E":
                                dramt += tramt;
                                break;
                        }
                    }
                }
                else
                {
                    DataTable temp = new DataTable();
                    temp = GetBaseRecords(cracno);
                    int crcat = int.Parse(temp.Rows[0]["crcat"].ToString());
                    double intrate = double.Parse(temp.Rows[0]["intrate"].ToString());
                    DateTime nextdue = DateTime.Parse(temp.Rows[0]["datedue"].ToString());
                    DateTime datedue = DateTime.Parse(temp.Rows[0]["lastcompletedduedate"].ToString());

                    //if (CheckDueDateinTrans(cracno) == true)
                    //{
                    //    cs.SetTransDateDue(cracno);
                    //    SetDateDue(cracno, nextdue, datedue);
                    //}

                    switch (trtype)
                    {
                        case "I":
                            cramt += tramt;
                            break;

                        case "E":
                            dramt += tramt;
                            break;
                    }
                }
            }
            tempBal = Math.Round(tempBal, 2);
            temptrBal = Math.Round(cramt - dramt, 2);
            if (temptrBal == tempBal)
            {

            }
            else
            {
                string ErrorRef = "Error in account" + cracno;
                temptrBal = tempBal - tramt;
                UpdateBatchTmp("903088110309", batchrefno, ErrorRef);
                this.msg += "Error in " + cracno + " account. Temporaly accounted to the suspence \n";
                break;
                this.errorcracno += cracno;
                switch (trtype)
                {
                    case "I":
                        cramt += tramt;
                        break;

                    case "E":
                        dramt += tramt;
                        break;
                }
            }
        }

        cramt = Math.Round(cramt, 2);
        dramt = Math.Round(dramt, 2);

        if (cramt == dramt)
        {
            tempdata = InsertRow("CR", cramt, tempdata);
            tempdata = InsertRow("DR", dramt, tempdata);
        }

        return tempdata;
    }

    private int UpdateBatchTmp(string cracno, string refno, string ErrorRef)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update batchtmp set cracno=@cracno, ErrorRef=@ErrorRef where refno=@refno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("refno", refno);
        dw.SetSqlCommandParameters("ErrorRef", ErrorRef);
        return dw.Update();
    }

    private DataTable SetDataTable(DataTable tempdata)
    {
        throw new NotImplementedException();
    }


    public DataTable GetBaseRecords(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select h.outbal,  h.actoutbal, h.cracno, h.datedue, h.intrate, h.instalment, 
                            h.LastCompletedDueDate, h.graceperiod, h.crperiod-h.paidInstalments as RemainingInstalment,
                            h.LastCompletedDueDate, c.crcat
                            from housprop h, crmast c where h.cracno =@cracno and 
                            c.cracno = h.cracno");
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }

    //public void BatchProcess(DataTable dt)
    //{
    //    AccountPosition ap = new AccountPosition();
    //    cc = new CrTransClass();
    //    for (int i = 0; i < dt.Rows.Count; i++)
    //    {
    //        double tramt = double.Parse(dt.Rows[i]["tramt"].ToString());
    //        string cracno = dt.Rows[i]["cracno"].ToString();
    //        string taskid = dt.Rows[i]["taskid"].ToString();
    //        string trtype = dt.Rows[i]["acsign"].ToString();
    //        long batchno = long.Parse(dt.Rows[i]["batchno"].ToString());
    //        DateTime batchdate = DateTime.Parse(dt.Rows[i]["batchdate"].ToString());
    //        DateTime transdate = DateTime.Parse(dt.Rows[i]["transdate"].ToString());
    //        string batchrefno = dt.Rows[i]["refno"].ToString();
    //        string desc = dt.Rows[i]["TrDetail"].ToString();
    //        string batchusr = "0308Trans";

    //        if (trtype == "CR")
    //        {
    //            trtype = "I";
    //        }
    //        else
    //        {
    //            trtype = "E";
    //        }

    //        string refglcode;
    //        if (cracno.Substring(0, 1) == "9")
    //        {
    //            refglcode = cc.GetRefGLCode(cracno);
    //            if (refglcode == "0")
    //            {
    //                refglcode = cracno;
    //            }
    //            cc.InsertTransAssign(refglcode, taskid, tramt, tramt, "N", batchusr, batchdate, "OTHR", trtype, 0, 1, batchno, transdate, desc, batchdate, 0, batchrefno);
    //        }
    //        else
    //        {
    //            if (batchno == GetBatchNo(cracno))
    //            {
    //                ap = new AccountPosition();
    //                DataTable houspropdata = new DataTable();
    //                houspropdata = ap.GetnormalDetails(cracno);
    //                double actoutbal = double.Parse(houspropdata.Rows[0]["OutstandBal"].ToString());
    //                double intrate = double.Parse(houspropdata.Rows[0]["InterestRate"].ToString());
    //                int crcat = int.Parse(houspropdata.Rows[0]["crcat"].ToString());
    //                ap.InsertRecords(cracno, transdate, batchdate, actoutbal, intrate, batchno, crcat, tramt, batchusr, batchrefno);
    //            }
    //            else
    //            {
    //                ap.GetRecoveryData(cracno, tramt, transdate, batchdate, batchno, batchusr, batchrefno);
    //                //RecoveryProcess(batchusr, cracno, tramt, transdate, batchno);
    //            }
    //        }
    //    }
    //}


    private string GetRecStatus(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select recstatus from housprop where cracno =@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return dw.GetSingleData();
    }

    private long GetBatchNo(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select disbrefno from housprop where cracno =@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return long.Parse(dw.GetSingleData());
    }

    double GetExtTrAmt(string refno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select tramt from transassign where refno =@refno");
        dw.SetSqlCommandParameters("refno", refno);
        return double.Parse(dw.GetSingleData());
    }

    private double GetExtAssAmt(string disbrefno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select tramt from transassign where disbrefno =@disbrefno");
        dw.SetSqlCommandParameters("disbrefno", disbrefno);
        return double.Parse(dw.GetSingleData());
    }


    //    private int UpdateDisbRefNo(string disbrefno, string refno, DateTime trdate, double tramt)
    //    {
    //        dw = new DataWorksClass(constring);
    //        dw.SetCommand(@"update transassign set disbrefno=@disbrefno, trdate=@trdate, tramt=@tramt
    //                        where refno=@refno");
    //        dw.SetSqlCommandParameters("disbrefno", disbrefno);
    //        dw.SetSqlCommandParameters("trdate", trdate);
    //        dw.SetSqlCommandParameters("refno", refno);
    //        dw.SetSqlCommandParameters("tramt", tramt);
    //        return dw.Update();
    //    }

    //    private int UpdateDisbRefNo(string disbrefno, string refno, DateTime trdate)
    //    {
    //        dw = new DataWorksClass(constring);
    //        dw.SetCommand(@"update transassign set disbrefno=@disbrefno, trdate=@trdate
    //                        where refno=@refno");
    //        dw.SetSqlCommandParameters("disbrefno", disbrefno);
    //        dw.SetSqlCommandParameters("trdate", trdate);
    //        dw.SetSqlCommandParameters("refno", refno);
    //        return dw.Update();
    //    }


    private int UpdateDisbRefNoTemp(string disbrefno, string refno, DateTime trdate, double tramt)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update transassigntemp set disbrefno=@disbrefno, trdate=@trdate, tramt=@tramt
                        where refno=@refno");
        dw.SetSqlCommandParameters("disbrefno", disbrefno);
        dw.SetSqlCommandParameters("trdate", trdate);
        dw.SetSqlCommandParameters("refno", refno);
        dw.SetSqlCommandParameters("tramt", tramt);
        return dw.Update();
    }


    public void OtherRecordProcess(DataTable dt)
    {
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            string cracno = dt.Rows[i]["cracno"].ToString();
            string taskid = dt.Rows[i]["taskid"].ToString();
            double assignamt = double.Parse(dt.Rows[i]["tramt"].ToString());
            string adduser = dt.Rows[i]["adduser"].ToString();
            long disbrefno = long.Parse(dt.Rows[i]["batchno"].ToString());
            DateTime adddate = DateTime.Parse(dt.Rows[i]["batchdate"].ToString());
            string trtype = dt.Rows[i]["trtype"].ToString();
            // Insert Interst Portion
            cc.InsertTransAssign(cracno, taskid, assignamt, "N", adduser, adddate, "RECV", trtype, disbrefno);
        }
    }

    private int SetPayments(string cracno)
    {
        return 0;
    }

    public override string ToString()
    {
        return "yyyy-MM-dd 00:00:00.000";
    }


    private double CalculateIntAmount(double outbal, double intrate)
    {
        return Math.Round(outbal * intrate / 1200, 2);
    }

    private double CalculateCapital(double installment, double intAmount, int crcat, double outbal)
    {
        if (crcat != 6)
        {
            if (installment >= outbal)
            {
                return Math.Round(outbal, 2);
            }
            else
            {
                return Math.Round(installment - intAmount, 2);
            }
        }
        else
        {
            return 0;
        }
    }

    public string GetPenalRecords(DateTime datedue)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter("");
        return "";
    }


    private double CalculatePenal(DateTime workingDate, double penalint, int graceperiod, string cracno, DateTime datedue, double installment, int crcat)
    {
        if ((crcat == 9 || crcat == 11) && (cracno != "603080000215"))
        {
            penalint = 0;
        }
        DataTable basicRec = new DataTable(); //Loan Number Table
        int i = 0; //count of no of loans based on the date due
        //workingDate = workingDate.AddDays(-1);

        int noofdue; // Due Months
        int dayDD; // Due Day
        int dayWD; // Working Day
        int monthDD; // Due Month
        int monthWD; // Working Month
        int yearDD; // Due Year
        int yearWd; // Working Year
        double penal; // Penal Charges

        //Get date and Month From the Working Date and Due Date
        dayDD = datedue.Day;
        dayWD = workingDate.Day;
        monthDD = datedue.Month;
        monthWD = workingDate.Month;
        yearDD = datedue.Year;
        yearWd = workingDate.Year;

        if (dayDD > dayWD)
        {
            noofdue = (yearWd * 12 + monthWD) - (yearDD * 12 + monthDD);
        }
        else
        {
            noofdue = (yearWd * 12 + monthWD) - (yearDD * 12 + monthDD) + 1;
        }

        //Reduce the Grace Period
        noofdue = noofdue - graceperiod;

        // Penal calculation
        return Math.Round((installment * penalint * noofdue) / 1200, 2);

    }

    //2009-06-21 vihanga
    public DateTime GetDueDate(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand("select datedue from housprop where cracno=@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return Convert.ToDateTime(dw.GetSingleData());
    }

    public void GetTransTempData(string batchno, DateTime date)
    {
        cc = new CrTransClass();
        DataTable dt = new DataTable();
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"SELECT [TransNo],[CrAcNo],[AssignAmt],[TrAmt],[IsReady],[TrStatus]
      ,[AddUser],[AddDate],[DateDue],[IntRate],[TransRef],[TaskID],[TrType]
      ,[DisbRefNo],[PaymentStage],[RecOrder],[System],[CrCat],[Description]
      ,[trdate] from TransAssignTemp where disbrefno = @batchno and TrDate=@date");
        dw.SetDataAdapterParameters("batchno", batchno);
        dw.SetDataAdapterParameters("date", date);
        dt = dw.GetDataTable();
        dw.SetCommand();
        dw.InsertBulk(dt, "TransAssign");
    }

    public int DeleteTransTemp(string disbrefno, DateTime trdate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"delete from transassigntemp where disbrefno = @disbrefno and trdate=@trdate");
        dw.SetSqlCommandParameters("disbrefno", disbrefno);
        dw.SetSqlCommandParameters("trdate", trdate);
        return dw.Delete();
    }

    public bool CheckDateDue(string cracno)
    {
        DataTable dt = new DataTable();
        dt = GetBaseRecords(cracno);
        DateTime edatedue = DateTime.Parse(dt.Rows[0]["lastcompletedduedate"].ToString());
        DateTime enextdue = DateTime.Parse(dt.Rows[0]["DateDue"].ToString());

        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select isnull(max(Datedue), '1/1/1900') as capdcount from transassign 
                        where cracno=@cracno 
                        and trstatus<>'C' and transref != 'DISB' and trtype = 'I'
                         and (system <> 'M' or system is null)");
        dw.SetSqlCommandParameters("cracno", cracno);
        DateTime date = DateTime.Parse(dw.GetSingleData());
        if (date == DateTime.Parse("01/01/2009"))
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public void SetDateDue(string cracno, DateTime edatedue, DateTime eLdatedue)
    {
        Class1 cs = new Class1();
        int capitalcount = cs.GetCapitalCount(cracno);
        if (capitalcount > 0)
        {
            DataTable dtamt = new DataTable();
            dtamt = cs.GeTrAndAssgAmt(cracno);
            try
            {
                double tramt = double.Parse(dtamt.Rows[0]["tramt"].ToString());
                double assgamt = double.Parse(dtamt.Rows[0]["assignamt"].ToString());
                DateTime maxdatedue = cs.GetMaxDateDue(cracno);
                if (maxdatedue != DateTime.Parse("1/1/0001"))
                {
                    DateTime nLdatedue = new DateTime();
                    DateTime ndatedue = new DateTime();
                    if (tramt == assgamt)
                    {
                        nLdatedue = maxdatedue.AddMonths(capitalcount);
                        ndatedue = maxdatedue.AddMonths(capitalcount);
                    }
                    if (tramt < assgamt)
                    {
                        nLdatedue = maxdatedue.AddMonths(capitalcount - 1);
                        ndatedue = maxdatedue.AddMonths(capitalcount);
                    }

                    if (edatedue != ndatedue)
                    {
                        InsertToTemp(cracno, eLdatedue, edatedue, nLdatedue, ndatedue);
                    }

                    if (eLdatedue != nLdatedue)
                    {
                        InsertToTemp(cracno, eLdatedue, edatedue, nLdatedue, ndatedue);
                    }

                    this.datedue = nLdatedue;
                    this.nextdue = ndatedue;
                    cs.updateHousPropDueDates(cracno, nLdatedue, ndatedue);
                }
                else
                {
                    this.datedue = eLdatedue;
                    this.nextdue = edatedue;
                }
            }
            catch (Exception ex)
            {
                this.datedue = eLdatedue;
                this.nextdue = edatedue;
            }
        }
        else
        {
            this.datedue = eLdatedue;
            this.nextdue = eLdatedue.AddMonths(1);
        }
    }
    private int InsertToTemp(string cracno, DateTime eLdatedue, DateTime edatedue, DateTime nLdatedue, DateTime ndatedue)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO tempTable (cracno,eLdatedue,edatedue,nLdatedue,ndatedue) VALUES
                       (@cracno,@eLdatedue,@edatedue,@nLdatedue ,@ndatedue)");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("eLdatedue", eLdatedue);
        dw.SetSqlCommandParameters("edatedue", edatedue);
        dw.SetSqlCommandParameters("nLdatedue", nLdatedue);
        dw.SetSqlCommandParameters("ndatedue", ndatedue);
        return dw.Insert();
    }

    public DataTable RecoveryProcessTemp(string cracno, double tramt, DateTime trdate, DataTable dt)
    {
        cs = new Corrections();
        DateTime recoveryProcessDate = new DateTime();
        fc = new FunctionClass();
        cc = new CrTransClass();
        rc = new Recovery();
        double intamount = 0, capital = 0, penal = 0;
        int RecOrder = 0;
        DataTable basicRec = new DataTable(); //Loan Number Table


        basicRec = GetBaseRecords("A", cracno);
        if (basicRec.Rows.Count != 0)
        {
            try
            {
                double t = GetOutBal(cracno);
                actoutbal = Math.Round(Convert.ToDouble(basicRec.Rows[0]["actoutbal"].ToString()), 2);
                outbal = SubstractAmount(actoutbal, GetOutBal(cracno));
            }
            catch
            {
                outbal = 0;
            }
            double intrate = 0;
            try
            {
                intrate = Convert.ToDouble(basicRec.Rows[0]["intrate"].ToString());
            }
            catch
            {
                intrate = 0;
            }
            double installment = Convert.ToDouble(basicRec.Rows[0]["instalment"].ToString());

            // Graceperiod
            int graceperiod = int.Parse(basicRec.Rows[0]["graceperiod"].ToString());
            this.datedue = DateTime.Parse(basicRec.Rows[0]["LastCompletedDueDate"].ToString());
            int crcat = int.Parse(basicRec.Rows[0]["crcat"].ToString());
            this.nextdue = DateTime.Parse(basicRec.Rows[0]["datedue"].ToString());

            //SetDateDue(cracno, nextdue, datedue);
            //if (CheckDueDateinTrans(cracno) == true)
            //{
            //    cs.SetTransDateDue(cracno);
            //}
            DateTime penaldate = DateTime.Parse("01/01/1900");
            Double penalarreas = 0;
            int loopno = 0;
            string nextduedisplay = fc.GetDisplayDate(datedue);
            double arreasamt, assignamt;
            string arreastask, refno;
            //Calculate Penal
            DataTable arreasdata = new DataTable();
            arreasdata = GetArreasAmount(cracno, "P", "N");
            DateTime edatedue;
            if (arreasdata.Rows.Count > 0)
            {

                arreasamt = double.Parse(arreasdata.Rows[0]["arreas"].ToString());
                arreastask = arreasdata.Rows[0]["taskid"].ToString();
                refno = arreasdata.Rows[0]["refno"].ToString();
                assignamt = double.Parse(arreasdata.Rows[0]["assignamt"].ToString());
                try
                {
                    edatedue = DateTime.Parse(arreasdata.Rows[0]["datedue"].ToString());
                }
                catch
                {
                    edatedue = datedue;
                }
                nextduedisplay = fc.GetDisplayDate(edatedue);
                if (arreastask == "PNLR")
                {
                    if (arreasamt <= tramt)
                    {
                        dt = InsertRow(refno, cracno, assignamt, arreasamt, nextduedisplay, "P", "PNLR", dt);
                        tramt = SubstractAmount(tramt, arreasamt);
                    }
                    else
                    {
                        if (arreasamt != 0)
                        {
                            dt = InsertRow(refno, cracno, assignamt, tramt, nextduedisplay, "P", "PNLR", dt);
                        }
                        tramt = 0;
                    }
                    penaldate = edatedue;
                    penalarreas = assignamt;

                }
            }
            RecOrder = fc.GetRecordOrder(cracno);
            DataTable arreasanstalmentdata = new DataTable();
            //arreasanstalmentdata = GetArreasInstalment(cracno, nextdatedue);
            arreasanstalmentdata = GetArreasInstalment(cracno);
            if (arreasanstalmentdata.Rows.Count > 0)
            {
                edatedue = datedue;
                double arreasTot = 0;
                for (int i = 0; arreasanstalmentdata.Rows.Count > i; i++)
                {
                    arreasamt = double.Parse(arreasanstalmentdata.Rows[i]["arreas"].ToString());
                    arreasTot = AddAmount(arreasTot, arreasamt);
                    try
                    {
                        edatedue = DateTime.Parse(arreasanstalmentdata.Rows[i]["datedue"].ToString());
                    }
                    catch
                    {
                        edatedue = datedue;
                    }
                }

                recoveryProcessDate = GetPenalValidDate(cracno);
                if (recoveryProcessDate <= trdate)
                {
                    int penalInt = int.Parse(GetPenalInt("PEN", edatedue));
                    
                    penal = CalculatePenal(trdate, penalInt, graceperiod, cracno, edatedue, arreasTot, crcat);
                    //Insert Penal

                    if (penal > 0)
                    {
                        nextduedisplay = fc.GetDisplayDate(edatedue);
                        if (penal <= tramt)
                        {
                            dt = InsertRow("0", cracno, penal, penal, nextduedisplay, "N", "PNLR", dt);
                            tramt = SubstractAmount(tramt, penal);
                        }
                        else
                        {
                            if (tramt != 0)
                            {
                                dt = InsertRow("0", cracno, penal, tramt, nextduedisplay, "P", "PNLR", dt);
                                tramt = SubstractAmount(tramt, penal);
                            }
                            tramt = 0;
                        }
                    }
                }

                recoveryProcessDate = fc.SetRecoveryProcessDate(trdate, cracno);

                if (arreasanstalmentdata.Rows.Count > 0)
                {
                    for (int i = 0; arreasanstalmentdata.Rows.Count > i; i++)
                    {
                        string taskid = arreasanstalmentdata.Rows[i]["taskid"].ToString();
                        arreasamt = double.Parse(arreasanstalmentdata.Rows[i]["arreas"].ToString());
                        refno = arreasanstalmentdata.Rows[i]["refno"].ToString();
                        assignamt = double.Parse(arreasanstalmentdata.Rows[i]["assignamt"].ToString());
                        try
                        {
                            edatedue = DateTime.Parse(arreasanstalmentdata.Rows[i]["datedue"].ToString());
                        }
                        catch
                        {
                            edatedue = datedue;
                        }
                        nextduedisplay = fc.GetDisplayDate(edatedue);
                        if (tramt >= arreasamt)
                        {
                            if (arreasamt != 0)
                            {
                                if (arreasamt == assignamt)
                                {
                                    dt = InsertRow(refno, cracno, assignamt, arreasamt, nextduedisplay, "N", taskid, dt);
                                    tramt = SubstractAmount(tramt, arreasamt);
                                }
                                else
                                {
                                    dt = InsertRow(refno, cracno, assignamt, arreasamt, nextduedisplay, "P", taskid, dt);
                                    tramt = SubstractAmount(tramt, arreasamt);
                                }
                            }
                        }
                        else
                        {
                            if (arreasamt > 0)
                            {
                                dt = InsertRow(refno, cracno, assignamt, tramt, nextduedisplay, "P", taskid, dt);
                                tramt = 0;
                            }
                        }


                        //if (taskid == "CAPD")
                        //{
                        //    outbal -= arreasamt;
                        //}
                    }
                }
            }

            else
            {
                recoveryProcessDate = fc.SetRecoveryProcessDate(trdate, cracno);
            }

            while (Math.Round(tramt, 2) > 0)
            {
                if (outbal > 0)
                {
                    if (penaldate == DateTime.Parse("01/01/1900"))
                    {
                        int penalInt = int.Parse(GetPenalInt("PEN", nextdue));
                        penal = CalculatePenal(trdate, penalInt, graceperiod, cracno, nextdue, installment, crcat);
                    }
                    else
                    {
                        int penalInt = int.Parse(GetPenalInt("PEN", penaldate));
                        penal = SubstractAmount(CalculatePenal(trdate, penalInt, graceperiod, cracno, penaldate, installment, crcat), penalarreas);
                        penaldate = DateTime.Parse("01/01/1900");
                    }
                    intamount = CalculateIntAmount(outbal, intrate);
                    capital = CalculateCapital(installment, intamount, crcat, outbal);

                    nextduedisplay = fc.GetDisplayDate(nextdue);
                    // Insert Penal Protion
                    if (penal > 0)
                    {
                        //Insert Penal
                        if (penal <= tramt)
                        {
                            dt = InsertRow("0", cracno, penal, penal, nextduedisplay, "N", "PNLR", dt);
                            tramt = SubstractAmount(tramt, penal);
                        }
                        else
                        {
                            if (tramt != 0)
                            {
                                dt = InsertRow("0", cracno, penal, Math.Round(tramt, 2), nextduedisplay, "P", "PNLR", dt);
                                tramt = 0;
                            }
                        }
                    }

                    // Interest Portion
                    tramt = Math.Round(tramt, 2);
                    //if (Math.Round(tramt, 2) > 0)
                    //{
                    if (intamount > 0)
                    {
                        if (intamount <= tramt)
                        {
                            dt = InsertRow("0", cracno, intamount, intamount, nextduedisplay, "N", "INTR", dt);
                            tramt = SubstractAmount(tramt, intamount);
                        }
                        else
                        {
                            if (tramt != 0)
                            {
                                dt = InsertRow("0", cracno, intamount, Math.Round(tramt, 2), nextduedisplay, "P", "INTR", dt);
                                tramt = 0;
                            }
                            else
                            {
                                dt = InsertRow("0", cracno, intamount, Math.Round(tramt, 2), nextduedisplay, "N", "INTR", dt);
                            }
                        }
                    }
                    tramt = Math.Round(tramt, 2);
                    if (capital > 0)
                    {

                        if (capital <= tramt)
                        {
                            dt = InsertRow("0", cracno, capital, capital, nextduedisplay, "N", "CAPD", dt);
                            tramt = SubstractAmount(tramt, capital);
                        }
                        else
                        {
                            if (tramt != 0)
                            {
                                dt = InsertRow("0", cracno, capital, Math.Round(tramt, 2), nextduedisplay, "P", "CAPD", dt);
                            }
                            else
                            {
                                dt = InsertRow("0", cracno, capital, Math.Round(tramt, 2), nextduedisplay, "N", "CAPD", dt);
                            }
                            tramt = 0;
                        }
                        outbal = SubstractAmount(outbal, capital);
                    }
                    //}

                    nextdue = fc.SetRecoveryDate(nextdue);
                }
                else
                {
                    if (tramt > 1000)
                    {
                        dt = InsertRow("0", "903081000000987", Math.Round(tramt, 2), Math.Round(tramt, 2), nextduedisplay, "N", "OTHR", dt);
                        tramt = 0;
                    }
                    else
                    {
                        t = new Trans();
                        string refglcode = t.GetGlCode(9, 0, "INTR", "RECV", cracno, "0308");
                        dt = InsertRow("0", refglcode, Math.Round(tramt, 2), Math.Round(tramt, 2), nextduedisplay, "N", "OTHR", dt);
                        tramt = 0;
                    }
                }
            }
        }
        return dt;
    }

    public bool CheckDueDateinTrans(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select taskid, datedue, count(datedue) from transassign where cracno = @cracno
                            and (taskid ='CAPD' or taskid = 'INTR')
                            and trstatus <> 'c' and (system is null or system != 'M')
                            group by taskid, datedue
                            having count(datedue) > 2");
        dw.SetDataAdapterParameters("cracno", cracno);
        if (dw.GetDataTable().Rows.Count > 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public DataTable RecoveryProcessTemp(string cracno, DateTime operationdate, DateTime trdate, DataTable dt)
    {
        cs = new Corrections();
        DateTime recoveryProcessDate;
        fc = new FunctionClass();
        cc = new CrTransClass();
        rc = new Recovery();
        double intamount = 0, capital = 0, penal = 0;
        double actoutbal = 0, outbal = 0;
        int RecOrder = 0;
        DataTable basicRec = new DataTable(); //Loan Number Table       


        basicRec = GetBaseRecords("A", cracno);
        //cs.SetTransDateDue(cracno);
        // Set OUtbal from actoutbal
        actoutbal = Math.Round(Convert.ToDouble(basicRec.Rows[0]["actoutbal"].ToString()), 2);
        outbal = Math.Round((actoutbal - GetOutBal(cracno)), 2);

        double intrate = Convert.ToDouble(basicRec.Rows[0]["intrate"].ToString());
        double installment = Convert.ToDouble(basicRec.Rows[0]["instalment"].ToString());
        int graceperiod = int.Parse(basicRec.Rows[0]["graceperiod"].ToString());
        datedue = DateTime.Parse(basicRec.Rows[0]["LastCompletedDueDate"].ToString());
        nextdue = DateTime.Parse(basicRec.Rows[0]["datedue"].ToString());
        string nextduedisplay = fc.GetDisplayDate(datedue);
        int crcat = int.Parse(basicRec.Rows[0]["crcat"].ToString());
        DateTime penalnextdue = DateTime.Parse(basicRec.Rows[0]["datedue"].ToString());
        DateTime penaldate = DateTime.Parse("01/01/1900");
        Double penalarreas = 0;
        double arreasamt, assignamt;
        string arreastask, refno;
        //Calculate Penal
        DataTable arreasdata = new DataTable();
        arreasdata = GetArreasAmount(cracno, "P", "N");
        if (actoutbal > 0)
        {
            DateTime edatedue;
            if (arreasdata.Rows.Count > 0)
            {
                arreasamt = double.Parse(arreasdata.Rows[0]["arreas"].ToString());
                arreastask = arreasdata.Rows[0]["taskid"].ToString();
                refno = arreasdata.Rows[0]["refno"].ToString();
                assignamt = double.Parse(arreasdata.Rows[0]["assignamt"].ToString());
                try
                {
                    edatedue = DateTime.Parse(arreasdata.Rows[0]["datedue"].ToString());
                }
                catch
                {
                    edatedue = datedue;
                }
                nextduedisplay = fc.GetDisplayDate(edatedue);
                if (arreastask == "PNLR")
                {
                    dt = InsertRow(refno, cracno, assignamt, arreasamt, nextduedisplay, "P", "PNLR", dt);
                    penalnextdue = edatedue.AddMonths(1);
                    penaldate = edatedue;
                    penalarreas = assignamt;
                }
            }

            RecOrder = fc.GetRecordOrder(cracno);
            DataTable arreasanstalmentdata = new DataTable();
            arreasanstalmentdata = GetArreasInstalment(cracno, datedue);
            if (arreasanstalmentdata.Rows.Count > 0)
            {
                double arreasTot = 0;
                edatedue = datedue;
                for (int i = 0; arreasanstalmentdata.Rows.Count > i; i++)
                {
                    arreasamt = double.Parse(arreasanstalmentdata.Rows[i]["arreas"].ToString());
                    arreasTot += arreasamt;
                    try
                    {
                        edatedue = DateTime.Parse(arreasanstalmentdata.Rows[i]["datedue"].ToString());
                        nextduedisplay = fc.GetDisplayDate(edatedue);
                    }
                    catch
                    {
                        edatedue = datedue;
                        nextduedisplay = fc.GetDisplayDate(edatedue);
                    }
                }
                recoveryProcessDate = GetPenalValidDate(cracno);

                if (penaldate == DateTime.Parse("01/01/1900"))
                {
                    int penalInt = int.Parse(GetPenalInt("PEN", edatedue));
                    penal = CalculatePenal(trdate, penalInt, graceperiod, cracno, edatedue, arreasTot, crcat);
                }
                else
                {
                    int penalInt = int.Parse(GetPenalInt("PEN", penaldate));
                    penal = SubstractAmount(CalculatePenal(trdate, penalInt, graceperiod, cracno, penaldate, installment, crcat), penalarreas);
                    penaldate = DateTime.Parse("01/01/1900");
                }

                //penal = CalculatePenal(trdate, penalInt, graceperiod, cracno, edatedue, arreasTot, intrate);
                if (recoveryProcessDate <= trdate)
                {
                    if (penal > 0)
                    {
                        dt = InsertRow("0", cracno, penal, penal, nextduedisplay, "N", "PNLR", dt);
                    }
                }
                if (arreasanstalmentdata.Rows.Count > 0)
                {
                    for (int i = 0; arreasanstalmentdata.Rows.Count > i; i++)
                    {
                        string taskid = arreasanstalmentdata.Rows[i]["taskid"].ToString();
                        arreasamt = double.Parse(arreasanstalmentdata.Rows[i]["arreas"].ToString());
                        refno = arreasanstalmentdata.Rows[i]["refno"].ToString();
                        assignamt = double.Parse(arreasanstalmentdata.Rows[i]["assignamt"].ToString());
                        try
                        {
                            edatedue = DateTime.Parse(arreasanstalmentdata.Rows[i]["datedue"].ToString());
                        }
                        catch
                        {
                            edatedue = datedue;
                        }
                        nextduedisplay = fc.GetDisplayDate(edatedue);
                        if (arreasamt > 0)
                        {
                            if (arreasamt == assignamt)
                            {
                                dt = InsertRow(refno, cracno, assignamt, arreasamt, nextduedisplay, "N", taskid, dt);
                            }
                            else
                            {
                                dt = InsertRow(refno, cracno, assignamt, arreasamt, nextduedisplay, "P", taskid, dt);
                            }
                        }

                        //if (taskid == "CAPD")
                        //{
                        //    outbal -= arreasamt;
                        //}
                    }
                }
            }

            if (outbal > installment)
            {
                if (trdate >= nextdue)
                {
                    while (trdate >= nextdue)
                    {
                        int penalInt = int.Parse(GetPenalInt("PEN", nextdue));
                        penal = CalculatePenal(trdate, penalInt, graceperiod, cracno, nextdue, installment, crcat);
                        intamount = CalculateIntAmount(outbal, intrate);
                        capital = CalculateCapital(installment, intamount, crcat, outbal);
                        nextduedisplay = fc.GetDisplayDate(nextdue);
                        //Set Penal Valid date
                        recoveryProcessDate = fc.SetRecoveryProcessDate(trdate, cracno);
                        //UpdatePenalValidDate(cracno, recoveryProcessDate);
                        // Insert Penal Portion
                        if (penal > 0)
                        {
                            dt = InsertRow("0", cracno, penal, penal, nextduedisplay, "N", "PNLR", dt);
                        }

                        // Interest Portion
                        dt = InsertRow("0", cracno, intamount, intamount, nextduedisplay, "N", "INTR", dt);

                        // Capital Portion
                        dt = InsertRow("0", cracno, capital, capital, nextduedisplay, "N", "CAPD", dt);
                        outbal -= capital;
                        outbal = Math.Round(outbal, 2);

                        //SetPayments Next Due
                        nextdue = fc.SetRecoveryDate(nextdue);
                    }
                    datedue = nextdue.AddMonths(-1);
                }
            }
            else
            {
                while (trdate >= penalnextdue)
                {
                    int penalInt = int.Parse(GetPenalInt("PEN", penalnextdue));
                    penal = CalculatePenal(trdate, penalInt, graceperiod, cracno, penalnextdue, installment, crcat);
                    if (penal > 0)
                    {
                        dt = InsertRow("0", cracno, penal, penal, nextduedisplay, "N", "PNLR", dt);
                    }
                    penalnextdue = fc.SetRecoveryDate(penalnextdue);
                    nextduedisplay = fc.GetDisplayDate(penalnextdue);
                }
                datedue = penalnextdue.AddMonths(-1);
            }
        }
        else
        {
            outbal = 0;
        }
        intdatedue = nextdue.AddMonths(-1);
        this.outbal = outbal;
        return dt;
    }

    public double SubstractAmount(double mainamount, double subamount)
    {
        return Math.Round((mainamount - subamount), 2);
    }

    public double AddAmount(double mainamount, double subamount)
    {
        return Math.Round((mainamount + subamount), 2);
    }

    private double GetOutBal(string cracno)
    {
        double outbalE = GetOutBalE(cracno);
        double outbalI = GetOutBalI(cracno);
        return Math.Round((outbalI - outbalE), 2);
    }



    private double GetOutBalI(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select (select isnull(sum(assignamt),0) as diff from transassign where cracno=@cracno
                        and taskid='CAPD' and trstatus = 'N' and trtype = 'I') +
                        (select isnull(sum(assignamt),0) as diff from transassign where cracno=@cracno
                        and taskid='CAPD' and trstatus = 'P' and trtype = 'I' and transno is null and system is null) +
                        (select isnull(sum(assignamt-tramt),0) as diff from transassign where cracno=@cracno
                        and taskid='CAPD' and trstatus = 'P' and trtype = 'I' and transno is not null) +
                        (select isnull(sum(assignamt-tramt),0) as diff from transassign where cracno=@cracno
                        and taskid='CAPD' and trstatus = 'P' and trtype = 'I' and transno is null and system = 'T')");
        dw.SetSqlCommandParameters("cracno", cracno);
        return double.Parse(dw.GetSingleData());
    }

    private double GetOutBalE(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select isnull(sum(tramt),0) as diff from transassign where cracno=@cracno
                        and taskid='CAPD' and trstatus = 'N' and trtype = 'E'");
        dw.SetSqlCommandParameters("cracno", cracno);
        return double.Parse(dw.GetSingleData());
    }




    private DataTable InsertRow(string refno, string cracno, double assignamt, double tramt, string datedue,
        string trstatus, string taskid, DataTable dt)
    {
        DataRow dr;
        dr = dt.NewRow();
        dr["refno"] = refno;
        dr["cracno"] = cracno;
        dr["assignamt"] = assignamt;
        dr["tramt"] = tramt;
        dr["datedue"] = datedue;
        dr["trstatus"] = trstatus;
        dr["taskid"] = taskid;
        dt.Rows.Add(dr);
        return dt;
    }

    private DataTable InsertRow(string acsign, double tramt, DataTable dt)
    {
        DataRow dr;
        dr = dt.NewRow();
        dr["acsign"] = acsign;
        dr["tramt"] = tramt;
        dt.Rows.Add(dr);
        return dt;
    }

    private DataTable InsertRow(string cracno, double tramt, string datedue, string trstatus, string taskid, DataTable dt)
    {
        if (taskid == "CAPD")
        {
            DataRow dr;
            dr = dt.NewRow();
            dr["cracno"] = cracno;
            dr["tramt"] = tramt;
            dr["datedue"] = datedue;
            dr["trstatus"] = trstatus;
            dr["taskid"] = taskid;
            dt.Rows.Add(dr);
        }
        else
        {
            if (tramt != 0)
            {
                DataRow dr;
                dr = dt.NewRow();
                dr["cracno"] = cracno;
                dr["tramt"] = tramt;
                dr["datedue"] = datedue;
                dr["trstatus"] = trstatus;
                dr["taskid"] = taskid;
                dt.Rows.Add(dr);
            }
        }
        return dt;
    }

    private int UpdatePenalValidDate(string cracno, DateTime PenalValidDate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update housprop set PenalValidDate=@PenalValidDate where cracno =@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("PenalValidDate", PenalValidDate);
        return dw.Update();
    }

    private DateTime GetPenalValidDate(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select case when PenalValidDate is null 
                        then '01/01/1900' 
                        else PenalValidDate end as PenalValidDate 
                        from housprop where cracno =@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return DateTime.Parse(dw.GetSingleData());
    }


    private DataTable GetArreasAmount(string cracno, string trstatus1, string trstatus2)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select refno, assignamt, assignamt-tramt as arreas, taskid, datedue from  transassign 
                            where cracno =  @cracno and trtype = 'I' and taskid = 'PNLR'
                            and tramt != assignamt  and (trstatus = @trstatus1 or trstatus = @trstatus2)");
        dw.SetDataAdapterParameters(@"cracno", cracno);
        dw.SetDataAdapterParameters(@"trstatus1", trstatus1);
        dw.SetDataAdapterParameters(@"trstatus2", trstatus2);
        return dw.GetDataTable();
    }

    //Datedue Removed
    //Change Dilanka 24032010
    private DataTable GetArreasInstalment(string cracno, DateTime datedue)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select refno, assignamt, assignamt-tramt as arreas, taskid, datedue from  transassign 
                            where cracno =  @cracno and (trstatus = 'p' or trstatus='n') and trtype = 'I'
                            and (taskid = 'capd' or taskid = 'intr') and tramt != assignamt and datedue <= @datedue");
        dw.SetDataAdapterParameters(@"cracno", cracno);
        dw.SetDataAdapterParameters(@"datedue", datedue);
        return dw.GetDataTable();
    }

    private DataTable GetArreasInstalment(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select refno, assignamt, assignamt-tramt as arreas, taskid, datedue from  transassign 
                            where cracno =  @cracno and (trstatus = 'p' or trstatus='n') and trtype = 'I'
                            and (taskid = 'capd' or taskid = 'intr')  and tramt != assignamt");
        dw.SetDataAdapterParameters(@"cracno", cracno);
        return dw.GetDataTable();
    }



    public void AddPAyments(string taskid, double tramt)
    {
        switch (taskid)
        {
            case "CAPD":
                this.captotal += tramt;
                break;


            case "INTR":
                this.inttotal += tramt;
                break;

            case "PNLT":
                this.penaltotal += tramt;
                break;
        }
    }


    public DataTable SetArreasAmountsTemp(string cracno, DateTime trdate, DataTable setclosingdata, double actoutbal)
    {
        if (actoutbal != 0)
        {
            DateTime datedue = new DateTime(); //Set Date Due for advance payments
            fc = new FunctionClass();
            rc = new Recovery();
            DataTable dt = new DataTable();
            cc = new CrTransClass();
            dt = GetAdvancePayments(cracno, trdate, "C");
            double execesspayment = 0;
            for (int a = 0; a < dt.Rows.Count; a++)
            {
                double rectramount = double.Parse(dt.Rows[a]["tramt"].ToString());
                double recassignamount = double.Parse(dt.Rows[a]["assignamt"].ToString());
                string rectaskid = dt.Rows[a]["taskid"].ToString();
                string rectransacref = dt.Rows[a]["transref"].ToString();
                double recintrate = double.Parse(dt.Rows[a]["intrate"].ToString());
                int recrecOrder = int.Parse(dt.Rows[a]["recOrder"].ToString());
                //int recdisbrefno = int.Parse(dt.Rows[a]["disbrefno"].ToString());
                DateTime rectrDate = DateTime.Parse(dt.Rows[a]["trDate"].ToString());
                string recdescription = dt.Rows[a]["trDate"].ToString();
                DateTime recduedate = DateTime.Parse(dt.Rows[a]["datedue"].ToString());
                int reccrcate = int.Parse(dt.Rows[a]["crcat"].ToString());
                string displayduedate = fc.GetDisplayDate(recduedate);
                if (rectramount != 0)
                {
                    if (rectaskid != "CAPD")
                    {
                        setclosingdata = InsertRow(cracno, -rectramount, displayduedate, "F", rectaskid, setclosingdata);
                        execesspayment += rectramount;
                    }
                    else
                    {
                        actoutbal += rectramount;
                        datedue = recduedate;
                        //setclosingdata = InsertRow(cracno, recassignamount-rectramount, displayduedate, "F", rectaskid, setclosingdata);
                        //execesspayment += (recassignamount - rectramount);
                    }
                }

            }
            // To show the exxecc payments
            if (dt.Rows.Count > 0)
            {
                this.exesspayment = execesspayment;
                this.outbal = actoutbal;
                this.datedue = datedue;
            }
        }
        return setclosingdata;
        //Pudate outbal to previuose state
    }

    public DataTable GetActOutBal(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select h.actoutbal,c.appno from housprop h,crmast c where c.cracno = h.cracno and h.cracno = @cracno");
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }

    public DataTable GetAdvancePayments(string cracno, DateTime today, string trstatus)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from transassign where datedue>=@today and 
                            cracno =@cracno and (trstatus!=@trstatus)
                            and (system != 'M' or system is null)
                            order by datedue desc");
        dw.SetDataAdapterParameters("today", today);
        dw.SetDataAdapterParameters("cracno", cracno);
        dw.SetDataAdapterParameters("trstatus", trstatus);
        return dw.GetDataTable();
    }

    public int SetOutBal(string cracno, double recoutbal)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update housprop set outbal=@recoutbal where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("recoutbal", recoutbal);
        return dw.Update();
    }


    public DataTable AmortizationShedule(string cracno, DateTime operationdate, DateTime trdate /*, DataTable dt*/)
    {
        DataTable dt = new DataTable();
        dt = SetAmtzDataTable(dt);

        cs = new Corrections();
        DateTime recoveryProcessDate;
        fc = new FunctionClass();
        cc = new CrTransClass();
        rc = new Recovery();
        double intamount = 0, capital = 0, penal = 0;
        double actoutbal = 0, outbal = 0;
        int RecOrder = 0;
        DataTable basicRec = new DataTable(); //Loan Number Table       


        basicRec = GetBaseRecords("A", cracno);
        //cs.SetTransDateDue(cracno);
        // Set OUtbal from actoutbal
        actoutbal = Math.Round(Convert.ToDouble(basicRec.Rows[0]["actoutbal"].ToString()), 2);
        outbal = Math.Round((actoutbal - GetOutBal(cracno)), 2);

        double intrate = Convert.ToDouble(basicRec.Rows[0]["intrate"].ToString());
        double installment = Convert.ToDouble(basicRec.Rows[0]["instalment"].ToString());
        int graceperiod = int.Parse(basicRec.Rows[0]["graceperiod"].ToString());
        datedue = DateTime.Parse(basicRec.Rows[0]["LastCompletedDueDate"].ToString());
        nextdue = DateTime.Parse(basicRec.Rows[0]["datedue"].ToString());
        string nextduedisplay = fc.GetDisplayDate(datedue);
        int crcat = int.Parse(basicRec.Rows[0]["crcat"].ToString());
        DateTime penalnextdue = DateTime.Parse(basicRec.Rows[0]["datedue"].ToString());
        DateTime penaldate = DateTime.Parse("01/01/1900");
        Double penalarreas = 0;
        double arreasamt, assignamt;
        string arreastask;
        int refno = 1;
        //Calculate Penal
        DataTable arreasdata = new DataTable();
        arreasdata = GetArreasAmount(cracno, "P", "N");
        if (actoutbal > 0)
        {
            DateTime edatedue;
            if (arreasdata.Rows.Count > 0)
            {
                arreasamt = double.Parse(arreasdata.Rows[0]["arreas"].ToString());
                arreastask = arreasdata.Rows[0]["taskid"].ToString();
                //refno = arreasdata.Rows[0]["refno"].ToString();
                assignamt = double.Parse(arreasdata.Rows[0]["assignamt"].ToString());
                try
                {
                    edatedue = DateTime.Parse(arreasdata.Rows[0]["datedue"].ToString());
                }
                catch
                {
                    edatedue = datedue;
                }
                nextduedisplay = fc.GetDisplayDate(edatedue);
               
            }

            RecOrder = fc.GetRecordOrder(cracno);
            DataTable arreasanstalmentdata = new DataTable();
            arreasanstalmentdata = GetArreasInstalment(cracno, datedue);
            if (arreasanstalmentdata.Rows.Count > 0)
            {
                double arreasTot = 0;
                edatedue = datedue;
                for (int i = 0; arreasanstalmentdata.Rows.Count > i; i++)
                {
                    arreasamt = double.Parse(arreasanstalmentdata.Rows[i]["arreas"].ToString());
                    arreasTot += arreasamt;
                    try
                    {
                        edatedue = DateTime.Parse(arreasanstalmentdata.Rows[i]["datedue"].ToString());
                        nextduedisplay = fc.GetDisplayDate(edatedue);
                    }
                    catch
                    {
                        edatedue = datedue;
                        nextduedisplay = fc.GetDisplayDate(edatedue);
                    }
                }
                recoveryProcessDate = GetPenalValidDate(cracno);

                if (arreasanstalmentdata.Rows.Count > 0)
                {
                    double capd = 0;
                    double interst = 0;
                    for (int i = 0; arreasanstalmentdata.Rows.Count > i; i++)
                    {
                        string taskid = arreasanstalmentdata.Rows[i]["taskid"].ToString();
                        arreasamt = double.Parse(arreasanstalmentdata.Rows[i]["arreas"].ToString());
                        //refno = arreasanstalmentdata.Rows[i]["refno"].ToString();
                        assignamt = double.Parse(arreasanstalmentdata.Rows[i]["assignamt"].ToString());
                        try
                        {
                            edatedue = DateTime.Parse(arreasanstalmentdata.Rows[i]["datedue"].ToString());
                        }
                        catch
                        {
                            edatedue = datedue;
                        }
                        nextduedisplay = fc.GetDisplayDate(edatedue);
                        if (arreasamt > 0)
                        {
                            
                        }

                        if (taskid == "CAPD")
                        {
                            outbal -= arreasamt;
                            capd = arreasamt;

                        }
                        else if (taskid == "INTR")
                        {
                            interst = arreasamt;
                        }
                    } //End of for loop

                    dt = InsertRow(refno.ToString(), cracno, capd, interst, outbal, dt);
                    refno = refno + 1;
                }
            }

            if (outbal > installment)
            {
                while (outbal > 0)
                {
                    intamount = CalculateIntAmount(outbal, intrate);
                    capital = CalculateCapital(installment, intamount, crcat, outbal);
                    nextduedisplay = fc.GetDisplayDate(nextdue);
                    //Set Penal Valid date
                    recoveryProcessDate = fc.SetRecoveryProcessDate(trdate, cracno);
                    // Interest Portion
                    outbal -= capital;
                    outbal = Math.Round(outbal, 2);

                    dt = InsertRow(refno.ToString(), cracno, capital, intamount, outbal, dt);


                    //SetPayments Next Due
                    nextdue = fc.SetRecoveryDate(nextdue);
                    refno = refno + 1;
                }

                datedue = nextdue.AddMonths(-1);
            }
        }
        else
        {
            outbal = 0;
        }
        intdatedue = nextdue.AddMonths(-1);
        this.outbal = outbal;
        return dt;
    }

    private DataTable SetAmtzDataTable(DataTable dt)
    {
        dt = new DataTable();
        DataColumn refno;
        refno = new DataColumn();
        refno.DataType = Type.GetType("System.String");
        refno.ColumnName = "Refno";
        dt.Columns.Add(refno);

        DataColumn cracno;
        cracno = new DataColumn();
        cracno.DataType = Type.GetType("System.String");
        cracno.ColumnName = "Cracno";
        dt.Columns.Add(cracno);

        DataColumn Capd;
        Capd = new DataColumn();
        Capd.DataType = Type.GetType("System.String");
        Capd.ColumnName = "Capd";
        dt.Columns.Add(Capd);

        DataColumn Intr;
        Intr = new DataColumn();
        Intr.DataType = Type.GetType("System.String");
        Intr.ColumnName = "Intr";
        dt.Columns.Add(Intr);

        DataColumn outbal;
        outbal = new DataColumn();
        outbal.DataType = Type.GetType("System.String");
        outbal.ColumnName = "Outbal";
        dt.Columns.Add(outbal);

        return dt;

    }


    private DataTable InsertRow(string refno, string cracno, double Capd, double Intr, double outbal, DataTable dt)
    {
        DataRow dr;
        dr = dt.NewRow();
        dr["refno"] = refno;
        dr["cracno"] = cracno;
        dr["Capd"] = Capd;
        dr["Intr"] = Intr;
        dr["outbal"] = outbal;
        dt.Rows.Add(dr);
        return dt;
    }


    public void GetCapInt(string cracno, DateTime fromdate, DateTime operationdate, DateTime trdate /*, DataTable dt*/)
    {
        cs = new Corrections();
        DateTime recoveryProcessDate;
        fc = new FunctionClass();
        cc = new CrTransClass();
        rc = new Recovery();
        double intamount = 0, capital = 0;
        double actoutbal = 0, outbal = 0;
        captotal = 0; inttotal = 0;
        int RecOrder = 0;
        DataTable basicRec = new DataTable(); //Loan Number Table       


        basicRec = GetBaseRecords("A", cracno);
        // Set OUtbal from actoutbal
        actoutbal = Math.Round(Convert.ToDouble(basicRec.Rows[0]["actoutbal"].ToString()), 2);
        outbal = Math.Round((actoutbal - GetOutBal(cracno)), 2);
        DataTable arreasanstalmentdata = new DataTable();
        double intrate = Convert.ToDouble(basicRec.Rows[0]["intrate"].ToString());
        double installment = Convert.ToDouble(basicRec.Rows[0]["instalment"].ToString());
        int graceperiod = int.Parse(basicRec.Rows[0]["graceperiod"].ToString());
        datedue = DateTime.Parse(basicRec.Rows[0]["LastCompletedDueDate"].ToString());
        nextdue = DateTime.Parse(basicRec.Rows[0]["datedue"].ToString());
        int crcat = int.Parse(basicRec.Rows[0]["crcat"].ToString());
        DateTime penalnextdue = DateTime.Parse(basicRec.Rows[0]["datedue"].ToString());
        if (fromdate > datedue)
        {

            while (fromdate >= nextdue)
            //while (outbal > 0)
            {
                if (crcat == 9)
                {
                    if (nextdue.Month == 4 || nextdue.Month == 12)
                    {
                        nextdue = fc.SetRecoveryDate(nextdue);
                    }
                }

                intamount = CalculateIntAmount(outbal, intrate);
                capital = CalculateCapital(installment, intamount, crcat, outbal);
                outbal -= capital;
                outbal = Math.Round(outbal, 2);
                nextdue = fc.SetRecoveryDate(nextdue);
            }

        }
        else
        {
            string nextduedisplay = fc.GetDisplayDate(datedue);

            DateTime penaldate = DateTime.Parse("01/01/1900");
            Double penalarreas = 0;
            double arreasamt, assignamt;
            string arreastask;
            int refno = 1;
            //Calculate Penal
            DataTable arreasdata = new DataTable();
            arreasdata = GetArreasAmount(cracno, "P", "N");
            if (actoutbal > 0)
            {
                DateTime edatedue;

                //RecOrder = fc.GetRecordOrder(cracno);
               
                arreasanstalmentdata = GetArreasInstalment(cracno, datedue);
                if (arreasanstalmentdata.Rows.Count > 0)
                {

                    for (int i = 0; arreasanstalmentdata.Rows.Count > i; i++)
                    {
                        string taskid = arreasanstalmentdata.Rows[i]["taskid"].ToString();
                        arreasamt = double.Parse(arreasanstalmentdata.Rows[i]["arreas"].ToString());

                        if (taskid == "CAPD")
                        {
                            //outbal -= arreasamt;
                            captotal += arreasamt;
                        }
                        else if (taskid == "INTR")
                        {
                            inttotal += arreasamt;
                        }
                    } //End of for loop


                }
            }
        }

        if (outbal > installment)
        {

            while (trdate >= nextdue)
            //while (outbal > 0)
            {
                if (crcat == 9)
                {
                    if (nextdue.Month == 4 || nextdue.Month == 12)
                    {
                        nextdue = fc.SetRecoveryDate(nextdue);
                    }
                }

                intamount = CalculateIntAmount(outbal, intrate);
                capital = CalculateCapital(installment, intamount, crcat, outbal);
                outbal -= capital;
                outbal = Math.Round(outbal, 2);
                captotal += capital;
                inttotal += intamount;
                nextdue = fc.SetRecoveryDate(nextdue);
            }
        }
    }

    // Change Dilanka 24032010
    public DataTable GetAccountDetails(string cracno, string datefrom, string dateto)
    {
        dt = new DataTable();
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select(select sum(g.tramt) from gltrans g,transassign t
                                where right(left(g.refglcode,14),6) = '100001'
                                and t.datedue >= @datefrom and t.datedue < @dateto and g.cracno = @cracno
                                and g.acsign = 'CR' and t.cracno=g.cracno and g.transassignrefno=t.refno
                                and g.trstatus != 'C') as capital,
                                (select sum(g.tramt) from gltrans g, transassign t
                                where right(left(g.refglcode,14),6) = '000001' and right(left(g.refglcode,6),1) = '4'
                                and t.datedue >= @datefrom and t.datedue < @dateto and g.cracno = @cracno
                                and g.acsign = 'CR' and t.cracno=g.cracno and g.transassignrefno=t.refno
                                and g.trstatus != 'C') as Interest");
        dw.SetDataAdapterParameters("cracno", cracno);
        dw.SetDataAdapterParameters("datefrom", datefrom);
        dw.SetDataAdapterParameters("dateto", dateto);
        return dw.GetDataTable();
    }

	public int getcrcat(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select crcat from housprop where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return int.Parse(dw.GetSingleData()); 
    }

    public DataTable GetStaffAccountDetails(string cracno, string datefrom, string dateto)
    {
        dt = new DataTable();
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select(select sum(g.tramt) from gltrans g,transassign t
                                where right(left(g.refglcode,14),6) = '100001'
                                and t.trdate >= @datefrom and t.trdate < @dateto and g.cracno = @cracno
                                and g.acsign = 'CR' and t.cracno=g.cracno and g.transassignrefno=t.refno
                                and g.trstatus != 'C') as capital,
                                (select sum(g.tramt) from gltrans g, transassign t
                                where right(left(g.refglcode,14),6) = '000001' and right(left(g.refglcode,6),1) = '4'
                                and t.trdate >= @datefrom and t.trdate < @dateto and g.cracno = @cracno
                                and g.acsign = 'CR' and t.cracno=g.cracno and g.transassignrefno=t.refno
                                and g.trstatus != 'C') as Interest");
        dw.SetDataAdapterParameters("cracno", cracno);
        dw.SetDataAdapterParameters("datefrom", datefrom);
        dw.SetDataAdapterParameters("dateto", dateto);
        return dw.GetDataTable();
    }

    public double getoutbalnew(string cracno, string dateto)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select actoutbal from IntProvisionIndividual where datekey=@dateto and  cracno =@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("dateto", dateto);
        return double.Parse(dw.GetSingleData());  
        
    }
}


