using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// Summary description for FacilityPaperDetails
/// </summary>
public class FacilityPaperDetails
{
    private SqlDataAdapter da;
    DataSet ds;
    private SqlConnection mycon;
    DataWorksClass dw;
    string constring = ConfigurationManager.ConnectionStrings["housdbstring"].ConnectionString.ToString();

	public FacilityPaperDetails()
	{
        //SqlConnection myconnection = new SqlConnection(ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString);
        //this.mycon = myconnection;
	}

    public DataTable LoadFacilityPaperComment()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"SELECT * FROM FacilityPaperCom");
        return dw.GetDataTable();
    }

    public int InsertFacilityComments(string appno, string description, int commentid, int updateLevel)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO FacilityPaperDetails (AppNo,FacilityDescrip,CommentId,UpdateLevel)
                       values (@appno,@description,@commentid,@updatelevel)");
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("description", description);
        dw.SetSqlCommandParameters("commentid", commentid);
        dw.SetSqlCommandParameters("updateLevel", updateLevel);
        return dw.Insert();
    }

    public DataTable GetFacilityPaperDetails(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"SELECT f.CommentId AS CommentId, CommentDes, FacilityDescrip FROM 
                            FacilityPaperCom f, FacilityPaperDetails d WHERE
                            f.Commentid = d.CommentId AND AppNo=@appno");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();
    }


    public DataTable GetFacilityPaper(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"SELECT CommentId, CommentDes FROM FacilityPaperCom WHERE AppNo=@appno");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();
    }
    
    public DataTable GetExistCommentId(string appno, int comntid)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"SELECT CommentId FROM FacilityPaperDetails WHERE CommentId IN
                            (SELECT CommentId FROM FacilityPaperCom) AND AppNo=@appno AND CommentId=@comntid");
        dw.SetDataAdapterParameters("appno", appno);
        dw.SetDataAdapterParameters("comntid", comntid);
        return dw.GetDataTable();
    }

    public int UpdateFacilityPaperCom(string appno, int commentid, string comments)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"UPDATE FacilityPaperDetails SET FacilityDescrip=@comments WHERE
                     AppNo=@appno AND CommentId=@commentid");
        dw.SetSqlCommandParameters("comments", comments);
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("commentid", commentid);
        return dw.Update();
    }

    public int DeleteFacilityPaperComments(string appno, int commentid)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"DELETE FROM FacilityPaperDetails WHERE AppNo=@appno AND CommentId=@commentid");
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("commentid", commentid);
        return dw.Delete();
    }

    public int InsertIntoApplicantLoanNumber(string appno, string nicno, string loannumber, string additional)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO ApplicantLoanNumber(AppNo,NicNo,LoanNumber,AdditionalNumber) VALUES
                     (@appno,@nicno,@loannumber,@additional)");
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("nicno", nicno);
        dw.SetSqlCommandParameters("loannumber", loannumber);
        dw.SetSqlCommandParameters("additional", additional);
        return dw.Insert();
    }

    public DataTable GetExistLoanNumbers(string appno, string nicno)
    {
        dw.SetDataAdapter(@"SELECT * FROM ApplicantLoanNumber WHERE AppNo=@appno AND NicNo=@nicno");
        dw.SetDataAdapterParameters("appno", appno);
        dw.SetDataAdapterParameters("nicno", nicno);
        return dw.GetDataTable();
    }

    public int UpdateApplicantLoanNumber(string appno, string loannum, string addnum)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"UPDATE ApplicantLoanNumber SET LoanNumber=@loannum,AdditionalNumber=@addnum
                        WHERE AppNo=@appno");
        dw.SetSqlCommandParameters("loannum", loannum);
        dw.SetSqlCommandParameters("addnum", addnum);
        dw.SetSqlCommandParameters("appno", appno);
        return dw.Update();
    }

    public string GetLoanDetails(string appno)
    {
            string tmp = "";
            DataTable dt = new DataTable();
            dw = new DataWorksClass(constring);
            dw.SetDataAdapter(@"select distinct descrip from appcategory a, crcatpurpose c, crpurpose p
                                where appno=@appno and a.catpurposeid=c.catpurposeid
                                and c.purposecode=p.purposecode");
            dw.SetDataAdapterParameters("appno", appno);
            dt = dw.GetDataTable();

            for (int a = 0; a < dt.Rows.Count; a++)
            {
                tmp += dt.Rows[a]["descrip"].ToString();

                if (dt.Rows.Count != (a + 1))
                    tmp += " / ";
            }

            return tmp;
        //else //gl number
        //{
        //    string tmp = "";
        //    dw = new DataWorksClass(constring);
        //    dw.SetCommand(@"select gldesc from glcode where refglcode=@cracno");
        //    dw.SetSqlCommandParameters("cracno", cracno);
        //    tmp = dw.GetSingleData();
        //    return tmp;
        //}
    }

    public decimal GetPremium(string grade, int crcat)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select Premium from PricingModel where grade = @grade and crcat = @crcat");
        dw.SetSqlCommandParameters("grade", grade);
        dw.SetSqlCommandParameters("crcat", crcat);
        return decimal.Parse(dw.GetSingleData());
    }

    //public int UpdateAppCategoryForCRESS(string appno, decimal intrate, int category, int crcat, int RecordNo,
    //    decimal OldIntRate)
    //{
    //    dw = new DataWorksClass(constring);
    //    dw.SetCommand(@"UPDATE AppCategory SET IntRate=@intrate,CatPurposeId=@category,
    //                  CrCat=@crcat, OldIntRate = @OldIntRate 
    //                  WHERE AppNo=@appno AND RecordNo=@RecordNo");
    //    dw.SetSqlCommandParameters("intrate", intrate);
    //    dw.SetSqlCommandParameters("category", category);
    //    dw.SetSqlCommandParameters("appno", appno);
    //    dw.SetSqlCommandParameters("crcat", crcat);
    //    dw.SetSqlCommandParameters("RecordNo", RecordNo);
    //    dw.SetSqlCommandParameters("OldIntRate", OldIntRate);
    //    return dw.Update();
    //}

    public int UpdateAppCategoryForCRESS(string appno, decimal intrate, decimal OldIntRate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"UPDATE AppCategory SET IntRate=@intrate, OldIntRate=@OldIntRate WHERE AppNo=@appno");
        dw.SetSqlCommandParameters("intrate", intrate);
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("OldIntRate", OldIntRate);
        return dw.Update();
    }

    public int UpdateAppCategoryForCRESS(string appno, decimal intrate, decimal OldIntRate, decimal Amount, int CatPurposeId,
                                         int CrCat, int newPurpose)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"UPDATE AppCategory SET IntRate=@intrate, OldIntRate=@OldIntRate, CrCat=@CrCat, CatPurposeId=@newPurpose
                        WHERE AppNo=@appno and IntRate=@OldIntRate and Amount=@Amount and CatPurposeId=@CatPurposeId");
        dw.SetSqlCommandParameters("intrate", intrate);
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("OldIntRate", OldIntRate);
        dw.SetSqlCommandParameters("Amount", Amount);
        dw.SetSqlCommandParameters("CatPurposeId", CatPurposeId);
        dw.SetSqlCommandParameters("CrCat", CrCat);
        dw.SetSqlCommandParameters("newPurpose", newPurpose);
        return dw.Update();
    }
    public int UpdateNewIntRateCRESS(string AppNo, decimal IntRate, decimal NewIntRate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"UPDATE CRESSData SET IntRate=@IntRate,NewIntRate=@NewIntRate WHERE AppNo=@appno");
        dw.SetSqlCommandParameters("AppNo", AppNo);
        dw.SetSqlCommandParameters("IntRate", IntRate);
        dw.SetSqlCommandParameters("NewIntRate", NewIntRate);
        return dw.Update();
    }
    public int GetNoOfLoans(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select COUNT(*) as NoOfLoans from Appcategory where AppNo = @appno");
        dw.SetSqlCommandParameters("appno", appno);
        return int.Parse(dw.GetSingleData());
    }

    public int GetCategory(string AppNo)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select CrCat from AppCategory Where AppNo = @AppNo");
        dw.SetSqlCommandParameters("AppNo", AppNo);
        return int.Parse(dw.GetSingleData());
    }

    

    public decimal GetIntRate(string AppNo)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select IntRate from AppCategory Where AppNo = @AppNo");
        dw.SetSqlCommandParameters("AppNo", AppNo);
        return decimal.Parse(dw.GetSingleData());
    }

    public decimal GetOldIntRate(string AppNo)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select OldIntRate from AppCategory Where AppNo = @AppNo");
        dw.SetSqlCommandParameters("AppNo", AppNo);
        return decimal.Parse(dw.GetSingleData());
    }

}
