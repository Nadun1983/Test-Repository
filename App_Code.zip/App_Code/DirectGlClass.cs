﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

/// <summary>
/// Summary description for DirectGlClass
/// </summary>
public class DirectGlClass
{

    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();
    string crmastString = ConfigurationManager.ConnectionStrings["crmastString"].ConnectionString.ToString();
    private DataTable dt;
    DataWorksClass dw;


	public DirectGlClass()
	{
		//
		// TODO: Add constructor logic here
		//
	}


    public DataTable GetGlDetails(string refglno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select refglcode, Gldesc,curbal from glcode where refglcode=@refglcode");
        dw.SetDataAdapterParameters("refglcode", refglno);
        return dw.GetDataTable();
    }

    public string GetUserNameCracno(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select rtrim(rtrim(cm.initials) + ' ' + rtrim(cm.surname)) as CustomerName
                        from housprop h,crholder c,customermain cm
                        where h.cracno=@cracno and c.cracno=h.cracno and cm.nicno=c.nicno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return dw.GetSingleData();
    }


    public string GetUserNameAppNo(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select distinct rtrim(rtrim(cm.initials) + ' ' + rtrim(cm.surname)) as CustomerName
                        from appholder c,customermain cm
                        where c.appno=@appno and cm.nicno=c.nicno");
        dw.SetSqlCommandParameters("appno", appno);
        return dw.GetSingleData();
    }

    public DataTable GetNewGlDetails(string refglno)
    {
        dw = new DataWorksClass(crmastString);
        dw.SetDataAdapter(@"select refglcode,gldesc,curbal from tdb.creditadmin.glcode 
                            where refglcode in (select newglcode from crmast.creditadmin.glcode 
                            where glcode = @refglno)");
        dw.SetDataAdapterParameters("refglno", refglno);
        return dw.GetDataTable();
    }
}
