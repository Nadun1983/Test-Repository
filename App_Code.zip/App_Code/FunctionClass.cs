using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Security.Permissions;
using System.Globalization;


/// <summary>
/// Summary description for FunctionClass
/// </summary>
public class FunctionClass
{
    double totamount;
    SqlConnection sqlConn;
    SqlDataReader sqlDataReader;
    SqlCommand sqlCmd;
    DataTable dt;
    SqlDataAdapter sqlAdapter;
    DataWorksClass dw;
    double totcap, totint, totpnl, total, totcr, totdr, totSum;
    int noofinstalments;



    public double TotCr
    {
        get
        {
            return this.totcr;
        }
    }


    public double TotDr
    {
        get
        {
            return this.totdr;
        }
    }

    public double TotalCapital
    {
        get
        {
            return this.totcap;
        }
    }

    public double TotalInterest
    {
        get
        {
            return this.totint;
        }
    }

    public double TotalPenal
    {
        get
        {
            return this.totpnl;
        }
    }

    public int ArrearsInstallment
    {
        get
        {
            return this.noofinstalments;
        }
    }

    public double Total
    {
        get
        {
            return this.total;
        }
    }

    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString;
    string reportconstring = ConfigurationManager.ConnectionStrings["reporTString"].ConnectionString;
    string TDBBranchesConString = ConfigurationManager.ConnectionStrings["TDBBranchesConString"].ConnectionString;
	public FunctionClass()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public DateTime SetRecoveryDate(DateTime date)
    {
        return date.AddMonths(1);
    }

    public DateTime ReduceRecoveryDate(DateTime date)
    {
        return date.AddMonths(-1);
    }

    public DateTime SetRecoveryProcessDate(DateTime date, string cracno)
    {
        if (cracno == "603086036375")
        {
            string newcracno = cracno;
        }
        if (cracno == "603080037683")
        {
            string newcracno = cracno;
        }

        DateTime datedue = date; ;
        dw = new DataWorksClass(constring);
        dw.SetCommand("select LastCompletedDueDate from housprop where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        try
        {
            datedue = DateTime.Parse(dw.GetSingleData());
        }
        catch
        {

        }

        int trdatekey = int.Parse(date.Year.ToString("0000") + date.Month.ToString("00") + date.Day.ToString("00"));
        int dateduekey = int.Parse(datedue.Year.ToString("0000") + datedue.Month.ToString("00") + datedue.Day.ToString("00"));
        int dueday = datedue.Day;
        int trday = date.Day;
        int duemonth = datedue.Month;
        int trmonth = date.Month;
        if (trdatekey >= dateduekey)
        {
            if (trday >= dueday)
            {
                date = date.AddMonths(1);
            }
            else
            {
                if (GetMaxDate(date.Month, date.Day, date.Year) == 30)
                {
                    date = date.AddMonths(1);
                }
                else
                {
                    if (date.Month == 2)
                    {
                        if (date.Year % 4 == 0)
                        {
                            if (date.Day == 29)
                            {
                                date = date.AddMonths(1);
                            }
                        }
                        else
                        {
                            if (date.Day == 28)
                            {
                                date = date.AddMonths(1);
                            }
                        }
                    }
                }
            }
        }

        dueday = GetMaxDate(date.Month, dueday, date.Year);

        //string a =  date.Month + "/" + day + 1 + "/" + GetMaxYear(date.Month, date.Year);

        // Need to Modify if we follow a calender 
        //if (date.Month == 12)
        //{
        //    date = date.AddMonths(-11);
        //}

       // return DateTime.Parse(DateTime.Parse(date.Month + "/" + dueday + "/" + GetMaxYear(date.Month, date.Year).ToShortDateString());

        // change on 10-12-2010//

        return DateTime.Parse(DateTime.Parse(date.Month + "/" + dueday + "/" + date.Year).ToShortDateString());
    }

    //Support Function
    public int GetMaxDate(int month, int day, int year)
    {
        int returnday = 0;
        switch (month)
        {

            case 2:
                if (year % 4 == 0)
                {
                    if (day > 29)
                    {
                        returnday = 29;
                    }
                    else
                    {
                        returnday = day;
                    }
                }
                else
                {
                    if (day > 28)
                    {
                        returnday = 28;
                    }
                    else
                    {
                        returnday = day;
                    }
                }
                break;


            case 4:
                if (day == 31)
                {
                    returnday = 30;
                }
                else
                {
                    returnday = day;
                }
                return returnday;

            case 6:
                if (day == 31)
                {
                    returnday = 30;
                }
                else
                {
                    returnday = day;
                }
                return returnday;


            case 9:
                if (day == 31)
                {
                    returnday = 30;
                }
                else
                {
                    returnday = day;
                }
                return returnday;

            case 11:
                if (day == 31)
                {
                    returnday = 30;
                }
                else
                {
                    returnday = day;
                }
                break;


            default:
                returnday = day;
                break;

        }
        return returnday;
    }

   //  Support Function
    public int GetNoofDatesinMonth(int month, int day, int year)
    {
        if (month == 12)
        {
            month = 1;
            year -= 1;
        }
        //else
        //{
        //    month -= 1;
        //}

        int days = 0;
        switch (month)
        {
            case 1:
                days=31;
                break;
            case 2:
                if (year % 4 == 0)
                {
                    days = 29;
                }
                else
                {
                    days = 28;
                }
                break;


            case 3:
                days = 31;
                break;

            case 4:
                days = 30;
                break;

            case 5:
                days = 31;
                break;

            case 6:
                days = 30;
                break;
            case 7:
                days = 31;
                break;

            case 8:
                days = 31;
                break;

            case 9:
                days = 30;
                break;
            case 10:
                days = 31;
                break;

            case 11:
                days = 30;
                break;
            case 12:
                days = 31;
                break;
               
        }
        return days;
    }

    public DateTime GetDateDue(DateTime grantdate)
    {
        return grantdate.AddMonths(1);
    }

    // Supprot Function
    private int GetMaxYear(int month, int year)
    {
        if (month == 12)
        {
            return year + 1;
        }
        else
        {
            return year;
        }

    }

    public DateTime GetDate(string date)
    {
        DateTime outDate = new DateTime();
        outDate = DateTime.Parse("07/07/7777");
        if (date.Length == 8)
        {
            string strFromDate = date.Substring(2, 2) + "/" + date.Substring(0, 2) + "/" + date.Substring(4, 4);

            if (DateTime.TryParse(strFromDate, out outDate))
            {

            }
          
        }
        return outDate;
    }

    public string GetStrDate(DateTime date)
    {
      string strFromDate = date.Day.ToString("00") +  date.Month.ToString("00") + date.Year.ToString("0000");
      return strFromDate;
    }

//Get Userid
      private DataTable GetProgrammeAccess(int PrgId)
    {
        string sqlSelect;
        dt = new DataTable();
        sqlSelect = @"SELECT UserID from PrgAccess where PrgId = @PrgId";

        sqlConn = new SqlConnection(constring);

        sqlAdapter = new SqlDataAdapter(sqlSelect, sqlConn);
        sqlAdapter.SelectCommand.Parameters.AddWithValue("PrgId", PrgId);

        try
        {
            sqlConn.Open();
            sqlAdapter.Fill(dt);
        }

        catch (Exception err)
        {
            
        }

        finally
        {
            sqlConn.Close();
        }

        return dt;
    }    

    // Get LoanType
    private int GetProgID(string PrgDestination)
    {
        string sqlSelect, _errmessage;
        int PrgId = 0;
        sqlSelect = @"SELECT  PrgId from ProgramNames where PrgDestination = @PrgDestination";

        sqlConn = new SqlConnection(constring);

        sqlCmd = new SqlCommand(sqlSelect, sqlConn);
        sqlCmd.Parameters.AddWithValue("PrgDestination", PrgDestination);


        try
        {
            sqlConn.Open();
            sqlDataReader = sqlCmd.ExecuteReader();
            sqlDataReader.Read();
            if (sqlDataReader.HasRows == true)
            {
                PrgId = int.Parse(sqlDataReader["PrgId"].ToString());
            }
            else
            {

            }
            sqlDataReader.Close();

        }

        catch (Exception err)
        {
            _errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
        }

        return PrgId;

    }

    //public bool IsValid(string PrgDestination, string sessionuserid)
    //{
    //    bool isactive = false;
    //    int prgId;
    //    DataTable userid = new DataTable(); 

    //    prgId = GetProgID(PrgDestination);
    //    userid = GetProgrammeAccess(prgId);
    //    string struserid;
    //    int i = 0;
    //    while (userid.Rows.Count > i)
    //    {
    //        struserid = userid.Rows[i]["UserID"].ToString();
    //        if (sessionuserid == struserid)
    //        {
    //            isactive = true;
    //            break;
    //        }
    //        else
    //        {
    //            isactive = false;
    //        }
    //        i++;
    //    }
    //    return isactive;
    //}

    public bool IsValid(string PrgDestination, string sessionuserid)
    {
        string struserid = GetUserName(PrgDestination, sessionuserid);
        bool isactive = false;
        if (sessionuserid == struserid)
        {
            isactive = true;
        }
        else
        {
            isactive = false;
        }
        return isactive;
    }

    private string GetUserName(string PrgDestination, string userid)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"SELECT UserID from PrgAccess pa, ProgramNames pn 
            where pa.PrgId = pn.PrgId and
            PrgDestination = @PrgDestination and userid = @userid");
        dw.SetSqlCommandParameters("PrgDestination", PrgDestination);
        dw.SetSqlCommandParameters("userid", userid);
        return dw.GetSingleData();
    }

    public bool CheckDigit(string no11, string no12)
    {
        int ch11 = Function11(no11);
        int ch12 = Function12(no12);
        if (ch11 == ch12)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public int GetModuler10(string seraino)
    {
        int chechdigit = 0;
        switch (seraino.Length)
        {
            case 11:
                chechdigit = Function11(seraino);
                break;

            case 12:
                chechdigit = Function12(seraino);
                break;


            case 14:
                chechdigit = Function14(seraino);
                break;

            default:
                chechdigit = 0;
                break;
        }

        return chechdigit;

    }

    private int Function12(string seraino)
    {
        int firstDigit;
        int secondDigit;
        int thirdDigit;
        int fourthDigit;
        int fifthtDigit;
        int sixthDigit;
        int seventhDigit;
        int eightDigit;
        int ninethDigit;
        int tenthDigit;
        int eleventhDigit;
        int twelthDigit;
        int total;

        firstDigit = int.Parse(seraino.Substring(0, 1));
        secondDigit = int.Parse(seraino.Substring(1, 1));
        thirdDigit = int.Parse(seraino.Substring(2, 1));
        fourthDigit = int.Parse(seraino.Substring(3, 1));
        fifthtDigit = int.Parse(seraino.Substring(4, 1));
        sixthDigit = int.Parse(seraino.Substring(5, 1));
        seventhDigit = int.Parse(seraino.Substring(6, 1));
        eightDigit = int.Parse(seraino.Substring(7, 1));
        ninethDigit = int.Parse(seraino.Substring(8, 1));
        tenthDigit = int.Parse(seraino.Substring(9, 1));
        eleventhDigit = int.Parse(seraino.Substring(10, 1));
        twelthDigit = int.Parse(seraino.Substring(11,1));

        firstDigit = firstDigit * 5;
        secondDigit = secondDigit * 6;
        thirdDigit = thirdDigit * 3;
        fourthDigit = fourthDigit * 7;
        fifthtDigit = fifthtDigit * 9;
        sixthDigit = sixthDigit * 8;
        seventhDigit = seventhDigit * 2;
        eightDigit = eightDigit * 4;
        ninethDigit = ninethDigit * 7;
        tenthDigit = tenthDigit * 9;
        eleventhDigit = eleventhDigit * 7;
        twelthDigit = twelthDigit * 8;
        total = firstDigit + secondDigit + thirdDigit + fourthDigit + fifthtDigit + sixthDigit +
            seventhDigit + eightDigit + ninethDigit + tenthDigit + eleventhDigit+twelthDigit;

        total = total % 10;
        total = 10 - total;

        if (total == 10)
        {
            total = 0;
        }
        return total;
    }

    private int Function11(string seraino)
    {
        int firstDigit;
        int secondDigit;
        int thirdDigit;
        int fourthDigit;
        int fifthtDigit;
        int sixthDigit;
        int seventhDigit;
        int eightDigit;
        int ninethDigit;
        int tenthDigit;
        int eleventhDigit;
        //int twelthDigit;
        int total;

        firstDigit = int.Parse(seraino.Substring(0, 1));
        secondDigit = int.Parse(seraino.Substring(1, 1));
        thirdDigit = int.Parse(seraino.Substring(2, 1));
        fourthDigit = int.Parse(seraino.Substring(3, 1));
        fifthtDigit = int.Parse(seraino.Substring(4, 1));
        sixthDigit = int.Parse(seraino.Substring(5, 1));
        seventhDigit = int.Parse(seraino.Substring(6, 1));
        eightDigit = int.Parse(seraino.Substring(7, 1));
        ninethDigit = int.Parse(seraino.Substring(8, 1));
        tenthDigit = int.Parse(seraino.Substring(9, 1));
        eleventhDigit = int.Parse(seraino.Substring(10, 1));
        //twelthDigit = int.Parse(seraino.Substring(11, 1));

        firstDigit = firstDigit * 5;
        secondDigit = secondDigit * 6;
        thirdDigit = thirdDigit * 3;
        fourthDigit = fourthDigit * 7;
        fifthtDigit = fifthtDigit * 9;
        sixthDigit = sixthDigit * 2;
        seventhDigit = seventhDigit * 4;
        eightDigit = eightDigit * 7;
        ninethDigit = ninethDigit * 9;
        tenthDigit = tenthDigit * 7;
        eleventhDigit = eleventhDigit * 8;
        total = firstDigit + secondDigit + thirdDigit + fourthDigit + fifthtDigit + sixthDigit +
            seventhDigit + eightDigit + ninethDigit + tenthDigit + eleventhDigit;

        total = total % 10;
        total = 10 - total;

        if (total == 10)
        {
            total = 0;
        }
        return total;
    }

    private int Function14(string seraino)
    {
        int firstDigit;
        int secondDigit;
        int thirdDigit;
        int fourthDigit;
        int fifthtDigit;
        int sixthDigit;
        int seventhDigit;
        int eightDigit;
        int ninethDigit;
        int tenthDigit;
        int eleventhDigit;
        int twelthDigit;
        int thirteenthDigit;
        int fourteenthDigit;

        int total;

        firstDigit = int.Parse(seraino.Substring(0, 1));
        secondDigit = int.Parse(seraino.Substring(1, 1));
        thirdDigit = int.Parse(seraino.Substring(2, 1));
        fourthDigit = int.Parse(seraino.Substring(3, 1));
        fifthtDigit = int.Parse(seraino.Substring(4, 1));
        sixthDigit = int.Parse(seraino.Substring(5, 1));
        seventhDigit = int.Parse(seraino.Substring(6, 1));
        eightDigit = int.Parse(seraino.Substring(7, 1));
        ninethDigit = int.Parse(seraino.Substring(8, 1));
        tenthDigit = int.Parse(seraino.Substring(9, 1));
        eleventhDigit = int.Parse(seraino.Substring(10, 1));
        twelthDigit = int.Parse(seraino.Substring(11,1));
        thirteenthDigit = int.Parse(seraino.Substring(12, 1));
        fourteenthDigit = int.Parse(seraino.Substring(13, 1));

        firstDigit = firstDigit * 5;
        secondDigit = secondDigit * 6;
        thirdDigit = thirdDigit * 3;
        fourthDigit = fourthDigit * 7;
        fifthtDigit = fifthtDigit * 9;
        sixthDigit = sixthDigit * 8;
        seventhDigit = seventhDigit * 2;
        eightDigit = eightDigit * 4;
        ninethDigit = ninethDigit * 7;
        tenthDigit = tenthDigit * 9;
        eleventhDigit = eleventhDigit * 7;
        twelthDigit = twelthDigit * 2;
        thirteenthDigit = thirteenthDigit * 5;
        fourteenthDigit = fourteenthDigit * 3;
        total = firstDigit + secondDigit + thirdDigit + fourthDigit + fifthtDigit + sixthDigit +
            seventhDigit + eightDigit + ninethDigit + tenthDigit + eleventhDigit+twelthDigit+ thirteenthDigit+ fourteenthDigit;

        total = total % 10;
        total = 10 - total;

        if (total == 10)
        {
            total = 0;
        }
        return total;
    }

    public string GetStringDate(DateTime date)
    {
        return date.Year.ToString() + date.Month.ToString("00") + date.Day.ToString("00");
    }

    
    public string GetShortDateKeyinDate(string date)
    {
        return date.Substring(2, 2) + date.Substring(4, 2) + date.Substring(6, 2);
    }

    public string GetLongDateinDateKey(string datekey)
    {
        return datekey.Substring(6, 2) + "/" + datekey.Substring(4, 2) + "/" + datekey.Substring(0, 4);
    }

    public string GetStringLongDate(string datekey)
    {
        return datekey.Substring(0, 2) + "/" + datekey.Substring(2, 2) + "/" + datekey.Substring(4, 4);
    }

    public DateTime GetDateinDateKey(string datekey)
    {
        return DateTime.Parse(datekey.Substring(2, 2) + "/" + datekey.Substring(0, 2) + "/" + datekey.Substring(4, 4));
    }

    public string GetDateKeyinDate(string date)
    {
        return date.Substring(4, 4) + date.Substring(2, 2) + date.Substring(0, 2);
    }

    public int GetDateKeyinDate(DateTime date)
    {
        return int.Parse(date.Year.ToString("0000") + date.Month.ToString("00") + date.Day.ToString("00"));
    }

    public int GetDateinDate(DateTime date)
    {
        return int.Parse(date.Day.ToString("00") + date.Month.ToString("00") + date.Year.ToString("0000"));
    }
  
    public DateTime GetShortDate(DateTime date)
    {
        return Convert.ToDateTime(date.ToShortDateString());
    }

    public double CalculateTotal(DataTable dt, string fieldname)
    {
        foreach (DataRow dr in dt.Rows)
        {
            string trtype = dr["TrType"].ToString();
            switch (trtype)
            {
                case "I":
                    this.totamount += double.Parse(dr[fieldname].ToString());
                    break;

                case "E":
                    this.totamount -= double.Parse(dr[fieldname].ToString());
                    break;
            }
        }
        return Math.Round(totamount,2);
    }

    public double CalculateTotal(string fieldname, DataTable dt)
    {
        foreach (DataRow dr in dt.Rows)
        {
            this.totamount += double.Parse(dr[fieldname].ToString());
        }
        return Math.Round(totamount, 2);
    }

    public double CalculateTotal(DataTable dt, string fieldname, string fieldname2)
    {
        foreach (DataRow dr in dt.Rows)
        {
            string trtype = dr["TrType"].ToString();
            string Trstatus = dr["Trstatus"].ToString();
            switch (trtype)
            {
                case "I":
                    if (Trstatus != "N")
                    {
                        this.totamount += double.Parse(dr[fieldname].ToString()) - double.Parse(dr[fieldname2].ToString());
                    }
                    else
                    {
                        this.totamount += double.Parse(dr[fieldname].ToString());
                    }
                    break;

                case "E":
                    if (Trstatus != "N")
                    {
                        this.totamount -= double.Parse(dr[fieldname].ToString()) - double.Parse(dr[fieldname2].ToString());
                    }
                    else
                    {
                        this.totamount -= double.Parse(dr[fieldname].ToString());
                    }
                    break;
            }
        }
        return Math.Round(totamount, 2);
    }

    public double CalculateTotal(DataTable dt)
    {
        foreach (DataRow dr in dt.Rows)
        {
            string acsign = dr["acsign"].ToString();
            double tramt = double.Parse(dr["tramt"].ToString());
            switch (acsign)
            {
                case "CR":
                    totcr += tramt;
                    totSum += tramt;
                    break;

                case "DR":
                    totdr += totdr;
                    totSum -= tramt;
                    break;
            }
        }
        totcr = Math.Round(totcr, 2);
        totdr = Math.Round(totdr, 2);
        return Math.Round(totSum,2);
    }

    //BranchCode-000001

    public string GetBranchCode(string user)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select brcode from users where userid=@userid");
        dw.SetSqlCommandParameters("userid", user);
        return int.Parse(dw.GetSingleData()).ToString("0000");
    }

    public double GetMonthlyInstalment(double loanamount, double intrate, int crperiod)
    {
        double instalment = 0;
        instalment = loanamount * (intrate / (12 * 100)) / (1 - (1 / Math.Pow((double)((1 + (intrate / (12 * 100)))), crperiod)));
        return Math.Round(instalment, 2);
    }

    public double GetMonthlyInstalmentRounded(double loanamount, double intrate, int crperiod)
    {
        double instalment = 0;
        instalment = loanamount * (intrate / (12 * 100)) / (1 - (1 / Math.Pow((double)((1 + (intrate / (12 * 100)))), crperiod)));
        instalment = (instalment - instalment % 10) + 10;
        return Math.Round(instalment, 2);
    }

    public string GetSystemTime()
    {
        return DateTime.Now.TimeOfDay.ToString();
    }

    public DataTable GetPrinterName(string username, string branchcode)
    {


        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select ServerName, PrinterName from BranchPrinters
                        where userid=@username and BranchCode=@BranchCode");
        dw.SetDataAdapterParameters("username", username);
        dw.SetDataAdapterParameters("BranchCode", branchcode);
        return dw.GetDataTable();
    }

    public DataTable GetPrinters(string username, string branchcode)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select ServerName, PrinterName from BranchPrinters
                                where userid=@username and BranchCode=@BranchCode order by PriorityList");
        dw.SetDataAdapterParameters("username", username);
        dw.SetDataAdapterParameters("BranchCode", branchcode);
        return dw.GetDataTable();
       
    }

    public int GetRecordOrder(string cracno)
    {
        int recorder = 0;
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select case max(RecOrder) when null then 1 else max(RecOrder) end as Recorder from 
                        transassign where cracno=@cracno and trstatus='N' ");
        dw.SetSqlCommandParameters("cracno", cracno);
        recorder = int.Parse(dw.GetSingleData());
        if (recorder == 0)
        {
            recorder = 1;
        }

        return recorder;
    }

    public string GetDisplayDate(DateTime dateTime)
    {
        return dateTime.Day + "/" + dateTime.Month + "/" + dateTime.Year;
    }

   


    public void GetTotal(DataTable dt, int crcat)
    {
        foreach (DataRow dr in dt.Rows)
        {
            string taskid = dr["taskid"].ToString();
            double tramt = double.Parse(dr["tramt"].ToString());
            switch (taskid)
            {
                case "CAPD":
                    totcap += tramt;
                    if (crcat != 6)
                    {
                        if (tramt != 0)
                        {

                            if (tramt > 0)
                            {
                                noofinstalments++;
                            }

                            else
                            {
                                noofinstalments--;
                            }
                        }
                    }
                    break;

                case "INTR":

                    if (crcat == 6)
                    {
                        if (tramt != 0)
                        {
                            if (tramt > 0)
                            {
                                noofinstalments++;
                            }
                            else
                            {
                                noofinstalments--;
                            }
                        }
                    }
                    totint += tramt;
                    break;

                case "PNLR":
                    totpnl += tramt;
                    break;
            }
            total += tramt;
        }
    }

    public DateTime GetDatefromDisplayDate(string date)
    {
        string[] words = date.Split('/');
        date = words[1]+"/"+words[0]+"/"+words[2];
        return DateTime.Parse(date);
    }

    public DataTable GetHousPropData(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from housprop where cracno = @cracno");
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();

    }




    public int GetPaidInstallmets(DateTime grantDate, DateTime DateDue)
    {
        int noofyears = 0;
        int noOfmonth = 0;
        int noOfDate = 0;

        int preyear = grantDate.Year;
        int curyear = DateDue.Year;
        int premonth = grantDate.Month;
        int curmonth = DateDue.Month;
        int preDate = grantDate.Day;
        int curDate = DateDue.Day;

        noofyears = curyear - preyear;
        noOfDate = curDate - preDate;


        if (premonth == curmonth)
        {
            noOfmonth = noofyears * 12;
        }
        else
        {
            noOfmonth = curmonth - premonth;
            noOfmonth = noOfmonth + (noofyears * 12);
        }

        if (noOfDate < 0)
        {
            noOfmonth = noOfmonth - 1;
        }
        return noOfmonth;
    }

    public DateTime GetDateinKeyDate(string datekey)
    {
        return DateTime.Parse(datekey.Substring(4, 2) + "/" + datekey.Substring(6, 2) + "/" + datekey.Substring(0, 4));
    }


    public string GetDateinDateKeystr(DateTime dateTime)
    {
        return dateTime.Day.ToString("00") + dateTime.Month.ToString("00") + dateTime.Year.ToString();
    }


    //public DateTime GetSystemDate(string currentStatus)
    //{
    //    dw = new DataWorksClass(constring);
    //    dw.SetCommand(@"select OperationDate from OperationCalendar where CurrentStatus=@CurrentStatus");
    //    dw.SetSqlCommandParameters("CurrentStatus", currentStatus);
    //    string strdate = dw.GetSingleData();
    //    return DateTime.Parse(strdate.Substring(4, 2) + "/" + strdate.Substring(6, 2) + "/" + strdate.Substring(0, 4) + " 00:00:00.000");
    //}

    //public string GetSystemDateKey(string currentStatus)
    //{
    //    dw = new DataWorksClass(constring);
    //    dw.SetCommand(@"select OperationDate from OperationCalendar where CurrentStatus=@CurrentStatus");
    //    dw.SetSqlCommandParameters("CurrentStatus", currentStatus);
    //    return dw.GetSingleData();

    //}

    //vihanga 2009-11-29
    public DateTime GetSystemDate(string currentStatus)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select OperationDate from OperationCalendarBranch where CurrentStatus=@CurrentStatus");
        dw.SetSqlCommandParameters("CurrentStatus", currentStatus);
        string strdate = dw.GetSingleData();
        //return DateTime.Parse(strdate.Substring(4, 2) + "/" + strdate.Substring(6, 2) + "/" + strdate.Substring(0, 4));
        return DateTime.Parse(strdate.Substring(4, 2) + "/" + strdate.Substring(6, 2) + "/" + strdate.Substring(0, 4) + " 00:00:00.000");
    }

    //vihanga 2009-11-29
    public string GetSystemDateKey(string currentStatus)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select OperationDate from OperationCalendarBranch where CurrentStatus=@CurrentStatus");
        dw.SetSqlCommandParameters("CurrentStatus", currentStatus);
        return dw.GetSingleData();
    }

    //vihanga 2009-11-29
    public string GetMainSystemDateKey(string CurrentStatus)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select OperationDate from operationcalendar where CurrentStatus=@CurrentStatus");
        dw.SetSqlCommandParameters("CurrentStatus", CurrentStatus);
        return dw.GetSingleData();
    }
    public decimal GetOpeningBalinGl(string date, string branchcode)
    {
        dw = new DataWorksClass(reportconstring);
        dw.SetCommand(@"select CloseBal from dailygltransaction
                        where date = (select max(date) from
                        dailygltransaction where date < @date)
                        and refglcode=903081000000994
                        and branchcode=@branchcode");
        dw.SetSqlCommandParameters("date", date);
        dw.SetSqlCommandParameters("branchcode", branchcode);
        return decimal.Parse(dw.GetSingleData());
    }

    public bool GetNicNo(string cracno)
    {
        ExsistLoanDetails eld = new ExsistLoanDetails();
        LoadCustomer lct = new LoadCustomer();
        CrTransClass ctc = new CrTransClass();
        string appno = ctc.GetAppNo(cracno);
        bool status = false;
        string nicno;


        //string appno = eld.Getappno(cracno);
        DataTable existcrholder = new DataTable();
        DataTable existsappholder = new DataTable();

        DataTable oldcrhdetails = new DataTable();
        DataTable oldaphdetails = new DataTable();

        existsappholder = eld.GetExistAppHolder(appno, "P");
        existcrholder = eld.GetExistCrHolder(appno, "P");

        //Insert Data to CrApp
        if (eld.GetExistAppno(appno) == "0")
        {
            eld.InsertDataToCrApp(appno);
        }

        //Insert Data to AppHolder
        if (existsappholder.Rows.Count > 0)
        {
            for (int i = 0; i < existsappholder.Rows.Count; i++)
            {
                nicno = existsappholder.Rows[i]["nicno"].ToString();
                if (nicno.Trim() == "" || nicno == null)
                {
                    status = true;
                }
            }
        }
        else
        {
            oldaphdetails = eld.GetOldAppHolder(appno);
            for (int i = 0; i < oldaphdetails.Rows.Count; i++)
            {
                nicno = oldaphdetails.Rows[i]["nicno"].ToString();
                bool nicvalidate = validateNIC(nicno);
                if (nicvalidate == true)
                {
                    eld.InsertDataToAppHolder(appno);
                    status = false;
                }
                else
                {
                    status = true;
                }
            }


        }

        //Insert Data to CrHolder
        if (existcrholder.Rows.Count > 0)
        {
            for (int i = 0; i < existcrholder.Rows.Count; i++)
            {
                nicno = existcrholder.Rows[i]["nicno"].ToString();
                bool nicvalidate = validateNIC(nicno);

                if (nicno.Trim() == "" || nicno == null)
                {
                    status = true;
                }
            }
        }
        else
        {
            oldcrhdetails = eld.GetOldCrHolder(appno);
            for (int i = 0; i < oldcrhdetails.Rows.Count; i++)
            {
                nicno = oldcrhdetails.Rows[i]["nicno"].ToString();
                bool nicvalidate = validateNIC(nicno);
                if (nicvalidate == true)
                {
                    eld.InsertDataToCrHolder(cracno, appno);
                    status = false;
                }
                else
                {
                    status = true;
                }
            }
        }


        //Insert Data to CustomerMain
        DataTable nic515 = new DataTable();
        nic515 = eld.GetNICFrom515(appno);
        if (nic515.Rows.Count > 0)
        {
            for (int i = 0; i < nic515.Rows.Count; i++)
            {
                string nicnum = nic515.Rows[i]["nicno"].ToString().Trim();
                string custno = nic515.Rows[i]["custno"].ToString().Trim();

                bool nicvalidate = validateNIC(nicnum);
                if (nicvalidate == true)
                {
                    if (eld.GetExistCustomerMain(nicnum) == "0")
                    {
                        eld.InsertCustomerMain(nicnum, custno);
                        eld.InsertCustomerSub(nicnum, custno);
                        lct.InsertCustomerLog(nicnum, DateTime.Parse("01/01/1900"), "Application", "0308", "Already Exist Customer",
                                              "0308a", "accept", 0, 0, "0", -100);
                    }
                }
                else
                {
                    status = true;
                }

            }
        }
        return status;
    }


    private bool validateNIC(string nicno)
    {
        bool validation = false;

        if (nicno.Length != 10)
        {
            validation = false;
        }
        else if (nicno.Substring(9, 1) != "V" && nicno.Substring(9, 1) != "X" && nicno.Substring(9, 1) != "v" && nicno.Substring(9, 1) != "x")
        {
            validation = false;
        }
        else
        {
            try
            {
                int.Parse(nicno.Substring(0, 9));
                int dob = int.Parse(nicno.Substring(2, 3));
                if (dob > 366)
                {
                    dob = dob - 500;
                }
                if (dob > 0)
                {
                    if (dob < 367)
                    {
                        validation = true;
                    }
                    else
                    {
                        validation = false;
                    }
                }
                else
                {
                    validation = false;
                }
            }
            catch
            {
                validation = false;
            }
        }

        return validation;
    }

    public bool EnterNicNoInTextBox(string nicno, string cracno)
    {
        bool nicStatus = false;
        LoadCustomer lct = new LoadCustomer();
        ExsistLoanDetails eld = new ExsistLoanDetails();
        DataTable existsappholder = new DataTable();
        DataTable existcrholder = new DataTable();
        bool nicvalidate = validateNIC(nicno);
        string appno = eld.Getappno(cracno);
        string custno;

        if (nicvalidate == true)
        {
            existsappholder = eld.GetExistAppHolder(appno, "P");
            if (existsappholder.Rows.Count > 0)
            {
                eld.UpdateAppHolderNIC(appno, nicno);
            }
            else
            {
                eld.WithoutNicDataToAppH(appno, nicno);
            }

            existcrholder = eld.GetExistCrHolder(appno, "P");
            if (existcrholder.Rows.Count > 0)
            {
                eld.UpdateCrHolderNIC(appno, nicno);
            }
            else
            {
                eld.WithoutNicDataToCrHolder(cracno, nicno);
            }

            if (eld.GetExistCustomerMain(nicno) == "0")
            {
                custno = eld.GetCustNo(appno);
                eld.InsertCustomerMainDataCorrectNIC(nicno, custno);
                eld.InsertCustomerSubDataCorrectNIC(nicno, custno);
                lct.InsertCustomerLog(nicno, DateTime.Parse("01/01/1900"), "Application", "0308", "Already Exist Customer",
                                              "0308a", "accept", 0, 0, "0", -100);
            }

            //lblMsg.Text = "";
            nicStatus = false;
        }
        else
        {
            //lblMsg.Text = "Invalid NIC Number !";
            nicStatus = true;
        }

        return nicStatus;
    }

    //vihanga 
    public DateTime GetDatefromFiles(string datekey)
    {
        string a = datekey.Substring(0, 2);
        string b = datekey.Substring(3, 2);
        string c = datekey.Substring(6, 4);
        a = a + b + c;
        DateTime date = GetDate(a);
        return date;
    }

    
    public string ConvertStringDate(string tmp)
    {
        string returnvalue = tmp.Substring(6, 2) + tmp.Substring(4, 2) + tmp.Substring(0, 4);
        return returnvalue;
    }

    public string GetMinimumDate(string datekey)
    {
        dw = new DataWorksClass(TDBBranchesConString);
        dw.SetCommand(@"select max(datekey) from CR1Details where datekey<@datekey");
        dw.SetSqlCommandParameters("datekey", datekey);
        return dw.GetSingleData();
    }
    public string GetEnterDateinDate(DateTime date)
    {
        return date.Day.ToString("00") + date.Month.ToString("00") + int.Parse(date.Year.ToString("0000"));
    }

    public string getbranchname(string branchno)
    {
        dw = new DataWorksClass(TDBBranchesConString);
        dw.SetCommand(@"select RTRIM(branchname) as branchname from nsb_branch where branchno=@branchno");
        dw.SetSqlCommandParameters("branchno", branchno);
        return dw.GetSingleData();
    }

    public DateTime GetDueDate(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select LastCompletedDueDate from Housprop where cracno=@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return DateTime.Parse(dw.GetSingleData());
    }

    public DataTable MetricUnit()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from MetricUnit");
        return dw.GetDataTable();

    }

    public DataTable LoanSettlePrint(decimal cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"exec spLoanSettlePrint @cracno");
        dw.SetDataAdapterParameters("cracno", cracno);
        dt = dw.GetDataTable();
        return dt;
    }
    public DataTable OtherBankLoanSettlePrint(decimal cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select Distinct M.CrAcNo,M.Aprovdamt,M.GrantAmt,M.GrantDate,UPPER(CP.Descrip) as Descrip,M.CrPeriod,HP.ActOutBal,
                    M.IntRate,HP.Instalment,UPPER(CM.NicNo) as NIC,H.HolderType ,
                    UPPER(RTRIM(T.TITLEDESC )+' '+ RTRIM(cm.Initials)+' '+  RTRIM(CM.Surname)) as [P_Name], 
                    CM.Location,CM.Street,CM.City,
                     HP.LstPaiddate 
                    from TITLE T,HousProp HP,Customermain CM,CrHolder H,CrMast M
                    left OUTER JOIN CrPurpose CP
                    on M.CatPurposeId = CP.PurposeCode 
                    where M.CrAcNo = H.CrAcNo and CM.TitleCode = T.TITLECODE  and H.NicNo = CM.NicNo  
                    and M.CrAcNo = HP.CrAcNo  and M.CrAcNo = @CrAcNo
                    order by H.HolderType ASC");
        dw.SetDataAdapterParameters("cracno", cracno);
        dt = dw.GetDataTable();
        return dt; 
    }

    public DataTable ReleasingEPFSecuryBalance(string NICNo)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select C.Appno,S.NicNo,S.EpfNo ,C.CrCat ,C.IntRate,C.GrantAmt,C.GrantDate,C.CrPeriod,C.instalment,
                UPPER(RTRIM(M.Initials) +  RTRIM(M.Surname)) as [P_Name]
                from CrMast C,Customersub S,CrHolder P ,Customermain M
                where  C.CrAcNo = P.CrAcNo and C.CrCat = '11' and M.NicNo = S.NicNo 
                and P.NicNo = S.NicNo and P.NicNo = @NicNo");
        dw.SetDataAdapterParameters("NicNo", NICNo);
        return dw.GetDataTable();

    }
    public DataTable ReleasingEPFSecuryBalanceForVehicleLoan(string NICNo)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select A.NicNo, A.AppNo,UPPER(RTRIM(T.TITLEDESC )+' '+ RTRIM(C.Initials)+' '+  RTRIM(C.Surname)) as [Name],S.EpfNo,
	                M.CrAcNo,M.GrantAmt,M.IntRate,M.GrantDate, H.ActOutBal,CASE WHEN H.ActOutBal = '0.00' THEN '0.00' ELSE M.instalment
					END AS instalment,((H.ActOutBal * M.IntRate)/36000) as P_Day
                    from CrMast M,Appholder A,HousProp H,Customermain C,TITLE T,Customersub S
                    where M.CrCat in ('11','12','16') and C.NicNo = S.NicNo and
                    C.TitleCode = T.TITLECODE  and A.NicNo = C.NicNo and M.CrAcNo = H.CrAcNo and A.AppNo = M.Appno and A.NicNo = @NicNo
                    order by GrantDate DESC");
        dw.SetDataAdapterParameters("NicNo", NICNo);
        return dw.GetDataTable();

    }

    public DataTable ReleasingEPFSecuryBalanceForHousingLoan(string NICNo)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select A.NicNo,A.AppNo,UPPER(RTRIM(T.TITLEDESC )+' '+ RTRIM(C.Initials)+' '+  RTRIM(C.Surname)) as [Name],S.EpfNo,
	                        M.CrAcNo,M.GrantAmt,M.GrantDate, H.ActOutBal,CASE WHEN H.ActOutBal = '0.00' THEN '0.00' ELSE M.instalment
													                        END AS instalment
                            from CrMast M,Appholder A,HousProp H,Customermain C,TITLE T,Customersub S
                            where M.CrCat in ('1','4','6','9','10') and C.NicNo = S.NicNo and
                            C.TitleCode = T.TITLECODE  and A.NicNo = C.NicNo and M.CrAcNo = H.CrAcNo and A.AppNo = M.Appno and A.NicNo = @NicNo
                            order by GrantDate DESC");
        dw.SetDataAdapterParameters("NicNo", NICNo);
        return dw.GetDataTable();

    }

    public DataTable GetPrimaryHolderAddress(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select UPPER(RTRIM(T.TITLEDESC )+' '+ RTRIM(cm.Initials)+' '+  RTRIM(CM.Surname)) as FullName, 
                    RTRIM(CM.Location) as Location,RTRIM(CM.Street) as Street, RTRIM(CM.City) as City
                    from TITLE T,Customermain CM,CrHolder H
                    where CM.TitleCode = T.TITLECODE  and H.NicNo = CM.NicNo  
                    and H.CrAcNo = @cracno and H.HolderType='P'");
        dw.SetDataAdapterParameters("@cracno", cracno);
        return dw.GetDataTable();

    }

    public static string ToCurrencyString(double value)
    {
        return value.ToString("N", CultureInfo.InvariantCulture);
    }

    public int GetNewCatId(int CrCatCode, int purposecode)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select catpurposeid from CrCatPurpose where CrCatCode = @CrCatCode and purposecode = @purposecode");
        dw.SetSqlCommandParameters("CrCatCode", CrCatCode);
        dw.SetSqlCommandParameters("purposecode", purposecode);
        return int.Parse(dw.GetSingleData());
    }

    public DataTable AMLData(string Date)
    {
        dw = new DataWorksClass(TDBBranchesConString);
        dw.SetDataAdapter(@"exec AMLData @Date");
        dw.SetDataAdapterParameters("Date", Date);

        return dw.GetDataTable();
    }

 public DataTable ChangeLog(DateTime FDate, DateTime TDate)
    {
        DataTable returndt = new DataTable();
        dw = new DataWorksClass(constring);

        dw.SetDataAdapter(@"exec MasterLog @fDate,@tDate");

        dw.SetDataAdapterParameters("fDate", FDate);
        dw.SetDataAdapterParameters("tDate", TDate);

        returndt = dw.GetDataTable();
        return returndt;



    }

    public DataTable ChangeLog_IntRate(DateTime FDate, DateTime TDate)
    {
        DataTable returndt = new DataTable();
        dw = new DataWorksClass(constring);

        dw.SetDataAdapter(@"exec MasterLog_intRate @fDate,@tDate");

        dw.SetDataAdapterParameters("fDate", FDate);
        dw.SetDataAdapterParameters("tDate", TDate);

        returndt = dw.GetDataTable();
        return returndt;



    }

    public DataTable ChangeLog_LoanPeriod(DateTime FDate, DateTime TDate)
    {
        DataTable returndt = new DataTable();
        dw = new DataWorksClass(constring);

        dw.SetDataAdapter(@"exec MasterLog_LoanPeriod @fDate,@tDate");

        dw.SetDataAdapterParameters("fDate", FDate);
        dw.SetDataAdapterParameters("tDate", TDate);

        returndt = dw.GetDataTable();
        return returndt;



    }

    //MasterLog_LoanCategory

    public DataTable ChangeLog_LoanCategory(DateTime FDate, DateTime TDate)
    {
        DataTable returndt = new DataTable();
        dw = new DataWorksClass(constring);

        dw.SetDataAdapter(@"exec MasterLog_LoanCategory @fDate,@tDate");

        dw.SetDataAdapterParameters("fDate", FDate);
        dw.SetDataAdapterParameters("tDate", TDate);

        returndt = dw.GetDataTable();
        return returndt;

    }

    public DataTable ResheduleLoans()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"exec ViewAllNPLResheduleLoans");

        dt = dw.GetDataTable();
        return dt;
    }

    public DataTable GetGLTransaction(DateTime currentdate)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"exec spGlTransactionsBatch @currentdate");
        dw.SetDataAdapterParameters("currentdate", currentdate);
        dt = dw.GetDataTable();
        return dt;
    }

}
