﻿using System;
using System.Data;
using System.Configuration;
//using System.Web;
//using System.Web.Security;
//using System.Web.UI;
//using System.Web.UI.WebControls;
//using System.Web.UI.WebControls.WebParts;
//using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
/// <summary>
/// Summary description for CribDetails
/// </summary>

/// <summary>
/// Summary description for CribCalculateNDIA
/// </summary>
public class CribCalculateNDIA
{
    private double captotal, inttotal, penaltotal;
    int arreasdaye = 0;

    //Corrections cs;
    DateTime datedue, nextdue, intdatedue;
    double outbal, actoutbal, exesspayment, totarreas, intoutstandinamt;
    string msg;
    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();
    CrTransClass cc;
    DataWorksClass dw;
    FunctionClass fc;
    Recovery rc;
    Trans t;

    public double CapitalTot
    {
        get
        {
            return this.captotal;
        }
    }

    public double INtTot
    {
        get
        {
            return this.inttotal;
        }
    }

    public double PenalTot
    {
        get
        {
            return this.penaltotal;
        }
    }

    public double TotArreas
    {
        get
        {
            return this.totarreas; ;
        }
    }

    public int NoofDaysinArreas
    {
        get
        {
            return this.arreasdaye;
        }
    }

    public double IntOutstandinAmt
    {
        get
        {
            return this.intoutstandinamt; ;
        }
    }

    

public CribCalculateNDIA()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public DataTable GetBaseRecords(string acstatus, string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select h.outbal,  h.actoutbal, h.cracno, h.datedue, c.intrate, h.instalment, 
                            h.LastCompletedDueDate, h.graceperiod, h.crperiod-h.paidInstalments as RemainingInstalment,
                            h.LastCompletedDueDate, c.crcat, c.grantdate, c.crperiod
                            from housprop h, crmast c where h.cracno =@cracno and c.acstatus =@acstatus and
                            c.cracno = h.cracno and c.Aprovdamt = c.GrantAmt and h.actoutbal <> 0");
        dw.SetDataAdapterParameters("acstatus", acstatus);
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }

    private double GetOutBal(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select sum(assignamt-tramt) as diff from transassign where cracno=@cracno
                        and taskid='CAPD' and (trstatus = 'P' or trstatus = 'N')");
        dw.SetSqlCommandParameters("cracno", cracno);
        return double.Parse(dw.GetSingleData());
    }
    private DataTable GetArreasAmount(string cracno, string trstatus1, string trstatus2)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select refno, assignamt, assignamt-tramt as arreas, taskid, datedue from  transassign 
                            where cracno =  @cracno 
                            and tramt != assignamt and tramt!=0 and (trstatus = @trstatus1 or trstatus = @trstatus2)");
        dw.SetDataAdapterParameters(@"cracno", cracno);
        dw.SetDataAdapterParameters(@"trstatus1", trstatus1);
        dw.SetDataAdapterParameters(@"trstatus2", trstatus2);
        return dw.GetDataTable();
    }


    private DataTable GetArreasInstalment(string cracno, DateTime datedue)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select refno, assignamt, assignamt-tramt as arreas, taskid, datedue from  transassign 
                            where cracno =  @cracno and (trstatus = 'p' or trstatus='n')
                            and (taskid = 'capd' or taskid = 'intr') and tramt != assignamt");
        dw.SetDataAdapterParameters(@"cracno", cracno);
        return dw.GetDataTable();
    }


    private double CalculatePenal(DateTime workingDate, double penalint, int graceperiod, string cracno, DateTime datedue, double installment, double intrate)
    {
        if (intrate == 3 || intrate == 5)
        {
            penalint = 0;
        }
        DataTable basicRec = new DataTable(); //Loan Number Table
        int i = 0; //count of no of loans based on the date due
        //workingDate = workingDate.AddDays(-1);

        int noofdue; // Due Months
        int dayDD; // Due Day
        int dayWD; // Working Day
        int monthDD; // Due Month
        int monthWD; // Working Month
        int yearDD; // Due Year
        int yearWd; // Working Year
        double penal; // Penal Charges

        //Get date and Month From the Working Date and Due Date
        dayDD = datedue.Day;
        dayWD = workingDate.Day;
        monthDD = datedue.Month;
        monthWD = workingDate.Month;
        yearDD = datedue.Year;
        yearWd = workingDate.Year;

        if (dayDD > dayWD)
        {
            noofdue = (yearWd * 12 + monthWD) - (yearDD * 12 + monthDD);
        }
        else
        {
            noofdue = (yearWd * 12 + monthWD) - (yearDD * 12 + monthDD) + 1;
        }

        //Reduce the Grace Period
        noofdue = noofdue - graceperiod;

        // Penal calculation
        return Math.Round((installment * penalint * noofdue) / 1200, 2);

    }


    private double CalculateIntAmount(double outbal, double intrate)
    {
        return Math.Round(outbal * intrate / 1200, 2);
    }

    private double CalculateCapital(double installment, double intAmount, int crcat, double outbal)
    {
        if (crcat != 6)
        {
            if (installment >= outbal)
            {
                return Math.Round(outbal, 2);
            }
            else
            {
                return Math.Round(installment - intAmount, 2);
            }
        }
        else
        {
            return 0;
        }
    }


    private DateTime GetPenalValidDate(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select case when PenalValidDate is null 
                        then '01/01/1900' 
                        else PenalValidDate end as PenalValidDate 
                        from housprop where cracno =@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return DateTime.Parse(dw.GetSingleData());
    }


    private string GetPenalInt(string ratetype)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand("select rateamt from ratecode where ratetype=@ratetype order by ratecode desc");
        dw.SetSqlCommandParameters("ratetype", ratetype);
        return dw.GetSingleData();
    }


    private int GetNoDaysForInterest(DateTime intdatedue, DateTime trdate)
    {
        int days = 0;
        fc = new FunctionClass();
        TimeSpan t = trdate.Subtract(intdatedue);
        days = t.Days;
        if (days > 9999)
            return 9999;
        else if (days < 0)
            return 0;
        else
            return days;
    }

    public void RecoveryProcessTempForCrib(string cracno)
    {
        DateTime recoveryProcessDate;
        fc = new FunctionClass();
        cc = new CrTransClass();
        rc = new Recovery();

        DateTime trdate = fc.GetSystemDate("A");
        DataTable dt = new DataTable();

        double intamount = 0, capital = 0, penal = 0, penalarreas = 0;
        double actoutbal = 0, outbal = 0;
        int RecOrder = 0;
        int crperiod;
        DateTime grantdate;
        DataTable basicRec = new DataTable(); //Loan Number Table       
        int penalInt = int.Parse(GetPenalInt("PEN"));

        basicRec = GetBaseRecords("A", cracno);
        if (basicRec.Rows.Count > 0)
        {

            // Set OUtbal from actoutbal
            actoutbal = Math.Round(Convert.ToDouble(basicRec.Rows[0]["actoutbal"].ToString()), 2);
            outbal = Math.Round((actoutbal - GetOutBal(cracno)), 2);
            crperiod = int.Parse(basicRec.Rows[0]["crperiod"].ToString());
            try
            {
                grantdate = DateTime.Parse(basicRec.Rows[0]["grantdate"].ToString());
            }
            catch
            {
                grantdate = DateTime.Parse("1900/1/1");
            }
            double intrate = Convert.ToDouble(basicRec.Rows[0]["intrate"].ToString());
            double installment = Convert.ToDouble(basicRec.Rows[0]["instalment"].ToString());
            int graceperiod = int.Parse(basicRec.Rows[0]["graceperiod"].ToString());
            datedue = DateTime.Parse(basicRec.Rows[0]["LastCompletedDueDate"].ToString());
            nextdue = DateTime.Parse(basicRec.Rows[0]["datedue"].ToString());
            string nextduedisplay = fc.GetDisplayDate(datedue);
            int crcat = int.Parse(basicRec.Rows[0]["crcat"].ToString());
            arreasdaye = GetNoDaysForInterest(datedue, trdate);
            double arreasamt, assignamt;
            string arreastask, refno;
            //Calculate Penal
            DataTable arreasdata = new DataTable();
            arreasdata = GetArreasAmount(cracno, "P", "N");
            if (actoutbal > 0)
            {
                if (arreasdata.Rows.Count > 0)
                {
                    arreasamt = double.Parse(arreasdata.Rows[0]["arreas"].ToString());
                    arreastask = arreasdata.Rows[0]["taskid"].ToString();
                    refno = arreasdata.Rows[0]["refno"].ToString();
                    assignamt = double.Parse(arreasdata.Rows[0]["assignamt"].ToString());
                    //datedue = DateTime.Parse(arreasdata.Rows[0]["datedue"].ToString());
                    //nextduedisplay = fc.GetDisplayDate(datedue);
                    if (arreastask == "PNLR")
                    {
                        penaltotal += arreasamt;
                        //dt = InsertRow(refno, cracno, assignamt, arreasamt, nextduedisplay, "P", "PNLR", dt);
                    }
                }

                RecOrder = fc.GetRecordOrder(cracno);
                DataTable arreasanstalmentdata = new DataTable();
                arreasanstalmentdata = GetArreasInstalment(cracno, datedue);
                if (arreasanstalmentdata.Rows.Count > 0)
                {
                    double arreasTot = 0;
                    for (int i = 0; arreasanstalmentdata.Rows.Count > i; i++)
                    {
                        arreasamt = double.Parse(arreasanstalmentdata.Rows[i]["arreas"].ToString());
                        arreasTot += arreasamt;
                    }
                    recoveryProcessDate = GetPenalValidDate(cracno);
                    penal = CalculatePenal(trdate, penalInt, graceperiod, cracno, datedue, arreasTot, intrate);
                    if (recoveryProcessDate <= trdate)
                    {
                        if (penal > 0)
                        {
                            penaltotal += penal;
                            //dt = InsertRow("0", cracno, penal, penal, nextduedisplay, "N", "PNLR", dt);
                        }
                    }
                    if (arreasanstalmentdata.Rows.Count > 0)
                    {
                        for (int i = 0; arreasanstalmentdata.Rows.Count > i; i++)
                        {
                            string taskid = arreasanstalmentdata.Rows[i]["taskid"].ToString();
                            arreasamt = double.Parse(arreasanstalmentdata.Rows[i]["arreas"].ToString());
                            refno = arreasanstalmentdata.Rows[i]["refno"].ToString();
                            assignamt = double.Parse(arreasanstalmentdata.Rows[i]["assignamt"].ToString());
                            //datedue = DateTime.Parse(arreasanstalmentdata.Rows[0]["datedue"].ToString());
                            if (arreasamt > 0)
                            {
                                switch (taskid)
                                {
                                    case "CAPD":
                                        captotal += arreasamt;
                                        break;

                                    case "INTR":
                                        inttotal += arreasamt;
                                        break;
                                }

                            }
                        }
                    }
                }
                if (outbal > installment)
                {
                    if (trdate >= nextdue)
                    {
                        while (trdate >= nextdue)
                        {
                            penal = CalculatePenal(trdate, penalInt, graceperiod, cracno, nextdue, installment, intrate);
                            intamount = CalculateIntAmount(outbal, intrate);
                            capital = CalculateCapital(installment, intamount, crcat, outbal);
                            nextduedisplay = fc.GetDisplayDate(nextdue);
                            //Set Penal Valid date
                            recoveryProcessDate = fc.SetRecoveryProcessDate(trdate, cracno);
                            //UpdatePenalValidDate(cracno, recoveryProcessDate);
                            // Insert Penal Portion
                            if (penal > 0)
                            {
                                penaltotal += penal;
                                //dt = InsertRow("0", cracno, penal, penal, nextduedisplay, "N", "PNLR", dt);
                            }
                            inttotal += intamount;
                            captotal += capital;
                            // Interest Portion
                            //dt = InsertRow("0", cracno, intamount, intamount, nextduedisplay, "N", "INTR", dt);

                            // Capital Portion
                            //dt = InsertRow("0", cracno, capital, capital, nextduedisplay, "N", "CAPD", dt);
                            outbal -= capital;
                            outbal = Math.Round(outbal, 2);

                            //SetPayments Next Due
                            nextdue = fc.SetRecoveryDate(nextdue);
                        }
                        datedue = nextdue.AddMonths(-1);
                    }
                }
                else
                {
                    while (trdate >= nextdue)
                    {
                        penal = CalculatePenal(trdate, penalInt, graceperiod, cracno, nextdue, installment, intrate);
                        if (penal > 0)
                        {
                            penaltotal += penal;
                            //dt = InsertRow("0", cracno, penal, penal, nextduedisplay, "N", "PNLR", dt);
                        }
                        nextdue = fc.SetRecoveryDate(nextdue);
                    }
                    datedue = nextdue.AddMonths(-1);
                }
            }
            else
            {
                outbal = 0;
            }
            intdatedue = nextdue.AddMonths(-1);
            this.outbal = outbal;
            this.totarreas = Math.Round(captotal + inttotal + penaltotal);

            intoutstandinamt = Math.Round(GetIntOutstanding(grantdate, datedue, installment, actoutbal, crperiod));
        }
        else
        {
            this.totarreas = 0;
            this.intoutstandinamt = 0;
            this.arreasdaye = 0;
        }
    }

    private double GetIntOutstanding(DateTime grantdate, DateTime datedue, double installment, double actoutbal,int crperiod)
    {
        fc = new FunctionClass();
        if (GetMonthDifference(grantdate, datedue) > 0)
        {
            crperiod = crperiod - GetMonthDifference(grantdate, datedue);
        }
        double amtTobePaid = crperiod * installment;
        double intAmt = amtTobePaid - outbal;
        return intAmt;
    }


    public int GetDateDifference(DateTime grantdate, DateTime datedue)
    {
        int days = 0;
        TimeSpan t = datedue.Subtract(grantdate);
        days = t.Days;
        return days;
    }
    public int GetMonthDifference(DateTime grantdate, DateTime datedue)
    {
        int months = 0;
        TimeSpan t = datedue.Subtract(grantdate);
        months = Math.Abs((t.Days / 365) * 12);
        return months;
    }

}
