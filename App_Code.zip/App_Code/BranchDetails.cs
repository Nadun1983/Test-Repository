﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// Summary description for BranchDetails
/// </summary>
public class BranchDetails
{
    DataWorksClass dw;
    DataTable dt;

    string Branchconstring = ConfigurationManager.ConnectionStrings["TDBBranchesConString"].ConnectionString.ToString();

	public BranchDetails()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    //2012-01-25 Nikeshana
    public DataTable GetCategory()
    {
        dw = new DataWorksClass(Branchconstring);
        dw.SetDataAdapter(@"select crcatcode,crdes from crcategory");
        return dw.GetDataTable();
    }

    //2012-01-25 Nikeshana
    public DataTable GetPurpose()
    {
        dw = new DataWorksClass(Branchconstring);
        dw.SetDataAdapter(@"select purposecode,descrip from crpurpose");
        return dw.GetDataTable();
    }

    //2012-01-25 Nikeshana
    public DataTable GetIntRates()
    {
        dw = new DataWorksClass(Branchconstring);
        dw.SetDataAdapter(@"select distinct intrate from interestcode order by intrate");
        return dw.GetDataTable();
    }

    public DataTable GetMISDetails(DateTime fromDate, DateTime toDate, int crcatcode, int purposecode, double Intrate)
    {
        dw = new DataWorksClass(Branchconstring);
        dt = new DataTable();

        if ((crcatcode == 0) && (purposecode == 0) && (Intrate == 0))
            dw.SetDataAdapter(@"select nb.BranchName,c.Cracno,h.instalment,cm.nicno,rtrim(t.titledesc+cm.initials+cm.surname) as CustName,cm.location,cm.street,cm.city,
                                c.Intrate,c.Aprovdamt,c.Grantamt,convert(varchar, c.GrantDate, 111) as GrantDate,h.ActOutBal,h.crPeriod as Period,r.crdes
                                from crmast c, Housprop h,crholder cr, customermain cm,title t,nsb_branch nb, crcategory r
                                where cm.titlecode=t.titlecode and c.cracno=h.cracno and cr.cracno=c.cracno and cm.BranchCode=nb.BranchNo and c.catpurposeid in 
                                (select catpurposeid from crcatpurpose) 
                                and cm.nicno=cr.nicno and c.grantdate>=@fromDate and c.grantdate<=@toDate and nb.branchno=h.branchcode
                                and cr.holdertype='P' and h.crcat=r.crcatcode order by c.Branchcode,c.GrantDate");

        else if ((crcatcode == 0) && (purposecode == 0))
            dw.SetDataAdapter(@"select nb.BranchName,c.Cracno,h.instalment,cm.nicno,rtrim(t.titledesc+cm.initials+cm.surname) as CustName,cm.location,cm.street,cm.city,
                                c.Intrate,c.Aprovdamt,c.Grantamt,convert(varchar, c.GrantDate, 111) as GrantDate,h.ActOutBal,h.crPeriod as Period,r.crdes
                                from crmast c, Housprop h,crholder cr, customermain cm,title t,nsb_branch nb, crcategory r
                                where cm.titlecode=t.titlecode and c.cracno=h.cracno and cr.cracno=c.cracno and cm.BranchCode=nb.BranchNo and c.catpurposeid in 
                                (select catpurposeid from crcatpurpose) 
                                and cm.nicno=cr.nicno and c.intrate=@Intrate and 
                                c.grantdate>=@fromDate and c.grantdate<=@toDate and nb.branchno=h.branchcode
                                and cr.holdertype='P' and h.crcat=r.crcatcode order by c.Branchcode,c.GrantDate");

        else if ((crcatcode == 0) && (Intrate == 0))
            dw.SetDataAdapter(@"select nb.BranchName,c.Cracno,h.instalment,cm.nicno,rtrim(t.titledesc+cm.initials+cm.surname) as CustName,cm.location,cm.street,cm.city,
                                c.Intrate,c.Aprovdamt,c.Grantamt,convert(varchar, c.GrantDate, 111) as GrantDate,h.ActOutBal,h.crPeriod as Period,r.crdes
                                from crmast c, Housprop h,crholder cr, customermain cm,title t,nsb_branch nb, crcategory r
                                where cm.titlecode=t.titlecode and c.cracno=h.cracno and cr.cracno=c.cracno and cm.BranchCode=nb.BranchNo and  c.catpurposeid in 
                                (select catpurposeid from crcatpurpose where purposecode=@purposecode) 
                                and cm.nicno=cr.nicno and c.grantdate>=@fromDate and c.grantdate<=@toDate and nb.branchno=h.branchcode
                                and cr.holdertype='P' and h.crcat=r.crcatcode order by c.Branchcode,c.GrantDate");

        else if ((purposecode == 0) && (Intrate == 0))
            dw.SetDataAdapter(@"select nb.BranchName,c.Cracno,h.instalment,cm.nicno,rtrim(t.titledesc+cm.initials+cm.surname) as CustName,cm.location,cm.street,cm.city,
                                c.Intrate,c.Aprovdamt,c.Grantamt,convert(varchar, c.GrantDate, 111) as GrantDate,h.ActOutBal,h.crPeriod as Period,r.crdes
                                from crmast c, Housprop h,crholder cr, customermain cm,title t,nsb_branch nb, crcategory r
                                where cm.titlecode=t.titlecode and c.cracno=h.cracno and cr.cracno=c.cracno and cm.BranchCode=nb.BranchNo and  c.catpurposeid in 
                                (select catpurposeid from crcatpurpose where crcatcode=@crcatcode) 
                                and cm.nicno=cr.nicno and c.grantdate>=@fromDate and c.grantdate<=@toDate and nb.branchno=h.branchcode
                                and cr.holdertype='P' and h.crcat=r.crcatcode order by c.Branchcode,c.GrantDate");

        else if (crcatcode == 0)
            dw.SetDataAdapter(@"select nb.BranchName,c.Cracno,h.instalment,cm.nicno,rtrim(t.titledesc+cm.initials+cm.surname) as CustName,cm.location,cm.street,cm.city,
                                c.Intrate,c.Aprovdamt,c.Grantamt,convert(varchar, c.GrantDate, 111) as GrantDate,h.ActOutBal,h.crPeriod as Period,r.crdes
                                from crmast c, Housprop h,crholder cr, customermain cm,title t,nsb_branch nb, crcategory r
                                where cm.titlecode=t.titlecode and c.cracno=h.cracno and cr.cracno=c.cracno and cm.BranchCode=nb.BranchNo and  c.catpurposeid in 
                                (select catpurposeid from crcatpurpose where purposecode=@purposecode) 
                                and cm.nicno=cr.nicno and c.intrate=@Intrate and 
                                c.grantdate>=@fromDate and c.grantdate<=@toDate and nb.branchno=h.branchcode
                                and cr.holdertype='P' and h.crcat=r.crcatcode order by c.Branchcode,c.GrantDate");

        else if (purposecode == 0)
            dw.SetDataAdapter(@"select nb.BranchName,c.Cracno,h.instalment,cm.nicno,rtrim(t.titledesc+cm.initials+cm.surname) as CustName,cm.location,cm.street,cm.city,
                                c.Intrate,c.Aprovdamt,c.Grantamt,convert(varchar, c.GrantDate, 111) as GrantDate,h.ActOutBal,h.crPeriod as Period,r.crdes
                                from crmast c, Housprop h,crholder cr, customermain cm,title t,nsb_branch nb, crcategory r
                                where cm.titlecode=t.titlecode and c.cracno=h.cracno and cr.cracno=c.cracno and cm.BranchCode=nb.BranchNo and  c.catpurposeid in 
                                (select catpurposeid from crcatpurpose where crcatcode=@crcatcode) 
                                and cm.nicno=cr.nicno and c.intrate=@Intrate and 
                                c.grantdate>=@fromDate and c.grantdate<=@toDate and nb.branchno=h.branchcode
                                and cr.holdertype='P' and h.crcat=r.crcatcode order by c.Branchcode,c.GrantDate");


        else if (Intrate == 0)
            dw.SetDataAdapter(@"select nb.BranchName,c.Cracno,h.instalment,cm.nicno,rtrim(t.titledesc+cm.initials+cm.surname) as CustName,cm.location,cm.street,cm.city,
                                c.Intrate,c.Aprovdamt,c.Grantamt,convert(varchar, c.GrantDate, 111) as GrantDate,h.ActOutBal,h.crPeriod as Period,r.crdes
                                from crmast c, Housprop h,crholder cr, customermain cm,title t,nsb_branch nb, crcategory r
                                where cm.titlecode=t.titlecode and c.cracno=h.cracno and cr.cracno=c.cracno and cm.BranchCode=nb.BranchNo and  c.catpurposeid in 
                                (select catpurposeid from crcatpurpose where purposecode=@purposecode and crcatcode=@crcatcode) 
                                and cm.nicno=cr.nicno and c.grantdate>=@fromDate and c.grantdate<=@toDate and nb.branchno=h.branchcode
                                and cr.holdertype='P' and h.crcat=r.crcatcode order by c.Branchcode,c.GrantDate");

        else
            dw.SetDataAdapter(@"select nb.BranchName,c.Cracno,h.instalment,cm.nicno,rtrim(t.titledesc+cm.initials+cm.surname) as CustName,cm.location,cm.street,cm.city,
                                c.Intrate,c.Aprovdamt,c.Grantamt,convert(varchar, c.GrantDate, 111) as GrantDate,h.ActOutBal,h.crPeriod as Period,r.crdes
                                from crmast c, Housprop h,crholder cr, customermain cm,title t,nsb_branch nb, crcategory r
                                where cm.titlecode=t.titlecode and c.cracno=h.cracno and cr.cracno=c.cracno cm.BranchCode=nb.BranchNo and  and c.catpurposeid in 
                                (select catpurposeid from crcatpurpose where purposecode=@purposecode and crcatcode=@crcatcode) 
                                and cm.nicno=cr.nicno and c.intrate=@Intrate and 
                                c.grantdate>=@fromDate and c.grantdate<=@toDate and nb.branchno=h.branchcode
                                and cr.holdertype='P' and h.crcat=r.crcatcode order by c.Branchcode,c.GrantDate");

        dw.SetDataAdapterParameters("crcatcode", crcatcode);
        dw.SetDataAdapterParameters("purposecode", purposecode);
        dw.SetDataAdapterParameters("Intrate", Intrate);
        dw.SetDataAdapterParameters("fromDate", fromDate);
        dw.SetDataAdapterParameters("toDate", toDate);
        return dw.GetDataTable();

    }

    public DataTable Getagriloans()
    {
        dw = new DataWorksClass(Branchconstring);
        dw.SetDataAdapter(@"select I.cracno,C.GrantAmt,C.GrantDate,I.actoutbal,I.intprovision,I.IntRate,I.DateDue,
                                I.Name,I.branchcode,A.purpose,D.Details,P.ProductDetail From 
                                AgriLoans A,AgriDetails D,AgriProducts P,IntProvisionIndividual I,CrMast C where 
                                AgriItem != 1
                                --and A.AgriProduct != 1 
                                and A.AgriItem=D.AgriCode and A.AgriProduct=P.AgriProduct
                                and C.Appno=A.AppNo and C.cracno=I.cracno and I.DateKey in (
                                select max(DateKey) from IntProvisionIndividual )");
        return dw.GetDataTable();
    }
}
