using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;


/// <summary>
/// Summary description for valuerreceieve
/// </summary>
public class valuerreceieve
{

    SqlConnection myconnection = new SqlConnection(ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString);
    private SqlDataAdapter sqlAdapter;
    private SqlCommand sqlCmd;
    private DataTable dt;

	public valuerreceieve()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public DataTable getvalNameandgetSendDate(string APPNO)
    {
        string sqlSelect;

        sqlSelect = @"select (rtrim(vler.Initial) + ' ' + rtrim(vler.SurName)) as valuername ,v.SENDDATE
                      from VALUATION v, Valuer vler
                      where v.VALUERID=vler.ValuerId and APPNO=@APPNO and v.updatelevel=-100";


        //sqlConn = new SqlConnection(conStringServer);
        sqlAdapter = new SqlDataAdapter(sqlSelect, myconnection);

        sqlAdapter.SelectCommand.Parameters.AddWithValue("APPNO", @APPNO);

        dt = new DataTable();

        try
        {
            myconnection.Open();
            sqlAdapter.Fill(dt);
        }
        catch (Exception err)
        {
            //
        }

        finally
        {
            myconnection.Close();
        }

        return dt;
    }


    public int userdetailofunhidevaluer(string HIDEUSER, string APPNO, DateTime RECVDATE)
    {
        string _errmessage;
        string sqlInsert;

        sqlInsert = @"update VALUATION set HIDEUSER=@HIDEUSER, RECVDATE=@RECVDATE ,HIDE='U'
                      where APPNO=@APPNO and UpdateLevel=-100";

        //sqlConn = new SqlConnection(myconnection);
        sqlCmd = new SqlCommand(sqlInsert, myconnection);

        sqlCmd.Parameters.AddWithValue("HIDEUSER", HIDEUSER);
        sqlCmd.Parameters.AddWithValue("APPNO", APPNO);
        sqlCmd.Parameters.AddWithValue("RECVDATE", RECVDATE);        

        int rowAdded = 0;

        try
        {
            myconnection.Open();
            rowAdded = sqlCmd.ExecuteNonQuery();
        }

        catch (Exception err)
        {
            _errmessage = err.Message;
        }

        finally
        {
            myconnection.Close();
        }

        return rowAdded;

    }

    //Get receieve date
    public DataTable getrecdate(string APPNO)
    {
        string sqlSelect;

        sqlSelect = @"select SENDDATE , RECVDATE from VALUATION where APPNO=@APPNO and
                       SENDDATE is not null and RECVDATE is not null and updatelevel=-100";


        //sqlConn = new SqlConnection(conStringServer);
        sqlAdapter = new SqlDataAdapter(sqlSelect, myconnection);

        sqlAdapter.SelectCommand.Parameters.AddWithValue("APPNO", @APPNO);

        dt = new DataTable();

        try
        {
            myconnection.Open();
            sqlAdapter.Fill(dt);
        }
        catch (Exception err)
        {
            //
        }

        finally
        {
            myconnection.Close();
        }

        return dt;
    }

    //GetValuerName
    public string GetValuerName(long AppNo)
     {
        string sqlSelect;
        sqlSelect = @"select rtrim(val.initial + val.surName) as fullname from valuation v, valuer val 
                   where v.valuerid=val.valuerid and v.appno=@AppNo";

        sqlAdapter = new SqlDataAdapter(sqlSelect, myconnection);

        sqlAdapter.SelectCommand.Parameters.AddWithValue("AppNo", AppNo);

        string sValuerName = "";
        dt = new DataTable();

        try
        {
            myconnection.Open();
            sqlAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }
        finally
        {
            myconnection.Close();
        }

        if (dt.Rows.Count > 0)
            sValuerName = dt.Rows[0][0].ToString();


        return sValuerName;
    }

    public int updvalrepdata(int VALUPERIOD , DateTime DATEOFVAL, decimal PRESENTVAL, decimal COMPLETEVAL, decimal FORCEVAL, 
                             decimal FIREINSURANCE, string REMARKS, string ValuerComments, string AccessRoad,
                             long APPNO, int UpdateLevel)
    {

        string _errmessage;
        string sqlUpdate;


        sqlUpdate = @"UPDATE VALUATION SET VALUPERIOD=@VALUPERIOD , DATEOFVAL=@DATEOFVAL , PRESENTVAL=@PRESENTVAL , 
                      COMPLETEVAL=@COMPLETEVAL , FORCEVAL=@FORCEVAL, FIREINSURANCE=@FIREINSURANCE, REMARKS=@REMARKS, 
                      ValuerComments=@ValuerComments , AccessRoad=@AccessRoad
                      where APPNO=@APPNO and status='A' and UpdateLevel=@UpdateLevel";

        //sqlConn = new SqlConnection(myconnection);
        sqlCmd = new SqlCommand(sqlUpdate, myconnection);

        //

        sqlCmd.Parameters.AddWithValue("VALUPERIOD", VALUPERIOD);
        sqlCmd.Parameters.AddWithValue("DATEOFVAL", DATEOFVAL);
        sqlCmd.Parameters.AddWithValue("PRESENTVAL", PRESENTVAL);
        sqlCmd.Parameters.AddWithValue("COMPLETEVAL", COMPLETEVAL);
        sqlCmd.Parameters.AddWithValue("FORCEVAL", FORCEVAL);
        sqlCmd.Parameters.AddWithValue("FIREINSURANCE", FIREINSURANCE);
        sqlCmd.Parameters.AddWithValue("REMARKS", REMARKS);
        sqlCmd.Parameters.AddWithValue("ValuerComments", ValuerComments);
        sqlCmd.Parameters.AddWithValue("AccessRoad", AccessRoad);
        sqlCmd.Parameters.AddWithValue("APPNO", APPNO);
        sqlCmd.Parameters.AddWithValue("UpdateLevel", UpdateLevel);

        int rowAdded = 0;

        try
        {
            myconnection.Open();
            rowAdded = sqlCmd.ExecuteNonQuery();
        }

        catch (Exception err)
        {
            _errmessage = err.Message;
        }

        finally
        {
            myconnection.Close();
        }

        return rowAdded;

    }
}
