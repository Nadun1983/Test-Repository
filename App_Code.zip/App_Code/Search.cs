using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data;
using System.Data.SqlClient;

/// <summary>
/// Summary description for Search
/// </summary>
public class Search
{

    SqlConnection myconnection = new SqlConnection(ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString);
    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();

    private SqlDataAdapter sqlAdapter;
    private SqlCommand sqlCmd;
    private DataTable dt;
    DataWorksClass dw;

    public Search()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public DataTable searchbyNIC(string NicNo)
    {
        string sqlSelect;
        string Error;

        sqlSelect = @"select distinct ah.NicNo,c.cracno as LoanNo,
                        ah.AppNo, rtrim(cm.Surname) + '   ' + rtrim(cm.Initials) AS Fullname , 
                        rtrim(cm.Location) + ',' + rtrim(cm.Street) + ',' + rtrim(cm.City) as Address ,
                        cm.HomeNo , ca.RecvDate , ca.ApprovDate 
                        from CrApp ca inner join AppHolder ah on ah.AppNo=ca.AppNo
                        inner join CustomerMain cm on  ah.NicNo=cm.NicNo
                        inner join crmast c on c.appno=ca.AppNo
                        where ah.NicNo=@NicNo
                        and c.acstatus='A'
                        UNION ALL
                        select distinct ah.NicNo,0 as LoanNo,
                        ah.AppNo, rtrim(cm.Surname) + '   ' + rtrim(cm.Initials) AS Fullname , 
                        rtrim(cm.Location) + ',' + rtrim(cm.Street) + ',' + rtrim(cm.City) as Address ,
                        cm.HomeNo , ca.RecvDate , ca.ApprovDate 
                        from CrApp ca inner join AppHolder ah on ah.AppNo=ca.AppNo
                        inner join CustomerMain cm on  ah.NicNo=cm.NicNo
                        where ah.NicNo=@NicNo and ca.AppNo not in (select AppNo from CrMast)
                        order by cracno";

        sqlAdapter = new SqlDataAdapter(sqlSelect, myconnection);

        sqlAdapter.SelectCommand.Parameters.AddWithValue("NicNo", NicNo);
        dt = new DataTable();

        try
        {
            myconnection.Open();
            sqlAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            Error = er.ToString();
        }
        finally
        {
            myconnection.Close();
        }

        return dt;

    }

    public DataTable searchbySurname(string Surname)
    {
        string sqlSelect;
        string Error;

        sqlSelect = @"select ah.NicNo, ah.AppNo, rtrim(cm.Surname) + '   ' + rtrim(cm.Initials) AS Fullname , 
                    rtrim(cm.Location) + ',' + rtrim(cm.Street) + ',' + rtrim(cm.City) as Address ,
                    cm.HomeNo , ca.RecvDate , ca.ApprovDate from AppHolder ah , CrApp ca , CustomerMain cm 
                    where ah.AppNo=ca.AppNo and ah.NicNo=cm.NicNo and  cm.Surname=@Surname";

        sqlAdapter = new SqlDataAdapter(sqlSelect, myconnection);

        sqlAdapter.SelectCommand.Parameters.AddWithValue("Surname", Surname);
        dt = new DataTable();

        try
        {
            myconnection.Open();
            sqlAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            Error = er.ToString();
        }
        finally
        {
            myconnection.Close();
        }

        return dt;

    }

    public DataTable searchbyPassportNo(string PassportNo)
    {
        string sqlSelect;
        string Error;

        sqlSelect = @"select ah.NicNo, ah.AppNo, rtrim(cm.Surname) + '   ' + rtrim(cm.Initials) AS Fullname , 
                    rtrim(cm.Location) + ',' + rtrim(cm.Street) + ',' + rtrim(cm.City) as Address ,
                    cm.HomeNo , ca.RecvDate , ca.ApprovDate from AppHolder ah , CrApp ca , CustomerMain cm 
                    where ah.AppNo=ca.AppNo and ah.NicNo=cm.NicNo and  cm.PassportNo=@PassportNo";

        sqlAdapter = new SqlDataAdapter(sqlSelect, myconnection);

        sqlAdapter.SelectCommand.Parameters.AddWithValue("PassportNo", PassportNo);
        dt = new DataTable();

        try
        {
            myconnection.Open();
            sqlAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            Error = er.ToString();
        }
        finally
        {
            myconnection.Close();
        }

        return dt;

    }

    public DataTable serchByCracno(string cracno)
    {
        string sqlSelect;
        string Error;

        sqlSelect = @"SELECT M.NicNo, C.CrAcNo, H.AppNo, C.AprovdAmt, 
                      rtrim(M.Initials)  + '  ' +rtrim(M.Surname) AS Fullname, HoldRelation
                      FROM CrMast C, AppHolder H, CustomerMain M WHERE C.AppNo=H.AppNo AND
                      H.NicNo=M.NicNo AND C.CrAcNo=@cracno and C.AcStatus='A' ORDER BY HolderType";

        sqlAdapter = new SqlDataAdapter(sqlSelect, myconnection);

        sqlAdapter.SelectCommand.Parameters.AddWithValue("cracno", cracno);
        dt = new DataTable();

        try
        {
            myconnection.Open();
            sqlAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            Error = er.ToString();
        }
        finally
        {
            myconnection.Close();
        }

        return dt;

    }

    public DataTable searchbyAppno(string appno)
    {
        string sqlSelect;
        string Error;

        sqlSelect = @"SELECT M.NicNo, C.CrAcNo, H.AppNo, C.AprovdAmt, 
                      rtrim(M.Initials)  + '  ' +rtrim(M.Surname) AS Fullname, HoldRelation
                      FROM CrMast C, AppHolder H, CustomerMain M WHERE C.AppNo=H.AppNo AND
                      H.NicNo=M.NicNo AND C.AppNo=@appno and C.AcStatus='A' ORDER BY HolderType";

        sqlAdapter = new SqlDataAdapter(sqlSelect, myconnection);

        sqlAdapter.SelectCommand.Parameters.AddWithValue("appno", appno);
        dt = new DataTable();

        try
        {
            myconnection.Open();
            sqlAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            Error = er.ToString();
        }
        finally
        {
            myconnection.Close();
        }

        return dt;

    }

    public DataTable GetInquiryByDateRange(DateTime fromdate, DateTime Todate)
    {
        string sqlSelect = @"SELECT NicNo AS CustomerNic, LogDate,UserName, rtype AS TypeOfInquiry, Remarks
                             FROM Logtb L, Users U 
                             WHERE Logdate >= @fromdate AND Logdate <= @Todate AND
                             L.UserId=U.UserId
                             ORDER BY U.UserName";
        
        sqlAdapter = new SqlDataAdapter(sqlSelect, myconnection);
        sqlAdapter.SelectCommand.Parameters.AddWithValue("fromdate", fromdate);
        sqlAdapter.SelectCommand.Parameters.AddWithValue("Todate", Todate);

        dt = new DataTable();

        try
        {
            myconnection.Open();
            sqlAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }

        finally
        {
            myconnection.Close();
            myconnection.Dispose();
        }

        return dt;

    }

    public DataTable GetInquiryByUserName(DateTime fromdate, DateTime Todate, string userid)
    {
        string sqlSelect = @"SELECT NicNo AS CustomerNic, LogDate,UserName,  rtype AS TypeOfInquiry, Remarks
                             FROM Logtb L, Users U 
                             WHERE Logdate >= @fromdate AND Logdate <= @Todate AND
                             L.UserId=U.UserId AND L.UserId=@userid
                             ORDER BY U.UserName";

        sqlAdapter = new SqlDataAdapter(sqlSelect, myconnection);
        sqlAdapter.SelectCommand.Parameters.AddWithValue("fromdate", fromdate);
        sqlAdapter.SelectCommand.Parameters.AddWithValue("Todate", Todate);
        sqlAdapter.SelectCommand.Parameters.AddWithValue("userid", userid);

        dt = new DataTable();

        try
        {
            myconnection.Open();
            sqlAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }

        finally
        {
            myconnection.Close();
            myconnection.Dispose();
        }

        return dt;
    }

    public DataTable CurrentlyProcessFile(DateTime startdate, DateTime enddate)
    {
        dt = new DataTable();
        dw = new DataWorksClass(constring);
        DateTime adddate = Convert.ToDateTime(System.DateTime.Now.ToShortDateString());
        dw.SetDataAdapter(@"select cm.nicno,ca.AppNo as ApplicationNo , rtrim(rtrim(cm.initials) + '  ' + rtrim(cm.surname)) as CustomerName,
                            ca.CrAmt as LoanAmount ,
                            rtrim(rtrim(year(jr.startdate))+ '/'+ rtrim(month(jr.startdate))+'/'+ rtrim(day(jr.startdate))) as 
                            StartDate , e.Empname as CreditOfficer
                            from jobrecord jr,crapp ca,appholder ah,customermain cm,Employee e
                            where ca.appno=jr.appno and ah.holdertype='P' and ah.nicno=cm.nicno and ah.appno=ca.appno
                            and jr.enddate is null and jr.jobcode=11 and jr.processingOfficer1=e.empno 
                            and jr.startdate >= @startdate and jr.startdate <=@enddate
                            order by year(jr.startdate) , month(jr.startdate) ,day(jr.startdate) , ca.AppNo");
        dw.SetDataAdapterParameters("startdate", startdate);
        dw.SetDataAdapterParameters("enddate", enddate);
        dt = dw.GetDataTable();
        return dt;
    }

    public DataTable ForProcessFile()
    {
        dt = new DataTable();
        dw = new DataWorksClass(constring);
        DateTime adddate = Convert.ToDateTime(System.DateTime.Now.ToShortDateString());
        dw.SetDataAdapter(@"SELECT A.NicNo,ZZ.AppNo,ZZ.CustomerName
                            FROM (SELECT A.AppNo,
                            RTRIM(E.TITLEDESC) + ' ' + RTRIM(D.Initials)+ ' ' + RTRIM(D.Surname) AS CustomerName, 
                            CONVERT(varchar(10),MAX(DISTINCT A.EndDate),112)ReceivedDate,
                            CONVERT(VARCHAR(10), MAX(DISTINCT A.Enddate), 103)ReceivedDateTime 
                            FROM JobRecord A 
                            INNER JOIN AppHolder C ON A.AppNo = C.AppNo 
                            INNER JOIN CustomerMain D ON C.NicNo = D.NicNo 
                            INNER JOIN TITLE E ON D.TitleCode = E.TITLECODE
                            WHERE A.JobCode IN (2, 9, 44) AND 
                            C.HolderType = 'P' AND
                            A.EndDate <> '' 
                            GROUP BY A.AppNo, 
                            D.Surname,
                            D.Initials, 
                            E.TITLEDESC 
                            HAVING(COUNT(A.JobCode) >= 2)) ZZ
                            LEFT JOIN 
                            (SELECT B.AppNo 
                            FROM JobRecord B 
                            WHERE B.JobCode=11) YY 
                            ON ZZ.AppNo=YY.AppNo 
                            WHERE(YY.AppNo Is NULL)
                            GROUP BY ZZ.AppNo, 
                            ZZ.CustomerName ");       
        dt = dw.GetDataTable();
        return dt;
    }

    public DataTable GetDisbursementDaysInArreas()
    {
        dt = new DataTable();
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select m.Nicno,d.CrAcnO as CrAcno, RTRIM(Initials) + RTRIM(Surname) AS FullName,
                            RTRIM(Location) + RTRIM(Street) + RTRIM(City) AS FullAddress,
                            m.NicNo, DATEDIFF(day,d.GrantDate,GETDATE()) as NoOfDayes,
                            NoOfDisb-ScheduleNo AS NoOfDisbursementsToBeDisb,r.IntRate
                            from disbbalsum d, appholder a, customermain m, crmast r, crapp c
                            where r.cracno=d.cracno and r.appno=c.appno and
                            c.appno=a.appno and a.nicno=m.nicno and
                            holdertype='P' and DATEDIFF(day,d.GrantDate,GETDATE()) < 90 
                            and NoOfDisb-ScheduleNo !=0 order by d.cracno ");
        dt = dw.GetDataTable();
        return dt;
    }

    public DataTable GetFinalNotRelease()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select c.crdes as LoanCategory, count(m.cracno) as NoofLoans, sum(m.aprovdamt) as AprovedAmt, 				
                            sum(m.grantamt) as GrantAmt from crmast m,CrCategory c				
                            where m.acstatus = 'A' and m.aprovdamt > m.grantamt and c.crcatcode=m.crcat				
                            group by c.crdes");
        return dw.GetDataTable();
    }


  public DataTable GatherloanData()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select distinct c.nicno,c.custno,rtrim(titledesc)+' '+rtrim(initials)+' '+rtrim(surname) as fullname,
                            c.location as personalLocation , c.street as personalStreet , c.city as personalCity,
                            e.empname, ea.location as employerLocation , ea.street as employerStreet , ea.city as employerCity,
                            ed.designation,cm.appno,cr.crdes, p.descrip,
                            cm.cracno,h.intrate,h.instalment,h.lastcompletedduedate,
                            h.PaidInstalments,h.actoutbal,cm.grantamt,cm.grantdate,
                            cm.crperiod,
                            case 
                            when  datediff(month,h.LastCompletedDueDate,getdate()) < 0 then 0
                            else 
                            datediff(month,h.LastCompletedDueDate,getdate()) end as arreasmonths,
                            isnull(tab1.shortfall,0) as shortfall,
                            case 
                            when datediff(month,h.LastCompletedDueDate,getdate()) < 0 then
                            0+isnull(tab1.shortfall,0)
                            else
                            datediff(month,h.LastCompletedDueDate,getdate()) * h.instalment + isnull(tab1.shortfall,0)
                            end as arreasamount
                            from crmast cm left join
                            (select sum(assignamt-tramt) as shortfall,cracno from transassign where
                             trdate = (select max(trdate) from transassign where trstatus='P')
                            and trstatus='P' group by cracno) as  tab1 on cm.cracno=tab1.cracno
                            inner join housprop h on cm.cracno=h.cracno inner join
                            crholder ch on ch.appno=cm.appno inner join 
                            customermain c on c.nicno=ch.nicno inner join customersub s
                            on c.nicno=s.nicno inner join title t on c.titlecode=t.titlecode
                            inner join  empdesig ed on s.empid=ed.id inner join
                            empaddress ea on ed.recordno=ea.recordno inner join
                            employer e on ea.employerno=e.employerno inner join
                            crcategory cr on cm.crcat=cr.crcatcode inner join
                            crcatpurpose cp on cm.catpurposeid=cp.catpurposeid inner join
                            crpurpose p on cp.purposecode=p.purposecode
                            where cm.acstatus='A'
                            order by c.nicno");
        return dw.GetDataTable();
    }


  public object SearchByInitials(string Initials)
  {
      dw = new DataWorksClass(constring);
      dw.SetDataAdapter(@"select distinct ah.NicNo, c.cracno as LoanNo,
                        ah.AppNo,  rtrim(cm.Surname) + '   ' + rtrim(cm.Initials) AS Fullname , 
                        rtrim(cm.Location) + ',' + rtrim(cm.Street) + ',' + rtrim(cm.City) as Address ,
                        cm.HomeNo , ca.RecvDate , ca.ApprovDate 
                        from AppHolder ah inner join CrApp ca on ah.AppNo=ca.AppNo inner join
                        CustomerMain cm on ah.NicNo=cm.NicNo left join crmast c on ca.appno=c.AppNo
                        where cm.Initials like '%" + Initials + @"%' and 
                        order by cracno");
      dw.SetDataAdapterParameters("Initials", Initials);
      return dw.GetDataTable();
  }

  public object SearchByInstalment(string Instalment)
  {
      dw = new DataWorksClass(constring);
      dw.SetDataAdapter(@"SELECT M.NicNo,C.CrAcNo, H.AppNo,  C.AprovdAmt, 
                        rtrim(M.Initials)  + '  ' +rtrim(M.Surname) AS Fullname, HoldRelation
                        FROM CrMast C, AppHolder H, CustomerMain M ,housprop hp WHERE C.AppNo=H.AppNo 
                        and hp.cracno=c.cracno and H.NicNo=M.NicNo AND hp.instalment=@Instalment
                        and c.acstatus='A' ORDER BY HolderType");
      dw.SetDataAdapterParameters("Instalment", Instalment);
      return dw.GetDataTable();
  }

  public object SearchByEPF(string EPF)
  {
      dw = new DataWorksClass(constring);
      dw.SetDataAdapter(@"select distinct ah.NicNo, c.cracno as LoanNo,
                        ah.AppNo, rtrim(cm.Surname) + '   ' + rtrim(cm.Initials) AS Fullname , 
                        rtrim(cm.Location) + ',' + rtrim(cm.Street) + ',' + rtrim(cm.City) as Address ,
                        cm.HomeNo , ca.RecvDate , ca.ApprovDate 
                        from AppHolder ah inner join CrApp ca on ah.AppNo=ca.AppNo inner join
                        CustomerMain cm on ah.NicNo=cm.NicNo left join crmast c on ca.appno=c.AppNo
                        inner join customersub cs on cs.nicno=cm.NicNo
                        where  cs.epfno=@EPF and c.acstatus='A'
                        and cm.customertype <> 'O' order by cracno");
      dw.SetDataAdapterParameters("EPF", EPF);
      return dw.GetDataTable();
  }

  public object SearchByAddress(string Address)
  {
      dw = new DataWorksClass(constring);
      dw.SetDataAdapter(@"select distinct ah.NicNo, c.cracno as LoanNo,
                        ah.AppNo, rtrim(cm.Surname) + '   ' + rtrim(cm.Initials) AS Fullname , 
                        rtrim(cm.Location) + ',' + rtrim(cm.Street) + ',' + rtrim(cm.City) as Address ,
                        cm.HomeNo , ca.RecvDate , ca.ApprovDate 
                        from AppHolder ah inner join CrApp ca on ah.AppNo=ca.AppNo
                        inner join CustomerMain cm on ah.NicNo=cm.NicNo left join crmast c on ca.appno=c.AppNo
                        where ((cm.Location like '%" + Address+@"%') or (cm.Street like '%"+Address+@"%') or (cm.City like '%"+Address+@"%'))
                        and c.acstatus='A' order by cracno");
      dw.SetDataAdapterParameters("Address", Address);
      return dw.GetDataTable();
  }

  public DataTable GetCustdetail(string nicno)
  {
      dw = new DataWorksClass(constring);
      dw.SetDataAdapter(@"select distinct ah.NicNo,cm.passportno,c.cracno as LoanNo,
                                    ah.AppNo, rtrim(cm.othername) + '   ' + rtrim(cm.Surname) AS Fullname , 
                                    rtrim(cm.Location) + ',' + rtrim(cm.Street) + ',' + rtrim(cm.City) as PersonalAddress ,
                                    cm.HomeNo,cm.mobile,cm.dobirth as DateofBirth,ah.holdrelation,cs.epfno as EpfNo,em.designation as Designation ,ep.EmpName,
                                    ed.location as Location,ed.street as Street
                                    from AppHolder ah inner join CrApp ca on ah.AppNo=ca.AppNo
                                    inner join CustomerMain cm on h.NicNo=cm.NicNo left join crmast c 
                                    on ca.appno=c.AppNo inner join customersub cs on cs.nicno=cm.nicno
                                    inner join Empdesig em on cs.empid=em.id inner join empaddress ed
                                    on em.recordno=ed.recordno inner join employer ep on ed.employerno=ep.employerno
                                    where ah.NicNo=@NicNo and c.acstatus='A' order by cracno");
      dw.SetDataAdapterParameters("nicno", nicno);
      return dw.GetDataTable();
  }


    //2010-04-30 vihanga
  public DataTable GetGlDetailsMain(string number)
  {
      dw = new DataWorksClass(constring);
      dw.SetDataAdapter(@"select bnk.BankName,br.BranchName,b.Batchdate,b.TransDate,b.BatchType,b.Number,
                            sum(b.tramt) as TotAmount,b.BankName as Bankcode,b.BranchName as BranchCode
                            from batchtmp b,bank bnk,branch br
                            where b.number=@number and bnk.bankno=b.bankname and br.branchno=b.branchname 
                            and br.bankno=b.bankname
                            group by bnk.BankName,br.BranchName,b.Batchdate,b.transdate,b.batchtype,b.number,
                            b.BankName,b.BranchName");
      dw.SetDataAdapterParameters("number", number);
      return dw.GetDataTable();
  }

  //2010-04-30 vihanga
  public DataTable GetglDetailsSub(string number, string bankname, string branchname)
  {
      dw = new DataWorksClass(constring);
      dw.SetDataAdapter(@"select b.RefNo,b.Cracno,b.TrAmt,b.TaskId,b.Status,b.IsGlUpdate,b.TransNo
                          from batchtmp b where b.number = @number and b.bankname=@bankname and b.branchname=@branchname");
      dw.SetDataAdapterParameters("number", number);
      dw.SetDataAdapterParameters("bankname", bankname);
      dw.SetDataAdapterParameters("branchname", branchname);
      return dw.GetDataTable();
  }



  //2010-07-01 vihanga
  public DataTable GetCustMainDetails(string nicno)
  {
      dw = new DataWorksClass(constring);
      dw.SetDataAdapter(@"select c.NicNo, rtrim(t.titledesc) + ' ' + rtrim(c.initials) + ' ' + rtrim(surname) as CutName,
                        rtrim(c.location) + ' ' + rtrim(c.street) + ' ' + rtrim(c.city) as Address , c.HomeNo,c.Mobile
                        from CustomerMain c , title t where t.titlecode=c.titlecode and nicno=@nicno");
      dw.SetDataAdapterParameters("nicno", nicno);
      return dw.GetDataTable();
  }

  //2010-07-01 vihanga
  //and c.acstatus='A' 
  public DataTable GetCustLoanDetail(string NicNo)
  {
      dw = new DataWorksClass(constring);
      dw.SetDataAdapter(@"select h.cracno as LoanNo,ah.AppNo, 
							rtrim(year(ca.RecvDate))+'/'+ rtrim(month(ca.RecvDate))+'/'+rtrim(day(ca.RecvDate)) as RecevDate, 
							rtrim(year(ca.ApprovDate))+'/'+ rtrim(month(ca.ApprovDate))+'/'+rtrim(day(ca.ApprovDate)) as ApprovDate,
							rtrim(year(c.GrantDate))+'/'+ rtrim(month(c.GrantDate))+'/'+rtrim(day(c.GrantDate)) as GrantDate,
							c.AprovdAmt,h.Instalment,h.IntRate ,h.actoutbal as OutBal,ISNULL(i.ArreasTotal,0) as Arreas,CrDes
							,(c.crperiod-(datediff(month,c.grantdate,h.LastCompletedDueDate))) as Remaining
							from AppHolder ah inner join CrApp ca on ah.AppNo=ca.AppNo
							inner join CustomerMain cm on ah.NicNo=cm.NicNo left join crmast c
							on ca.appno=c.AppNo inner join housprop h on h.cracno=c.cracno
							inner join CrCategory r on h.CrCat=r.CrCatCode inner join 
							IntProvisionIndividual i on i.cracno = h.CrAcNo
							where ah.NicNo= @NicNo and i.DateKey =
							(select MAX(DateKey) from IntProvisionIndividual where NicNo=@NicNo)	
							order by c.cracno");
      dw.SetDataAdapterParameters("NicNo", NicNo);
      return dw.GetDataTable();
  }

  //2011-11-04 vihanga
  public DataTable GatherloanDataforDeed()
  {
      dw = new DataWorksClass(constring);
      dw.SetDataAdapter(@"select c.AppNo,c.Cracno,c.Aprovdamt,CONVERT(nvarchar(30), c.GrantDate, 102) as Grant_Date,
  			  ch.Nicno,rtrim(cm.initials) + ' ' + rtrim(cm.surname) as Cust_Name
  			  from crmast c,crholder ch, customermain cm
  			  where --c.aprovdamt=c.grantamt and c.grantamt>0 and 
			  ch.cracno=c.cracno 
			  and cm.nicno=ch.nicno and ch.holdertype='P' --and c.GrantDate>'2009-08-01' 
			  order by c.cracno");
      return dw.GetDataTable();
  }

  public DataTable gettrackingdetails(DateTime fromdate, DateTime todate)
  {
      dw = new DataWorksClass(constring);
      dw.SetDataAdapter(@"select CASE when C.CrAmt <= 5000000.00
                                then 
                                'Credit Officer'
                                else
                                '-' end as Authority,
                                CASE when C.CrAmt > 5000000.00 and C.CrAmt <= 6000000.00
                                then 
                                'AGM (Credit / CFI)'
                                else
                                '-' end as Authority,
                                CASE when C.CrAmt > 6000000.00 and C.CrAmt <= 7000000.00
                                then 
                                'DGM (Credit)'
                                else
                                '-' end as Authority,
                                CASE when C.CrAmt > 7000000.00 and C.CrAmt <= 8000000.00
                                then 
                                'Senior Deputy General Manager'
                                else
                                '-' end as Authority,
                                CASE when C.CrAmt > 8000000.00 and C.CrAmt <= 12000000.00
                                then 
                                'General Manager / CEO'
                                else
                                '-' end as Authority,
                                CASE when C.CrAmt > 12000000.00 and C.CrAmt <= 50000000.00
                                then 
                                'Credit Committee'
                                else
                                '-' end as Authority,
                                C.appno,Cp.Descrip,StartDate,EndDate,E.EmpName,JobDesc,C.ApprovedAmt
                                 from JobRecord  jr,JobListing jl,Employee E,
                                crapp C,CrPurpose Cp,CrCatPurpose Cr,Appcategory A where 
                                jr.JobCode=jl.JobCode 
                                and (jr.StartDate >= @fromdate and jr.StartDate <= @todate)
                                and E.EmpNo=jr.ProcessingOfficer1
                                and C.appno=jr.AppNo and c.AppNo=A.AppNo 
                                and A.CatPurposeId=Cr.catpurposeid and Cr.purposecode=Cp.PurposeCode
                                order by jr.StartDate");
      dw.SetDataAdapterParameters("fromdate", fromdate);
      dw.SetDataAdapterParameters("todate", todate);
      return dw.GetDataTable();
  }
}
