using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for ReminderClass
/// </summary>
public class ReminderClass
{

    public ReminderClass()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    private string constring = ConfigurationManager.ConnectionStrings["housdbString"].ToString();
    DataWorksClass dw; // dataworks class



    public DataTable GetreminderData()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from reminder");
        return dw.GetDataTable();
    }

    public DataTable GetAccDetails(int duration)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter
            (@"Exec SPReminder1 @duration");
        dw.SetDataAdapterParameters("@duration", duration);
        
        return dw.GetDataTable();
    }

    public DataTable Getdatalist()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select H.CrAcNo,C.CrDes,IntRate,Instalment,ActOutBal,
                                CONVERT(VARCHAR(10),lsttrdate, 111) AS LastTransactionDate,
                                CONVERT(VARCHAR(10),DateDue, 111) AS DateDue,HomeNo,Mobile  from 
                                HousProp H,CrCategory C,CrHolder Cr,Customermain Cm where 
                                ActOutBal < Instalment and C.CrCatCode=H.CrCat and H.CrAcNo=Cr.cracno
                                and Cr.HolderType='P' and Cr.NicNo=Cm.NicNo
                                and ActOutBal > 0.00 order by DateDue");
        return dw.GetDataTable();
    }

//    public DataTable GetPrintAccDetails(int duration)
//    {
//        dw = new DataWorksClass(constring);
//        dw.SetDataAdapter
//            (@"select h.CrAcNo as Loan_Account_No,rTrim(Initials) + '' + rTrim(Othername) + ''+rtrim(Surname) as HolderName, 
//            rTrim(Location) as Number, rTrim(Street) as street, rTrim(City) as city,
//            LastCompletedDueDate from HousProp h 
//            inner join crholder c on h.CrAcNo = c.CrAcNo
//            inner join customermain cm on c.CustNo = cm.CustNo 
//            where DateDiff(month,LastCompletedDueDate,GetDate())= @duration");
//        dw.SetDataAdapterParameters("@duration", duration);

//        return dw.GetDataTable();
//    }

}
