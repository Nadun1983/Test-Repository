
using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// Summary description for LoadCustomer
/// </summary>
public class LoadCustomer
{

    private SqlDataAdapter da;
    DataSet ds;
    private SqlConnection mycon;
    SqlCommand scm;
    DataWorksClass dw;
    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();

    public LoadCustomer()
    {
        SqlConnection myconnection = new SqlConnection(ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString);
        this.mycon = myconnection;
    }

    public DataTable GetCustomerDet(string nicno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"SELECT ag.NicNo AS AgNicNo,* FROM logtb l inner join CustomerMain c 
                            on c.nicno=l.nicno left join AppSecGarant ag on c.nicno=ag.nicno 
                            inner join CustomerSub S on C.NicNo=S.NicNo WHERE c.nicno =@nicno");
        dw.SetDataAdapterParameters("nicno", nicno);
        return dw.GetDataTable();
    }
    

    public DataTable GetPreviousGurantorDetails(string nicno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select a.nicno as NicNo, R.AppNo,H.CrAcNo,T.CrDes, N.BranchName
                            from CREDITBRDB.TDBBranches.CreditAdmin.AppSecGarant a, 
                            CREDITBRDB.TDBBranches.CreditAdmin.CrHolder R, 
                            CREDITBRDB.TDBBranches.CreditAdmin.HousProp H, 
                            CREDITBRDB.TDBBranches.CreditAdmin.nsb_branch N, 
                            CREDITBRDB.TDBBranches.CreditAdmin.CrCategory T where a.AppNo=R.AppNo 
                            and a.nicno=@nicno and R.CrAcNo = H.CrAcNo
                            and H.BranchCode = N.BranchNo and H.ActOutBal > 0 and H.CrCat = T.CrCatCode
                            UNION ALL
                            select a.nicno as NicNo, R.AppNo,H.CrAcNo, T.CrDes, 'Credit Division' as BranchName
                            from AppSecGarant a, CrHolder R, 
                            HousProp H, CrCategory T where a.AppNo=R.AppNo 
                            and a.nicno=@nicno and R.CrAcNo = H.CrAcNo and
                            H.ActOutBal > 0 and H.CrCat = T.CrCatCode");
        dw.SetDataAdapterParameters("nicno", nicno);
        return dw.GetDataTable();
    }

    //public DataSet InsertCustomerLog(string nicno, DateTime logdate, string rtype, string brcode,
    //                                 string remarks, string userid, string application, decimal amtreq,
    //                                 decimal amtgr, string reasonid, int updatelevel)
    //{
    //    string SQL = " INSERT INTO LogTb (nicno,logdate,rtype,brcode,remarks,userid,application,amtreq,"+
    //                 " amtgr,reasonid, UpdateLevel) VALUES" +
    //                 " ('" + nicno + "','" + logdate + "','" + rtype + "','" + brcode + "'," +
    //                 " '" + remarks.Trim() + "','" + userid + "','" + application + "'," +
    //                 " '" + amtreq + "','" + amtgr + "','" + reasonid + "', "+updatelevel+")";

    //    da = new SqlDataAdapter(SQL, mycon);
    //    ds = new DataSet();
    //    mycon.Open();
    //    da.Fill(ds, SQL);
    //    da.Dispose();
    //    mycon.Close();
    //    return ds;
    //}

    public int InsertCustomerLog(string nicno, DateTime logdate, string rtype, string brcode,
                                  string remarks, string userid, string application, decimal amtreq,
                                  decimal amtgr, string reasonid, int updatelevel)
    {
        string SQL = @"INSERT INTO LogTb (nicno,logdate,rtype,brcode,remarks,userid,application,amtreq,
                       amtgr,reasonid, UpdateLevel) VALUES
                       (@nicno,@logdate,@rtype,@brcode,@remarks,@userid,@application,@amtreq,
                        @amtgr,@reasonid,@updatelevel)";
        scm = new SqlCommand(SQL, mycon);

        scm.Parameters.AddWithValue("nicno", nicno);
        scm.Parameters.AddWithValue("logdate", logdate);
        scm.Parameters.AddWithValue("rtype", rtype);
        scm.Parameters.AddWithValue("brcode", brcode);
        scm.Parameters.AddWithValue("remarks", remarks);
        scm.Parameters.AddWithValue("userid", userid);
        scm.Parameters.AddWithValue("application", application);
        scm.Parameters.AddWithValue("amtreq", amtreq);
        scm.Parameters.AddWithValue("amtgr", amtgr);
        scm.Parameters.AddWithValue("reasonid", reasonid);
        scm.Parameters.AddWithValue("updatelevel", updatelevel);

        int rowadd = 0;
        try
        {
            mycon.Open();
            rowadd = scm.ExecuteNonQuery();
        }
        catch (Exception er)
        {
            //sqlError = er.Message;
        }
        finally
        {
            mycon.Close();
        }
        return rowadd;
    }

    //public DataSet InsertCMasterDet(string nicno, string titlecode, string intial, string surname, string oname,
    //                                string location, string street, string city,string custType, int updateLevel)
    //{ 
    //    string SQL = " INSERT INTO CustomerMain (nicno,titlecode,initials,surname,othername,location,street,"+
    //                 " city, CustomerType, UpdateLevel)" +
    //                 " VALUES ('" + nicno + "','" + titlecode + "','" + intial.Trim() + "'," +
    //                 " '" + surname.Trim() + "','" + oname.Trim() + "','" +location.Trim() + "'," +
    //                 " '" + street.Trim() + "','" + city.Trim() + "', '"+custType+"',"+updateLevel+")";

    //     da = new SqlDataAdapter(SQL, mycon);
    //     ds = new DataSet();
    //     da.Fill(ds, SQL);
    //     da.Dispose();
    //     mycon.Close(); 
    //    return ds;
    //}

    public int InsertCMasterDet(string nicno, string titlecode, string intial, string surname, string oname,
                                    string location, string street, string city, string custType, int updateLevel)
    {
        string sql = @"INSERT INTO CustomerMain (nicno,titlecode,initials,surname,othername,location,street,
                     city, CustomerType, UpdateLevel)
                     VALUES (@nicno,@titlecode,@intial,@surname,@oname,@location,@street,@city,
                     @custType,@updateLevel)";

        scm = new SqlCommand(sql, mycon);

        scm.Parameters.AddWithValue("nicno", nicno);
        scm.Parameters.AddWithValue("titlecode", titlecode);
        scm.Parameters.AddWithValue("intial", intial);
        scm.Parameters.AddWithValue("surname", surname);
        scm.Parameters.AddWithValue("oname", oname);
        scm.Parameters.AddWithValue("location", location);
        scm.Parameters.AddWithValue("street", street);
        scm.Parameters.AddWithValue("city", city);
        scm.Parameters.AddWithValue("custType", custType);
        scm.Parameters.AddWithValue("updateLevel", updateLevel);

        int rowadd = 0;
        try
        {
            mycon.Open();
            rowadd = scm.ExecuteNonQuery();
        }
        catch (Exception er)
        {
            //sqlError = er.Message;
        }
        finally
        {
            mycon.Close();
        }
        return rowadd;
    }

    public int InserCustomerSub(string nicno, string customercat, int updateLevel)
    {
        string SQL = @"INSERT INTO CustomerSub (NicNo, CustomerCat, UpdateLevel) VALUES
                      (@nicno,@customercat,@updateLevel)";
        scm = new SqlCommand(SQL, mycon);

        scm.Parameters.AddWithValue("nicno", nicno);
        scm.Parameters.AddWithValue("customercat", customercat);
        scm.Parameters.AddWithValue("updateLevel", updateLevel);
        

        int rowadd = 0;
        try
        {
            mycon.Open();
            rowadd = scm.ExecuteNonQuery();
        }
        catch (Exception er)
        {
            //sqlError = er.Message;
        }
        finally
        {
            mycon.Close();
        }
        return rowadd;
    }

    public DataSet GetCustomerInqHistory(string nicno)
    {
        string SQL =  " SELECT branchname,logdate,rtype,descript,remarks,application,amtreq,amtgr,userid FROM "+
                      " customermain c inner join logtb l on l.nicno=c.nicno inner join nsb_branch on "+
                      " l.brcode=branchno LEFT OUTER JOIN reasontb r on l.reasonid=r.reasonid WHERE "+
                      " l.nicno='"+nicno+"' OR "+
                      " (l.reasonid=0 and l.nicno='"+nicno+"') ORDER BY logdate";

        da = new SqlDataAdapter(SQL, mycon);
        ds = new DataSet();
        mycon.Open();
        da.Fill(ds, SQL);
        da.Dispose();
        mycon.Close();
        return ds;
    }

    //public DataSet InserCustomerSub(string nicno, string customercat, int updateLevel)
    //{
    //    string SQL = " INSERT INTO CustomerSub (NicNo, CustomerCat, UpdateLevel) VALUES "+
    //                 " ('" + nicno + "', '"+customercat+"' ," + updateLevel + ")";
    //    da = new SqlDataAdapter(SQL, mycon);
    //    ds = new DataSet();
    //    mycon.Open();
    //    da.Fill(ds,SQL);
    //    da.Dispose();
    //    mycon.Close();
    //    return ds;
    //}

    public DataSet GetEmployerDetails(string nicno)
    {
        string SQL = " SELECT EmpName, RTRIM(A.Location) + ' ' + RTRIM(A.Street) + ' ' + RTRIM(A.City) AS Address," +
                     " D.Telephone, D.Designation FROM CustomerSub C, Employer E, EmpAddress A, EmpDesig D "+
                     " WHERE C.EmpId = D.Id AND D.RecordNo = A.RecordNo AND " +
                     " A.EmployerNo=E.EmployerNo AND C.NicNo='" + nicno + "' AND C.EmpId <> 0";
        
        da = new SqlDataAdapter(SQL, mycon);
        ds = new DataSet();
        mycon.Open();
        da.Fill(ds, SQL);
        da.Dispose();
        mycon.Close();
        return ds;
    }

    //public DataSet UpdateCustomerMain(int title, string initials, string surname, string oname, 
    //                                  string stat, string location, string street, string city, 
    //                                  string hno, string mobile,
    //                                  DateTime dob, string email, string customertype, string nicno)
    //{
    //    string updatemaster = " UPDATE customermain SET titlecode=" + title + ","+
    //                          " initials='" + initials + "'," +
    //                          " surname='" + surname + "',othername='" + oname + "',"+
    //                          " cstatus='" + stat + "'," +
    //                          " location='" + location + "', street='" + street + "'," +
    //                          " city='" + city + "', homeno='" + hno + "'," +
    //                          " mobile='" + mobile + "',dobirth='" + dob + "',"+
    //                          " email='" + email.Trim() + "', CustomerType='" + customertype + "' WHERE " +
    //                          " nicno='" + nicno.Trim() + "' ";
    //    da = new SqlDataAdapter(updatemaster, mycon);
    //    ds = new DataSet();
    //    mycon.Open();
    //    da.Fill(ds, updatemaster);
    //    da.Dispose();
    //    mycon.Close();
    //    return ds;
    //}

    public int UpdateCustomerMain(int titlecode, string initials, string surname, string othername,
                                      string cstatus, string location, string street, string city,
                                      string homeno, string mobile,
                                      DateTime dobirth, string email, string customertype, string ForeignNo, string nicno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update customermain set titlecode=@titlecode,initials=@initials,surname=@surname,othername=@othername,cstatus=@cstatus,
                        location=@location, street=@street, city=@city, homeno=@homeno, mobile=@mobile, dobirth=@dobirth,
                        email=@email, customertype=@customertype, ForeignNo=@ForeignNo where nicno=@nicno");
        dw.SetSqlCommandParameters("nicno", nicno);
        dw.SetSqlCommandParameters("titlecode", titlecode);
        dw.SetSqlCommandParameters("initials", initials);
        dw.SetSqlCommandParameters("surname", surname);
        dw.SetSqlCommandParameters("othername", othername);
        dw.SetSqlCommandParameters("cstatus", cstatus);
        dw.SetSqlCommandParameters("location", location);
        dw.SetSqlCommandParameters("street", street);
        dw.SetSqlCommandParameters("city", city);
        dw.SetSqlCommandParameters("homeno", homeno);
        dw.SetSqlCommandParameters("mobile", mobile);
        dw.SetSqlCommandParameters("dobirth", dobirth);
        dw.SetSqlCommandParameters("email", email);
        dw.SetSqlCommandParameters("customertype", customertype);
        dw.SetSqlCommandParameters("ForeignNo", ForeignNo);
        return dw.Update();
    }

    public DataSet UpdateCustomerSubDet(string epfno, string desig, string prof, string offtel, string fax, string period,
                                        string type, int conf, decimal sal, string category, 
                                        decimal expen, decimal oincome,
                                        string nicno)
    {
        string updatesub = " UPDATE customersub SET epfNo='" + epfno + "', designation='" + desig + "'," +
                           " Profesion='" + prof + "', " +
                           " offtele='" + offtel + "'," +
                           " faxno='" + fax + "', service='" + period + "', emptype='" + type + "', " +
                           " confirmed=" + conf + ",salary=" + sal + ",CustomerCat='" + category + "', " +
                           " totexpen=" + expen + ", " +
                           " othincome=" + oincome + " WHERE NicNo='" + nicno + "'";
        da = new SqlDataAdapter(updatesub, mycon);
        ds = new DataSet();
        mycon.Open();
        da.Fill(ds, updatesub);
        da.Dispose();
        mycon.Close();
        return ds;
    }

    public DataSet UpdateSpouseDetails(string spnic, int sptitle, string spint, string spsurname,
                                       string oname, DateTime spdob, 
                                       string addr, string street, string city, string nicno, 
                                       string spemp, string dependants)
    {
        string updatesp = " UPDATE customersub SET spnicno='" + spnic + "', sptitlecode=" + sptitle + ", "+
                          " spinitials='" + spint + "'," +
                          " spsurname='" + spsurname + "',spothname='" + oname + "',"+
                          " spdob='" + spdob + "'," +
                          " spaddress='" + addr + "', spstreet='"+street+"', spcity='" + city + "', "+
                          " SpDesig = '" + spemp + "', Dependants='"+dependants+"' WHERE nicno='" + nicno + "'";

        da = new SqlDataAdapter(updatesp, mycon);
        ds = new DataSet();
        mycon.Open();
        da.Fill(ds, updatesp);
        da.Dispose();
        mycon.Close();
        return ds;
    }

    public DataSet GetDependantDetails(string nicno)
    {
        string sql = "SELECT DOB,Relationship,NicNo FROM Dependants WHERE NicNo='" + nicno + "'";
        da = new SqlDataAdapter(sql, mycon);
        ds = new DataSet();
        mycon.Open();
        da.Fill(ds, sql);
        da.Dispose();
        mycon.Close();
        return ds;
    }

    public DataSet AssignEmployer(string nicno, int empid)
    {
        string sql = "UPDATE CustomerSub SET EmpId=" + empid + " WHERE NicNo='" + nicno + "'";
        da = new SqlDataAdapter(sql, mycon);
        ds = new DataSet();
        mycon.Open();
        da.Fill(ds, sql);
        da.Dispose();
        mycon.Close();
        return ds;
    }

    public DataSet InsertDependantDetails(string nicno, string dob, string relation)
    {
        string sql = " INSERT INTO Dependants(NicNo,DOB,Relationship) "+
                     " VALUES ('" + nicno + "','" + dob + "','" + relation + "')";
        da = new SqlDataAdapter(sql, mycon);
        ds = new DataSet();
        mycon.Open();
        da.Fill(ds, sql);
        da.Dispose();
        mycon.Close();
        return ds;
    }

    public DataSet LoadRejectReasons()
    {
        string sql = "SELECT * FROM ReasonTb";
        da = new SqlDataAdapter(sql, mycon);
        ds = new DataSet();
        mycon.Open();
        da.Fill(ds, sql);
        da.Dispose();
        mycon.Close();
        return ds;
    }

    public DataSet GetCmasterDet(string nicno)
    {
        string sql = "SELECT * FROM CustomerMain WHERE NicNo='"+nicno+"'";
        da = new SqlDataAdapter(sql, mycon);
        ds = new DataSet();
        mycon.Open();
        da.Fill(ds, sql);
        da.Dispose();
        mycon.Close();
        return ds;
    }

    public DataSet GetCustPrevLoan(string nicno)
    {
        string sql = " SELECT A.AppNo AS AppNo, Cr.GrantDate AS GrantDate, HoldRelation, Cr.CrAcNo AS CrAcNo, "+
                     " Cr.AprovdAmt AS Amount,Cr.Instalment AS Instalment, Cr.IntRate AS IntRate "+
                     " FROM CustomerMain C, AppHolder A, CrMast Cr, HousProp H, CrApp P "+
                     " WHERE C.Nicno='"+nicno+"' "+
                     " AND C.NicNo=A.NicNo "+
                     " AND A.AppNo=Cr.AppNo "+
                     " AND A.AppNo=P.AppNo "+
                     " AND Cr.CrAcNo=H.CrAcNo "+
                     " AND P.IsApproved='Y'";
        da = new SqlDataAdapter(sql, mycon);
        ds = new DataSet();
        mycon.Open();
        da.Fill(ds, sql);
        da.Dispose();
        mycon.Close();
        return ds;
    }

    public DataSet GetProcessingAps(string nicno)
    {
        string sql = " SELECT DISTINCT C.AppNo AS AppNo,* FROM CustomerMain M, AppHolder A, CrApp C "+
                     " WHERE M.NicNo=A.NicNo AND A.AppNo=C.AppNo AND M.NicNo='"+nicno+"' AND "+
                     " C.IsApproved='N'";
        da = new SqlDataAdapter(sql, mycon);
        ds = new DataSet();
        mycon.Open();
        da.Fill(ds, sql);
        da.Dispose();
        mycon.Close();
        return ds;
    }

    public int UpdatePostalEmployer(string nicno, string IsEmployer, DateTime AddDate, string AddUser)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update PostalEmployerDetails set IsEmployer=@IsEmployer,
                        AddDate=@AddDate, AddUser=@AddUser where nicno=@nicno");
        dw.SetSqlCommandParameters("nicno", nicno);
        dw.SetSqlCommandParameters("IsEmployer", IsEmployer);
        dw.SetSqlCommandParameters("AddDate", AddDate);
        dw.SetSqlCommandParameters("AddUser", AddUser);
        return dw.Update();
    }

    public int InsertPostalEmployerData(string NicNo, string IsEmployer, DateTime AddDate, string AddUser)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into PostalEmployerDetails(NicNo,IsEmployer,AddDate,AddUser) 
                        values (@NicNo,@IsEmployer,@AddDate,@AddUser)");
        dw.SetSqlCommandParameters("NicNo", NicNo);
        dw.SetSqlCommandParameters("IsEmployer", IsEmployer);
        dw.SetSqlCommandParameters("AddDate", AddDate);
        dw.SetSqlCommandParameters("AddUser", AddUser);
        return dw.Insert();
    }

    public string getEmployerStatus(string NicNo)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"SELECT IsEmployer from PostalEmployerDetails where NicNo=@NicNo");
        dw.SetSqlCommandParameters("NicNo", NicNo);
        return dw.GetSingleData();
    }
    public int getNicLoanCOunt(string NicNo)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select COUNT(*) from Appholder A, Crapp C where
                        A.AppNo = C.AppNo and left(A.NicNo,9) = @NicNo");
        dw.SetSqlCommandParameters("NicNo", NicNo);
        return int.Parse(dw.GetSingleData());
    }

    public int getExistLoanCount(string NicNo)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select COUNT(*) from CREDITBRDB.TDBBranches.CreditAdmin.Housprop H, 
                        CREDITBRDB.TDBBranches.CreditAdmin.CrHolder C
                        WHERE H.Cracno = C.Cracno and C.NicNo=@NicNo
                        and H.ActOutbal > 0");
        dw.SetSqlCommandParameters("NicNo", NicNo);
        return int.Parse(dw.GetSingleData());
    }

    public string getNewNicNo(string oldnicno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select NewNICNo from NICChangeLogs where oldnicno=@oldnicno");
        dw.SetSqlCommandParameters("oldnicno", oldnicno);
        return dw.GetSingleData();
    }

    public DataTable GetCustomerdetails(string OLDNICNO)
    {
        
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select cr.Cracno as LoanNumber ,rtrim(titledesc)+ ' ' + rTrim(c.INitials) + ' ' + rTrim(c.Surname) as [Name],
                            rtrim(c.location)+' '+rtrim(c.street)+' '+rtrim(c.city) as Address ,
                            c.NicNo, Holdertype,'Credit Div' as Branchname from customermain c, appholder a , Crmast cr, title t,
                            housprop h
                            where c.nicno = a.nicno and a.appno = cr.appno and c.titlecode=t.titlecode and a.NicNo=@OLDNICNO
                            and  cr.cracno=h.cracno
                            union all
                            select cr.Cracno as LoanNumber ,rtrim(titledesc)+ ' ' + rTrim(c.INitials) + ' ' + rTrim(c.Surname) as [Name],
                            rtrim(c.location)+' '+rtrim(c.street)+' '+rtrim(c.city) as Address ,
                            c.NicNo, Holdertype,n.branchname as Branchname from CREDITBRDB.TDBBranches.CreditAdmin.customermain c, 
                            CREDITBRDB.TDBBranches.CreditAdmin.appholder a , 
                            CREDITBRDB.TDBBranches.CreditAdmin.Crmast cr, 
                            CREDITBRDB.TDBBranches.CreditAdmin.title t,
                            CREDITBRDB.TDBBranches.CreditAdmin.housprop h,
                            CREDITBRDB.TDBBranches.CreditAdmin.nsb_branch n
                            where c.nicno = a.nicno and a.appno = cr.appno and c.titlecode=t.titlecode and a.NicNo=@OLDNICNO
                            and  cr.cracno=h.cracno and c.branchcode=a.branchcode
                            and h.branchcode = n.branchno ");
        dw.SetDataAdapterParameters("OLDNICNO", OLDNICNO);
        return dw.GetDataTable();
    }

    public int updatecustomermain(string NEWNICNO, string OLDNICNO)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update customermain set nicno=@NEWNICNO where nicno=@OLDNICNO");
        dw.SetSqlCommandParameters("NEWNICNO", NEWNICNO);
        dw.SetSqlCommandParameters("OLDNICNO", OLDNICNO);
        return dw.Update();
    }

    public int updateCustomerSub(string NEWNICNO, string OLDNICNO)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update CustomerSub set nicno=@NEWNICNO where nicno=@OLDNICNO");
        dw.SetSqlCommandParameters("NEWNICNO", NEWNICNO);
        dw.SetSqlCommandParameters("OLDNICNO", OLDNICNO);
        return dw.Update();
    }
    public int updatelogtd(string NEWNICNO, string OLDNICNO)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update Logtb set nicno=@NEWNICNO where nicno=@OLDNICNO");
        dw.SetSqlCommandParameters("NEWNICNO", NEWNICNO);
        dw.SetSqlCommandParameters("OLDNICNO", OLDNICNO);
        return dw.Update();
    }
    public int updateappholder(string NEWNICNO, string OLDNICNO)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update Appholder set nicno=@NEWNICNO where nicno=@OLDNICNO");
        dw.SetSqlCommandParameters("NEWNICNO", NEWNICNO);
        dw.SetSqlCommandParameters("OLDNICNO", OLDNICNO);
        return dw.Update();
    }
    public int updatecrholder(string NEWNICNO, string OLDNICNO)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update CrHolder set nicno=@NEWNICNO where nicno=@OLDNICNO");
        dw.SetSqlCommandParameters("NEWNICNO", NEWNICNO);
        dw.SetSqlCommandParameters("OLDNICNO", OLDNICNO);
        return dw.Update();
    }

    public int updateappsecgarant(string NEWNICNO, string OLDNICNO)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update AppSecGarant set nicno=@NEWNICNO where nicno=@OLDNICNO");
        dw.SetSqlCommandParameters("NEWNICNO", NEWNICNO);
        dw.SetSqlCommandParameters("OLDNICNO", OLDNICNO);
        return dw.Update();
    }

    public int updateBranchappholder(string NEWNICNO, string OLDNICNO)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update CREDITBRDB.TDBBranches.CreditAdmin.Appholder set nicno=@NEWNICNO where nicno=@OLDNICNO");
        dw.SetSqlCommandParameters("NEWNICNO", NEWNICNO);
        dw.SetSqlCommandParameters("OLDNICNO", OLDNICNO);
        return dw.Update();
    }
    public int updateBranchcrholder(string NEWNICNO, string OLDNICNO)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update CREDITBRDB.TDBBranches.CreditAdmin.CrHolder set nicno=@NEWNICNO where nicno=@OLDNICNO");
        dw.SetSqlCommandParameters("NEWNICNO", NEWNICNO);
        dw.SetSqlCommandParameters("OLDNICNO", OLDNICNO);
        return dw.Update();
    }

    public int updateBranchappsecgarant(string NEWNICNO, string OLDNICNO)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update CREDITBRDB.TDBBranches.CreditAdmin.AppSecGarant set nicno=@NEWNICNO where nicno=@OLDNICNO");
        dw.SetSqlCommandParameters("NEWNICNO", NEWNICNO);
        dw.SetSqlCommandParameters("OLDNICNO", OLDNICNO);
        return dw.Update();
    }

    public DataTable GetCustomerdetailsnew(string NEWNICNO)
    {
       // dt = new DataTable();
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select cr.Cracno as LoanNumber ,rtrim(titledesc)+ ' ' + rTrim(c.INitials) + ' ' + rTrim(c.Surname) as [Name],
                            rtrim(c.location)+' '+rtrim(c.street)+' '+rtrim(c.city) as Address ,
                            c.NicNo, Holdertype from customermain c, appholder a , Crmast cr, title t,
                            housprop h
                            where c.nicno = a.nicno and a.appno = cr.appno and c.titlecode=t.titlecode and a.NicNo=@NEWNICNO
                            and  cr.cracno=h.cracno");
        dw.SetDataAdapterParameters("NEWNICNO", NEWNICNO);
        return dw.GetDataTable();
    }

    public double insertNICChangeData(string NEWNICNO, string OLDNICNO, DateTime ChangeDate, string ChangeUser)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO NICChangeLogs (NEWNICNO,OLDNICNO,ChangeDate,ChangeUser)
                        VALUES (@NEWNICNO,@OLDNICNO,@ChangeDate,@ChangeUser)");
        dw.SetSqlCommandParameters("NEWNICNO", NEWNICNO);
        dw.SetSqlCommandParameters("OLDNICNO", OLDNICNO);
        dw.SetSqlCommandParameters("ChangeDate", ChangeDate);
        dw.SetSqlCommandParameters("ChangeUser", ChangeUser);
        return double.Parse(dw.GetSingleData());
    }

    public double insertBranchNICChangeData(string NEWNICNO, string OLDNICNO, DateTime ChangeDate, string ChangeUser)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO CREDITBRDB.TDBBranches.CreditAdmin.NICChangeLogs (NEWNICNO,OLDNICNO,ChangeDate,ChangeUser)
                        VALUES (@NEWNICNO,@OLDNICNO,@ChangeDate,@ChangeUser)");
        dw.SetSqlCommandParameters("NEWNICNO", NEWNICNO);
        dw.SetSqlCommandParameters("OLDNICNO", OLDNICNO);
        dw.SetSqlCommandParameters("ChangeDate", ChangeDate);
        dw.SetSqlCommandParameters("ChangeUser", ChangeUser);
        return double.Parse(dw.GetSingleData());
    }

    public void InsertBulkEpfNo(DataTable tmpDatatTable)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand();
        dw.InsertBulk(tmpDatatTable, "EPFDetails");
    }

    public double insetLegalData(string cracno,DateTime  TranserDate,string AddUser,string Status,string Action1,double outbal,string CaseNo)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO LegalActionData (cracno,TranserDate,AddUser,Status,Action1,outbal,CaseNo)
                        VALUES (@cracno,@TranserDate,@AddUser,@Status,@Action1,@outbal,@CaseNo)");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("TranserDate", TranserDate);
        dw.SetSqlCommandParameters("AddUser", AddUser);
        dw.SetSqlCommandParameters("Status", Status);
        dw.SetSqlCommandParameters("Action1", Action1);
        dw.SetSqlCommandParameters("outbal", outbal);
        dw.SetSqlCommandParameters("CaseNo", CaseNo);
        return double.Parse(dw.GetSingleData());   
    }
    public int UpdateLegalData(string cracno,string Status,string Action1,double outbal,string CaseNo,DateTime ChangeDate, string ChangeUser)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update LegalActionData set Status=@Status,Action1=@Action1,outbal=@outbal,CaseNo=@CaseNo,ChangeDate=@ChangeDate,ChangeUser=@ChangeUser where cracno=@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("Status", Status);
        dw.SetSqlCommandParameters("Action1", Action1);
        dw.SetSqlCommandParameters("outbal", outbal);
        dw.SetSqlCommandParameters("CaseNo", CaseNo);
        dw.SetSqlCommandParameters("ChangeDate", ChangeDate);
        dw.SetSqlCommandParameters("ChangeUser", ChangeUser);
        return dw.Update();
    }
}
