using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// Summary description for Valuation
/// </summary>
public class ValuationFunctions
{
    SqlConnection myconnection = new SqlConnection(ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString);
    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();
    string reporTString = ConfigurationManager.ConnectionStrings["reporTString"].ConnectionString.ToString();
    string constringBranchReport = ConfigurationManager.ConnectionStrings["reporTStringBranch"].ConnectionString.ToString();
    string TDBBranchesConString = ConfigurationManager.ConnectionStrings["TDBBranchesConString"].ConnectionString.ToString();
    private SqlDataAdapter sqlAdapter;
    private SqlCommand sqlCmd;
    private DataTable dt;
    DataWorksClass dw;

    public ValuationFunctions()
	{
		//
		// TODO: Add constructor logic here
		//
	}    

    public int Inactivate(string AppNo)
    {
        string error;
        string sqlUpdate = @"update valuation set status='I' where status='A' and APPNO=@AppNo";
        sqlCmd = new SqlCommand(sqlUpdate, myconnection);

        sqlCmd.Parameters.AddWithValue("AppNo", AppNo);

        int rowadd = 0;

        try
        {
            myconnection.Open();
            rowadd = sqlCmd.ExecuteNonQuery();
        }
        catch (Exception er)
        {
            error = er.Message;
        }
        finally
        {
            myconnection.Close();
        }
        return rowadd;
    }

    public int Activate(string AppNo)
    {
        string error;
        string sqlUpdate = @"update valuation set status='A' where status='I' and APPNO=@AppNo and senddate=(select max(senddate) from valuation where appno=@AppNo)";
        sqlCmd = new SqlCommand(sqlUpdate, myconnection);

        sqlCmd.Parameters.AddWithValue("APPNO", AppNo);

        int rowadd = 0;

        try
        {
            myconnection.Open();
            rowadd = sqlCmd.ExecuteNonQuery();
        }
        catch (Exception er)
        {
            error = er.Message;
        }
        finally
        {
            myconnection.Close();
        }
        return rowadd;
    }

    public DataTable ValuationReportDetails(string APPNO)
    {
        string sqlSelect;
        string err;
        sqlSelect = @"select DATEOFVAL,PRESENTVAL,COMPLETEVAL,FORCEVAL,FIREINSURANCE,AccessRoad,ValuerComments,REMARKS
                    from valuation where appno=@AppNo and status='A' and updatelevel=-100";
               
        sqlAdapter = new SqlDataAdapter(sqlSelect, myconnection);
        sqlAdapter.SelectCommand.Parameters.AddWithValue("AppNo", APPNO);

        dt = new DataTable();

        try
        {
            myconnection.Open();
            sqlAdapter.Fill(dt);
        }

        catch (Exception er)
        {
            err = er.ToString();
        }
        finally
        {
            myconnection.Close();
        }

        return dt;
    }

    public int updateValuationReport(string AppNo, DateTime DATEOFVAL, decimal PRESENTVAL, decimal COMPLETEVAL, decimal FORCEVAL, decimal FIREINSURANCE,
                                     string AccessRoad, string ValuerComments, string REMARKS)
    {
        string sqlUpdate;
        string Error;

        sqlUpdate = @"update valuation set DATEOFVAL=@DATEOFVAL,PRESENTVAL=@PRESENTVAL,COMPLETEVAL=@COMPLETEVAL,FORCEVAL=@FORCEVAL,
                        FIREINSURANCE=@FIREINSURANCE,AccessRoad=@AccessRoad,ValuerComments=@ValuerComments,REMARKS=@REMARKS
                        where AppNo=@AppNo and status='A' and updatelevel=-100";
        sqlCmd = new SqlCommand(sqlUpdate, myconnection);

        sqlCmd.Parameters.AddWithValue("AppNo",AppNo);
        sqlCmd.Parameters.AddWithValue("DATEOFVAL",DATEOFVAL);
        sqlCmd.Parameters.AddWithValue("PRESENTVAL",PRESENTVAL);
        sqlCmd.Parameters.AddWithValue("COMPLETEVAL",COMPLETEVAL);
        sqlCmd.Parameters.AddWithValue("FORCEVAL",FORCEVAL);
        sqlCmd.Parameters.AddWithValue("FIREINSURANCE",FIREINSURANCE);
        sqlCmd.Parameters.AddWithValue("AccessRoad",AccessRoad);
        sqlCmd.Parameters.AddWithValue("ValuerComments",ValuerComments);
        sqlCmd.Parameters.AddWithValue("REMARKS", REMARKS);

        int rowadded = 0;

        try
        {
            myconnection.Open();
            rowadded = sqlCmd.ExecuteNonQuery();
        }
        catch (Exception er)
        {
            Error = er.Message;
        }
        finally
        {
            myconnection.Close();
        }

        return rowadded;
    }

    public string CheckCurrentStatus(string APPNo)
    {
        string sqlSelect;
        string Error;
        string status = null;

        sqlSelect = @"select status from valuation where APPNO=@APPNo and updatelevel=-100 and senddate=
                      (select max(senddate) from valuation where APPNO=@APPNo)";
        sqlAdapter = new SqlDataAdapter(sqlSelect, myconnection);

        sqlAdapter.SelectCommand.Parameters.AddWithValue("APPNO", APPNo);

        dt = new DataTable();

        try
        {
            myconnection.Open();
            sqlAdapter.Fill(dt);
        }
        catch (Exception err)
        {
            Error = err.ToString();
        }
        finally
        {
            myconnection.Close();
        }

        int count = dt.Rows.Count;
        if (count > 0)
        {
            status = dt.Rows[0][0].ToString();
        }
        else
        {
            //
        }

        if (status == "A")
            status = "Active";
        else if (status == "I")
            status = "Inactivate";

        return status;
    }


    public int ChangeApprovalstatus(string AppNo, int status)
    {
        string sqlUpdate;
        string Error;
        sqlUpdate = @"update approvalstatus set isValuationOk=@status where appno=@appno";

        sqlCmd = new SqlCommand(sqlUpdate, myconnection);

        sqlCmd.Parameters.AddWithValue("AppNo", AppNo);
        sqlCmd.Parameters.AddWithValue("status", status);

        int rowadded = 0;

        try
        {
            myconnection.Open();
            rowadded = sqlCmd.ExecuteNonQuery();
        }
        catch (Exception er)
        {
            Error = er.ToString();
        }
        finally
        {
            myconnection.Close();
        }
        return rowadded;
    }


    public DataTable DisplayCustDetails(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select cm.Cracno,cm.IntRate,a.Appno,a.Nicno,rtrim(rtrim(c.initials) + ' ' +rtrim(c.surname)) as CustName
                            from appholder a,customermain c,crmast cm where a.appno=cm.appno and 
                            a.appno=@appno and a.nicno=c.nicno order by cm.Intrate");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();
    }

    public DataTable DisplayExistValDetails(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select v.DateofVal,
                            CAST(CONVERT(varchar, CAST(v.CompleteVal  AS money), 1)  AS varchar) as CompleteVal,
                            CAST(CONVERT(varchar, CAST(v.PresentVal  AS money), 1)  AS varchar) as PresentVal,
                            CAST(CONVERT(varchar, CAST(v.ForceVal  AS money), 1)  AS varchar) as ForceVal,
                            rtrim(val.Initial) +' '+rtrim(val.surname) as ValuerName
                            from valuation v, valuer val where v.appno=@appno and v.status='A'
                            and v.valuerid=val.valuerid order by v.senddate");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();
    }

    public string GetrecentValuerName(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select rtrim(v.initial)+' '+rtrim(v.surname) as ValuerName from 
                            (select valuerid from valuation where senddate=
                            (select max(senddate) from valuation where appno=@appno) and status='A'  and appno=@appno) as t1,valuer v
                            where t1.valuerid=v.valuerid");
        dw.SetSqlCommandParameters("appno", appno);
        return dw.GetSingleData();
    }

    public DataTable GetDetails(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select dateofval,presentval,completeval,forceval,accessroad,valuercomments,
                            remarks from valuation where senddate=
                            (select max(senddate) from valuation where appno=@appno and status='A') and appno=@appno");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();
    }

    public int updateReValuationReport(string appno, DateTime DATEOFVAL, decimal PRESENTVAL, decimal COMPLETEVAL, decimal FORCEVAL, decimal FIREINSURANCE,
                                 string AccessRoad, string ValuerComments, string REMARKS)
    {
        string sqlUpdate;
        string Error;

        sqlUpdate = @"update valuation set DATEOFVAL=@DATEOFVAL,PRESENTVAL=@PRESENTVAL,COMPLETEVAL=@COMPLETEVAL,FORCEVAL=@FORCEVAL,
                        FIREINSURANCE=@FIREINSURANCE,AccessRoad=@AccessRoad,ValuerComments=@ValuerComments,REMARKS=@REMARKS
                        where senddate=(select max(senddate) from valuation where appno=@appno and status='A') and appno=@appno";
        sqlCmd = new SqlCommand(sqlUpdate, myconnection);

        sqlCmd.Parameters.AddWithValue("appno", appno);
        sqlCmd.Parameters.AddWithValue("DATEOFVAL", DATEOFVAL);
        sqlCmd.Parameters.AddWithValue("PRESENTVAL", PRESENTVAL);
        sqlCmd.Parameters.AddWithValue("COMPLETEVAL", COMPLETEVAL);
        sqlCmd.Parameters.AddWithValue("FORCEVAL", FORCEVAL);
        sqlCmd.Parameters.AddWithValue("FIREINSURANCE", FIREINSURANCE);
        sqlCmd.Parameters.AddWithValue("AccessRoad", AccessRoad);
        sqlCmd.Parameters.AddWithValue("ValuerComments", ValuerComments);
        sqlCmd.Parameters.AddWithValue("REMARKS", REMARKS);

        int rowadded = 0;

        try
        {
            myconnection.Open();
            rowadded = sqlCmd.ExecuteNonQuery();
        }
        catch (Exception er)
        {
            Error = er.Message;
        }
        finally
        {
            myconnection.Close();
        }

        return rowadded;
    }

    public DataTable DisplayPropertyDetails(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select LotNo,PlanNo,LandExtent,LandName,LandLocation,LandStreet,LandCity 
                            from hpsec where appno=@appno");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();
    }

    public DataTable getCracnoIntProvisionIndividual(string datekey)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select cracno from IntProvisionIndividual where datekey=@datekey");
        dw.SetDataAdapterParameters("datekey", datekey);
        return dw.GetDataTable();
    }

    public int insertRecordtoReportTableOne(string cracno, string datekey)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into creditreportsdb.reportuser.reporttableone 
                        SELECT i.[DateKey]  ,i.[cracno] ,c.appno,i.[intprovision]  ,i.[exessinterest]  ,i.[actoutbal]  ,i.[IntRate]
                        ,i.[CrCat]  ,cat.crdes , i.[StatusId]  ,
                        case [StatusId]  
                        when '1' then 'Performing'
                        when '2' then 'Special'
                        when '3' then 'Substandard'
                        when '4' then 'Doubtful'
                        when '5' then 'Loss'
                        end as StatusDesc,
                        i.[ArreasDays]  ,i.[DateDue] ,i.[NicNo]  ,i.[Name],c.crperiod,c.aprovdamt,c.grantamt,
                        c.grantdate,c.instalment as CrmastInstalment,h.graceperiod,h.lsttrdate,h.lstpaiddate,h.recptperiod,
                        h.paidinstalments,v.valuerid,v.dateofval,v.presentval,v.completeval,v.forceval,v.fireinsurance,
                        v.status as valStatus,h.instalment as HouspropInstalment,hps.iscondominium,hps.lotno,hps.planno,
                        hps.plandate,hps.unitno,hps.schemeno,hps.surveyname,hps.isowner,hps.landextent,hps.landname,
                        hps.landlocation,hps.landstreet,hps.landcity,hps.floorarea,hps.villagename,hps.divsecname,
                        hps.ownersname,hps.addate
                        FROM IntProvisionIndividual i,crcategory cat,crmast c,housprop h
                        ,valuation v,hpsec hps
                        where i.datekey=@datekey and cat.crcatcode=i.CrCat and c.cracno=i.cracno and
                        c.cracno=h.cracno and v.appno=*c.appno and c.appno*=hps.appno 
                        and c.cracno=@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("datekey", datekey);
        return dw.Insert();
    }

    public DataTable GetCARReport(string datekey, string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select [Name],cracno,AppNo,GrantDate,AprovdAmt,Grantamt,Actoutbal,Forceval,max(DateofVal) as DateofVal,
                            catDesc,StatusDesc from creditreportsdb.reportuser.reporttableone where datekey=@datekey
                            group by [Name],cracno,AppNo,GrantDate,AprovdAmt,Grantamt,Actoutbal,Forceval,catDesc ,StatusDesc
                            order by @appno");
        dw.SetDataAdapterParameters("appno", appno);
        dw.SetDataAdapterParameters("datekey", datekey);
        return dw.GetDataTable();
    }

    public DataTable getCracnoIntProvisionIndividualBR(string datekey)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select cracno from IntProvisionIndividual where datekey=@datekey");
        dw.SetDataAdapterParameters("datekey", datekey);
        return dw.GetDataTable();
    }

    public int insertRecordtoReportTableOneBR(string cracno, string datekey)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into creditreportsdb.reportuser.reporttableone 
                        SELECT i.[DateKey],c.BranchCode ,i.[cracno] ,c.appno,i.[intprovision]  ,i.[exessinterest]  ,i.[actoutbal]  ,i.[IntRate]
                        ,i.[CrCat]  ,cat.crdes , i.[StatusId]  ,
                        case [StatusId]  
                        when '1' then 'Performing'
                        when '2' then 'Special'
                        when '3' then 'Substandard'
                        when '4' then 'Doubtful'
                        when '5' then 'Loss'
                        end as StatusDesc,
                        i.[ArreasDays]  ,i.[DateDue] ,i.[NicNo]  ,i.[Name],c.crperiod,c.aprovdamt,c.grantamt,
                        c.grantdate,c.instalment as CrmastInstalment,h.graceperiod,h.lsttrdate,h.lstpaiddate,h.recptperiod,
                        h.paidinstalments,v.valuerid,v.dateofval,v.presentval,v.completeval,v.forceval,v.fireinsurance,
                        v.status as valStatus,h.instalment as HouspropInstalment,hps.iscondominium,hps.lotno,hps.planno,
                        hps.plandate,hps.unitno,hps.schemeno,hps.surveyname,hps.isowner,hps.landextent,hps.landname,
                        hps.landlocation,hps.landstreet,hps.landcity,hps.floorarea,hps.villagename,hps.divsecname,
                        hps.ownersname,hps.addate
                        FROM IntProvisionIndividual i,crcategory cat,crmast c,housprop h
                        ,valuation v,hpsec hps
                        where i.datekey=@datekey and cat.crcatcode=i.CrCat and c.cracno=i.cracno and
                        c.cracno=h.cracno and v.appno=*c.appno and c.appno*=hps.appno 
                        and c.cracno=@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("datekey", datekey);
        return dw.Insert();
    }

    public string getAppNoFromCracno(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select appno from crmast where cracno=@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return dw.GetSingleData();
    }

    public DataTable GetExpireData(string valuertype, string count)
    {
        dw = new DataWorksClass(reporTString);
        dw.SetDataAdapter(@"exec expireVal @valuertype,@count");
        dw.SetDataAdapterParameters("valuertype", valuertype);
        dw.SetDataAdapterParameters("count", count);
        return dw.GetDataTable();
    }

 //2011-08-24 vihanga
        public object GetrelevantValData(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select v.appno,v.valuerid,rtrim(vu.initial)+' ' + rtrim(vu.surname) as 
                            ValuerName,CONVERT(VARCHAR(10), v.senddate, 120) as senddate,
                            v.hide,v.status from valuation v,valuer vu where 
                            v.appno=@appno and v.valuerid=vu.valuerid");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();
    }

    //2011-08-24 vihanga
    public int ChangeStatus(string appno, string valuerid, DateTime senddate, string hide, string status)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update valuation set status=@status where appno=@appno and valuerid=@valuerid and 
                        CONVERT(VARCHAR(10), senddate, 120)=@senddate and hide=@hide");
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("valuerid", valuerid);
        dw.SetSqlCommandParameters("senddate", senddate);
        dw.SetSqlCommandParameters("hide", hide);
        dw.SetSqlCommandParameters("status", status);
        return dw.Update();
    }

    //2011-08-24 vihanga
    public int AssignExitValReco(string appno, string newApp)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into Valuation
                        SELECT @newApp,VALUERID,SENDDATE,RECVDATE,VALUPERIOD,DATEOFVAL,PRESENTVAL,COMPLETEVAL
                        ,FORCEVAL,ValuerFee,TrportFee,FIREINSURANCE,REMARKS,HIDE,STATUS,HIDEUSER,IsTrPortPd
                        ,IsValuerPd,IsCommisPaid,CommisFee,IsGovtPaid,PaidDate,ExpressTrPort,ExpValuerFee,IsExpTrPaid
                        ,IsExpValuerPd,ValuerComments,AccessRoad,AddUser,Adddatetime,UpdateLevel,ValuationStatus
                        ,TransactionNo,CommissionTransactionNo,ValuerType FROM Valuation where appno=@appno");
        dw.SetSqlCommandParameters("appno",appno);
        dw.SetSqlCommandParameters("newApp", newApp);
        return dw.Insert();
    }

    //2011-08-24 vihanga
    public int updateapprovalstatus(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update approvalstatus set isvaluationok=1 where appno=@appno");
        dw.SetSqlCommandParameters("appno", appno);
        return dw.Update();
    }

    //2011-09-01 vihanga - changed Bimali on 04/10/2017 for DGM(Credit) requirement
    public DataTable getValProvisionData(string datekey)
    {
        dw = new DataWorksClass(reporTString);
        dw.SetDataAdapter(@"select v.*,I.NicNo from ReportUser.valProvision v, 
                            TDB.CreditAdmin.IntProvisionIndividual I 
                            where v.datekey=@datekey and v.cracno = I.cracno and I.DateKey=@datekey");
        dw.SetDataAdapterParameters("datekey", datekey);
        return dw.GetDataTable();
    }

    //2011-10-05 vihanga
    public DataTable getValProvisionDataBranchSector(string datekey)
    {
        dt = new DataTable();
        dw = new DataWorksClass(constringBranchReport);
        dw.SetDataAdapter(@"select * from valprovision where datekey=@datekey");
        dw.SetDataAdapterParameters("datekey", datekey);
        dt = dw.GetDataTable();
        return dt;
    }

    //2011-10-05 vihanga
     public DataTable getValProvisionDataBranchSector(string datekey, string crdes1, string crdes2, string crdes3, string crdes4,
                                                     string crdes5)
    {
        //dt = new DataTable();
        //dw = new DataWorksClass(constringBranchReport);
        //dw.SetDataAdapter(@"select * from valprovision where datekey=@datekey and crdes in (@crdes1,@crdes2,@crdes3,@crdes4,@crdes5)");
        //dw.SetDataAdapterParameters("datekey", datekey);
        //dw.SetDataAdapterParameters("crdes1", crdes1);
        //dw.SetDataAdapterParameters("crdes2", crdes2);
        //dw.SetDataAdapterParameters("crdes3", crdes3);
        //dw.SetDataAdapterParameters("crdes4", crdes4);
        //dw.SetDataAdapterParameters("crdes5", crdes5);
        //dt = dw.GetDataTable();
        //return dt;

        dt = new DataTable();
        dw = new DataWorksClass(TDBBranchesConString);
        dw.SetDataAdapter(@"select V.branchcode,V.cracno,V.appno,V.name,V.grantamt,V.outbal,V.arreasDays
                            ,V.ArreasMonth,V.crdes,V.statusName,V.statusId,V.duedate,V.FSV
                            ,V.DateOfVal,V.provisionAmt,V.dateKey,V.valuertype,serialNo,I.GrantDate,N.BranchName,Z.ZonalName
                            from CreditReportsDb.ReportUser.valProvision V,IntProvisionIndividual I,
                            nsb_Zonal Z,nsb_branch N where 
                            v.datekey=@datekey and V.datekey=I.datekey and V.cracno=I.cracno
                            and I.DateKey=@datekey and V.branchcode=I.branchcode and V.branchcode=N.BranchNo
                            and N.ZonalCode=Z.ZonalCode and N.BranchNo=I.branchcode
                            and crdes in (@crdes1,@crdes2,@crdes3,@crdes4,@crdes5)");
        dw.SetDataAdapterParameters("datekey", datekey);
        dw.SetDataAdapterParameters("crdes1", crdes1);
        dw.SetDataAdapterParameters("crdes2", crdes2);
        dw.SetDataAdapterParameters("crdes3", crdes3);
        dw.SetDataAdapterParameters("crdes4", crdes4);
        dw.SetDataAdapterParameters("crdes5", crdes5);
        dt = dw.GetDataTable();
        return dt;
    }

}
