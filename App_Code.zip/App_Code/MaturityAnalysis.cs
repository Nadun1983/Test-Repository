﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

/// <summary>
/// Summary description for MaturityAnalysis
/// </summary>
public class MaturityAnalysis
{
    double noutbal = 0;
    DateTime ndatedue;
    DataTable dt;
    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();
    string reporTString = ConfigurationManager.ConnectionStrings["reporTString"].ConnectionString.ToString();
    string reporTStringBranch = ConfigurationManager.ConnectionStrings["reporTStringBranch"].ConnectionString.ToString();
    DataWorksClass dw;
    public MaturityAnalysis()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    double capital, interest, penal;


    public DataTable getMaturityAnalysisDetails(DateTime operationdate)
    {
        dw = new DataWorksClass(constring);
//        dw.SetDataAdapter(@"select cracno,intrate,instalment,actoutbal,lastcompletedduedate,crcat
//                            ,datediff(day,lastcompletedduedate,@operationdate) as Arreas, graceperiod from housprop
//                            where actoutbal > 0 ");
//        dw.SetDataAdapter(@"select cracno,intrate,instalment,actoutbal,lastcompletedduedate,crcat
//                            ,datediff(day,lastcompletedduedate,@operationdate) as Arreas, graceperiod from housprop");

        dw.SetDataAdapter(@"select c.cracno,h.intrate,h.instalment,h.actoutbal,h.lastcompletedduedate,h.crcat
                                ,datediff(day,h.lastcompletedduedate,@operationdate)
                                as Arreas, h.graceperiod from housprop h,crmast c
                                where h.cracno=c.cracno and h.actoutbal > 0.00 and c.aprovdamt = c.grantamt
                                and h.crcat != 3");
        dw.SetDataAdapterParameters("operationdate", operationdate);
        dt = dw.GetDataTable();
        return dt;
    }

    public DataTable getMaturityAnalysisDetails(string cracno)
    {
        dw = new DataWorksClass(reporTString);
        dw.SetDataAdapter(@"select cracno,intrate,instalment,actoutbal,lastcompletedduedate,crcat
                            from housprop where cracno = @cracno");
        dw.SetDataAdapterParameters("cracno", cracno);  
        dt = dw.GetDataTable();
        return dt;
    }

    public void GetMaturityAnalsys(DateTime trdate)
    {
        dt = new DataTable();
        dt = getMaturityAnalysisDetails(trdate);
        foreach (DataRow dr in dt.Rows)
        {
            string cracno = dr["cracno"].ToString();
                double intrate = double.Parse(dr["intrate"].ToString());
                double outbal = double.Parse(dr["actoutbal"].ToString());
                double actoutbal = double.Parse(dr["actoutbal"].ToString());
                DateTime ldatedue = DateTime.Parse(dr["lastcompletedduedate"].ToString());
                DateTime llastcompletedduedate = DateTime.Parse(dr["lastcompletedduedate"].ToString());
                double installment = double.Parse(dr["instalment"].ToString());
                int graceperiod = int.Parse(dr["graceperiod"].ToString());
                int arreasdays = int.Parse(dr["Arreas"].ToString());
                int crcat = int.Parse(dr["crcat"].ToString());
                string matcat = "";
                DateTime opdate = DateTime.Now;

                DateTime nplDate = llastcompletedduedate.AddMonths(2);

                if (nplDate.Date < opdate.Date) //time to be taken out of the date
                {
                    InsertMaturityData("31122010", cracno, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, outbal, crcat, intrate, opdate, actoutbal, "CAPD", llastcompletedduedate);
                }

                else
                {
                    InsertPL(cracno, intrate, outbal, crcat, ldatedue, outbal, installment, graceperiod, opdate, actoutbal, matcat, llastcompletedduedate);
                }         
                      
        }

    }


    private DataTable InsertRow(double arrcap, double arrint, DataTable dt)
    {
        DataRow dr;
        dr = dt.NewRow();
        dr["arrcap"] = arrcap;
        dr["arrint"] = arrint;
        dt.Rows.Add(dr);
        return dt;
    }


    private void InsertPL(string cracno, double intrate, double actoutbal, int crcat,
        DateTime ldatedue, double outbal, double installment, int graceperiod, DateTime opdate, double extoutbal, string matcat, DateTime llastcompletedduedate)
    
    {
        DataTable bulkdata = new DataTable();
        bulkdata = SetBucketTable(bulkdata);
        double caparreas = 0, intarreas = 0;
        //DataTable dt = new DataTable();
        DateTime trdate;
        //int matnumber = 0;
        //dt = GetMaturityBuckets();
        int[] arr  = {1,3,6,12,36,60,420};


        for (int i=0; i< arr.Length;i++)
        {
            while(ldatedue.Date < opdate.Date)
            {
                ldatedue = opdate.AddMonths(1);
            }

            if(ldatedue.Date >= opdate.Date)
            {
                trdate = ldatedue.AddMonths(arr[i]);                               

                if(i == 0 )
                {
                    if(ldatedue.Date < opdate.Date.AddDays(7) && ldatedue.Date >=opdate.Date)
                    {
                        //add to bucket1
                        caparreas = GetArreasInstalment(cracno, "capd");
                        intarreas = GetArreasInstalment(cracno, "intr");
                        bulkdata = GetMaturityBucket(trdate, 1, cracno, ldatedue, outbal, installment, intrate, graceperiod, crcat, caparreas, intarreas, bulkdata);
                        bulkdata = InsertRow(0, 0, bulkdata);
                    }                  
                                 
                    else if(ldatedue.Date < trdate.Date && ldatedue.Date >= opdate.Date.AddDays(7))
                    {
                        //add to bucket 2
                        caparreas = GetArreasInstalment(cracno, "capd");
                        intarreas = GetArreasInstalment(cracno, "intr");
                        bulkdata = InsertRow(0, 0, bulkdata);
                        bulkdata = GetMaturityBucket(trdate, 2, cracno, ldatedue, outbal, installment, intrate, graceperiod, crcat, caparreas, intarreas, bulkdata);
                        
                    }
                    else
                    {
                        bulkdata = InsertRow(0, 0, bulkdata);
                        bulkdata = InsertRow(0, 0, bulkdata);
                    }            
                 
                }
                
                else
                {
                    
                    if (ldatedue.Date < trdate.Date && outbal >0)
                    {                                                                 
                        caparreas = GetArreasInstalment(cracno, "capd");
                        intarreas = GetArreasInstalment(cracno, "intr");
                        bulkdata = GetMaturityBucket(trdate, i + 2, cracno, ldatedue, outbal, installment, intrate, graceperiod, crcat, caparreas, intarreas, bulkdata);
                        ldatedue = ndatedue;
                        outbal = noutbal;
                        
                    }
                    else
                    {
                       
                        bulkdata = InsertRow(0, 0, bulkdata);

                    }

                }
            }          

        }

                


        //for (int i = 0; i < dt.Rows.Count; i++)
        //{
        //    Calculate trdate for bucket 1
        //    if (i == 0)
        //    {
        //        matnumber = int.Parse(dt.Rows[i]["matnumber"].ToString());
        //        int MatStarting = int.Parse(dt.Rows[i]["MatStarting"].ToString());
        //        int MatEnding = int.Parse(dt.Rows[i]["MatEnding"].ToString());
        //        trdate = opdate.AddDays(MatEnding);
        //    }
        //    else //Calculate trdate for other buckets
        //    {
        //        matnumber = int.Parse(dt.Rows[i]["matnumber"].ToString());
        //        int MatStarting = int.Parse(dt.Rows[i]["MatStarting"].ToString());  
        //        int MatEnding = int.Parse(dt.Rows[i]["MatEnding"].ToString());
        //        trdate = opdate.AddMonths(MatEnding);
        //    }
            
        //    if (i == 0) 
        //    {
        //         add to bucket1
        //        if (ldatedue < trdate && ldatedue >= opdate)                                             //(ldatedue.AddDays(7) >= trdate)  
        //        {
        //            caparreas = GetArreasInstalment(cracno, "capd");
        //            intarreas = GetArreasInstalment(cracno, "intr");
        //            bulkdata = GetMaturityBucket(trdate, matnumber, cracno, ldatedue, outbal, installment, intrate, graceperiod, crcat, caparreas, intarreas, bulkdata);
        //        }
               
        //    }
        //    else
        //    {
        //        ldatedue = ndatedue;
        //        outbal = noutbal;
        //        if (i == 1)
        //        {
        //            add to bucket2
        //            if (ldatedue >= opdate && ldatedue <trdate )              //(ldatedue.AddDays(7) < trdate)
        //            {
        //                caparreas = GetArreasInstalment(cracno, "capd");
        //                intarreas = GetArreasInstalment(cracno, "intr");
        //                bulkdata = GetMaturityBucket(trdate, matnumber, cracno, ldatedue, outbal, installment, intrate, graceperiod, crcat, caparreas, intarreas, bulkdata);

        //            }
        //            else
        //            {
        //                bulkdata = InsertRow(0, 0, bulkdata);
        //            }
        //        }


        //        else
        //        {
        //            caparreas = GetArreasInstalment(cracno, "capd");
        //            intarreas = GetArreasInstalment(cracno, "intr");
        //            bulkdata = GetMaturityBucket(trdate, matnumber, cracno, ldatedue, outbal, installment, intrate, graceperiod, crcat, caparreas, intarreas, bulkdata);
        //        }

        //    }

        //}




        double[] arrd = new double[9];
        for (int i = 0; bulkdata.Rows.Count > i; i++)
        {
            arrd[i] = double.Parse(bulkdata.Rows[i]["arrcap"].ToString());
        }

        InsertMaturityData("31122010", cracno, arrd[0], arrd[1], arrd[2], arrd[3], arrd[4], arrd[5], arrd[6], arrd[7], arrd[8], crcat, intrate, ldatedue, extoutbal, "CAPD", llastcompletedduedate);
        
        double[] arri = new double[9];
        for (int i = 0; bulkdata.Rows.Count > i; i++)
        {

            arri[i] = double.Parse(bulkdata.Rows[i]["arrint"].ToString());
        }

        InsertMaturityData("31122010", cracno, arri[0], arri[1], arri[2], arri[3], arri[4], arri[5], arri[6], arri[7], arri[8], crcat, intrate, ldatedue, extoutbal, "INTR", llastcompletedduedate);
    }


    public double GetArreasInstalment(string cracno, string taskid)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select assignamt-tramt as arreas from  transassign 
                            where cracno =  @cracno and (trstatus = 'p' or trstatus='n') and trtype = 'I'
                            and taskid = @taskid and tramt != assignamt");
        dw.SetSqlCommandParameters(@"cracno", cracno);
        dw.SetSqlCommandParameters(@"taskid", taskid);
        return double.Parse(dw.GetSingleData());
    }
       

    private DataTable SetDataTable(DataTable dt)
    {
        dt = new DataTable();

        DataColumn refno;
        refno = new DataColumn();
        refno.DataType = Type.GetType("System.String");
        refno.ColumnName = "refno";
        dt.Columns.Add(refno);

        DataColumn cracno;
        cracno = new DataColumn();
        cracno.DataType = Type.GetType("System.String");
        cracno.ColumnName = "cracno";
        dt.Columns.Add(cracno);

        DataColumn TrStatus;
        TrStatus = new DataColumn();
        TrStatus.DataType = Type.GetType("System.String");
        TrStatus.ColumnName = "trstatus";
        dt.Columns.Add(TrStatus);

        DataColumn datedue;
        datedue = new DataColumn();
        datedue.DataType = Type.GetType("System.String");
        datedue.ColumnName = "datedue";
        dt.Columns.Add(datedue);


        DataColumn assignamt;
        assignamt = new DataColumn();
        assignamt.DataType = Type.GetType("System.String");
        assignamt.ColumnName = "assignamt";
        dt.Columns.Add(assignamt);

        DataColumn tramt;
        tramt = new DataColumn();
        tramt.DataType = Type.GetType("System.String");
        tramt.ColumnName = "tramt";
        dt.Columns.Add(tramt);

        DataColumn dcTaskId;
        dcTaskId = new DataColumn();
        dcTaskId.DataType = Type.GetType("System.String");
        dcTaskId.ColumnName = "TaskId";
        dt.Columns.Add(dcTaskId);

        DataColumn outbal;
        outbal = new DataColumn();
        outbal.DataType = Type.GetType("System.String");
        outbal.ColumnName = "outbal";
        dt.Columns.Add(outbal);

        return dt;
    }

    private DataTable SetBucketTable(DataTable dt)
    {
        dt = new DataTable();

        //DataColumn datekey;
        //datekey = new DataColumn();
        //datekey.DataType = Type.GetType("System.String");
        //datekey.ColumnName = "datekey";
        //dt.Columns.Add(datekey);

        //DataColumn cracno;
        //cracno = new DataColumn();
        //cracno.DataType = Type.GetType("System.String");
        //cracno.ColumnName = "cracno";
        //dt.Columns.Add(cracno);

        DataColumn arrint;
        arrint = new DataColumn();
        arrint.DataType = Type.GetType("System.Double");
        arrint.ColumnName = "arrint";
        dt.Columns.Add(arrint);


        DataColumn arrcap;
        arrcap = new DataColumn();
        arrcap.DataType = Type.GetType("System.Double");
        arrcap.ColumnName = "arrcap";
        dt.Columns.Add(arrcap);


        //DataColumn Mat3;
        //Mat3 = new DataColumn();
        //Mat3.DataType = Type.GetType("System.Double");
        //Mat3.ColumnName = "Mat3";
        //dt.Columns.Add(Mat3);

        //DataColumn Mat4;
        //Mat4 = new DataColumn();
        //Mat4.DataType = Type.GetType("System.Double");
        //Mat4.ColumnName = "Mat4";
        //dt.Columns.Add(Mat4);

        //DataColumn Mat5;
        //Mat5 = new DataColumn();
        //Mat5.DataType = Type.GetType("System.Double");
        //Mat5.ColumnName = "Mat5";
        //dt.Columns.Add(Mat5);

        //DataColumn Mat6;
        //Mat6 = new DataColumn();
        //Mat6.DataType = Type.GetType("System.Double");
        //Mat6.ColumnName = "Mat6";
        //dt.Columns.Add(Mat6);

        //DataColumn Mat7;
        //Mat7 = new DataColumn();
        //Mat7.DataType = Type.GetType("System.Double");
        //Mat7.ColumnName = "Mat7";
        //dt.Columns.Add(Mat7);

        //DataColumn Mat8;
        //Mat8 = new DataColumn();
        //Mat8.DataType = Type.GetType("System.Double");
        //Mat8.ColumnName = "Mat8";
        //dt.Columns.Add(Mat8);

        //DataColumn Mat9;
        //Mat9 = new DataColumn();
        //Mat9.DataType = Type.GetType("System.Double");
        //Mat9.ColumnName = "Mat9";
        //dt.Columns.Add(Mat9);

        //DataColumn crcat;
        //crcat = new DataColumn();
        //crcat.DataType = Type.GetType("System.Int32");
        //crcat.ColumnName = "crcat";
        //dt.Columns.Add(crcat);

        //DataColumn Intrate;
        //Intrate = new DataColumn();
        //Intrate.DataType = Type.GetType("System.Double");
        //Intrate.ColumnName = "Intrate";
        //dt.Columns.Add(Intrate);

        //DataColumn lastcompletedduedate;
        //lastcompletedduedate = new DataColumn();
        //lastcompletedduedate.DataType = Type.GetType("System.String");
        //lastcompletedduedate.ColumnName = "lastcompletedduedate";
        //dt.Columns.Add(lastcompletedduedate);

        return dt;
    }


    private DataTable GetMaturityBucket(DateTime trdate, int matnumber, string cracno,
        DateTime datedue, double outbal, double installment,double intrate, int graceperiod, int crcat, double caparreas, 
        double inrarreas, DataTable dt)
    {
        interest = penal = capital = 0;
        RecoveryProcesClass rpc = new RecoveryProcesClass();
        //DataTable setclosingdata = new DataTable();
        //setclosingdata = SetDataTable(setclosingdata);
        rpc.MaturityAnalysis(cracno, datedue, outbal, installment, intrate, graceperiod, crcat, caparreas, inrarreas, trdate);
        capital = rpc.MCapital;
        interest = rpc.MInterest;
        penal = rpc.MPenal;
        this.noutbal = rpc.Noutbal;
        this.ndatedue = rpc.Ndatedue;
        dt = InsertRow(capital, interest, dt);
        return dt;
    }

    public void InsertMaturityData(string datekey, string cracno, double mat1, double mat2, double mat3, double mat4, double mat5
        , double mat6, double mat7, double mat8, double mat9, int crcat, double intrate, DateTime lastcompletedduedate, double outbal, string matcat, DateTime llastcompletedduedate)
    {
        int rowAdded = 0;
        dw = new DataWorksClass(reporTString);
        dw.SetCommand(@"INSERT INTO MaturityData (datekey ,cracno ,Mat1 ,Mat2 ,Mat3 ,Mat4 ,Mat5 ,Mat6
                    ,Mat7 ,Mat8 ,Mat9 ,crcat ,intrate ,lastcompletedduedate, outbal, matcat,datedue)
                    VALUES
                    (@datekey ,@cracno ,@Mat1 ,@Mat2 ,@Mat3 ,@Mat4 ,@Mat5 ,@Mat6 ,@Mat7
                    ,@Mat8 ,@Mat9 ,@crcat ,@intrate ,@lastcompletedduedate, @outbal, @matcat,@datedue)");
        dw.SetSqlCommandParameters("datekey", datekey);
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("Mat1", mat1);
        dw.SetSqlCommandParameters("Mat2", mat2);
        dw.SetSqlCommandParameters("Mat3", mat3);
        dw.SetSqlCommandParameters("Mat4", mat4);
        dw.SetSqlCommandParameters("Mat5", mat5);
        dw.SetSqlCommandParameters("Mat6", mat6);
        dw.SetSqlCommandParameters("Mat7", mat7);
        dw.SetSqlCommandParameters("Mat8", mat8);
        dw.SetSqlCommandParameters("Mat9", mat9);
        dw.SetSqlCommandParameters("crcat", crcat);
        dw.SetSqlCommandParameters("intrate", intrate);
        dw.SetSqlCommandParameters("lastcompletedduedate", lastcompletedduedate);
        dw.SetSqlCommandParameters("outbal", outbal);
        dw.SetSqlCommandParameters("matcat", matcat);
        dw.SetSqlCommandParameters("datedue", llastcompletedduedate);
        rowAdded = dw.Insert();
    }


    private DataTable GetMaturityBuckets()
    {
        dw = new DataWorksClass(reporTString);
        dw.SetDataAdapter(@"select * from MaturityBucket");
        return dw.GetDataTable();
    }

    public object GetLoanCatogery()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select CRDES as LoanCatogery,Crcatcode from CrCategory");
        return dw.GetDataTable();
    }

    public DataTable DisplayData(string date, int crcat, string Crdesc)
    {
        dw = new DataWorksClass(reporTString);

        dt = new DataTable();
        dw.SetDataAdapter(@"select cracno, Mat1 as [1-7days],Mat2 as [7-30days],
                                    Mat3 as [1-3Months],Mat4 as [3-6Months],Mat5 as [6-12Months],
                                    Mat6 as [1-3Year],Mat7 as [3-5Year],Mat8 as [Over 5Year],
                                    Mat9 as [Unclassified] from MaturityData where
                                    datekey=@date and crcat=@crcat and MatCat=@Crdesc");
        dw.SetDataAdapterParameters("date", date);
        dw.SetDataAdapterParameters("crcat", crcat);
        dw.SetDataAdapterParameters("Crdesc", Crdesc);
        dt = dw.GetDataTable();
        return dt;
    }

    public DataTable DisplayDataBranch(string date, int crcat, string Crdesc)
    {
        dw = new DataWorksClass(reporTStringBranch);

        dt = new DataTable();
        dw.SetDataAdapter(@"select cracno, Mat1 as [1-7days],Mat2 as [7-30days],
                                    Mat3 as [1-3Months],Mat4 as [3-6Months],Mat5 as [6-12Months],
                                    Mat6 as [1-3Year],Mat7 as [3-5Year],Mat8 as [Over 5Year],
                                    Mat9 as [Unclassified] from MaturityData where
                                    datekey=@date and crcat=@crcat and MatCat=@Crdesc");
        dw.SetDataAdapterParameters("date", date);
        dw.SetDataAdapterParameters("crcat", crcat);
        dw.SetDataAdapterParameters("Crdesc", Crdesc);
        dt = dw.GetDataTable();
        return dt;
    }
}

