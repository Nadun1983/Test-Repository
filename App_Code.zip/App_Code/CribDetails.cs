﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
/// <summary>
/// Summary description for CribDetails
/// </summary>
public class CribDetails
{

    private double captotal, inttotal, penaltotal;
    int arreasdaye = 0;

    Corrections cs;
    DateTime datedue, nextdue, intdatedue;
    double outbal, actoutbal, exesspayment;
    string msg;
    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();
    CrTransClass cc;
    DataWorksClass dw;
    FunctionClass fc;
    Recovery rc;
    Trans t;

    public double CapitalTot
    {
        get
        {
            return this.captotal;
        }
    }

    public double INtTot
    {
        get
        {
            return this.inttotal;
        }
    }

    public double PenalTot
    {
        get
        {
            return this.penaltotal;
        }
    }

    public CribDetails()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public DataTable GetBaseRecords(string acstatus, string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select h.outbal,  h.actoutbal, h.cracno, h.datedue, h.intrate, h.instalment, 
                            h.LastCompletedDueDate, h.graceperiod, h.crperiod-h.paidInstalments as RemainingInstalment,
                            h.LastCompletedDueDate, c.crcat
                            from housprop h, crmast c where h.cracno =@cracno and c.acstatus =@acstatus and
                            c.cracno = h.cracno");
        dw.SetDataAdapterParameters("acstatus", acstatus);
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }

    private double GetOutBal(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select sum(assignamt-tramt) as diff from transassign where cracno=@cracno
                        and taskid='CAPD' and (trstatus = 'P' or trstatus = 'N')");
        dw.SetSqlCommandParameters("cracno", cracno);
        return double.Parse(dw.GetSingleData());
    }
    private DataTable GetArreasAmount(string cracno, string trstatus1, string trstatus2)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select refno, assignamt, assignamt-tramt as arreas, taskid, datedue from  transassign 
                            where cracno =  @cracno 
                            and tramt != assignamt and tramt!=0 and (trstatus = @trstatus1 or trstatus = @trstatus2)");
        dw.SetDataAdapterParameters(@"cracno", cracno);
        dw.SetDataAdapterParameters(@"trstatus1", trstatus1);
        dw.SetDataAdapterParameters(@"trstatus2", trstatus2);
        return dw.GetDataTable();
    }


    private DataTable GetArreasInstalment(string cracno, DateTime datedue)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select refno, assignamt, assignamt-tramt as arreas, taskid, datedue from  transassign 
                            where cracno =  @cracno and (trstatus = 'p' or trstatus='n')
                            and (taskid = 'capd' or taskid = 'intr') and tramt != assignamt");
        dw.SetDataAdapterParameters(@"cracno", cracno);
        return dw.GetDataTable();
    }


    private double CalculatePenal(DateTime workingDate, double penalint, int graceperiod, string cracno, DateTime datedue, double installment, double intrate)
    {
        if ((intrate == 3 || intrate == 5 || intrate == 8 || intrate == 6 || intrate == 7 || intrate == 9) && (cracno != "603080000215"))
        {
            penalint = 0;
        }
        DataTable basicRec = new DataTable(); //Loan Number Table
        int i = 0; //count of no of loans based on the date due
        //workingDate = workingDate.AddDays(-1);

        int noofdue; // Due Months
        int dayDD; // Due Day
        int dayWD; // Working Day
        int monthDD; // Due Month
        int monthWD; // Working Month
        int yearDD; // Due Year
        int yearWd; // Working Year
        double penal; // Penal Charges

        //Get date and Month From the Working Date and Due Date
        dayDD = datedue.Day;
        dayWD = workingDate.Day;
        monthDD = datedue.Month;
        monthWD = workingDate.Month;
        yearDD = datedue.Year;
        yearWd = workingDate.Year;

        if (dayDD > dayWD)
        {
            noofdue = (yearWd * 12 + monthWD) - (yearDD * 12 + monthDD);
        }
        else
        {
            noofdue = (yearWd * 12 + monthWD) - (yearDD * 12 + monthDD) + 1;
        }

        //Reduce the Grace Period
        noofdue = noofdue - graceperiod;

        // Penal calculation
        return Math.Round((installment * penalint * noofdue) / 1200, 2);

    }


    private double CalculateIntAmount(double outbal, double intrate)
    {
        return Math.Round(outbal * intrate / 1200, 2);
    }

    private double CalculateCapital(double installment, double intAmount, int crcat, double outbal)
    {
        if (crcat != 6)
        {
            if (installment >= outbal)
            {
                return Math.Round(outbal, 2);
            }
            else
            {
                return Math.Round(installment - intAmount, 2);
            }
        }
        else
        {
            return 0;
        }
    }


    private DateTime GetPenalValidDate(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select case when PenalValidDate is null 
                        then '01/01/1900' 
                        else PenalValidDate end as PenalValidDate 
                        from housprop where cracno =@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return DateTime.Parse(dw.GetSingleData());
    }


    private string GetPenalInt(string ratetype)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand("select rateamt from ratecode where ratetype=@ratetype");
        dw.SetSqlCommandParameters("ratetype", ratetype);
        return dw.GetSingleData();
    }


    public int GetNoDaysForInterest(DateTime intdatedue, DateTime trdate)
    {
        int days = 0;
        fc = new FunctionClass();
        TimeSpan t = trdate.Subtract(intdatedue);
        days = t.Days;
        return days;
    }

    public DataTable RecoveryProcessTempForCrib(string cracno, DateTime operationdate, DateTime trdate, DataTable dt)
    {
        DateTime recoveryProcessDate;
        fc = new FunctionClass();
        cc = new CrTransClass();
        rc = new Recovery();
        double intamount = 0, capital = 0, penal = 0, penalarreas = 0;
        double actoutbal = 0, outbal = 0;
        int RecOrder = 0;
        DataTable basicRec = new DataTable(); //Loan Number Table       
        int penalInt = int.Parse(GetPenalInt("PEN"));

        basicRec = GetBaseRecords("A", cracno);

        // Set OUtbal from actoutbal
        actoutbal = Math.Round(Convert.ToDouble(basicRec.Rows[0]["actoutbal"].ToString()), 2);
        outbal = Math.Round((actoutbal - GetOutBal(cracno)), 2);

        double intrate = Convert.ToDouble(basicRec.Rows[0]["intrate"].ToString());
        double installment = Convert.ToDouble(basicRec.Rows[0]["instalment"].ToString());
        int graceperiod = int.Parse(basicRec.Rows[0]["graceperiod"].ToString());
        datedue = DateTime.Parse(basicRec.Rows[0]["LastCompletedDueDate"].ToString());
        nextdue = DateTime.Parse(basicRec.Rows[0]["datedue"].ToString());
        string nextduedisplay = fc.GetDisplayDate(datedue);
        int crcat = int.Parse(basicRec.Rows[0]["crcat"].ToString());
        arreasdaye = GetNoDaysForInterest(datedue, trdate);
        double arreasamt, assignamt;
        string arreastask, refno;
        //Calculate Penal
        DataTable arreasdata = new DataTable();
        arreasdata = GetArreasAmount(cracno, "P", "N");
        if (actoutbal > 0)
        {
            if (arreasdata.Rows.Count > 0)
            {
                arreasamt = double.Parse(arreasdata.Rows[0]["arreas"].ToString());
                arreastask = arreasdata.Rows[0]["taskid"].ToString();
                refno = arreasdata.Rows[0]["refno"].ToString();
                assignamt = double.Parse(arreasdata.Rows[0]["assignamt"].ToString());
                //datedue = DateTime.Parse(arreasdata.Rows[0]["datedue"].ToString());
                //nextduedisplay = fc.GetDisplayDate(datedue);
                if (arreastask == "PNLR")
                {
                    penaltotal += arreasamt;

                    //dt = InsertRow(refno, cracno, assignamt, arreasamt, nextduedisplay, "P", "PNLR", dt);
                }
            }

            RecOrder = fc.GetRecordOrder(cracno);
            DataTable arreasanstalmentdata = new DataTable();
            arreasanstalmentdata = GetArreasInstalment(cracno, datedue);
            if (arreasanstalmentdata.Rows.Count > 0)
            {
                double arreasTot = 0;
                for (int i = 0; arreasanstalmentdata.Rows.Count > i; i++)
                {
                    arreasamt = double.Parse(arreasanstalmentdata.Rows[i]["arreas"].ToString());
                    arreasTot += arreasamt;
                }
                recoveryProcessDate = GetPenalValidDate(cracno);
                penal = CalculatePenal(trdate, penalInt, graceperiod, cracno, datedue, arreasTot, intrate);
                if (recoveryProcessDate <= trdate)
                {
                    if (penal > 0)
                    {
                        penaltotal += penal;
                        //dt = InsertRow("0", cracno, penal, penal, nextduedisplay, "N", "PNLR", dt);
                    }
                }
                if (arreasanstalmentdata.Rows.Count > 0)
                {
                    for (int i = 0; arreasanstalmentdata.Rows.Count > i; i++)
                    {
                        string taskid = arreasanstalmentdata.Rows[i]["taskid"].ToString();
                        arreasamt = double.Parse(arreasanstalmentdata.Rows[i]["arreas"].ToString());
                        refno = arreasanstalmentdata.Rows[i]["refno"].ToString();
                        assignamt = double.Parse(arreasanstalmentdata.Rows[i]["assignamt"].ToString());
                        //datedue = DateTime.Parse(arreasanstalmentdata.Rows[0]["datedue"].ToString());
                        if (arreasamt > 0)
                        {
                            switch (taskid)
                            {
                                case "CAPD":
                                    captotal += arreasamt;
                                    break;

                                case "INTR":
                                    penaltotal += arreasamt;
                                    break;
                            }

                        }
                    }
                }
            }
            if (outbal > installment)
            {
                if (trdate >= nextdue)
                {
                    while (trdate >= nextdue)
                    {
                        penal = CalculatePenal(trdate, penalInt, graceperiod, cracno, nextdue, installment, intrate);
                        intamount = CalculateIntAmount(outbal, intrate);
                        capital = CalculateCapital(installment, intamount, crcat, outbal);
                        nextduedisplay = fc.GetDisplayDate(nextdue);
                        //Set Penal Valid date
                        recoveryProcessDate = fc.SetRecoveryProcessDate(trdate, cracno);
                        //UpdatePenalValidDate(cracno, recoveryProcessDate);
                        // Insert Penal Portion
                        if (penal > 0)
                        {
                            penaltotal += penal;
                            //dt = InsertRow("0", cracno, penal, penal, nextduedisplay, "N", "PNLR", dt);
                        }
                        inttotal += intamount;
                        captotal += capital;
                        // Interest Portion
                        //dt = InsertRow("0", cracno, intamount, intamount, nextduedisplay, "N", "INTR", dt);

                        // Capital Portion
                        //dt = InsertRow("0", cracno, capital, capital, nextduedisplay, "N", "CAPD", dt);
                        outbal -= capital;
                        outbal = Math.Round(outbal, 2);

                        //SetPayments Next Due
                        nextdue = fc.SetRecoveryDate(nextdue);
                    }
                    datedue = nextdue.AddMonths(-1);
                }
            }
            else
            {
                while (trdate >= nextdue)
                {
                    penal = CalculatePenal(trdate, penalInt, graceperiod, cracno, nextdue, installment, intrate);
                    if (penal > 0)
                    {
                        penaltotal += penal;
                        //dt = InsertRow("0", cracno, penal, penal, nextduedisplay, "N", "PNLR", dt);
                    }
                    nextdue = fc.SetRecoveryDate(nextdue);
                }
                datedue = nextdue.AddMonths(-1);
            }
        }
        else
        {
            outbal = 0;
        }
        intdatedue = nextdue.AddMonths(-1);
        this.outbal = outbal;
        return dt;
    }



    public int insertCRIB_ProjectLoan_CNCS(string Cracno
           , string BusRegNo, string LegalConstruction, string EconActType
           , string SubName, string ShortName, string MailLine1
           , string MailLine2, string MailLineCity, string MailDistrict
           , string MailProvince, string MailCountry, string PerAddressLine1
           , string PerAddressLine2, string PerAddressCity , string PerAddressDistrict
           , string PerAddressProvince, string PerAddressCountry, string PhoneNum, string FaxNum,string AddUser)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO CRIB_Corp_CNCS
           ([Cracno]
           ,[BusRegNo]
           ,[LegalConstruction]
           ,[EconActType]
           ,[SubName]
           ,[ShortName]
           ,[MailLine1]
           ,[MailLine2]
           ,[MailLineCity]
           ,[MailDistrict]
           ,[MailProvince]
           ,[MailCountry]
           ,[PerAddressLine1]
           ,[PerAddressLine2]
           ,[PerAddressCity]
           ,[PerAddressDistrict]
           ,[PerAddressProvince]
           ,[PerAddressCountry]
           ,[PhoneNum]
           ,[FaxNum]
           ,[AddUser])
     VALUES
           (@Cracno
           ,@BusRegNo 
           ,@LegalConstruction
           ,@EconActType 
           ,@SubName 
           ,@ShortName 
           ,@MailLine1 
           ,@MailLine2 
           ,@MailLineCity 
           ,@MailDistrict
           ,@MailProvince
           ,@MailCountry
           ,@PerAddressLine1
           ,@PerAddressLine2
           ,@PerAddressCity
           ,@PerAddressDistrict
           ,@PerAddressProvince
           ,@PerAddressCountry 
           ,@PhoneNum
           ,@FaxNum
           ,@AddUser)");
        dw.SetSqlCommandParameters("Cracno",Cracno);
           dw.SetSqlCommandParameters("BusRegNo",BusRegNo );
           dw.SetSqlCommandParameters("LegalConstruction",LegalConstruction);
           dw.SetSqlCommandParameters("EconActType",EconActType );
           dw.SetSqlCommandParameters("SubName",SubName );
           dw.SetSqlCommandParameters("ShortName",ShortName) ;
           dw.SetSqlCommandParameters("MailLine1",MailLine1 );
           dw.SetSqlCommandParameters("MailLine2",MailLine2 );
           dw.SetSqlCommandParameters("MailLineCity",MailLineCity );
           dw.SetSqlCommandParameters("MailDistrict",MailDistrict);
           dw.SetSqlCommandParameters("MailProvince",MailProvince);
           dw.SetSqlCommandParameters("MailCountry",MailCountry);
           dw.SetSqlCommandParameters("PerAddressLine1",PerAddressLine1);
           dw.SetSqlCommandParameters("PerAddressLine2",PerAddressLine2);
           dw.SetSqlCommandParameters("PerAddressCity",PerAddressCity);
           dw.SetSqlCommandParameters("PerAddressDistrict",PerAddressDistrict);
           dw.SetSqlCommandParameters("PerAddressProvince",PerAddressProvince);
           dw.SetSqlCommandParameters("PerAddressCountry",PerAddressCountry );
           dw.SetSqlCommandParameters("PhoneNum", PhoneNum);
           dw.SetSqlCommandParameters("FaxNum", FaxNum);
           dw.SetSqlCommandParameters("AddUser", AddUser);
       return dw.Insert();
    }
}