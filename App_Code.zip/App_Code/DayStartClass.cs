﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Data.SqlClient;

/// <summary>
/// Summary description for DayStartClass
/// </summary>
public class DayStartClass
{
    double totamount;
    SqlConnection sqlConn;
    SqlDataReader sqlDataReader;
    SqlCommand sqlCmd;
    DataTable dt;
    FunctionClass fc;
    SqlDataAdapter sqlAdapter;
    DataWorksClass dw;

    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString;

	public DayStartClass()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    //public string GetCurrentDate(string currentstatus)
    //{
    //    dw = new DataWorksClass(constring);
    //    dw.SetCommand(@"select operationdate as OperationDate from OperationCalendar where currentstatus=@currentstatus");
    //    dw.SetSqlCommandParameters("currentstatus", currentstatus);
    //    return dw.GetSingleData();
    //}

    //BranchCode-000001

    public DataTable GetBranchNumbers()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select branchno from nsb_branch");
        return dw.GetDataTable();
    }

    //vihanga 2009-11-29
    public int SetOperationCalendarBranch(string operationdate, string branchcode, string usermode, int SerialNo, string CurrentStatus)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into OperationCalendarBranch(operationdate,branchcode,usermode,SerialNo,CurrentStatus)
                        values(@operationdate,@branchcode,@usermode,@SerialNo,@CurrentStatus)");
        dw.SetSqlCommandParameters("operationdate", operationdate);
        dw.SetSqlCommandParameters("branchcode", branchcode);
        dw.SetSqlCommandParameters("usermode", usermode);
        dw.SetSqlCommandParameters("SerialNo", SerialNo);
        dw.SetSqlCommandParameters("CurrentStatus", CurrentStatus);
        return dw.Insert();
    }


    public int UpdateOperationCalendar(string operationdate,string starttime,string startuserid,string currentstatus)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update OperationCalendar set starttime=@starttime, startuserid=@startuserid , currentstatus=@currentstatus
                        where operationdate=@operationdate");
        dw.SetSqlCommandParameters("operationdate",operationdate);
        dw.SetSqlCommandParameters("starttime",starttime);
        dw.SetSqlCommandParameters("startuserid",startuserid);
        dw.SetSqlCommandParameters("currentstatus", currentstatus);
        return dw.Update();
    }

    public string CheckCurrentStatus(string currentstatus)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select operationdate from OperationCalendar where currentstatus=@currentstatus");
        dw.SetSqlCommandParameters("currentstatus", currentstatus);
        return dw.GetSingleData();
    }

    public bool CheckStatusToProceed(string currentstatus)
    {
        string temp = "0";
        temp = CheckCurrentStatus(currentstatus);
        if (temp == "0")
            return true;
        else
            return false;
    }

    public int InsertRecordToStartDayProcess(string WorkDate, int SetOperationDate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into StartDayProcess(WorkDate,SetOperationDate) values(@WorkDate,@SetOperationDate)");
        dw.SetSqlCommandParameters("WorkDate", WorkDate);
        dw.SetSqlCommandParameters("SetOperationDate", SetOperationDate);
        return dw.Insert();
    }


    //vihanga 2009-11-29
    public DataTable GetBrancAdminConfirmation(string branchcode)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select usermode,serialno,min(operationdate) from OperationCalendarbranch where 
                        branchcode=@branchcode and dayend is null group by usermode,serialno,operationdate order by operationdate");
        dw.SetDataAdapterParameters("branchcode", branchcode);
        return dw.GetDataTable();
    }

    //vihanga 2009-11-29
    public string GetBranchWorkingDate(string branchcode)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select min(operationdate) as CurrentDate from OperationCalendarbranch 
                        where branchcode=@branchcode and dayend is null");
        dw.SetSqlCommandParameters("branchcode", branchcode);
        return dw.GetSingleData();
    }

    //vihanga 2009-11-29
    public int ConfirmDayStart(bool daystart, string starttime, string startuser, string operationdate, string branchcode, int serialNo, string CurrentStatus)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update OperationCalendarbranch set daystart=@daystart,starttime=@starttime,startuser=@startuser,serialNo=@serialNo,
                        CurrentStatus=@CurrentStatus where operationdate=@operationdate and branchcode=@branchcode");
        dw.SetSqlCommandParameters("daystart", daystart);
        dw.SetSqlCommandParameters("starttime", starttime);
        dw.SetSqlCommandParameters("startuser", startuser);
        dw.SetSqlCommandParameters("operationdate", operationdate);
        dw.SetSqlCommandParameters("branchcode", branchcode);
        dw.SetSqlCommandParameters("serialNo", serialNo);
        dw.SetSqlCommandParameters("CurrentStatus", CurrentStatus);
        return dw.Update();
    }

    //vihanga 2009-11-29
    public int ConfirmDayEnd(bool dayend, string endtime, string enduser, string operationdate, string branchcode, int serialNo, string CurrentStatus)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update OperationCalendarbranch set dayend=@dayend,endtime=@endtime,enduser=@enduser,serialNo=@serialNo,
                        CurrentStatus=@CurrentStatus where 
                        operationdate=@operationdate and branchcode=@branchcode and dayend is null and daystart is not null");
        dw.SetSqlCommandParameters("dayend", dayend);
        dw.SetSqlCommandParameters("endtime", endtime);
        dw.SetSqlCommandParameters("enduser", enduser);
        dw.SetSqlCommandParameters("operationdate", operationdate);
        dw.SetSqlCommandParameters("branchcode", branchcode);
        dw.SetSqlCommandParameters("serialNo", serialNo);
        dw.SetSqlCommandParameters("CurrentStatus", CurrentStatus);
        return dw.Update();
    }

    //vihanga 2009-11-29
    public int CompleteSystemDayEnd(DateTime EndTime)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update OperationCalendar set currentstatus='C',EndTime=@EndTime where currentstatus='A'");
        dw.SetSqlCommandParameters("EndTime", EndTime);
        int rows = dw.Update();

        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update operationcalendar set currentstatus='N' where operationdate=
                     (select min(operationdate) from operationcalendar where currentstatus is null)");
        rows += dw.Update();
        return rows;
    }



}
