﻿using System;
using System.Data;
using System.Configuration;
//using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
//using System.Xml.Linq;
using System.IO;

/// <summary>
/// Summary description for TextFileClass
/// </summary>
public class TextFileClass
{
    DataTable dt;
    DataWorksClass dw;
    //public TextFileClass()
    //{
        
    //     TODO: Add constructor logic here

    //}

    public void writeToFile(string writetext, string inpfilepath)
    {
        StreamWriter wr;
        using (wr = new StreamWriter(inpfilepath, true))
        {
            wr.WriteLine(writetext);
        }
    }
    public string CreateNewFile(string inptemppath, string inpfilepath)
    {
        string createmode = "";
        try
        {
            using (FileStream fs = new FileStream(inptemppath, FileMode.Create))
            { }
            createmode = "Success";
        }
        catch (Exception e)
        {
            createmode = "File create failed";
        }

        try
        {
            System.IO.File.Copy(inptemppath, inpfilepath, false);
        }
        catch (Exception ex)
        {
            createmode = "File already exists !";
        }
        return createmode;
    }


}
