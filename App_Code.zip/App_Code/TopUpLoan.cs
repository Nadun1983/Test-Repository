﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

/// <summary>
/// Summary description for TopUpLoan
/// </summary>
public class TopUpLoan
{
    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();
    DataWorksClass dw;

	public TopUpLoan()
	{
		//
		// TODO: Add constructor logic here
		//
	}

//    public DataTable GetSecurityDetails(string AppNo)
//    {
//        dw = new DataWorksClass(constring);
//        dw.SetDataAdapter(@"select IsCondominium,LotNo,PlanNo,PlanDate,UnitNo,SchemeNo,SurveyName,IsOwner,LandExtent,MetricUnitID,LandName
//                            ,LandLocation,LandStreet,LandCity,FloorArea,Camapno,Vplanno,VillageName,GrDivno,DivSecName,DistCode,OWNERSNAME,
//                            AdUser,status,AdDate,UpdateLevel from HpSec where AppNo=@AppNo");
//        dw.SetDataAdapterParameters("AppNo", AppNo);
//        return dw.GetDataTable();

//    }

    public int InsertSecurityDetails(string NewAppNo, string AppNo, string AdUser, DateTime AdDate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into HpSec SELECT @NewAppNo,IsCondominium,LotNo,PlanNo,PlanDate,UnitNo,SchemeNo,SurveyName,IsOwner
                        ,LandExtent,MetricUnitID,LandName,LandLocation,LandStreet,LandCity,FloorArea,Camapno
                        ,Vplanno,VillageName,GrDivno,DivSecName,DistCode,OWNERSNAME,@AdUser,status,@AdDate,UpdateLevel
                        FROM Hpsec WHERE AppNo=@AppNo and AdDate = (select MAX(AdDate) from
                        Hpsec where APPNO=@AppNo)");

        dw.SetSqlCommandParameters("NewAppNo", NewAppNo);
        dw.SetSqlCommandParameters("AppNo", AppNo);
        dw.SetSqlCommandParameters("AdUser", AdUser);
        dw.SetSqlCommandParameters("AdDate", AdDate);
        return dw.Insert();
    }

    public int InsertValuationDetails(string NewAppNo, string AppNo, string AddUser, DateTime Adddatetime)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into Valuation SELECT @NewAppNo,VALUERID,SENDDATE,RECVDATE,VALUPERIOD,DATEOFVAL,PRESENTVAL,COMPLETEVAL,FORCEVAL
                        ,ValuerFee,TrportFee,FIREINSURANCE,REMARKS,HIDE,STATUS,HIDEUSER,IsTrPortPd
                        ,IsValuerPd,IsCommisPaid,CommisFee,IsGovtPaid,PaidDate,ExpressTrPort,ExpValuerFee,IsExpTrPaid
                        ,IsExpValuerPd,ValuerComments,AccessRoad,@AddUser,@Adddatetime,-100,ValuationStatus
                        ,TransactionNo,CommissionTransactionNo,ValuerType
                          FROM Valuation where APPNO=@AppNo and DATEOFVAL = (select MAX(DATEOFVAL) from
                        Valuation where APPNO=@AppNo and ValuerType='O' and SENDDATE is not null and RECVDATE is not null)");

        dw.SetSqlCommandParameters("NewAppNo", NewAppNo);
        dw.SetSqlCommandParameters("AppNo", AppNo);
        dw.SetSqlCommandParameters("AddUser", AddUser);
        dw.SetSqlCommandParameters("Adddatetime", Adddatetime);
        return dw.Insert();
    }

    public int UpdateSecurityApprovalStat(string AppNo, bool IsSecurityOK)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update ApprovalStatus set IsSecurityOK=@IsSecurityOK where AppNo=@AppNo");
        dw.SetSqlCommandParameters("IsSecurityOK", IsSecurityOK);
        dw.SetSqlCommandParameters("AppNo", AppNo);
        return dw.Update();
    }

    public int UpdateValuationApprovalStat(string AppNo, bool IsValuationOK)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update ApprovalStatus set IsValuationOK=@IsValuationOK where AppNo=@AppNo");
        dw.SetSqlCommandParameters("IsValuationOK", IsValuationOK);
        dw.SetSqlCommandParameters("AppNo", AppNo);
        return dw.Update();
    }

    public int InsertTopUpLoanDetails(string AppNo, string CrAcNo, string NicNo,int CatPurposeId, DateTime RecvDate, string AddUser)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into TopUpLoans (AppNo,CrAcNo,NicNo,CatPurposeId,RecvDate,AddUser) 
                        Values (@AppNo,@CrAcNo,@NicNo,@CatPurposeId,@RecvDate,@AddUser)");

        dw.SetSqlCommandParameters("AppNo", AppNo);
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        dw.SetSqlCommandParameters("NicNo", NicNo);
        dw.SetSqlCommandParameters("CatPurposeId", CatPurposeId);
        dw.SetSqlCommandParameters("RecvDate", RecvDate);
        dw.SetSqlCommandParameters("AddUser", AddUser);
        return dw.Insert();
    }

    public string OldAppNo(string CrAcNo)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"SELECT AppNo FROM CrMast WHERE CrAcNo=@CrAcNo");
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        return dw.GetSingleData();
    }

}
