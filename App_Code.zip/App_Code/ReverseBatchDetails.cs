﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

/// <summary>
/// Summary description for ReverseBatchDetails
/// </summary>
public class ReverseBatchDetails
{
    DataWorksClass dw;
    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString;
	public ReverseBatchDetails()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public DataTable GetBatchDetails(DateTime trdate)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select distinct status from ProvisionBatchdetails where trdate=@trdate and reversebatchno is null");
        dw.SetDataAdapterParameters("trdate", trdate);
        return dw.GetDataTable();
    }

    public DataTable GetTransferDetails(string status)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select trdate, refglcode,GlDesc,acsign,taskid,CAST(CONVERT(varchar, CAST(tramt AS money), 1) AS varchar) as tramt 
                            from ProvisionBatchdetails where status=@status 
                            and reversebatchno is null");
        dw.SetDataAdapterParameters("status", status);
        return dw.GetDataTable();
    }

    public DataTable GetTotals(string status)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select CAST(CONVERT(varchar, CAST((SUM(tramt)) AS money), 1) AS varchar) as Credit, 'CR' as Acsign from ProvisionBatchdetails where status=@status and acsign='CR'
                            and reversebatchno is null
                            union all
                            select CAST(CONVERT(varchar, CAST((SUM(tramt)) AS money), 1) AS varchar) as Credit, 'DR' as Acsign from ProvisionBatchdetails where status=@status and acsign='DR'
                            and reversebatchno is null");
        dw.SetDataAdapterParameters("status", status);
        return dw.GetDataTable();
    }

    
}
