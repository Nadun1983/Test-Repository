using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// Summary description for NewApplication
/// </summary>
public class NewApplication
{
	private SqlDataAdapter da;
    DataSet ds;
    private SqlConnection mycon;
    SqlDataAdapter sqlAdapter;
    DataTable dt;
    SqlCommand scm;
    DataWorksClass dw;

    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();
    public NewApplication()
    {
       
        SqlConnection myconnection = new SqlConnection(ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString);
        this.mycon = myconnection;
    }

    public DataTable GetHolderDetails(string nic1, string nic2, string nic3, string nic4, string nic5,
                                    string nic6, string nic7)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"SELECT NicNo,Initials,Surname,OtherName,Location,Street,City,Dobirth FROM CustomerMain WHERE NicNo =@nic1 OR
                      (NicNo = @nic1 OR NicNo = @nic2 ) OR (NicNo = @nic1 OR NicNo = @nic2 OR NicNo = @nic3 ) OR 
                      (NicNo = @nic1 OR NicNo = @nic2 OR NicNo = @nic3 OR NicNo = @nic4 ) OR (NicNo = @nic1 OR NicNo = @nic2 OR NicNo = @nic3 
                      OR NicNo = @nic4 OR NicNo = @nic5 ) OR (NicNo = @nic1 OR NicNo = @nic2 OR NicNo = @nic3 
                      OR NicNo = @nic4 OR NicNo = @nic5 OR NicNo = @nic6 ) OR (NicNo = @nic1 OR NicNo = @nic2 OR NicNo = @nic3 
                      OR NicNo = @nic4 OR NicNo = @nic5 OR NicNo = @nic6 OR NicNo =@nic7)");
        dw.SetDataAdapterParameters("nic1", nic1);
        dw.SetDataAdapterParameters("nic2", nic2);
        dw.SetDataAdapterParameters("nic3", nic3);
        dw.SetDataAdapterParameters("nic4", nic4);
        dw.SetDataAdapterParameters("nic5", nic5);
        dw.SetDataAdapterParameters("nic6", nic6);
        dw.SetDataAdapterParameters("nic7", nic7);
        return dw.GetDataTable();
    }

    public DataTable GetPowerOfAttorneyDet(string nicno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"SELECT NicNo, Initials, Surname, Location, Street, City FROM CustomerMain 
                    WHERE NicNo=@nicno");
        dw.SetDataAdapterParameters("nicno", nicno);
        return dw.GetDataTable();
    }

    public DataTable LoadCrCategories()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from crcategory");
        return dw.GetDataTable();
    }

    public DataTable LoadOtherIncome()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"SELECT * FROM otherincome");
        return dw.GetDataTable();
    }

    public int GetAppSequenceNo()
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select max(serialno)+1 as appno from lastserial where serialdesc='AppNo'");
        return int.Parse(dw.GetSingleData());
    }

    public int InsertDetailstoCrApp(string appno, DateTime rdate, decimal cramt, decimal boqamt, 
                                        decimal puramt,
                                        int disbursement, int gracep, int maxperiod, string ctype,
                                        string loantype, string sectype, string username, DateTime addate,
                                        int updatelevel, int catcode, string isadd, string IsApprovd,
                                         string status, int LoanPeriod)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@" INSERT INTO CrApp (AppNo,RecvDate,CrAmt,BoqAmount,RedemPurchaseAmt, NoOfDisb,GracePeriod,
                        CrPeriod,ClientType,AppCat,SecurityType,AddUser,AddDate,UpdateLevel,CrCatCode,IsAdditional, 
                        IsApproved, Status, LoanPeriod)
                        values(@AppNo,@RecvDate,@CrAmt,@BoqAmount,@RedemPurchaseAmt, @NoOfDisb,@GracePeriod,
                        @CrPeriod,@ClientType,@AppCat,@SecurityType,@AddUser,@AddDate,@UpdateLevel,@CrCatCode,@IsAdditional, 
                        @IsApproved,@Status, @LoanPeriod)");
        dw.SetSqlCommandParameters("AppNo", appno);
        dw.SetSqlCommandParameters("RecvDate", rdate);
        dw.SetSqlCommandParameters("CrAmt", cramt);
        dw.SetSqlCommandParameters("BoqAmount", boqamt);
        dw.SetSqlCommandParameters("RedemPurchaseAmt", puramt);
        dw.SetSqlCommandParameters("NoOfDisb", disbursement);
        dw.SetSqlCommandParameters("GracePeriod", gracep);
        dw.SetSqlCommandParameters("CrPeriod", maxperiod);
        dw.SetSqlCommandParameters("ClientType", ctype);
        dw.SetSqlCommandParameters("AppCat", loantype);
        dw.SetSqlCommandParameters("SecurityType", sectype);
        dw.SetSqlCommandParameters("AddUser", username);
        dw.SetSqlCommandParameters("AddDate", addate);
        dw.SetSqlCommandParameters("UpdateLevel", updatelevel);
        dw.SetSqlCommandParameters("CrCatCode", catcode);
        dw.SetSqlCommandParameters("IsAdditional", isadd);
        dw.SetSqlCommandParameters("IsApproved", IsApprovd);
        dw.SetSqlCommandParameters("Status", status);
        dw.SetSqlCommandParameters("LoanPeriod", LoanPeriod);
        return dw.Insert();
    }

    public int InsertIntoAppHolder(string appno, string holdertype, string nicno, string holdrelation, int updateLevel)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO appholder (appno,holdertype,nicno,holdrelation,updateLevel) values 
                     (@appno, @holdertype , @nicno,@holdrelation ,@updateLevel)");
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("holdertype", holdertype);
        dw.SetSqlCommandParameters("nicno", nicno);
        dw.SetSqlCommandParameters("holdrelation", holdrelation);
        dw.SetSqlCommandParameters("updateLevel", updateLevel);
        return dw.Insert();
    }

    public int InsertToAppShare(string appno, string sharetype, string sharedet, decimal samout, int updatelevel)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO appshare (appno,sharetype,sharedetail,shareamt,UpdateLevel) values 
                     (@appno, @sharetype, @sharedet, @samout, @updatelevel)");
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("sharetype", sharetype);
        dw.SetSqlCommandParameters("sharedet", sharedet);
        dw.SetSqlCommandParameters("samout", samout);
        dw.SetSqlCommandParameters("updatelevel", updatelevel);
        return dw.Insert();
        
    }

    public int InsertToAppCategory(string appno, int catpid, decimal intrate, decimal amount, int updateLevel, int crcat)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO AppCategory (AppNo,CatPurposeId,Intrate,Amount,UpdateLevel,CrCat) values
                     (@appno, @catpid, @intrate, @amount, @updateLevel, @crcat)");
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("catpid", catpid);
        dw.SetSqlCommandParameters("intrate", intrate);
        dw.SetSqlCommandParameters("amount", amount);
        dw.SetSqlCommandParameters("updateLevel", updateLevel);
        dw.SetSqlCommandParameters("crcat", crcat);
        return dw.Insert();
       
    }

    public int InsertIntoPowerOfAttoneryTb(string appno, string nicno, int updatelevel)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO PowerOfAttonery (AppNo,NicNo,UpdateLevel) VALUES (@appno,@nicno,@updatelevel)");
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("nicno", nicno);
        dw.SetSqlCommandParameters("updatelevel", updatelevel);
        return dw.Insert();
        
    }

    public int UpdateLastSerial(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update lastserial set serialno= @appno where SerialDesc= 'AppNo'");
        dw.SetSqlCommandParameters("serialno", appno);
        return dw.Update();
       
    }

    public DataTable GetCounty()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select countrycode, countryname from country");
        return dw.GetDataTable(); 
    }

    public int InsertIntoApprovalStatus(string appno, string Status, bool IsToDisburse)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO ApprovalStatus (AppNo,Status,IsToDisburse) VALUES (@AppNo,@Status,@IsToDisburse)");
        dw.SetSqlCommandParameters("AppNo", appno);
        dw.SetSqlCommandParameters("Status", Status);
        dw.SetSqlCommandParameters("IsToDisburse", IsToDisburse);
        return dw.Insert();
       
    }

    public int InsertIntoAppRedemption(string appno, string bankname, string amount, string accno, string gdate, int updatelevel)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO AppRedemption (AppNo,BankName,GrantedAmt,AccountNo,GrantedDate,UpdateLevel)
                     VALUES (@appno, @bankname, @amount, @accno, @gdate, @updatelevel)");
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("bankname", bankname);
        dw.SetSqlCommandParameters("amount", amount);
        dw.SetSqlCommandParameters("accno", accno);
        dw.SetSqlCommandParameters("gdate", gdate);
        dw.SetSqlCommandParameters("updatelevel", updatelevel);
        return dw.Insert();
        
    }

    public string GetExistMonth(string NicNo)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"SELECT DATEPART(month,RecvDate)AS MonthNo
                        FROM AppHolder A, CrApp C WHERE A.AppNo=C.AppNo AND A.NicNo=@NicNo");
        dw.SetSqlCommandParameters("NicNo", NicNo);
        return dw.GetSingleData();
    }

    public string GetExistYear(string NicNo)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"SELECT DATEPART(year,RecvDate) AS YearNo 
                        FROM AppHolder A, CrApp C WHERE A.AppNo=C.AppNo AND A.NicNo=@NicNo");
        dw.SetSqlCommandParameters("NicNo", NicNo);
        return dw.GetSingleData();
    }

    public int GetNoOfGurantors(string nicno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select (select isnull(count(a.appno),0) from 
                        CREDITBRDB.TDBBranches.CreditAdmin.AppSecGarant a
                        where a.nicno=@NicNo
                        and a.AppNo in (select AppNo from CREDITBRDB.TDBBranches.CreditAdmin.CrMast c, 
                        CREDITBRDB.TDBBranches.CreditAdmin.HousProp h
                        where c.CrAcNo=h.CrAcNo and h.ActOutBal > 0))
                        +
                        (select isnull(count(a.appno),0) from 
                        AppSecGarant a
                        where a.nicno=@NicNo
                        and a.AppNo in (select AppNo from CrMast c, 
                        HousProp h
                        where c.CrAcNo=h.CrAcNo and h.ActOutBal > 0))");
        dw.SetSqlCommandParameters("NicNo", nicno);
        return int.Parse(dw.GetSingleData());
    }

    public string GetCustomerType(string NicNo)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"SELECT CustomerType FROM Customermain WHERE NicNo=@NicNo");
        dw.SetSqlCommandParameters("NicNo", NicNo);
        return dw.GetSingleData();
    }


    public int InsertIntoGurantorTable(string appno, string nicno, string aduser, DateTime addate, int Updatelevel)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO AppSecGarant (AppNo,NicNo,aduser,addate,Updatelevel)
                        VALUES (@appno,@nicno,@aduser,@addate,@updatelevel)");
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("nicno", nicno);
        dw.SetSqlCommandParameters("aduser", aduser);
        dw.SetSqlCommandParameters("addate", addate);
        dw.SetSqlCommandParameters("updatelevel", Updatelevel);
        return dw.Insert();

    }

    public string[] CheckCanGenerateAppno(string nicno)
    {
        string[] newArray = new string[2];
        dw = new DataWorksClass(constring);
        dt = new DataTable();
        string appno = "";
        string cracno = "";

        dw.SetDataAdapter(@"select ah.Appno from appholder ah,crapp c where ah.nicno=@nicno and ah.appno=c.appno and c.status<>'C'");
        dw.SetDataAdapterParameters("nicno", nicno);
        dt = dw.GetDataTable();

        if (dt.Rows.Count > 0)
        {
            for (int a = 0; a < dt.Rows.Count; a++)
            {
                appno = dt.Rows[a][0].ToString();
                dw = new DataWorksClass(constring);
                dw.SetCommand(@"select cracno from crmast where appno=@appno");
                dw.SetSqlCommandParameters("appno", appno);
                cracno = dw.GetSingleData();

                if ((cracno.Length > 2) && (cracno != null))
                {
                    dw = new DataWorksClass(constring);
                    dw.SetCommand(@"select cracno from crmast where cracno=@cracno and aprovdamt<>grantamt");
                    dw.SetSqlCommandParameters("cracno", cracno);
                    cracno = dw.GetSingleData();

                    if ((cracno.Length > 2) && (cracno != null))
                    {
                        newArray[0] = "True";
                        newArray[1] = cracno + " Loan Account is not Fully Disbursed...";
                        break;
                    }
                    else
                    {
                        newArray[0] = "False";
                        newArray[1] = "contact Admin";
                    }
                }
                else
                {
                    newArray[0] = "True";
                    newArray[1] = appno + " Loan Application is not Approved / Disbursed...";
                    break;
                }
            }
        }
        else
        {
            newArray[0] = "False";
            newArray[1] = "contact Admin";
        }
        return newArray;
    }

    public int InsertFloatingRateDetails(string appno, double ApprovedAmt, DateTime RecievedDate, int FixedPeriod,
                                         int VariablePeriod, string AddUser, DateTime AddDate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO FloatingRateApps (appno,ApprovedAmt,RecievedDate,FixedPeriod,VariablePeriod,
                        AddUser,AddDate) values 
                     (@appno, @ApprovedAmt, @RecievedDate, @FixedPeriod, @VariablePeriod,
                        @AddUser, @AddDate)");
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("ApprovedAmt", ApprovedAmt);
        dw.SetSqlCommandParameters("RecievedDate", RecievedDate);
        dw.SetSqlCommandParameters("FixedPeriod", FixedPeriod);
        dw.SetSqlCommandParameters("VariablePeriod", VariablePeriod);
        dw.SetSqlCommandParameters("AddUser", AddUser);
        dw.SetSqlCommandParameters("AddDate", AddDate);
        return dw.Insert();
    }

    public int InsertBuddhiLoan(string AppNo, string RecoveryType, DateTime ReceivedDate, string BranchCode, string AddUser)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO BuddhiLoanDetails (AppNo,RecoveryType,ReceivedDate,BranchCode,AddUser)
                        VALUES (@AppNo,@RecoveryType,@ReceivedDate,@BranchCode,@AddUser)");
        dw.SetSqlCommandParameters("AppNo", AppNo);
        dw.SetSqlCommandParameters("RecoveryType", RecoveryType);
        dw.SetSqlCommandParameters("ReceivedDate", ReceivedDate);
        dw.SetSqlCommandParameters("BranchCode", BranchCode);
        dw.SetSqlCommandParameters("AddUser", AddUser);
        return dw.Insert();
    }

    public DataTable GetLoanDetailsForTopUp(string nicno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select M.Appno as AppNo, H.CrAcNo,M.GrantAmt,H.ActOutBal,M.GrantDate,S.PlanNo,S.LotNo, R.CrDes 
                            from CrHolder C, CrMast M, HousProp H, Hpsec S, CrCategory R
                            where C.NicNo = @nicno and C.CrAcNo = M.CrAcNo and M.CrAcNo = H.CrAcNo
                            and H.ActOutBal > 0 and H.CrCat not in (9,11,19)
                            and C.AppNo = S.AppNo and H.CrCat = R.CrCatCode
                            ");
        dw.SetDataAdapterParameters("nicno", nicno);
        return dw.GetDataTable();
    }

    public string GetPrimaryHolderNicNo(string AppNo)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select NicNo from AppHolder where AppNo = @AppNo and HolderType = 'P' ");
        dw.SetSqlCommandParameters("AppNo", AppNo);
        return dw.GetSingleData();
    }

    public int insertNSBEcoMeterDetails(string AppNo, string NicNo, string MeterNo, string BranchCode, string AddUser, DateTime AddDate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO NSBEcoMeterDetails (AppNo,NicNo,MeterNo,BranchCode,AddUser,AddDate)
                        VALUES (@AppNo,@NicNo,@MeterNo,@BranchCode,@AddUser,@AddDate)");
        dw.SetSqlCommandParameters("AppNo", AppNo);
        dw.SetSqlCommandParameters("NicNo", NicNo);
        dw.SetSqlCommandParameters("MeterNo", MeterNo);
        dw.SetSqlCommandParameters("BranchCode", BranchCode);
        dw.SetSqlCommandParameters("AddUser", AddUser);
        dw.SetSqlCommandParameters("AddDate", AddDate);
        return dw.Insert();
    }

}
