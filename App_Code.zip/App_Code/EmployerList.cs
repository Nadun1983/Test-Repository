using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// Summary description for EmployerList
/// </summary>
public class EmployerList
{
    private SqlDataAdapter da;
    DataSet ds;
    private SqlConnection mycon;
    
    public EmployerList()
	{
        SqlConnection myconnection = new SqlConnection(ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString);
        this.mycon = myconnection;
	}

    public DataSet GetEmployerList()
    {
        string sql = "SELECT * FROM Employer ORDER BY EmpName";
        da = new SqlDataAdapter(sql, mycon);
        ds = new DataSet();
        da.Fill(ds, sql);
        da.Dispose();
        return ds;
    }

    public DataSet GetEmployerAddress(int empno)
    {
        string sql = " SELECT RecordNo,  RTRIM(Location) + '  ' + RTRIM( Street) + '  ' + RTRIM(City) AS Address"+
                     " FROM Employer e, EmpAddress a WHERE e.EmployerNo=a.EmployerNo AND "+
                     " e.EmployerNo="+empno+"";
        da = new SqlDataAdapter(sql, mycon);
        ds = new DataSet();
        da.Fill(ds, sql);
        da.Dispose();
        return ds;
    }

    public DataSet GetEmpDesignation(int recno)
    {
        string sql = " SELECT id, Designation, Telephone FROM EmpAddress a, EmpDesig d "+
                     " WHERE a.RecordNo=d.RecordNo AND a.RecordNo="+recno+"";
        da = new SqlDataAdapter(sql, mycon);
        ds = new DataSet();
        da.Fill(ds, sql);
        da.Dispose();
        return ds;
    }

    public DataSet GetEmpTelephone(int id)
    {
        string sql = "SELECT id, Telephone FROM EmpDesig WHERE id="+id+"";
        da = new SqlDataAdapter(sql, mycon);
        ds = new DataSet();
        da.Fill(ds, sql);
        da.Dispose();
        return ds;
    }

    public DataSet GetEmployerSelectedList(string empname)
    {
        string sql = "SELECT * FROM Employer WHERE EmpName LIKE '"+empname+"%' ORDER BY EmpName";
        da = new SqlDataAdapter(sql, mycon);
        ds = new DataSet();
        da.Fill(ds, sql);
        da.Dispose();
        return ds;
    }

    public DataSet InsertIntoEmployer(int empno, string empname, int updatelevel)
    {
        string sql = "INSERT INTO Employer VALUES ("+empno+", '"+empname+"',"+updatelevel+")";
        da = new SqlDataAdapter(sql, mycon);
        ds = new DataSet();
        da.Fill(ds, sql);
        da.Dispose();
        return ds;

    }

    public DataSet GetMaxEmpNo()
    {
        string sql = "SELECT MAX(SerialNo)+1 AS EmpNo FROM LastSerial WHERE SerialDesc='EmployerNo'";
        da = new SqlDataAdapter(sql, mycon);
        ds = new DataSet();
        da.Fill(ds, sql);
        da.Dispose();
        return ds;
    }

    public DataSet UpdateLastSerial(int empno)
    {
        string sql = "UPDATE LastSerial SET SerialNo=" + empno + " WHERE SerialDesc='EmployerNo'";
        da = new SqlDataAdapter(sql, mycon);
        ds = new DataSet();
        da.Fill(ds, sql);
        da.Dispose();
        return ds;
    }

    public DataSet InsertIntoEmpAddress(int empno, string location, string street, string city, int updatelevel)
    {
        string sql = " INSERT INTO EmpAddress(EmployerNo,Location,Street,City,UpdateLevel) VALUES"+
                     " (" + empno + "," +
                     " '" + location+ "','" + street + "','" + city + "', "+updatelevel+")";
        da = new SqlDataAdapter(sql, mycon);
        ds = new DataSet();
        da.Fill(ds, sql);
        da.Dispose();
        return ds;
    }

    public DataSet InsertIntoEmpDesig(int recno, string designation, string telephone, int updatelevel)
    {
        string sql = " INSERT INTO EmpDesig (RecordNo,Designation,Telephone,UpdateLevel)VALUES "+
                     " (" + recno + ", " +
                     " '" + designation + "', '" + telephone + "',"+updatelevel+")";

        da = new SqlDataAdapter(sql, mycon);
        ds = new DataSet();
        da.Fill(ds, sql);
        da.Dispose();
        return ds;
    }

    public DataSet GetRecordNo()
    {
        string sql = "SELECT MAX(RecordNo) AS RecordNo FROM EmpAddress";
        da = new SqlDataAdapter(sql, mycon);
        ds = new DataSet();
        da.Fill(ds, sql);
        da.Dispose();
        return ds;
    }

    public DataSet GetEmpAddressDet(int recordno)
    {
        string sql = "SELECT Location,Street,City FROM EmpAddress WHERE RecordNo=" + recordno+ "";
        da = new SqlDataAdapter(sql, mycon);
        ds = new DataSet();
        da.Fill(ds, sql);
        da.Dispose();
        return ds;
    }

    public DataSet LoadEmpDetailsToGrid(int empname)
    {
        string sql = " SELECT E.EmployerNo AS EmployerNo, A.RecordNo AS RecNo, D.Id AS desigId, EmpName, "+
                     " Location, Street, City, Telephone, Designation "+
                     " FROM Employer E, EmpAddress A, EmpDesig D WHERE E.EmployerNo=A.EmployerNo AND"+
                     " A.RecordNo=D.RecordNo AND E.EmployerNo = " + empname + " ORDER BY E.EmpName ";
        da = new SqlDataAdapter(sql, mycon);
        ds = new DataSet();
        da.Fill(ds, sql);
        da.Dispose();
        return ds;
    }

    public DataSet UpdateEmployer(int empno, string emp)
    {
        string sql = "UPDATE Employer SET EmpName='"+emp+"' WHERE EmployerNo="+empno+"";
        da = new SqlDataAdapter(sql, mycon);
        ds = new DataSet();
        da.Fill(ds, sql);
        da.Dispose();
        return ds;
    }

    public DataSet UpdateEmpAddress(int recno, string location, string street, string city)
    {
        string sql = " UPDATE EmpAddress SET Location='"+location+"', Street='"+street+"', City='"+city+"' "+
                     " WHERE RecordNo="+recno+"";
        da = new SqlDataAdapter(sql, mycon);
        ds = new DataSet();
        da.Fill(ds, sql);
        da.Dispose();
        return ds;
    }

    public DataSet UpdateEmpDesignation(int desigid, string desig, string telephone)
    {
        string sql = " UPDATE EmpDesig SET Designation='"+desig+"', Telephone='"+telephone+"' WHERE "+
                     " Id="+desigid+"";
        da = new SqlDataAdapter(sql, mycon);
        ds = new DataSet();
        da.Fill(ds, sql);
        da.Dispose();
        return ds;
    }
}
