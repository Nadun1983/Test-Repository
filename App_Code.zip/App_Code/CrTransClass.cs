using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;


/// <summary>
/// Summary description for CrTransClass
/// </summary>
public class CrTransClass
{
    private string constring = ConfigurationManager.ConnectionStrings["housdbString"].ToString();
    private string oldconstring = ConfigurationManager.ConnectionStrings["crmastString"].ToString();
    DataWorksClass dw;
    LastSerialClass ls;
    FunctionClass fc;
	public CrTransClass()
	{
		//
		// TODO: Add constructor logic here
		//
    }

    # region RecvTrans

//    public int InsertRecvTrans(string CrAcNo, int TrLineNo, int TrCode, double TransAmt, string TranStatus, string RecOrder, DateTime datedue, double intrate, string GlRefAcc)
//    {
//        dw = new DataWorksClass(constring);
//        dw.SetCommand(@"INSERT INTO RecvTrans (CrAcNo,TrLineNo,TrCode,TransAmt, TranStatus, RecOrder, datedue, intrate, GlRefAcc) 
//                        VALUES (@CrAcNo,@TrLineNo,@TrCode,@TransAmt, @TranStatus, @RecOrder,@datedue, @intrate, @GlRefAcc)");
//        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
//        dw.SetSqlCommandParameters("TrLineNo", TrLineNo);
//        dw.SetSqlCommandParameters("TrCode", TrCode);
//        dw.SetSqlCommandParameters("TransAmt", TransAmt);
//        dw.SetSqlCommandParameters("TranStatus", TranStatus);
//        dw.SetSqlCommandParameters("RecOrder", RecOrder);
//        dw.SetSqlCommandParameters("datedue", datedue);
//        dw.SetSqlCommandParameters("intrate", intrate);
//        dw.SetSqlCommandParameters("GlRefAcc", GlRefAcc);
//        return dw.ProperInsert();

//    }


    private int InactiveRecvTrans(string refno, string PaymentType)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update RecvTrans set TranStatus = @TranStatus where RefNo = @refno and
                       PaymentType=@PaymentType ");
        dw.SetSqlCommandParameters("RefNo", refno);
        dw.SetSqlCommandParameters("TranStatus", "C");
        dw.SetSqlCommandParameters("PaymentType", PaymentType);
        return dw.Update();
    }

    #endregion

    #region HousProp Works

    //public int UpdateDueDate(string cracno, DateTime datedue)
    //{
    //    dw = new DataWorksClass(constring);
    //    dw.SetCommand(@"update HousProp set datedue = @datedue where cracno = @cracno");
    //    dw.SetSqlCommandParameters("cracno", cracno);
    //    dw.SetSqlCommandParameters("datedue", datedue);
    //    return dw.Update();
    //}

    public int UpdateDueDateandOutBal(string cracno, DateTime datedue, double outbal)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update HousProp set datedue = @datedue, outbal=@outbal where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("datedue", datedue);
        dw.SetSqlCommandParameters("outbal", outbal);
        return dw.Update();
    }

    public int UpdateDueDateandOutBal(string cracno, DateTime datedue, double outbal, double excessamount)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update HousProp set datedue = @datedue, outbal=@outbal, excessamount=@excessamount
                        where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("datedue", datedue);
        dw.SetSqlCommandParameters("outbal", outbal);
        dw.SetSqlCommandParameters("excessamount", excessamount);
        return dw.Update();
    }

    public int UpdateOutBal(string cracno, double outbal)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update HousProp set outbal = @outbal where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("outbal", outbal);
        return dw.Update();
    }

    public int UpdateRecTransDueOutBal(string cracno, double outbal)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update RecTransDue set ActualOutBal = @outbal where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("outbal", outbal);
        return dw.Update();
    }

   
    #endregion


    // RecTransDue Works Section
    #region RecTransDue

    public double GetDuePenal(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand("select duepenal from RecTransDue where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno",cracno);
        return Math.Round(double.Parse(dw.GetSingleData()),2);
    }

    public double GetDueInterest(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand("select dueinterest from RecTransDue where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return Math.Round(double.Parse(dw.GetSingleData()), 2);
    }


    public double GetDueCapital(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand("select duecapital from RecTransDue where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return Math.Round(double.Parse(dw.GetSingleData()), 2);
    }


    public int UpdateDuePenal(string cracno,  double duepenal)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update RecTransDue set duepenal = @duepenal where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("duepenal", duepenal);
        return dw.Update();

    }



    public int UpdateDueInterest(string cracno, double dueinterest)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update RecTransDue set dueinterest = @dueinterest where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("dueinterest", dueinterest);
        return dw.Update();

    }

  

    public int UpdateDueCapital(string cracno, double duecapital)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update RecTransDue set duecapital = @duecapital where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("duecapital", duecapital);
        return dw.Update();

    }

    public int UpdateDueOtherCharges(string cracno, double dueinterest)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update RecTransDue set dueinterest = @dueinterest where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("dueinterest", dueinterest);
        return dw.Update();

    }

    #endregion

    // Insert Record To CrTrans Jurnal

    public int InsertCrTransJrnl(string TransNo, DateTime TransDate, string TranStatus,string CrAcNo,int TrCode,
        string AcSign,string Action,string RefAcNo,int BatchNo, DateTime BatchDate,string TrGenSec, double TransAmt,
        string TransDetail,string TransUser,string IsUpdate,string IsBchConfrm,string IsGrTrGen,string IsGlUpd,
        string IsProcess,string IsDayEnd,int TrStationId,string Time,string NormalRecov)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO CrTransJrnl (TransNo,TransDate,TranStatus,CrAcNo,TrCode,AcSign,Action,RefAcNo
           ,BatchNo,BatchDate,TrGenSec,TransAmt,TransDetail,TransUser,IsUpdate,IsBchConfrm,IsGrTrGen,IsGlUpd
           ,IsProcess,IsDayEnd,TrStationId,Time,NormalRecov) VALUES (@TransNo,@TransDate,@TranStatus,@CrAcNo
           ,@TrCode,@AcSign,@Action,@RefAcNo,@BatchNo,@BatchDate,@TrGenSec,@TransAmt,@TransDetail,@TransUser
           ,@IsUpdate,@IsBchConfrm,@IsGrTrGen,@IsGlUpd,@IsProcess,@IsDayEnd,@TrStationId,@Time,@NormalRecov)");
        dw.SetSqlCommandParameters("TransNo", TransNo);
        dw.SetSqlCommandParameters("TransDate", TransDate);
        dw.SetSqlCommandParameters("TranStatus", TranStatus);
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        dw.SetSqlCommandParameters("TrCode", TrCode);
        dw.SetSqlCommandParameters("AcSign", AcSign);
        dw.SetSqlCommandParameters("Action", Action);
        dw.SetSqlCommandParameters("RefAcNo", RefAcNo);
        dw.SetSqlCommandParameters("BatchNo", BatchNo);
        dw.SetSqlCommandParameters("BatchDate", BatchDate);
        dw.SetSqlCommandParameters("TrGenSec", TrGenSec);
        dw.SetSqlCommandParameters("TransAmt", TransAmt);
        dw.SetSqlCommandParameters("TransDetail", TransDetail);
        dw.SetSqlCommandParameters("TransUser", TransUser);
        dw.SetSqlCommandParameters("IsUpdate", IsUpdate);
        dw.SetSqlCommandParameters("IsBchConfrm", IsBchConfrm);
        dw.SetSqlCommandParameters("IsGrTrGen", IsGrTrGen);
        dw.SetSqlCommandParameters("IsGlUpd", IsGlUpd);
        dw.SetSqlCommandParameters("IsProcess", IsProcess);
        dw.SetSqlCommandParameters("IsDayEnd", IsDayEnd);
        dw.SetSqlCommandParameters("TrStationId", TrStationId);
        dw.SetSqlCommandParameters("Time", Time);
        dw.SetSqlCommandParameters("NormalRecov", NormalRecov); 
        return dw.Insert();

    }


    public int InsertCrTransJrnl(string TransNo, DateTime TrDate, string TrStatus, string CrAcNo, int TrCode,
       string AcSign, string Action, string RefAcNo, double TrAmt,string TransDetail, string TransUser, string Time)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand();
        string insert = @"INSERT INTO CrTransJrnl (TransNo,TrDate,TrStatus,CrAcNo,TrCode,AcSign,Action,RefAcNo,
           TrAmt,TransDetail,TransUser,Time) VALUES (@TransNo,@TrDate,@TrStatus,@CrAcNo,@TrCode,@AcSign,@Action,@RefAcNo,
           @TrAmt,@TransDetail,@TransUser,@Time)";
        
        dw.SetSqlCommandParameters("TransNo", TransNo);
        dw.SetSqlCommandParameters("TrDate", TrDate);
        dw.SetSqlCommandParameters("TrStatus", TrStatus);
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        dw.SetSqlCommandParameters("TrCode", TrCode);
        dw.SetSqlCommandParameters("AcSign", AcSign);
        dw.SetSqlCommandParameters("Action", Action);
        dw.SetSqlCommandParameters("RefAcNo", RefAcNo);
        dw.SetSqlCommandParameters("TrAmt", TrAmt);
        dw.SetSqlCommandParameters("TransDetail", TransDetail);
        dw.SetSqlCommandParameters("TransUser", TransUser);
        dw.SetSqlCommandParameters("Time", Time);
        return dw.Trans(insert);
    }


    public string GetLoanType(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"SELECT AppCat from CrApp where AppNo = @AppNo");
        dw.SetSqlCommandParameters("AppNo", appno);
        return dw.GetSingleData();
    }

    





    #region TransCat

    //Not Implemented
    // To Easness of refering forom the TrDesc other than referring tfrom TrCode
    public DataTable GetTrCodeAndGLRef(string TrType)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter("select TrCode, GlRefAcc from TransCat where TrType=@TrType");
        dw.SetDataAdapterParameters("TrType", TrType);
        return dw.GetDataTable();
    }

    public string GetGLRef(int trcode)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand("select GlRefAcc from TransCat where trcode=@trcode");
        dw.SetSqlCommandParameters("trcode", trcode);
        return dw.GetSingleData();
    }

    public string GetGLRef(string trtype)
    {
        DataWorksClass dw1 = new DataWorksClass(constring);
        dw1.SetCommand("select glcode from GlCode where trtype=@trtype");
        dw1.SetSqlCommandParameters("trtype", trtype);
        return dw1.GetSingleData();
    }


    public string GetGlRefAcc(int TrCode)
    {
        DataWorksClass dw1 = new DataWorksClass(constring);
        dw1.SetCommand("select GlRefAcc from TransCat where TrCode=@TrCode");
        dw1.SetSqlCommandParameters("TrCode", TrCode);
        return dw1.GetSingleData();
    }

    public int GetTrCode(string TransRef)
    {
        DataWorksClass dw1 = new DataWorksClass(constring);
        dw1.SetCommand("select trcode from TransCat where trtype=@trtype");
        dw1.SetSqlCommandParameters("trtype", TransRef);
        return int.Parse(dw1.GetSingleData());
    }

    public string GetTrDesc(int trcode)
    {
        DataWorksClass dw1 = new DataWorksClass(constring);
        dw1.SetCommand("select trdesc from TransCat where trcode=@trcode");
        dw1.SetSqlCommandParameters("trcode", trcode);
        return dw1.GetSingleData();
    }

    public DataTable GetTrDetails()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter("select TrCode, TrDesc from TransCat");
        return dw.GetDataTable();
    }

    public DataTable GetTrDetails(string trcat)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter("select TrCode, TrDesc from TransCat where trcat=@trcat");
        dw.SetSqlCommandParameters("trcat", trcat);
        return dw.GetDataTable();
    }


//    public DataTable GetPossiblePayment(int catpurposeid, string loantype)
//    {
//        dw = new DataWorksClass(constring);
//        dw.SetDataAdapter(@"select ct.crdesc, TransRef, .UnitCharge, pt.ValueType, pt.type  
//                            from PaymentType pt, PossiblePayments pp
//                            where crcatcode = 1 and pt.type= 'n' and  
//                            pt.trcode = pp.trcode order by pt.Description");
//        dw.SetSqlCommandParameters("trcat", catpurposeid);
//        return dw.GetDataTable();
//    }


//    public DataTable GetPossiblePayment(int crcatcode, string transref)
//    {
//        dw = new DataWorksClass(constring);
//        dw.SetDataAdapter(@"select ct.crdesc, TransRef, .UnitCharge, pt.ValueType, pt.type  
//                            from TransCat ct, PossiblePayments pp
//                            where crcatcode = @crcatcode  and pt.taskid = pp.taskid order by pt.Description");
//        dw.SetSqlCommandParameters("catpurposeid", catpurposeid);
//        dw.SetDataAdapterParameters("trasnref", transref);
//        return dw.GetDataTable();
//    }
    #endregion


    #region PaymentMade

   

//    private int InactivePaymentMade(string refno, string PaymentType)
//    {
//        dw = new DataWorksClass(constring);
//        dw.SetCommand(@"update PaymentMade set TranStatus = @TranStatus where refno = @refno and 
//                        PaymentType=@PaymentType");
//        dw.SetSqlCommandParameters("refno", refno);
//        dw.SetSqlCommandParameters("TranStatus", "C");
//        dw.SetSqlCommandParameters("PaymentType", PaymentType);
//        return dw.Update();
//    }


    
    #endregion

   
    #region DisbTrans
   

//    // Insert DisbTrans
//    public int InsertDisbTrans(string CrAcNo, int TrLineNo, int TrCode, double TransAmt, string TranStatus, DateTime TrDate, string RefGlAcNo)
//    {
//        dw = new DataWorksClass(constring);
//        dw.SetCommand(@"INSERT INTO DisbTrans (CrAcNo,TrLineNo,TrDate,TrCode,TrAmt,RefGlAcNo,IsGlUpd,TranStatus) 
//                        VALUES (@CrAcNo,@TrLineNo,@TrDate,@TrCode,@TrAmt,@RefGlAcNo,@IsGlUpd,@TranStatus)");
//        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
//        dw.SetSqlCommandParameters("TrLineNo", TrLineNo);
//        dw.SetSqlCommandParameters("TrCode", TrCode);
//        dw.SetSqlCommandParameters("TransAmt", TransAmt);
//        dw.SetSqlCommandParameters("TranStatus", TranStatus);
//        dw.SetSqlCommandParameters("TrDate", TrDate);
//        dw.SetSqlCommandParameters("RefGlAcNo", RefGlAcNo);
//        dw.SetSqlCommandParameters("TranStatus", "A");
//        return dw.ProperInsert();

//    }

    #endregion


    #region Trans
    public DataTable GetTransNo(string cracno, string trstatus)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select distinct t.transno from trans t, crtransjrnl ct where t.cracno = @cracno 
                            and t.TrStatus = @TrStatusT and ct.TrStatus = 'A' and ct.transno = t.transno");
        dw.SetDataAdapterParameters("cracno", cracno);
        dw.SetDataAdapterParameters("@TrStatusT", trstatus);
        return dw.GetDataTable();
    }

    public int InactiveTransaction(string transno, string TransRef)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update Trans set TrStatus = @TrStatus where transno = @transno and TransRef=@TransRef");
        dw.SetSqlCommandParameters("transno", transno);
        dw.SetSqlCommandParameters("TrStatus", "R");
        dw.SetSqlCommandParameters("TransRef", TransRef);
        return dw.Update();
    }

    public int InactiveGLTransaction(string transno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update Trans set TrStatus = @TrStatus where transno = @transno");
        dw.SetSqlCommandParameters("transno", transno);
        dw.SetSqlCommandParameters("TrStatus", "R");
        return dw.Update();
    }
    public int InactiveTransAssign(string refno, string TransRef)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update TransAssign set TrStatus = @TrStatus where refno = @refno and TransRef=@TransRef
                        and TrStatus=@OriTrStatus");
        dw.SetSqlCommandParameters("refno", refno);
        dw.SetSqlCommandParameters("TrStatus", "C");
        dw.SetSqlCommandParameters("TransRef", TransRef);
        dw.SetSqlCommandParameters("OriTrStatus", "N");
        return dw.Update();
    }

    public int ActiveTransAssign(string transno, string TransRef)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update TransAssign set TrStatus = @TrStatus where TransNo = @TransNo and TransRef=@TransRef");
        dw.SetSqlCommandParameters("TransNo", transno);
        dw.SetSqlCommandParameters("TrStatus", "N");
        dw.SetSqlCommandParameters("TransRef", TransRef);
        return dw.Update();
    }

    public int UpdateTrans(string cracno, int Trcode, bool ispaid, string TrUser)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update Trans set TrUser = @TrUser,ispaid = @ispaid where 
                       cracno = @cracno and Trcode = @Trcode and ispaid = @OriginalIspaid");

        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("ispaid", ispaid);
        dw.SetSqlCommandParameters("Trcode", Trcode);
        dw.SetSqlCommandParameters("userid", TrUser);
        dw.SetSqlCommandParameters("OriginalIspaid", false);
        return dw.Insert();
    }



    //Disb Trans 
    public int InsertTrans(string CrAcNo, int TrCode, double TrAmt, string TrLineNo, string AccSign, string TrStatus, string TransRef, string AddUser, DateTime AddDate, bool Ispaid, string RefGlAccNo, int DisbNo)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into Trans (CrAcNo,TrCode,TrAmt,TrLineNo,AccSign,TrStatus,AddUser,AddDate,TransRef, DisbNo, Ispaid,RefGlAccNo)
                       values (@CrAcNo,@TrCode,@TrAmt,@TrLineNo,@AccSign,@TrStatus,@AddUser,@AddDate,@TransRef, @DisbNo, @Ispaid,@RefGlAccNo) ");
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        dw.SetSqlCommandParameters("TrCode", TrCode);
        dw.SetSqlCommandParameters("TrAmt", TrAmt);
        dw.SetSqlCommandParameters("TrLineNo", TrLineNo);
        dw.SetSqlCommandParameters("AccSign", AccSign);
        dw.SetSqlCommandParameters("TrStatus", TrStatus);
        dw.SetSqlCommandParameters("AddUser", AddUser);
        dw.SetSqlCommandParameters("AddDate", AddDate);
        dw.SetSqlCommandParameters("TransRef", TransRef);
        dw.SetSqlCommandParameters("DisbNo", DisbNo);
        dw.SetSqlCommandParameters("Ispaid", Ispaid);
        dw.SetSqlCommandParameters("RefGlAccNo", RefGlAccNo);
        return dw.Insert();
    }

    // Recoveries
    public int InsertTrans(string CrAcNo, int TrCode, double TrAmt, int TrLineNo, string AccSign, string TrStatus, string TransRef, string AddUser, DateTime AddDate, bool Ispaid, string RefGlAccNo, DateTime DateDue, int RecOrder)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into Trans (CrAcNo,TrCode,TrAmt,TrLineNo,AccSign,TrStatus,AddUser,AddDate,TransRef, DateDue, RecOrder, Ispaid,RefGlAccNo)
                       values (@CrAcNo,@TrCode,@TrAmt,@TrLineNo,@AccSign,@TrStatus,@AddUser,@AddDate,@TransRef, @DateDue, @RecOrder, @Ispaid,@RefGlAccNo)");
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        dw.SetSqlCommandParameters("TrCode", TrCode);
        dw.SetSqlCommandParameters("TrAmt", TrAmt);
        dw.SetSqlCommandParameters("TrLineNo", TrLineNo);
        dw.SetSqlCommandParameters("AccSign", AccSign);
        dw.SetSqlCommandParameters("TrStatus", TrStatus);
        dw.SetSqlCommandParameters("AddUser", AddUser);
        dw.SetSqlCommandParameters("AddDate", AddDate);
        dw.SetSqlCommandParameters("TransRef", TransRef);
        dw.SetSqlCommandParameters("DateDue", DateDue);
        dw.SetSqlCommandParameters("RecOrder", RecOrder);
        dw.SetSqlCommandParameters("Ispaid", Ispaid);
        dw.SetSqlCommandParameters("RefGlAccNo", RefGlAccNo);
        return dw.Insert();
    }



       #endregion

    #region CrMast

    public string GetAppNo(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select appno from crmast where cracno=@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return dw.GetSingleData();
    }

    public string GetCrAcNo(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select cracno from crmast where cracno=@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return dw.GetSingleData();
    }


    public int UpdateCrMastGrantAmt(decimal grantamt, string cracno)
    {
        //dt = new DataTable();
        dw = new DataWorksClass(constring);
        dw.SetCommand(@" UPDATE CrMast SET GrantAmt=@grantamt WHERE CrAcNo=@cracno");
        dw.SetSqlCommandParameters("grantamt", grantamt);
        dw.SetSqlCommandParameters("cracno", cracno);
        return dw.Update();
    }

    #endregion


    public string PaymentTransaction(DataTable dt,string TransRef, string user, string paymentmode, string paymentdesc)
    {
        string status = "";
        switch (TransRef)
        {
            case "APPN":
                status = PaymentApp(dt, user, paymentmode,paymentdesc, TransRef);
                break;

            case "APPE":
                status = PaymentApp(dt, user, paymentmode, paymentdesc, TransRef);
                break;

            case "DISE":
                status = PaymentApp(dt, user, paymentmode, paymentdesc, TransRef);
                break;

            case "DISN":
                status = PaymentApp(dt, user, paymentmode, paymentdesc, TransRef);
                break;

            case "RECV":
                status = PaymentApp(dt, user, paymentmode, paymentdesc, TransRef);
                break;

            case "RECN":
                status = PaymentApp(dt, user, paymentmode, paymentdesc, TransRef);
                break;

        }

        return status;
    }

    private string PaymentApp(DataTable dt, string user, string paymentmode, string paymentdesc, string TransRef)
    {
        string status = "";
        dw = new DataWorksClass(constring);
        fc = new FunctionClass();
        ls = new LastSerialClass();

        double totamt = 0;
        string appno, glrefno, trdesc;
        int trcode;
        double tramt;
        string refno;

        
        DataTable disbT;
        disbT = new DataTable();
        disbT = GetTrCodeAndGLRef(TransRef);
        trcode = int.Parse(disbT.Rows[0]["TrCode"].ToString());
        glrefno = disbT.Rows[0]["GLRefAcc"].ToString();
        appno = dt.Rows[0]["CRACNO"].ToString();
        trdesc = GetTrDesc(trcode);
        
        // Get the total Amount
        foreach (DataRow dr in dt.Rows)
        {
            totamt += double.Parse(dr["AssignAmt"].ToString());
        }

        // get trans no - (1)
        string transno = ls.GetMaxNumber("TransNo", true).ToString();
        if (transno != "0")
        {

            //Insert CrTransJrnl - (2)
            int transrowadded = InsertCrTransJrnl(transno, fc.GetSystemDate("A"), "F" /*Need To Change*/, appno, trcode, "CR", paymentmode, glrefno, totamt, trdesc, user, DateTime.Now.TimeOfDay.ToString());
            if (transrowadded != 0)
            {
                int i = 0;
                foreach (DataRow dr in dt.Rows)
                {
                    appno = dr["cracno"].ToString();
                    trcode = int.Parse(dr["trcode"].ToString());
                    trdesc = dr["trdesc"].ToString();
                    tramt = double.Parse(dr["AssignAmt"].ToString());
                    refno = dr["refno"].ToString();
                    //Recover Trnas Method  
                    int rowadded = Module1(refno, transno, appno, trcode, trdesc, tramt, paymentmode, user, i, TransRef);
                    if (rowadded != 0)
                    {
                        i++;
                    }
                    else
                    {
                        status = "First Transaction is rollbacked - contact system administrator" + dw.ErrMsg; 
                        ls.UpdateLastSerialStatus("TransNo", true);
                        IncativeCrTransJrnl(transno, "R");
                        InactiveTransaction(transno, TransRef);
                        ActiveTransAssign(transno, TransRef);
                        return status;
                    }
                }

                if (i == dt.Rows.Count)
                {
                    if (Module2(transno, totamt, appno, TransRef, paymentmode, paymentdesc, user, i++) != 0)
                    {
                        status = "Transaction is Completed transaction no is " + transno;
                        ls.UpdateLastserial("TransNo", long.Parse(transno) + 1);

                    }
                    else
                    {
                        status = "Second Transaction is rollbacked - contact system administrator" + dw.ErrMsg; 
                        ls.UpdateLastSerialStatus("TransNo", true);
                        IncativeCrTransJrnl(transno, "R");
                        InactiveGLTransaction(transno);
                        InactiveTransaction(transno, TransRef);
                        ActiveTransAssign(transno, TransRef);

                    }
                }
                else
                {
                    status = "Error in Inserting Trans & Gltrans" + dw.ErrMsg;
                    ls.UpdateLastSerialStatus("TransNo", true);
                    IncativeCrTransJrnl(transno, "R");

                }
            }
            else
            {
                status = "Error in Updateing CrTrans " + dw.ErrMsg;
                ls.UpdateLastSerialStatus("TransNo", true);
                IncativeCrTransJrnl(transno, "R");
            }

        }
        else
        {
            status = "Transaction is already initiate wait for 15 seconds";
        }
        return status;
    }

    private int IncativeCrTransJrnl(string transno, string trstatus)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand("update crtransjrnl set trstatus = @trstatus where transno = @transno");
        dw.SetSqlCommandParameters("trstatus", trstatus);
        dw.SetSqlCommandParameters("transno", transno);
        return dw.Insert();
    }

    private int Module1(string refno, string transno, string appno, int trcode, string trdesc, double tramt, string paymentmode, string user, int lineno, string transref)
    {
        string glrefno = "0";
        fc = new FunctionClass();
        ls = new LastSerialClass();

        dw = new DataWorksClass(constring);
        dw.SetCommand();
        string[] commandarray = new string[4];

        commandarray[0] = @"insert into Trans (TrCode,CrAcNo,TrAmt,TrLineNo,AccSign,TrStatus,TrUser,TrDate,TransRef,RefGlAccNo,transno)
                       values (@TrCodeT,@CrAcNoT,@TrAmtT,@TrLineNoT,@AccSignT,@TrStatusT,@TrUserT,@TrDateT,@TransRefT,@RefGlAccNoT, @transnoT)";
       commandarray[1] = @"INSERT INTO Gltrans(GlCode,GlProcDate,TransNo,TrLineNo,TrDate,TrCode,AcSign,TrAmt)
                        values(@GlCodeG,@GlProcDateG,@TransNoG,@TrLineNoG,@TrDateG,@TrCodeG,@AcSignG,@TrAmtG)";
       commandarray[2] = @"UPDATE GlCode SET CurBal = @CurBalGL WHERE GlCode = @GlCodeG";
       commandarray[3] = @"UPDATE TransAssign set tramt = @tramtTA, TrStatus = @TrStatusTA, TransNo=@TransNoTA WHERE RefNo = @RefNo";

        

        DateTime trdate = new DateTime();
        trdate = fc.GetSystemDate("A");

        // Trans Paramenters
        glrefno = GetGLRef(trcode);
        dw.SetSqlCommandParameters("TrCodeT", trcode);
        dw.SetSqlCommandParameters("CrAcNoT", appno);
        dw.SetSqlCommandParameters("TrAmtT", tramt);
        dw.SetSqlCommandParameters("TrLineNoT", lineno);
        dw.SetSqlCommandParameters("AccSignT", "CR");
        dw.SetSqlCommandParameters("TrStatusT", "F"/*need to change*/);
        dw.SetSqlCommandParameters("TrUserT", user);
        dw.SetSqlCommandParameters("TrDateT", trdate);
        dw.SetSqlCommandParameters("TransRefT", transref);
        dw.SetSqlCommandParameters("RefGlAccNoT", glrefno);
        dw.SetSqlCommandParameters("transnoT", transno);


        // Gl Parameteres
        dw.SetSqlCommandParameters("GlCodeG", glrefno);
        dw.SetSqlCommandParameters("GlProcDateG", trdate);
        dw.SetSqlCommandParameters("transnoG", transno);
        dw.SetSqlCommandParameters("TrLineNoG", lineno);
        dw.SetSqlCommandParameters("TrDateG", trdate);
        dw.SetSqlCommandParameters("TrCodeG", trcode);
        dw.SetSqlCommandParameters("AcSignG", "DR");
        dw.SetSqlCommandParameters("TrAmtG", tramt);

        // TransAssign
        dw.SetSqlCommandParameters("refno", refno);
        dw.SetSqlCommandParameters("tramtTA", tramt);
        dw.SetSqlCommandParameters("TrStatusTA", "F");
        dw.SetSqlCommandParameters("TransNoTA", transno);
        // GL Code Parameteres

        double currentbalance = GetCurrentBalance(glrefno);
        currentbalance += tramt;
        
        dw.SetSqlCommandParameters("GlCodeGL", glrefno);
        dw.SetSqlCommandParameters("CurBalGL",currentbalance);
        // insert trans (3) Insert GlTrans (4)
        return dw.Trans(commandarray);


    }

    private double GetCurrentBalance(string GlCode)
    {
        DataWorksClass dw1 = new DataWorksClass(constring);
        dw1.SetCommand("select CurBal from glcode WHERE GlCode = @GlCode");
        dw1.SetSqlCommandParameters("GlCode", GlCode);
        return  double.Parse(dw1.GetSingleData());
    }



    private int Module2(string transno, double tramt, string cracno, string TransRef, string paymentmode, string paymentdesc, string user, int lineno)
    {
        string glrefno = "0";
        fc = new FunctionClass();
        ls = new LastSerialClass();

        dw = new DataWorksClass(constring);
        dw.SetCommand();
        string[] commandarray = new string[3];

        commandarray[0] = @"INSERT INTO CrTransJrnl (TransNo,TrDate,TrStatus,CrAcNo,TrCode,AcSign,Action,RefAcNo,TrAmt,TransDetail,TransUser,Time) 
                            VALUES (@TransNoJ,@TrDateJ,@TrStatusJ,@CrAcNoJ,@TrCodeJ,@AcSignJ,@ActionJ,@RefAcNoJ,@TrAmtJ,@TransDetailJ,@TransUserJ,@TimeJ)";
        commandarray[1] = @"INSERT INTO Gltrans(GlCode,GlProcDate,TransNo,TrLineNo,TrDate,TrCode,AcSign,TrAmt)
                            values(@GlCodeG,@GlProcDateG,@TransNoG,@TrLineNoG,@TrDateG,@TrCodeG,@AcSignG,@TrAmtG)";
        commandarray[2] = @"UPDATE GlCode SET CurBal = @CurBalGL WHERE GlCode = @GlCodeG";



        DateTime trdate = new DateTime();
        trdate = fc.GetSystemDate("A");

        // CrTransJrnl Paramenters
        dw.SetSqlCommandParameters("TransNoJ", transno);
        dw.SetSqlCommandParameters("TrDateJ", trdate);
        dw.SetSqlCommandParameters("TrStatusJ", "F");
        dw.SetSqlCommandParameters("CrAcNoJ", cracno);
        int trcodeJ = GetTrCode(TransRef);
        dw.SetSqlCommandParameters("TrCodeJ", trcodeJ);
        dw.SetSqlCommandParameters("AcSignJ", "DR");
        dw.SetSqlCommandParameters("ActionJ", paymentdesc);
        string RefAcNo = GetGLRef(paymentmode);
        dw.SetSqlCommandParameters("RefAcNoJ", RefAcNo);
        dw.SetSqlCommandParameters("TrAmtJ", tramt);
        dw.SetSqlCommandParameters("TransDetailJ", paymentdesc);
        dw.SetSqlCommandParameters("TransUserJ", user);
        dw.SetSqlCommandParameters("TimeJ", DateTime.Now.TimeOfDay.ToString());

        // Gl Parameteres
        dw.SetSqlCommandParameters("GlCodeG", RefAcNo);
        dw.SetSqlCommandParameters("GlProcDateG", trdate);
        dw.SetSqlCommandParameters("TransNoG", transno);
        dw.SetSqlCommandParameters("TrLineNoG", lineno);
        dw.SetSqlCommandParameters("TrDateG", trdate);
        int trcodeG = GetTrCode(paymentmode);
        dw.SetSqlCommandParameters("TrCodeG", trcodeG);
        dw.SetSqlCommandParameters("AcSignG", "CR");
        dw.SetSqlCommandParameters("TrAmtG", tramt);

        // GL Code Parameteres
        double currentbalance = GetCurrentBalance(RefAcNo);
        currentbalance += tramt;
        glrefno = GetGLRef(paymentmode);
        dw.SetSqlCommandParameters("GlCodeGL", glrefno);
        dw.SetSqlCommandParameters("CurBalGL", currentbalance);

        return dw.Trans(commandarray);
    }

    //private void GetTotal(double[] amount)
    //{
    //    double totamt = 0;
    //    for (int i = 0; i < amount.Length; i++)
    //    {
    //        totamt += amount[i];

    //    }
    //}

    #region GLTrans
    private int InserGLTrans(string GlCode, DateTime GlProcDate, string TransNo, int TrLineNo, DateTime TrDate, int TrCode, string AcSign,
        double TrAmt, string TrDetail)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO Gltrans(GlCode,GlProcDate,TransNo,TrLineNo,TrDate,TrCode,AcSign,TrAmt,TrDetail)
                        values(@GlCode,@GlProcDate,@TransNo,@TrLineNo,@TrDate,@TrCode,@AcSign,@TrAmt,@TrDetail)");
        dw.SetSqlCommandParameters("GlCode", GlCode);
        dw.SetSqlCommandParameters("GlProcDate", GlProcDate);
        dw.SetSqlCommandParameters("TransNo", TransNo);
        dw.SetSqlCommandParameters("TrLineNo", TrLineNo);
        dw.SetSqlCommandParameters("TrDate", TrDate);
        dw.SetSqlCommandParameters("TrCode", TrCode);
        dw.SetSqlCommandParameters("AcSign", AcSign);
        dw.SetSqlCommandParameters("TrAmt", TrAmt);
        dw.SetSqlCommandParameters("TrDetail", TrDetail);
        return dw.Insert();
    }
    #endregion

    #region TransAssign


    public int UpdateTransAmount(int trcode, string appno, string trstatus, double assgnamt)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand("update transassign set assignamt=@assignamt where trcode=@trcode and trstatus=@trstatus and cracno=@cracno");
        dw.SetSqlCommandParameters("assignamt", assgnamt);
        dw.SetSqlCommandParameters("trcode", trcode);
        dw.SetSqlCommandParameters("trstatus", trstatus);
        dw.SetSqlCommandParameters("cracno",appno);
        return dw.Update();
    }

//    public int InsertTransAssign(string CrAcNo, int TrCode, double AssignAmt, string TrStatus, string AddUser, DateTime AddDate, string RefGlCode, string TransRef)
//    {
//        dw = new DataWorksClass(constring);
//        dw.SetCommand(@"INSERT INTO TransAssign (CrAcNo,TrCode,AssignAmt,TrStatus,AddUser,AddDate,RefGlCode,TransRef)
//                       values (@CrAcNo,@TrCode,@AssignAmt,@TrStatus,@AddUser,@AddDate,@RefGlCode,@TransRef) ");
//        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
//        dw.SetSqlCommandParameters("TrCode", TrCode);
//        dw.SetSqlCommandParameters("AssignAmt", AssignAmt);
//        dw.SetSqlCommandParameters("TrStatus", TrStatus);
//        dw.SetSqlCommandParameters("AddUser", AddUser);
//        dw.SetSqlCommandParameters("AddDate", AddDate);
//        dw.SetSqlCommandParameters("RefGlCode", RefGlCode);
//        dw.SetSqlCommandParameters("TransRef", TransRef);

//        return dw.Insert();
//    }


    // Application Payment
     public int InsertTransAssign(string CrAcNo, string taskid, double AssignAmt,string description, string TrStatus, string AddUser, DateTime AddDate, string TransRef, string trtype)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO TransAssign (CrAcNo,taskid,AssignAmt,description,TrStatus,AddUser,AddDate,TransRef,trtype)
                       values (@CrAcNo,@taskid,@AssignAmt,@description,@TrStatus,@AddUser,@AddDate,@TransRef,@trtype) ");
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        dw.SetSqlCommandParameters("taskid", taskid);
        dw.SetSqlCommandParameters("AssignAmt", AssignAmt);
        dw.SetSqlCommandParameters("description", description);
        dw.SetSqlCommandParameters("TrStatus", TrStatus);
        dw.SetSqlCommandParameters("AddUser", AddUser);
        dw.SetSqlCommandParameters("AddDate", AddDate);
        dw.SetSqlCommandParameters("TransRef", TransRef);
        dw.SetSqlCommandParameters("trtype", trtype);
        return dw.Insert();
    }

    // Application Payment
    public int  InsertTransAssign(string CrAcNo, string taskid, double AssignAmt, double tramt, string TrStatus,
        string AddUser, DateTime AddDate, string TransRef, string trtype, double intrate, int RecOrder,
        long disbrefno, DateTime trdate, string Description)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO TransAssign (CrAcNo,taskid,AssignAmt, tramt,TrStatus,AddUser,AddDate,TransRef,trtype, intrate,RecOrder,disbrefno, trdate, Description)
                       values (@CrAcNo,@taskid,@AssignAmt, @tramt,@TrStatus,@AddUser,@AddDate,@TransRef,@trtype,@intrate,@RecOrder,@disbrefno, @trdate, @Description) ");
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        dw.SetSqlCommandParameters("taskid", taskid);
        dw.SetSqlCommandParameters("AssignAmt", AssignAmt);
        dw.SetSqlCommandParameters("tramt", tramt);
        dw.SetSqlCommandParameters("TrStatus", TrStatus);
        dw.SetSqlCommandParameters("AddUser", AddUser);
        dw.SetSqlCommandParameters("AddDate", AddDate);
        dw.SetSqlCommandParameters("TransRef", TransRef);
        dw.SetSqlCommandParameters("trtype", trtype);
        dw.SetSqlCommandParameters("intrate", intrate);
        dw.SetSqlCommandParameters("RecOrder", RecOrder);
        dw.SetSqlCommandParameters("disbrefno", disbrefno);
        dw.SetSqlCommandParameters("trdate", trdate);
        dw.SetSqlCommandParameters("Description", Description);
        return dw.Insert();
    }

    // Application Payment
    public int InsertTransAssignTemp(string CrAcNo, string taskid, double AssignAmt, double tramt, string TrStatus,
        string AddUser, DateTime AddDate, string TransRef, string trtype, double intrate, int RecOrder,
        long disbrefno, DateTime trdate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO TransAssignTemp (CrAcNo,taskid,AssignAmt, tramt,TrStatus,AddUser,AddDate,TransRef,trtype, intrate,RecOrder,disbrefno, trdate)
                       values (@CrAcNo,@taskid,@AssignAmt, @tramt,@TrStatus,@AddUser,@AddDate,@TransRef,@trtype,@intrate,@RecOrder,@disbrefno, @trdate) ");
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        dw.SetSqlCommandParameters("taskid", taskid);
        dw.SetSqlCommandParameters("AssignAmt", AssignAmt);
        dw.SetSqlCommandParameters("tramt", tramt);
        dw.SetSqlCommandParameters("TrStatus", TrStatus);
        dw.SetSqlCommandParameters("AddUser", AddUser);
        dw.SetSqlCommandParameters("AddDate", AddDate);
        dw.SetSqlCommandParameters("TransRef", TransRef);
        dw.SetSqlCommandParameters("trtype", trtype);
        dw.SetSqlCommandParameters("intrate", intrate);
        dw.SetSqlCommandParameters("RecOrder", RecOrder);
        dw.SetSqlCommandParameters("disbrefno", disbrefno);
        dw.SetSqlCommandParameters("trdate", trdate);
        return dw.Insert();
    }


   
    // Application Payment
    public int InsertTransAssign(string CrAcNo, string taskid, double AssignAmt, double tramt, string TrStatus,
        string AddUser, DateTime AddDate, string TransRef, string trtype, double intrate, int RecOrder,
        long disbrefno, DateTime trdate, DateTime DateDue)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO TransAssign (CrAcNo,taskid,AssignAmt, tramt,TrStatus,AddUser,AddDate,TransRef,trtype, intrate,RecOrder,disbrefno, trdate, DateDue)
                       values (@CrAcNo,@taskid,@AssignAmt, @tramt,@TrStatus,@AddUser,@AddDate,@TransRef,@trtype,@intrate,@RecOrder,@disbrefno, @trdate, @DateDue) ");
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        dw.SetSqlCommandParameters("taskid", taskid);
        dw.SetSqlCommandParameters("AssignAmt", AssignAmt);
        dw.SetSqlCommandParameters("tramt", tramt);
        dw.SetSqlCommandParameters("TrStatus", TrStatus);
        dw.SetSqlCommandParameters("AddUser", AddUser);
        dw.SetSqlCommandParameters("AddDate", AddDate);
        dw.SetSqlCommandParameters("TransRef", TransRef);
        dw.SetSqlCommandParameters("trtype", trtype);
        dw.SetSqlCommandParameters("intrate", intrate);
        dw.SetSqlCommandParameters("RecOrder", RecOrder);
        dw.SetSqlCommandParameters("disbrefno", disbrefno);
        dw.SetSqlCommandParameters("trdate", trdate);
        dw.SetSqlCommandParameters("DateDue", DateDue);
        return dw.Insert();
    }


//    // Application Payment
//    public string InsertTransAssign(string CrAcNo, string taskid, double AssignAmt, double tramt, string TrStatus,
//        string AddUser, DateTime AddDate, string TransRef, string trtype, double intrate, int RecOrder,
//        long disbrefno, DateTime trdate, string description, DateTime DateDue, int crcat, string system)
//    {
//        dw = new DataWorksClass(constring);
//        dw.SetCommand(@"INSERT INTO TransAssign (CrAcNo,taskid,AssignAmt, tramt,TrStatus,AddUser,
//                        AddDate,TransRef,trtype, intrate,RecOrder,disbrefno, trdate, DateDue, 
//                        description, crcat)
//                       values (@CrAcNo,@taskid,@AssignAmt, @tramt,@TrStatus,@AddUser,@AddDate,
//                        @TransRef,@trtype,@intrate,@RecOrder,@disbrefno, @trdate, @DateDue, 
//                        @description, @crcat) SELECT IDENT_CURRENT('TransAssign')  ");
//        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
//        dw.SetSqlCommandParameters("taskid", taskid);
//        dw.SetSqlCommandParameters("AssignAmt", AssignAmt);
//        dw.SetSqlCommandParameters("tramt", tramt);
//        dw.SetSqlCommandParameters("TrStatus", TrStatus);
//        dw.SetSqlCommandParameters("AddUser", AddUser);
//        dw.SetSqlCommandParameters("AddDate", AddDate);
//        dw.SetSqlCommandParameters("TransRef", TransRef);
//        dw.SetSqlCommandParameters("trtype", trtype);
//        dw.SetSqlCommandParameters("intrate", intrate);
//        dw.SetSqlCommandParameters("RecOrder", RecOrder);
//        dw.SetSqlCommandParameters("disbrefno", disbrefno);
//        dw.SetSqlCommandParameters("trdate", trdate);
//        dw.SetSqlCommandParameters("DateDue", DateDue);
//        dw.SetSqlCommandParameters("description", description);
//        dw.SetSqlCommandParameters("crcat", crcat);
//        dw.SetSqlCommandParameters("system", system);
//        return dw.InsertandReturnID();
//    }

    // Application Payment
    public string InsertTransAssign(string CrAcNo, string taskid, double AssignAmt, double tramt, string TrStatus,
        string AddUser, DateTime AddDate, string TransRef, string trtype, double intrate, int RecOrder,
        long disbrefno, DateTime trdate, string description, DateTime DateDue, int crcat, string batchrefno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO TransAssign (CrAcNo,taskid,AssignAmt, tramt,TrStatus,AddUser,
                        AddDate,TransRef,trtype, intrate,RecOrder,disbrefno, trdate, DateDue, 
                        description, crcat, batchrefno)
                       values (@CrAcNo,@taskid,@AssignAmt, @tramt,@TrStatus,@AddUser,@AddDate,
                        @TransRef,@trtype,@intrate,@RecOrder,@disbrefno, @trdate, @DateDue, 
                        @description, @crcat, @batchrefno) SELECT IDENT_CURRENT('TransAssign')  ");
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        dw.SetSqlCommandParameters("taskid", taskid);
        dw.SetSqlCommandParameters("AssignAmt", AssignAmt);
        dw.SetSqlCommandParameters("tramt", tramt);
        dw.SetSqlCommandParameters("TrStatus", TrStatus);
        dw.SetSqlCommandParameters("AddUser", AddUser);
        dw.SetSqlCommandParameters("AddDate", AddDate);
        dw.SetSqlCommandParameters("TransRef", TransRef);
        dw.SetSqlCommandParameters("trtype", trtype);
        dw.SetSqlCommandParameters("intrate", intrate);
        dw.SetSqlCommandParameters("RecOrder", RecOrder);
        dw.SetSqlCommandParameters("disbrefno", disbrefno);
        dw.SetSqlCommandParameters("trdate", trdate);
        dw.SetSqlCommandParameters("DateDue", DateDue);
        dw.SetSqlCommandParameters("description", description);
        dw.SetSqlCommandParameters("crcat", crcat);
        dw.SetSqlCommandParameters("batchrefno", batchrefno);
        return dw.InsertandReturnID();
    }
    // Application Payment
    public int InsertTransAssignTemp(string refno, string CrAcNo, double tramt, long disbrefno, 
        DateTime trdate, double assignamt, string trtype, DateTime datedue, string taskid,
        string trstatus, string adduser, string transref, double intrate, int crcat, string batchrefno)
    {
        if (tramt > 0)
        {
            dw = new DataWorksClass(constring);
            dw.SetCommand(@"update TransAssignTmp set status=@status where refno=@refno and transno is not null");
            dw.SetSqlCommandParameters("refno", refno);
            dw.SetSqlCommandParameters("status", "I");
            dw.Update();
            dw = new DataWorksClass(constring);
            dw.SetCommand(@"INSERT INTO TransAssignTmp (refno, CrAcNo, tramt,disbrefno, trdate, status, trtype, 
                          datedue,taskid,assignamt,trstatus,adduser,transref, intrate, crcat, batchrefno)
                          values (@refno, @CrAcNo, @tramt,@disbrefno, @trdate, @status, @trtype, @datedue,@taskid,
                          @assignamt,@trstatus,@adduser,@transref, @intrate,@crcat, @batchrefno)");
            dw.SetSqlCommandParameters("status", "A");
            dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
            dw.SetSqlCommandParameters("tramt", tramt);
            dw.SetSqlCommandParameters("disbrefno", disbrefno);
            dw.SetSqlCommandParameters("trdate", trdate);
            dw.SetSqlCommandParameters("refno", refno);
            dw.SetSqlCommandParameters("trtype", trtype);
            dw.SetSqlCommandParameters("datedue", datedue);
            dw.SetSqlCommandParameters("assignamt", assignamt);
            dw.SetSqlCommandParameters("taskid", taskid);
            dw.SetSqlCommandParameters("trstatus", trstatus);
            dw.SetSqlCommandParameters("adduser", adduser);
            dw.SetSqlCommandParameters("transref", transref);
            dw.SetSqlCommandParameters("intrate", intrate);
            dw.SetSqlCommandParameters("crcat", crcat);
            dw.SetSqlCommandParameters("batchrefno", batchrefno);
            return dw.Insert();
        }
        else
        {
            return 0;
        }
    }


    // Application Payment
    public int InsertTransAssign(string CrAcNo, string taskid, double AssignAmt, double tramt, string TrStatus,
        string AddUser, DateTime AddDate, string TransRef, string trtype, double intrate, int RecOrder,
        long disbrefno, DateTime trdate, DateTime DateDue, string system)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO TransAssign (CrAcNo,taskid,AssignAmt, tramt,TrStatus,AddUser,AddDate,TransRef,trtype, intrate,RecOrder,disbrefno, trdate, DateDue, system)
                       values (@CrAcNo,@taskid,@AssignAmt, @tramt,@TrStatus,@AddUser,@AddDate,@TransRef,@trtype,@intrate,@RecOrder,@disbrefno, @trdate, @DateDue, @system) ");
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        dw.SetSqlCommandParameters("taskid", taskid);
        dw.SetSqlCommandParameters("AssignAmt", AssignAmt);
        dw.SetSqlCommandParameters("tramt", tramt);
        dw.SetSqlCommandParameters("TrStatus", TrStatus);
        dw.SetSqlCommandParameters("AddUser", AddUser);
        dw.SetSqlCommandParameters("AddDate", AddDate);
        dw.SetSqlCommandParameters("TransRef", TransRef);
        dw.SetSqlCommandParameters("trtype", trtype);
        dw.SetSqlCommandParameters("intrate", intrate);
        dw.SetSqlCommandParameters("RecOrder", RecOrder);
        dw.SetSqlCommandParameters("disbrefno", disbrefno);
        dw.SetSqlCommandParameters("trdate", trdate);
        dw.SetSqlCommandParameters("DateDue", DateDue);
        dw.SetSqlCommandParameters("system", system);
        return dw.Insert();
    }

    // Application Payment Temp - 23/06/2009
    public int InsertTransAssignTemp(string CrAcNo, string taskid, double AssignAmt, double tramt, string TrStatus,
        string AddUser, DateTime AddDate, string TransRef, string trtype, double intrate, int RecOrder,
        long disbrefno, DateTime trdate, DateTime DateDue)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO TransAssignTemp (CrAcNo,taskid,AssignAmt, tramt,TrStatus,AddUser,AddDate,TransRef,trtype, intrate,RecOrder,disbrefno, trdate, DateDue)
                       values (@CrAcNo,@taskid,@AssignAmt, @tramt,@TrStatus,@AddUser,@AddDate,@TransRef,@trtype,@intrate,@RecOrder,@disbrefno, @trdate, @DateDue) ");
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        dw.SetSqlCommandParameters("taskid", taskid);
        dw.SetSqlCommandParameters("AssignAmt", AssignAmt);
        dw.SetSqlCommandParameters("tramt", tramt);
        dw.SetSqlCommandParameters("TrStatus", TrStatus);
        dw.SetSqlCommandParameters("AddUser", AddUser);
        dw.SetSqlCommandParameters("AddDate", AddDate);
        dw.SetSqlCommandParameters("TransRef", TransRef);
        dw.SetSqlCommandParameters("trtype", trtype);
        dw.SetSqlCommandParameters("intrate", intrate);
        dw.SetSqlCommandParameters("RecOrder", RecOrder);
        dw.SetSqlCommandParameters("disbrefno", disbrefno);
        dw.SetSqlCommandParameters("trdate", trdate);
        dw.SetSqlCommandParameters("DateDue", DateDue);
        return dw.Insert();
    }

    // Amila 09/06/2009
    public int InsertTransAssign(string CrAcNo, string taskid, double AssignAmt, string TrStatus, 
        string AddUser, DateTime AddDate, string TransRef, string trtype, long disbrefno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO TransAssign (CrAcNo,taskid,AssignAmt,TrStatus,AddUser,AddDate,TransRef,trtype,disbrefno)
                       values (@CrAcNo,@taskid,@AssignAmt,@TrStatus,@AddUser,@AddDate,@TransRef,@trtype,@disbrefno) ");
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        dw.SetSqlCommandParameters("taskid", taskid);
        dw.SetSqlCommandParameters("AssignAmt", AssignAmt);
        dw.SetSqlCommandParameters("TrStatus", TrStatus);
        dw.SetSqlCommandParameters("AddUser", AddUser);
        dw.SetSqlCommandParameters("AddDate", AddDate);
        dw.SetSqlCommandParameters("TransRef", TransRef);
        dw.SetSqlCommandParameters("trtype", trtype);
        dw.SetSqlCommandParameters("disbrefno", disbrefno);
        return dw.Insert();
    }


    public int InsertTransAssign(string CrAcNo, string taskid, double AssignAmt, string TrStatus, string AddUser, 
        DateTime AddDate, string TransRef, string trtype, double intrate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO TransAssign (CrAcNo,taskid,AssignAmt,TrStatus,AddUser,AddDate,TransRef,trtype,intrate)
                       values (@CrAcNo,@taskid,@AssignAmt,@TrStatus,@AddUser,@AddDate,@TransRef,@trtype,@intrate) ");
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        dw.SetSqlCommandParameters("taskid", taskid);
        dw.SetSqlCommandParameters("AssignAmt", AssignAmt);
        dw.SetSqlCommandParameters("TrStatus", TrStatus);
        dw.SetSqlCommandParameters("AddUser", AddUser);
        dw.SetSqlCommandParameters("AddDate", AddDate);
        dw.SetSqlCommandParameters("TransRef", TransRef);
        dw.SetSqlCommandParameters("trtype", trtype);
        dw.SetSqlCommandParameters("intrate", intrate);
        return dw.Insert();
    }

    public int InsertTransAssign(string CrAcNo, string taskid, double AssignAmt, string TrStatus, string AddUser, 
        DateTime AddDate, string TransRef, string trtype, double intrate, string description)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO TransAssign (CrAcNo,taskid,AssignAmt,TrStatus,AddUser,AddDate,TransRef,trtype,intrate,description)
                       values (@CrAcNo,@taskid,@AssignAmt,@TrStatus,@AddUser,@AddDate,@TransRef,@trtype,@intrate,@description) ");
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        dw.SetSqlCommandParameters("taskid", taskid);
        dw.SetSqlCommandParameters("AssignAmt", AssignAmt);
        dw.SetSqlCommandParameters("TrStatus", TrStatus);
        dw.SetSqlCommandParameters("AddUser", AddUser);
        dw.SetSqlCommandParameters("AddDate", AddDate);
        dw.SetSqlCommandParameters("TransRef", TransRef);
        dw.SetSqlCommandParameters("trtype", trtype);
        dw.SetSqlCommandParameters("intrate", intrate);
        dw.SetSqlCommandParameters("description", description);
        return dw.Insert();
    }

    // Application Payment
    public string InsertTransAssignandReturnID(string CrAcNo, string taskid, double AssignAmt, string TrStatus, string AddUser, DateTime AddDate, string TransRef, string trtype)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO TransAssign (CrAcNo,taskid,AssignAmt,TrStatus,AddUser,AddDate,TransRef,trtype)
                       values (@CrAcNo,@taskid,@AssignAmt,@TrStatus,@AddUser,@AddDate,@TransRef,@trtype) SELECT IDENT_CURRENT('TransAssign') ");
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        dw.SetSqlCommandParameters("taskid", taskid);
        dw.SetSqlCommandParameters("AssignAmt", AssignAmt);
        dw.SetSqlCommandParameters("TrStatus", TrStatus);
        dw.SetSqlCommandParameters("AddUser", AddUser);
        dw.SetSqlCommandParameters("AddDate", AddDate);
        dw.SetSqlCommandParameters("TransRef", TransRef);
        dw.SetSqlCommandParameters("trtype", trtype);
        return dw.InsertandReturnID();
    }


    public int InsertTransAssign(string CrAcNo, string taskid, double AssignAmt, string TrStatus, string AddUser, 
        DateTime AddDate, string TransRef, string trtype, DateTime datedue, double intrate, int RecOrder)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO TransAssign (CrAcNo,taskid,AssignAmt,TrStatus,AddUser,AddDate,TransRef,trtype,datedue,intrate,RecOrder)
                       values (@CrAcNo,@taskid,@AssignAmt,@TrStatus,@AddUser,@AddDate,@TransRef,@trtype,@datedue,@intrate,@RecOrder) ");
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        dw.SetSqlCommandParameters("taskid", taskid);
        dw.SetSqlCommandParameters("AssignAmt", AssignAmt);
        dw.SetSqlCommandParameters("TrStatus", TrStatus);
        dw.SetSqlCommandParameters("AddUser", AddUser);
        dw.SetSqlCommandParameters("AddDate", AddDate);
        dw.SetSqlCommandParameters("TransRef", TransRef);
        dw.SetSqlCommandParameters("trtype", trtype);
        dw.SetSqlCommandParameters("datedue", datedue);
        dw.SetSqlCommandParameters("intrate", intrate);
        dw.SetSqlCommandParameters("RecOrder", RecOrder);
        return dw.Insert();
    }

    public int InsertTransAssign(string CrAcNo, string taskid, double AssignAmt, string TrStatus, string AddUser, 
        DateTime AddDate, string TransRef, string trtype, double intrate, int RecOrder)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO TransAssign (CrAcNo,taskid,AssignAmt,TrStatus,AddUser,AddDate,TransRef,trtype,intrate,RecOrder)
                       values (@CrAcNo,@taskid,@AssignAmt,@TrStatus,@AddUser,@AddDate,@TransRef,@trtype,@intrate,@RecOrder) ");
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        dw.SetSqlCommandParameters("taskid", taskid);
        dw.SetSqlCommandParameters("AssignAmt", AssignAmt);
        dw.SetSqlCommandParameters("TrStatus", TrStatus);
        dw.SetSqlCommandParameters("AddUser", AddUser);
        dw.SetSqlCommandParameters("AddDate", AddDate);
        dw.SetSqlCommandParameters("TransRef", TransRef);
        dw.SetSqlCommandParameters("trtype", trtype);
        dw.SetSqlCommandParameters("intrate", intrate);
        dw.SetSqlCommandParameters("RecOrder", RecOrder);
        return dw.Insert();
    }


    public int InsertTransAssign(string CrAcNo, string taskid, double AssignAmt, double tramt, string TrStatus, string AddUser,
        DateTime AddDate, string TransRef, string trtype, double intrate, int RecOrder, long disbrefno, string system, bool isready)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO TransAssign (CrAcNo,taskid,AssignAmt,tramt,TrStatus,AddUser,AddDate,TransRef,trtype,intrate,RecOrder,disbrefno,system,isready)
                       values (@CrAcNo,@taskid,@AssignAmt,@tramt,@TrStatus,@AddUser,@AddDate,@TransRef,@trtype,@intrate,@RecOrder,@disbrefno,@system,@isready) ");
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        dw.SetSqlCommandParameters("taskid", taskid);
        dw.SetSqlCommandParameters("AssignAmt", AssignAmt);
        dw.SetSqlCommandParameters("tramt", tramt);
        dw.SetSqlCommandParameters("TrStatus", TrStatus);
        dw.SetSqlCommandParameters("AddUser", AddUser);
        dw.SetSqlCommandParameters("AddDate", AddDate);
        dw.SetSqlCommandParameters("TransRef", TransRef);
        dw.SetSqlCommandParameters("trtype", trtype);
        dw.SetSqlCommandParameters("intrate", intrate);
        dw.SetSqlCommandParameters("RecOrder", RecOrder);
        dw.SetSqlCommandParameters("disbrefno", disbrefno);
        dw.SetSqlCommandParameters("system", system);
        dw.SetSqlCommandParameters("isready", isready);
        return dw.Insert();
    }


    public int InsertTransAssign(string CrAcNo, string taskid, double AssignAmt, string TrStatus, string AddUser,
        DateTime AddDate, string TransRef, string trtype, long nplrefno, string Description)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO TransAssign (CrAcNo,taskid,AssignAmt,TrStatus,AddUser,AddDate,TransRef,trtype,disbrefno,Description)
                       values (@CrAcNo,@taskid,@AssignAmt,@TrStatus,@AddUser,@AddDate,@TransRef,@trtype,@disbrefno,@Description) ");
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        dw.SetSqlCommandParameters("taskid", taskid);
        dw.SetSqlCommandParameters("AssignAmt", AssignAmt);
        dw.SetSqlCommandParameters("TrStatus", TrStatus);
        dw.SetSqlCommandParameters("AddUser", AddUser);
        dw.SetSqlCommandParameters("AddDate", AddDate);
        dw.SetSqlCommandParameters("TransRef", TransRef);
        dw.SetSqlCommandParameters("trtype", trtype);
        dw.SetSqlCommandParameters("disbrefno", nplrefno);
        dw.SetSqlCommandParameters("Description", Description);
        return dw.Insert();
    }

    // 23/06/2009
    public int InsertTransAssignTemp(string CrAcNo, string taskid, double AssignAmt, string TrStatus, string AddUser,
        DateTime AddDate, string TransRef, string trtype, long nplrefno, string Description)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO TransAssigntTemp (CrAcNo,taskid,AssignAmt,TrStatus,AddUser,AddDate,TransRef,trtype,disbrefno,Description)
                       values (@CrAcNo,@taskid,@AssignAmt,@TrStatus,@AddUser,@AddDate,@TransRef,@trtype,@disbrefno,@Description) ");
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        dw.SetSqlCommandParameters("taskid", taskid);
        dw.SetSqlCommandParameters("AssignAmt", AssignAmt);
        dw.SetSqlCommandParameters("TrStatus", TrStatus);
        dw.SetSqlCommandParameters("AddUser", AddUser);
        dw.SetSqlCommandParameters("AddDate", AddDate);
        dw.SetSqlCommandParameters("TransRef", TransRef);
        dw.SetSqlCommandParameters("trtype", trtype);
        dw.SetSqlCommandParameters("disbrefno", nplrefno);
        dw.SetSqlCommandParameters("Description", Description);
        return dw.Insert();
    }


  
//    //Recovery

    public int InsertTransAssign(string CrAcNo, string taskid, double AssignAmt, double tramt, string TrStatus, string AddUser, 
        DateTime AddDate, string TransRef, string trtype, DateTime DateDue, double IntRate, int RecOrder,
        long disbrefno, string system, bool isready)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO TransAssign (CrAcNo,taskid,AssignAmt,tramt,TrStatus,AddUser,AddDate,TransRef, trtype,
                        DateDue, IntRate, RecOrder, disbrefno,system, isready)
                       values (@CrAcNo,@taskid,@AssignAmt,@tramt,@TrStatus,@AddUser,@AddDate,@TransRef, @trtype,@DateDue,
                        @IntRate,@RecOrder, @disbrefno,@system,@isready)");
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        dw.SetSqlCommandParameters("taskid", taskid);
        dw.SetSqlCommandParameters("AssignAmt", AssignAmt);
        dw.SetSqlCommandParameters("tramt", tramt);
        dw.SetSqlCommandParameters("TrStatus", TrStatus);
        dw.SetSqlCommandParameters("AddUser", AddUser);
        dw.SetSqlCommandParameters("AddDate", AddDate);
        dw.SetSqlCommandParameters("TransRef", TransRef);
        dw.SetSqlCommandParameters("trtype", trtype);
        dw.SetSqlCommandParameters("DateDue", DateDue);
        dw.SetSqlCommandParameters("IntRate", IntRate);
        dw.SetSqlCommandParameters("RecOrder", RecOrder);
        dw.SetSqlCommandParameters("disbrefno", disbrefno);
        dw.SetSqlCommandParameters("system", system);
        dw.SetSqlCommandParameters("isready", isready);
        return dw.Insert();
    }


//    //Recovery
//    public int InsertTransAssign(string CrAcNo, int TrCode, double AssignAmt, string TrStatus, string AddUser, DateTime AddDate, string RefGlCode, string TransRef, int RecOrder)
//    {
//        dw = new DataWorksClass(constring);
//        dw.SetCommand(@"INSERT INTO TransAssign (CrAcNo,TrCode,AssignAmt,TrStatus,AddUser,AddDate,RefGlCode,TransRef, RecOrder)
//                       values (@CrAcNo,@TrCode,@AssignAmt,@TrStatus,@AddUser,@AddDate,@RefGlCode,@TransRef,@RecOrder)");
//        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
//        dw.SetSqlCommandParameters("TrCode", TrCode);
//        dw.SetSqlCommandParameters("AssignAmt", AssignAmt);
//        dw.SetSqlCommandParameters("TrStatus", TrStatus);
//        dw.SetSqlCommandParameters("AddUser", AddUser);
//        dw.SetSqlCommandParameters("AddDate", AddDate);
//        dw.SetSqlCommandParameters("RefGlCode", RefGlCode);
//        dw.SetSqlCommandParameters("TransRef", TransRef);
//        dw.SetSqlCommandParameters("RecOrder", RecOrder);
//        return dw.Insert();
//    }



//    public DataTable GetAssignedPayments(string crcatcode, string trstatus)
//    {
//        dw = new DataWorksClass(constring);
//        dw.SetDataAdapter(@"select t.cracno, t.refno, t.tramt, t.trdate, tc.TrDesc
//                            from Trans t, transCat tc where 
//                            t.taskid=@taskid and tc.crcatcode= @crcatcode and t.taskid = tc.taskid");
//        dw.SetDataAdapterParameters("TrStatus", trstatus);
//        dw.SetDataAdapterParameters("crcatcode", crcatcode);
//        return dw.GetDataTable();
//    }

    public DataTable GetAssignPayment(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select ta.cracno, ta.refno, ta.trcode, ta.AssignAmt, tc.trdesc from TransAssign ta, TransCat tc
                                where ta.trcode = tc.trcode and cracno = @cracno");
        dw.SetDataAdapterParameters("cracno", appno);
        return dw.GetDataTable();
    }

    //2009-02-23 vihanga
    public string GetLoanCategory(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select crcat from crmast where cracno=@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return dw.GetSingleData();
    }

    //2009-02-23 vihanga
    public string GetRefGLCode(string glcode)
    {
        dw = new DataWorksClass(oldconstring);
        dw.SetCommand(@"select newglcode from glcode where glcode = @glcode");
        dw.SetSqlCommandParameters("glcode", glcode);
        return dw.GetSingleData();
    }



    //2009-02-23 vihanga
    public string GetLoanCategoryFromAppNo(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select crcat from crmast where appno=@appno");
        dw.SetSqlCommandParameters("appno", appno);
        return dw.GetSingleData();
    }


    public int DeleteRow(string refno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"delete from transassign where refno=@refno");
        dw.SetSqlCommandParameters("refno", refno);
        return dw.Delete();
    }
    //(+++++)
    // new 22/06/2009
    public DataTable GetAssignedPayments(string cracno, string TrStatus1, string TrStatus2, string TransRef, DateTime CurrentDate)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select distinct  ta.cracno, ta.refno, ta.AssignAmt, ta.tramt,
                            rtrim(cast(DAY(ta.Adddate) as nvarchar(5)))+ '/' + 
                            (cast(month(ta.Adddate) as nvarchar(5))) +  '/' +
                            (cast(year(ta.Adddate) as nvarchar(5))) as AddDate, 
                            tc.Description, ta.TrStatus, rtrim(cast(day(ta.DATEDUE) as nvarchar(5)))+ '/' + 
                            (cast(month(ta.DATEDUE) as nvarchar(5))) +  '/' +
                            (cast(year(ta.DATEDUE) as nvarchar(5))) as DueDate, ta.taskid, ta.trtype, recorder 
                            from TransAssign ta, transCat tc where ta.cracno = @cracno and 
                            (ta.TrStatus=@TrStatus1 or ta.TrStatus=@TrStatus2) 
                            and ta.TransRef = @TransRef and ta.taskid = tc.taskid and ta.TransRef = tc.TransRef
                            and ta.DATEDUE < @CurrentDate order by refno , recorder asc");

        dw.SetDataAdapterParameters("cracno", cracno);
        dw.SetDataAdapterParameters("TrStatus1", TrStatus1);
        dw.SetDataAdapterParameters("TrStatus2", TrStatus2);
        dw.SetDataAdapterParameters("TransRef", TransRef);
        dw.SetDataAdapterParameters("CurrentDate", CurrentDate);
        return dw.GetDataTable();
    }


    public DataTable GetAssignedPayments(string cracno, string TrStatus1, string TrStatus2, string TransRef)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select  ta.cracno, ta.refno, ta.AssignAmt, ta.tramt,
                            rtrim(cast(DAY(ta.Adddate) as nvarchar(5)))+ '/' + 
                            (cast(month(ta.Adddate) as nvarchar(5))) +  '/' +
                            (cast(year(ta.Adddate) as nvarchar(5))) as AddDate, 
                            tc.Description, ta.TrStatus, rtrim(cast(day(ta.DATEDUE) as nvarchar(5)))+ '/' + 
                            (cast(month(ta.DATEDUE) as nvarchar(5))) +  '/' +
                            (cast(year(ta.DATEDUE) as nvarchar(5))) as DueDate, ta.taskid, ta.trtype, recorder 
                            from TransAssign ta, transCat tc where ta.cracno = @cracno and 
                            (ta.TrStatus=@TrStatus1 or ta.TrStatus=@TrStatus2) 
                            and ta.TransRef =@TransRef  and ta.taskid = tc.taskid and ta.TransRef = tc.TransRef
                            order by datedue, recorder asc ");

        dw.SetDataAdapterParameters("cracno", cracno);
        dw.SetDataAdapterParameters("TrStatus1", TrStatus1);
        dw.SetDataAdapterParameters("TrStatus2", TrStatus2);
        dw.SetDataAdapterParameters("TransRef", TransRef);
        return dw.GetDataTable();
    }

    public DataTable GetArreasPayments(long disbrefno, string TrStatus1, string TrStatus2)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select cracno, tramt, AssignAmt, datedue, taskid, trtype, trstatus, adduser, 
                            refno, transref, intrate, crcat 
                            from transassign where trstatus = @TrStatus1
                            and  disbrefno = @disbrefno and cracno != 903080000000000
                            union
                            select cracno, tramt, AssignAmt, datedue, taskid, trtype, trstatus, adduser, 
                            refno, transref, intrate, crcat from transassigntmp where 
                            disbrefno = @disbrefno and status != 'I'
                            and refno in (select refno from transassign where disbrefno = @disbrefno 
                            and  trstatus = TrStatus2) 
                            order by datedue, recorder asc");

        dw.SetDataAdapterParameters("disbrefno", disbrefno);
        dw.SetDataAdapterParameters("TrStatus1", TrStatus1);
        dw.SetDataAdapterParameters("TrStatus2", TrStatus2);
        return dw.GetDataTable();
    }


    public DataTable GetAssignPayments(string transno, long disbrefno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select refno,  assignamt, tramt,
                            rtrim(cast(DAY(datedue) as nvarchar(5)))+ '/' + 
                            (cast(month(datedue) as nvarchar(5))) +  '/' +
                            (cast(year(datedue) as nvarchar(5))) as datedue,    
                            assignamt - tramt as arreasamount, taskid
                            from transassign where transno = @transno 
                            and disbrefno=@disbrefno
                            order by datedue, recorder asc");
        dw.SetDataAdapterParameters("transno", transno);
        dw.SetDataAdapterParameters("disbrefno", disbrefno);
        return dw.GetDataTable();
    }


    public DataTable GetPayments(long disbrefno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select tab1.tramt, tab1.AssignAmt, tab1.datedue, 
                            tab1.taskid, tab1.trstatus   from
                            (select tramt,  AssignAmt, datedue, taskid, trstatus
                            from transassigntmp where refno in (select refno from transassign
                            where disbrefno = @disbrefno ) and tramt != 0
                            and status = 'A' and transno is null
                            union all
                            select tramt,  AssignAmt, datedue, taskid, trstatus
                            from transassign where disbrefno = @disbrefno 
                            and refno not in 
                            (select refno from transassigntmp 
                            where status = 'A' and transno is null)) as tab1
                            order by tab1.datedue, tab1.taskid desc");

        dw.SetDataAdapterParameters("disbrefno", disbrefno);
        return dw.GetDataTable();
    }

//    public long GetDisbRefNo(string cracno, string TrStatus1, string TrStatus2, string TransRef)
//    {
//        dw = new DataWorksClass(constring);
//        dw.SetCommand(@"select  disbrefno from TransAssign where cracno = @cracno and 
//                            (TrStatus=@TrStatus1 or TrStatus=@TrStatus2) 
//                            and TransRef =@TransRef ");

//        dw.SetSqlCommandParameters("cracno", cracno);
//        dw.SetSqlCommandParameters("TrStatus1", TrStatus1);
//        dw.SetSqlCommandParameters("TrStatus2", TrStatus2);
//        dw.SetSqlCommandParameters("TransRef", TransRef);
//        return long.Parse(dw.GetSingleData());
//    }
    // For Batch
    public DataTable GetAssignedPayments(string cracno, string TrStatus1, string TrStatus2, string TransRef, long disbrefno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select  ta.cracno, ta.refno, ta.AssignAmt, ta.tramt,
                            rtrim(cast(DAY(ta.Adddate) as nvarchar(5)))+ '/' + 
                            (cast(month(ta.Adddate) as nvarchar(5))) +  '/' +
                            (cast(year(ta.Adddate) as nvarchar(5))) as AddDate, 
                            tc.Description, ta.TrStatus, rtrim(cast(day(ta.DATEDUE) as nvarchar(5)))+ '/' + 
                            (cast(month(ta.DATEDUE) as nvarchar(5))) +  '/' +
                            (cast(year(ta.DATEDUE) as nvarchar(5))) as DueDate, ta.taskid, ta.trtype, recorder 
                            from TransAssign ta, transCat tc where ta.cracno = @cracno and 
                            (ta.TrStatus=@TrStatus1 or ta.TrStatus=@TrStatus2) 
                            and ta.TransRef =@TransRef  and ta.taskid = tc.taskid and ta.TransRef = tc.TransRef
                            and ta.disbrefno = @disbrefno
                            order by datedue, recorder asc ");

        dw.SetDataAdapterParameters("cracno", cracno);
        dw.SetDataAdapterParameters("TrStatus1", TrStatus1);
        dw.SetDataAdapterParameters("TrStatus2", TrStatus2);
        dw.SetDataAdapterParameters("TransRef", TransRef);
        dw.SetDataAdapterParameters("disbrefno", disbrefno);
        return dw.GetDataTable();
    }


    public DataTable GetAssignedPayments(string trstatus, string transref, long mindisbrefno, long maxdisbrefno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select distinct  ta.refno, ta.cracno, ta.AssignAmt, ta.tramt,
                            rtrim(cast(DAY(ta.Adddate) as nvarchar(5)))+ '/' + 
                            (cast(month(ta.Adddate) as nvarchar(5))) +  '/' +
                            (cast(year(ta.Adddate) as nvarchar(5))) as AddDate, 
                            ta.TrStatus, ta.taskid, ta.trtype, ta.disbrefno
                            from TransAssign ta where ta.TrStatus=@TrStatus and 
                            (ta.disbrefno >= @mindisbrefno and ta.disbrefno <= @maxdisbrefno) 
                            and ta.TransRef = @TransRef
                            order by disbrefno asc");

        dw.SetDataAdapterParameters("mindisbrefno", mindisbrefno);
        dw.SetDataAdapterParameters("maxdisbrefno", maxdisbrefno);
        dw.SetDataAdapterParameters("TrStatus", trstatus);
        dw.SetDataAdapterParameters("TransRef", transref);
        return dw.GetDataTable();
    }

    //edit bimali 23/03/2009
    public DataTable GetAssignedPayments(string appno, string transref1, string transref2, string TrStatus1, string TrStatus2)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select distinct t.trtype, T.REFNO as Refno, t.cracno as LoanAccountNo, 
                            T.ADDDATE, c.Description,AssignAmt from transassign t,transcat c, crmast m
                            where m.appno=@appno and (m.cracno=t.cracno or m.appno=t.cracno)
                            and  t.taskid=c.taskid and (t.transref=@transref1 or t.transref=@transref2)
                            and (trstatus=@TrStatus1 or trstatus=@TrStatus2)");
        dw.SetDataAdapterParameters("appno", appno);
        dw.SetDataAdapterParameters("transref1", transref1);
        dw.SetDataAdapterParameters("transref2", transref2);
        dw.SetDataAdapterParameters("TrStatus1", TrStatus1);
        dw.SetDataAdapterParameters("TrStatus2", TrStatus2);
        return dw.GetDataTable();
    }

    public DataTable GetAssignedPayments(string appno, string TrStatus1, string TrStatus2)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select ta.cracno, ta.refno, ta.AssignAmt, ta.AddDate, 
                            tc.Description, ta.TrStatus, ta.datedue, ta.taskid from TransAssign ta, transCat tc 
                            where ta.cracno = @cracno 
                            and (ta.TrStatus=@TrStatus1 or ta.TrStatus=@TrStatus2) 
                            and ta.taskid = tc.taskid
                            order by TrStatus desc");

        dw.SetDataAdapterParameters("cracno", appno);
        dw.SetDataAdapterParameters("TrStatus1", TrStatus1);
        dw.SetDataAdapterParameters("TrStatus2", TrStatus2);

        return dw.GetDataTable();
    }

    public DataTable GetClosingPayments(long disbrefno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select cracno, tramt, AssignAmt, datedue, taskid, trtype, trstatus, adduser, 
                            refno, transref, intrate, crcat 
                            from transassign where trstatus = 'n'
                            and  disbrefno = @disbrefno and left(cracno,1) != '9'
                            union
                            select cracno, tramt, AssignAmt, datedue, taskid, trtype, trstatus, adduser, 
                            refno, transref, intrate, crcat from transassigntmp where 
                            disbrefno = @disbrefno
                            and refno in (select refno from transassign where disbrefno = @disbrefno 
                            and  trstatus = 'p' and left(cracno,1) != '9') 
                            order by datedue, taskid desc");

        dw.SetDataAdapterParameters("disbrefno", disbrefno);
        return dw.GetDataTable();
    }

    public DataTable GetExcessPayment(long disbrefno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select cracno, tramt, AssignAmt, datedue, taskid, 
                            case when trtype = 'I' then 'E'
                            else 'I' end as trtype, trstatus, adduser, 
                            refno, transref, intrate, crcat 
                            from transassign where disbrefno = @disbrefno and
                            cracno = '903081000000994'");

        dw.SetDataAdapterParameters("disbrefno", disbrefno);
        return dw.GetDataTable();
    }

    public DataTable GetClosedPayments(string transno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select distinct g.cracno, sum(distinct g.tramt) as [Sub Total], t.taskid as  [Description], 
                            case when g.acsign = 'CR' then 'I' else 'E' end as trtype 
                            from transassign t, gltrans g
                            where g.transno = @transno  and t.refno = g.transassignrefno
                            and refglcode != '903080000000000' and g.refglcode != 903081000000994
                            group by g.cracno, t.taskid, g.acsign");

        dw.SetDataAdapterParameters("transno", transno);
        return dw.GetDataTable();
    }

    public DataTable GetClosedPaymentsInternet(string transno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select distinct g.cracno, sum(distinct g.tramt) as [Sub Total], t.taskid as  [Description], 
                            case when g.acsign = 'CR' then 'I' else 'E' end as trtype 
                            from transassign t, gltrans g
                            where g.transno = @transno  and t.refno = g.transassignrefno
                            and refglcode != '903080000000000' and g.refglcode != 903081000000899
                            group by g.cracno, t.taskid, g.acsign");

        dw.SetDataAdapterParameters("transno", transno);
        return dw.GetDataTable();
    }

    public DataTable GetPassiblePayments(string cracno, string TrStatus1, string TrStatus2)
    {
         dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select tab1.cracno, tab1.tramt as [Transaction Amount], 
                            tab1.taskid, tab1.assignamt, tab1.datedue from
                            (select  cracno, tramt, taskid, assignamt, datedue
                             from tdb.creditadmin.transassigntmp where refno in 
                            (select refno from tdb.creditadmin.transassign
                            where cracno = @cracno) and (trstatus=@trstatus1 or trstatus = @trstatus2)
                            and status = 'A' and transno is null
                            union all
                            select cracno, tramt, taskid, assignamt, datedue
                            from tdb.creditadmin.transassign where cracno =@cracno
                            and (trstatus=@trstatus1 or trstatus = @trstatus2) and refno not in 
                            (select refno from tdb.creditadmin.transassigntmp 
                            where status = 'A' and transno is null) ) as tab1
                            order by tab1.taskid desc, tab1.datedue");

        dw.SetDataAdapterParameters("cracno", cracno);
        dw.SetDataAdapterParameters("TrStatus1", TrStatus1);
        dw.SetDataAdapterParameters("TrStatus2", TrStatus2);
        //dw.SetDataAdapterParameters("disbrefno", disbrefno);
        return dw.GetDataTable();
    }

    // 24/06/2009
    public DataTable GetAssignedPayments(long cracno, string TrStatus)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select ta.cracno, ta.refno, ta.AssignAmt, ta.tramt,
                            rtrim(cast(DAY(ta.Adddate) as nvarchar(5)))+ '/' + 
                            (cast(month(ta.Adddate) as nvarchar(5))) +  '/' +
                            (cast(year(ta.Adddate) as nvarchar(5))) as AddDate, 
                            tc.Description, ta.TrStatus, rtrim(cast(day(ta.DATEDUE) as nvarchar(5)))+ '/' + 
                            (cast(month(ta.DATEDUE) as nvarchar(5))) +  '/' +
                            (cast(year(ta.DATEDUE) as nvarchar(5))) as DueDate, ta.taskid, ta.trtype, recorder 
                            from TransAssign ta, transCat tc where ta.cracno = @cracno and 
                            ta.TrStatus=@TrStatus and ta.taskid = tc.taskid and ta.TransRef = tc.TransRef
                            order by datedue, recorder asc");

        dw.SetDataAdapterParameters("cracno", cracno);
        dw.SetDataAdapterParameters("TrStatus", TrStatus);
        return dw.GetDataTable();
    }

    public DataTable GetAssignedPayments(string transno, string trstatus)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select t.cracno, t.refno, t.tramt, t.trdate, tc.Description from Trans t, transCat tc where 
                            t.TrStatus=@TrStatus and  t.TransNo = @TransNo and LEFT(t.taskid,10) = tc.taskid");
        dw.SetDataAdapterParameters("TrStatus", trstatus);
        dw.SetDataAdapterParameters("TransNo", transno);
        return dw.GetDataTable();
    }

     //2009-03-26 vihanga U
    public string GetChargesAmount(string appno, string transref1, string transref2)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select sum(tab1.AssignAmt) as AssignAmt from 
                        (select distinct T.REFNO,Description,AssignAmt from transassign t,transcat c, crmast m
                        where m.appno=@appno and (m.cracno=t.cracno or m.appno=t.cracno)
                        and  t.taskid=c.taskid and (c.transref=@transref1 or c.transref=@transref2)
                        and (trstatus='N' or trstatus='P') and t.taskid!='CAPD') as tab1");
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("transref1", transref1);
        dw.SetSqlCommandParameters("transref2", transref2);
        return dw.GetSingleData();
    }





//    public DataTable GetAssignedPayments(string appno, string TrStatus1, string TrStatus2, string TransRef)
//      {
//          dw = new DataWorksClass(constring);
//          dw.SetDataAdapter(@"select ta.cracno, ta.TrCode, ta.refno, ta.AssignAmt, ta.AddDate, 
//                            tc.TrDesc, ta.TrStatus, ta.datedue from TransAssign ta, transCat tc where ta.cracno = @cracno 
//                            and (ta.TrStatus=@TrStatus1 or ta.TrStatus=@TrStatus2) and  ta.TransRef = @TransRef 
//                            and ta.trcode = tc.trcode
//                            order by TrStatus desc");

//          dw.SetDataAdapterParameters("cracno", appno);
//          dw.SetDataAdapterParameters("TrStatus1", TrStatus1);
//          dw.SetDataAdapterParameters("TrStatus2", TrStatus2); 
//          dw.SetDataAdapterParameters("TransRef", TransRef);
//          return dw.GetDataTable();
//      }

//    public DataTable GetAssignedPayments(string appno, string TrStatus, string TransRef)
//    {
//        dw = new DataWorksClass(constring);
//        dw.SetDataAdapter(@"select ta.cracno, ta.TrCode, ta.refno, ta.AssignAmt, ta.AddDate, 
//                                  tc.TrDesc, ta.datedue from TransAssign ta, transCat tc where ta.cracno = @cracno 
//                                  and ta.TrStatus=@TrStatus and  ta.TransRef = @TransRef 
//                                  and ta.trcode = tc.trcode
//                                  order by TrStatus desc");

//        dw.SetDataAdapterParameters("cracno", appno);
//        dw.SetDataAdapterParameters("TrStatus", TrStatus);
//        dw.SetDataAdapterParameters("TransRef", TransRef);
//        return dw.GetDataTable();
//    }

   

    //public int UpdatePaymentStatusInApprovalStat(string appno, bool IsPaymentOk)
    //{
    //    dw = new DataWorksClass(constring);
    //    dw.SetCommand(@"update approvalstatus set IsPaymentOk=@IsPaymentOk where AppNo=@appno");
    //    dw.SetSqlCommandParameters("appno",appno);
    //    dw.SetSqlCommandParameters("IsPaymentOk",IsPaymentOk);
    //    return dw.Update();
    //}

    public DataTable GetAssignedPaymentsNotMatchToTransRef(string appno, string TrStatus, string TransRef)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select ta.cracno, ta.TrCode, ta.refno, ta.AssignAmt, ta.AddDate, tc.TrDesc from TransAssign ta, transCat tc where ta.cracno = @cracno 
                            and ta.TrStatus!=@TrStatus and  ta.TransRef = @TransRef and ta.trcode = tc.trcode");
        dw.SetDataAdapterParameters("cracno", appno);
        dw.SetDataAdapterParameters("TrStatus", TrStatus);
        dw.SetDataAdapterParameters("TransRef", TransRef);
        return dw.GetDataTable();
    }   


//    //Get Possible Payments
//    public DataTable GetAssignPayment(string appno)
//    {
//        dw = new DataWorksClass(constring);
//        dw.SetDataAdapter(@"select ta.cracno, ta.refno, ta.trcode, ta.AssignAmt, tc.trdesc from TransAssign ta, TransCat tc
//                            where ta.trcode = tc.trcode and cracno = @cracno");
//        dw.SetDataAdapterParameters("cracno", appno);
//        return dw.GetDataTable();
//    }


//    public int UpdateTrans(string cracno, int Trcode, bool ispaid, string TrUser)
//    {
//        dw = new DataWorksClass(constring);
//        dw.SetCommand(@"update Trans set TrUser = @TrUser,ispaid = @ispaid where 
//                       cracno = @cracno and Trcode = @Trcode and ispaid = @OriginalIspaid");

//        dw.SetSqlCommandParameters("cracno", cracno);
//        dw.SetSqlCommandParameters("ispaid", ispaid);
//        dw.SetSqlCommandParameters("Trcode", Trcode);
//        dw.SetSqlCommandParameters("userid", TrUser);
//        dw.SetSqlCommandParameters("OriginalIspaid", false);
//        return dw.Insert();
//    }



//    //Disb Trans 
//    public int InsertTrans(string CrAcNo, int TrCode, double TrAmt, string TrLineNo, string AccSign, string TrStatus, string TransRef, string AddUser, DateTime AddDate, bool Ispaid, string RefGlAccNo, int DisbNo)
//    {
//        dw = new DataWorksClass(constring);
//        dw.SetCommand(@"insert into Trans (CrAcNo,TrCode,TrAmt,TrLineNo,AccSign,TrStatus,AddUser,AddDate,TransRef, DisbNo, Ispaid,RefGlAccNo)
//                       values (@CrAcNo,@TrCode,@TrAmt,@TrLineNo,@AccSign,@TrStatus,@AddUser,@AddDate,@TransRef, @DisbNo, @Ispaid,@RefGlAccNo) ");
//        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
//        dw.SetSqlCommandParameters("TrCode", TrCode);
//        dw.SetSqlCommandParameters("TrAmt", TrAmt);
//        dw.SetSqlCommandParameters("TrLineNo", TrLineNo);
//        dw.SetSqlCommandParameters("AccSign", AccSign);
//        dw.SetSqlCommandParameters("TrStatus", TrStatus);
//        dw.SetSqlCommandParameters("AddUser", AddUser);
//        dw.SetSqlCommandParameters("AddDate", AddDate);
//        dw.SetSqlCommandParameters("TransRef", TransRef);
//        dw.SetSqlCommandParameters("DisbNo", DisbNo);
//        dw.SetSqlCommandParameters("Ispaid", Ispaid);
//        dw.SetSqlCommandParameters("RefGlAccNo", RefGlAccNo);
//        return dw.Insert();
//    }

//    // Recoveries
//    public int InsertTrans(string CrAcNo, int TrCode, double TrAmt, int TrLineNo, string AccSign, string TrStatus, string TransRef, string AddUser, DateTime AddDate, bool Ispaid, string RefGlAccNo, DateTime DateDue, int RecOrder)
//    {
//        dw = new DataWorksClass(constring);
//        dw.SetCommand(@"insert into Trans (CrAcNo,TrCode,TrAmt,TrLineNo,AccSign,TrStatus,AddUser,AddDate,TransRef, DateDue, RecOrder, Ispaid,RefGlAccNo)
//                       values (@CrAcNo,@TrCode,@TrAmt,@TrLineNo,@AccSign,@TrStatus,@AddUser,@AddDate,@TransRef, @DateDue, @RecOrder, @Ispaid,@RefGlAccNo)");
//        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
//        dw.SetSqlCommandParameters("TrCode", TrCode);
//        dw.SetSqlCommandParameters("TrAmt", TrAmt);
//        dw.SetSqlCommandParameters("TrLineNo", TrLineNo);
//        dw.SetSqlCommandParameters("AccSign", AccSign);
//        dw.SetSqlCommandParameters("TrStatus", TrStatus);
//        dw.SetSqlCommandParameters("AddUser", AddUser);
//        dw.SetSqlCommandParameters("AddDate", AddDate);
//        dw.SetSqlCommandParameters("TransRef", TransRef);
//        dw.SetSqlCommandParameters("DateDue", DateDue);
//        dw.SetSqlCommandParameters("RecOrder", RecOrder);
//        dw.SetSqlCommandParameters("Ispaid", Ispaid);
//        dw.SetSqlCommandParameters("RefGlAccNo", RefGlAccNo);
//        return dw.Insert();
//    }
    #endregion

    #region GetPossiblePayments

    public DataTable GetPossiblePayments(int crcatcode, string type, string transref)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select pp.taskid, tc.description, tc.UnitCharge, tc.ValueType, tc.type  
                            from transcat tc, PossiblePayments pp
                            where  tc.taskid = pp.taskid and tc.transref=@transref and
                            pp.crcatcode = @crcatcode and tc.type= @type");
        dw.SetDataAdapterParameters("crcatcode", crcatcode);
        dw.SetDataAdapterParameters("type", type);
        dw.SetDataAdapterParameters("transref", transref);
        return dw.GetDataTable();
    }

    public DataTable GetPossiblePayments(int crcatcode, string transref)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select distinct pp.taskid, tc.description  
                            from transcat tc, PossiblePayments pp
                            where  tc.taskid = pp.taskid and tc.transref=@transref and
                            pp.crcatcode = @crcatcode");
        dw.SetDataAdapterParameters("crcatcode", crcatcode);
        dw.SetDataAdapterParameters("transref", transref);
        return dw.GetDataTable();
    }


    public int GetCrCatCode(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select crcatcode from crapp where appno = @appno");
        dw.SetSqlCommandParameters("appno", appno);
        return int.Parse(dw.GetSingleData());
    }


    public int GetCatCode(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select crcat from crmast where cracno = @cracno and acstatus='A'");
        dw.SetSqlCommandParameters("cracno", cracno);
        return int.Parse(dw.GetSingleData());
    }

    #endregion


    #region DisBalSum

    public int NoofDisb(string appno, int loancount)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand("select count(*) from DisbBalSum where appno = @appno and ScheduleStatus ='C' AND Status='A'");
        dw.SetSqlCommandParameters("appno", appno);
        return int.Parse(dw.GetSingleData()) / loancount + 1;
    }

    public int NoofDisbClose(string appno, int loancount)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand("select count(*) from DisbBalSum where appno = @appno and ScheduleStatus ='C' AND Status='A'");
        dw.SetSqlCommandParameters("appno", appno);
        return int.Parse(dw.GetSingleData()) / loancount;
    }

    public int InsertIntoDibBalSum(string cracno, string appno, decimal transamt, decimal outbal,
                                   DateTime batchdate, string status, string IsFinalRelease, string ScheduleStatus, int ScheduleNo)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO DisbBalSum (CrAcNo,AppNo,TransAmt,OutBal,BatchDate,
                        Status,IsFinalRelease,ScheduleNo, ScheduleStatus) VALUES (@cracno,@appno,@transamt,@outbal,
                        @batchdate,@status,@IsFinalRelease,@ScheduleNo, @ScheduleStatus)");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("transamt", transamt);
        dw.SetSqlCommandParameters("outbal", outbal);
        dw.SetSqlCommandParameters("batchdate", batchdate);
        dw.SetSqlCommandParameters("status", status);
        dw.SetSqlCommandParameters("IsFinalRelease", IsFinalRelease);
        dw.SetSqlCommandParameters("ScheduleNo", ScheduleNo);
        dw.SetSqlCommandParameters("ScheduleStatus", ScheduleStatus);
        return dw.Insert();
    }



    public int UpdateDibBalSum(string cracno, decimal transamt, decimal outbal, DateTime batchdate,
                                string status, string IsFinalRelease, string ScheduleStatus, int ScheduleNo)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update DisbBalSum set TransAmt=@TransAmt,OutBal=@OutBal,BatchDate=@BatchDate,
                        Status=@Status,IsFinalRelease=@IsFinalRelease,ScheduleStatus=@ScheduleStatus
                        where cracno=@cracno and ScheduleNo=@ScheduleNo");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("transamt", transamt);
        dw.SetSqlCommandParameters("outbal", outbal);
        dw.SetSqlCommandParameters("batchdate", batchdate);
        dw.SetSqlCommandParameters("status", status);
        dw.SetSqlCommandParameters("IsFinalRelease", IsFinalRelease);
        dw.SetSqlCommandParameters("ScheduleStatus", ScheduleStatus);
        dw.SetSqlCommandParameters("ScheduleNo", ScheduleNo);
        return dw.Update();
    }

    public int InsertChqDetails(int BankNo, int BranchNo, int ChqNo, DateTime RecvDate, DateTime RealizeDate, double TotalAmt, string AddUser, string CrAcNo, double SubAmt, int TrCode)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO ChqRecvTmp (BankNo,BranchNo,ChqNo,RecvDate,RealizeDate,TotalAmt,AddUser,CrAcNo,SubAmt,TrCode)
                       values (@BankNo,@BranchNo,@ChqNo,@RecvDate,@RealizeDate,@TotalAmt,@AddUser,@CrAcNo,@SubAmt,@TrCode) ");
        dw.SetSqlCommandParameters("BankNo", BankNo);
        dw.SetSqlCommandParameters("BranchNo", BranchNo);
        dw.SetSqlCommandParameters("ChqNo", ChqNo);
        dw.SetSqlCommandParameters("RecvDate", RecvDate);
        dw.SetSqlCommandParameters("RealizeDate", RealizeDate);
        dw.SetSqlCommandParameters("TotalAmt", TotalAmt);
        dw.SetSqlCommandParameters("AddUser", AddUser);
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        dw.SetSqlCommandParameters("SubAmt", SubAmt);
        dw.SetSqlCommandParameters("TrCode", TrCode);
        return dw.Insert();
    }

    public int UpdateDisBalSumOutBal(string cracno, decimal outbal)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@" UPDATE DisbBalSum SET OutBal=@outbal WHERE CrAcNo=@cracno");
        dw.SetSqlCommandParameters("outbal", outbal);
        dw.SetSqlCommandParameters("cracno", cracno);
        return dw.Update();
    }

    public int UpdateIsFinal(string appno, string isfinal)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@" UPDATE DisbBalSum SET IsFinalRelease=@isfinal WHERE AppNo=@appno");
        dw.SetSqlCommandParameters("outbal", isfinal);
        dw.SetSqlCommandParameters("cracno", appno);
        return dw.Update();
    }

    public int UpdateScheduleStatus(string appno, string ScheduleStatus)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@" UPDATE DisbBalSum SET ScheduleStatus=@ScheduleStatus WHERE AppNo=@appno 
                         AND ScheduleStatus='O' AND Status='A'");
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("ScheduleStatus", ScheduleStatus);
        return dw.Update();
    }

    public int UpdateDisbBalChequeNo(string appno, int chqno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@" UPDATE DisbBalSum SET ChqNo=@chqno WHERE AppNo=@appno 
                         AND ScheduleStatus='C' AND ChqNo IS NULL ");
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("chqno", chqno);
        return dw.Update();
    }


    //temorary one

//    public int InserIntoTransAssign(string cracno, int trcode, string trstatus, string adduser,
//                                    string transref, decimal assignamt)
//    {
//        dw = new DataWorksClass(constring);


//        dw.SetCommand(@"INSERT INTO TransAssign (CrAcno,TrCode,TrStatus,AddUser,TransRef,AssignAmt)
//                       values (@cracno,@trcode,@trstatus,@adduser,@transref,@assignamt) ");

//        dw.SetSqlCommandParameters("cracno", cracno);
//        dw.SetSqlCommandParameters("trcode", trcode);
//        dw.SetSqlCommandParameters("trstatus", trstatus);
//        dw.SetSqlCommandParameters("adduser", adduser);
//        dw.SetSqlCommandParameters("transref", transref);
//        dw.SetSqlCommandParameters("assignamt", assignamt);
//        return dw.Insert();

//    }
    //bimali
    public int CancelApprovedDisbursement(string appno, string status)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"UPDATE DisbBalSum SET status=@status WHERE AppNo=@appno AND ScheduleStatus='C' AND
                        GrantDate IS NULL");
        dw.SetSqlCommandParameters("status", status);
        dw.SetSqlCommandParameters("appno", appno);
        return dw.Update();
    }

    public int CancelApprovedCheque(string appno, string status)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"UPDATE DisbBalSum SET status=@status WHERE AppNo=@appno AND ScheduleStatus='C' AND
                        GrantDate IS NOT NULL AND GrantDate=(SELECT MAX(GrantDate) FROM DisbBalSum WHERE
                        AppNo=@appno AND GrantDate IS NOT NULL)");
        dw.SetSqlCommandParameters("status", status);
        dw.SetSqlCommandParameters("appno", appno);
        return dw.Update();
    }

    //
    public void CancelDisbUpdateGrantAmt(DataTable dt)
    {
        string cracno;
        decimal TransAmt = 0;
        //dw = new DataWorksClass(constring);
        DisbursementClass dc = new DisbursementClass();

        for (int i = 0; i < dt.Rows.Count; i++)
        {
            cracno = dt.Rows[i]["CrAcNo"].ToString();
            TransAmt = decimal.Parse(dt.Rows[i]["Transamt"].ToString());
            decimal grantAmt = dc.GetCreditAmountCrAcNo(cracno) - TransAmt;
            UpdateDetails(cracno, grantAmt);
        }
    }

    private int UpdateDetails(string cracno, decimal grantamt)
    {
        dw = new DataWorksClass(constring);

        dw.SetCommand(@"UPDATE CrMast SET GrantAmt=@grantamt WHERE CrAcNo=@cracno");
        dw.SetSqlCommandParameters("grantamt", grantamt);
        dw.SetSqlCommandParameters("cracno", cracno);
        return dw.Update();
    }

    // Dilanka 18-03-2009
    // Dilanka 18-03-2009 (edit bimali 01/04/2009)
    public int UpdateStatus(string appno, string Status)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@" UPDATE DisbBalSum SET Status=@Status WHERE AppNo=@appno 
                         AND ScheduleStatus='C' AND Status='A' and grantdate is null");
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("Status", Status);
        return dw.Update();
    }

    //Pradeep 23-02-2010
    public int UpdateDisbBalSumTransno(string cracno, int transno, DateTime grantdate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@" UPDATE DisbBalSum SET transno=@transno,grantdate=@grantdate WHERE cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("transno", transno);
        dw.SetSqlCommandParameters("grantdate", grantdate);
        return dw.Update();
    }

    //edit bimali 01/04/2009
    public int UpdateTrStatus(string Cracno, string TrStatus, string TaskId, string Transref)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@" UPDATE TransAssign SET TrStatus=@TrStatus  WHERE Cracno=@Cracno 
                         AND TrStatus='N' AND TaskId=@TaskId AND Transref=@Transref");
        dw.SetSqlCommandParameters("Cracno", Cracno);
        dw.SetSqlCommandParameters("TrStatus", TrStatus);
        dw.SetSqlCommandParameters("TaskId", TaskId);
        dw.SetSqlCommandParameters("Transref", Transref);
        return dw.Update();
    }
    #endregion


    public int InsertTransAssignT(string CrAcNo, string taskid, double AssignAmt, double tramt, string
        TrStatus, string AddUser, DateTime AddDate, string TransRef, string trtype, double intrate,
        int RecOrder, long disbrefno, DateTime trdate, DateTime DateDue, string system, int crcat)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO TransAssign (CrAcNo,taskid,AssignAmt, tramt,TrStatus,AddUser,AddDate,TransRef,trtype, intrate,RecOrder,disbrefno, trdate, DateDue, system, crcat)
                       values (@CrAcNo,@taskid,@AssignAmt, @tramt,@TrStatus,@AddUser,@AddDate,@TransRef,@trtype,@intrate,@RecOrder,@disbrefno, @trdate, @DateDue, @system, @crcat) ");
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        dw.SetSqlCommandParameters("taskid", taskid);
        dw.SetSqlCommandParameters("AssignAmt", AssignAmt);
        dw.SetSqlCommandParameters("tramt", tramt);
        dw.SetSqlCommandParameters("TrStatus", TrStatus);
        dw.SetSqlCommandParameters("AddUser", AddUser);
        dw.SetSqlCommandParameters("AddDate", AddDate);
        dw.SetSqlCommandParameters("TransRef", TransRef);
        dw.SetSqlCommandParameters("trtype", trtype);
        dw.SetSqlCommandParameters("intrate", intrate);
        dw.SetSqlCommandParameters("RecOrder", RecOrder);
        dw.SetSqlCommandParameters("disbrefno", disbrefno);
        dw.SetSqlCommandParameters("trdate", trdate);
        dw.SetSqlCommandParameters("DateDue", DateDue);
        dw.SetSqlCommandParameters("system", system);
        dw.SetSqlCommandParameters("crcat", crcat);
        return dw.Insert();
    }
    //new bimalin 13/08/2009
    public string GetTransCatDescription(string taskid)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select description from transcat where taskid=@taskid");
        dw.SetSqlCommandParameters("taskid", taskid);
        return dw.GetSingleData();
    }

    //new bimalin 16/08/2009
    public string GetCashierName(string transno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select distinct truser from trans where transno=@transno");
        dw.SetSqlCommandParameters("transno", transno);
        return dw.GetSingleData();
    }
    //new bimalin 16/08/2009
    public double GetArreasAmount(string cracno, string transref)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select sum(AssignAmt-TrAmt) from TransAssign Where cracno=@cracno
                        and transref=@transref and (trstatus='P' or trstatus='N')");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("transref", transref);
        return double.Parse(dw.GetSingleData());
    }

    public string fullname(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select rtrim(initials)+' '+rtrim(surname) as fullname from
                        customermain c,appholder a
                        where a.appno=@appno and c.nicno=a.nicno
                        and a.holdertype='P'");
        dw.SetSqlCommandParameters("appno", appno);
        return dw.GetSingleData();
    }

    public int UpdatePaymentStatusInApprovalStat(string appno, bool IsPaymentOk)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update approvalstatus set IsPaymentOk=@IsPaymentOk where appno=@appno");
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("IsPaymentOk", IsPaymentOk);
        return dw.Update();
    }

    public DataTable GetArreasPayments(string cracno, string TrStatus1, string TrStatus2, string TransRef)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select refno, 
                            rtrim(cast(DAY(datedue) as nvarchar(5)))+ '/' + 
                            (cast(month(datedue) as nvarchar(5))) +  '/' +
                            (cast(year(datedue) as nvarchar(5))) as datedue,    
                            assignamt - tramt as arreasamount, taskid
                            from transassign where cracno = @cracno
                            and (trstatus = @trstatus1 or trstatus = @trstatus2) 
                            and transref = @transref 
                            and (assignamt - tramt) !=0
                            order by datedue, recorder asc");

        dw.SetDataAdapterParameters("cracno", cracno);
        dw.SetDataAdapterParameters("TrStatus1", TrStatus1);
        dw.SetDataAdapterParameters("TrStatus2", TrStatus2);
        dw.SetDataAdapterParameters("TransRef", TransRef);
        return dw.GetDataTable();
    }

    //new 03/11/2009 bimali
    public double GetAdvancePayment(string cracno, string transref, DateTime currentdate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select isnull(sum(TrAmt) ,0) as Payment
                        from TransAssign Where cracno=@cracno
                        and transref=@transref and (trstatus='F' or trstatus='P')
                        and DateDue>@currentdate and transno is not null");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("transref", transref);
        dw.SetSqlCommandParameters("currentdate", currentdate);
        return double.Parse(dw.GetSingleData());
    }

    //new bimalin 16/08/2009 // edit 03/11/2009
    public double GetArreasAmount(string cracno, string transref, DateTime currentdate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select isnull(sum(AssignAmt-TrAmt) ,0) as Payment
                        from TransAssign Where cracno=@cracno
                        and transref=@transref and (trstatus='P' or trstatus='N')
                        and DateDue<@currentdate");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("transref", transref);
        dw.SetSqlCommandParameters("currentdate", currentdate);
        return double.Parse(dw.GetSingleData());
    }

    public string GetBatchno(string transno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select batchno from CashierTransaction where transno=@transno");
        dw.SetSqlCommandParameters("transno", transno);
        return dw.GetSingleData();
    }
}
