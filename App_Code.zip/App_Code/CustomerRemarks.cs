﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

/// <summary>
/// Summary description for CustomerRemarks
/// </summary>
public class CustomerRemarks
{
    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();
    string Oldconstring = ConfigurationManager.ConnectionStrings["TestOld"].ConnectionString.ToString();
    string reportconstring = ConfigurationManager.ConnectionStrings["reporTString"].ConnectionString.ToString();
    private DataTable dt;
    int RowAdded;
    DataWorksClass dw;
    FunctionClass fc;

	public CustomerRemarks()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public int InsertCustomerRemarks(string CrAcNo, DateTime AddDate, string Remarks, string AddUser, string BranchCode)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO LoanApplicantRemarks (CrAcNo,AddDate,Remarks,AddUser,BranchCode) values 
                     (@CrAcNo, @AddDate , @Remarks,@AddUser ,@BranchCode)");
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        dw.SetSqlCommandParameters("AddDate", AddDate);
        dw.SetSqlCommandParameters("Remarks", Remarks);
        dw.SetSqlCommandParameters("AddUser", AddUser);
        dw.SetSqlCommandParameters("BranchCode", BranchCode);
        return dw.Insert();
    }

    public string GetCustomerName(string CrAcNo)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select RTRIM(Initials) + ' ' + RTRIM(Surname) as FullName 
                        from CrHolder H, Customermain M where H.NicNo = M.NicNo
                        and H.CrAcNo=@CrAcNo and HolderType='P'");
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        return dw.GetSingleData();
    }

    public DataTable GetCustomerRemarks(string CrAcNo)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select AddDate, Remarks, AddUser from LoanApplicantRemarks where CrAcNo=@CrAcNo");
        dw.SetDataAdapterParameters("CrAcNo", CrAcNo);
        return dw.GetDataTable();
    }
}
