using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// Summary description for RiskAnalysis
/// </summary>
public class RiskAnalysis
{
    DataWorksClass dw;
    private SqlDataAdapter da;
    DataSet ds;
    private SqlConnection mycon;
    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();
    
    public RiskAnalysis()
	{
        //SqlConnection myconnection = new SqlConnection(ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString);
        //this.mycon = myconnection;
	}

    public int InsertIntoOtherInvestments(string appno, string NicNo, string FinanceIns, 
                                              string AcType, string AmountIns, int updatelevel)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO OtherInvestments (AppNo,NicNo,FinanceIns,AcType,AmountIns,UpdateLevel)
                       values (@appno,@NicNo,@FinanceIns,@AcType,@AmountIns,@updatelevel)");
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("NicNo", NicNo);
        dw.SetSqlCommandParameters("FinanceIns", FinanceIns);
        dw.SetSqlCommandParameters("AcType", AcType);
        dw.SetSqlCommandParameters("AmountIns", AmountIns);
        dw.SetSqlCommandParameters("updatelevel", updatelevel);
        return dw.Insert();
    }

    public int InsertIntoNSBInvestments(string appno, string nicno, string NSBAcType,
                                            string NSBAcNo, string NSBAmount, 
                                            int updatelevel)

    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO NSBInvestments (AppNo,NicNo,NSBAcType,NSBAcNo,NSBAmount,UpdateLevel)
                       values (@appno,@nicno,@NSBAcType,@NSBAcNo,@NSBAmount,@updatelevel)");
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("nicno", nicno);
        dw.SetSqlCommandParameters("NSBAcType", NSBAcType);
        dw.SetSqlCommandParameters("NSBAcNo", NSBAcNo);
        dw.SetSqlCommandParameters("NSBAmount", NSBAmount);
        dw.SetSqlCommandParameters("updatelevel", updatelevel);
        return dw.Insert();
    }

    public int InsertIntoLiabilities(string appno, string nicno, string Institue, string FacilityNat,
                                          string LiableAmt,
                                          string Instalment, int UpdateLevel)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO Liabilities (AppNo,NicNo,LaibleIns,FacilityNature,LiableAmt,Instalment,
                        UpdateLevel)values (@appno,@nicno,@Institue,@FacilityNat,@LiableAmt,@Instalment,@UpdateLevel)");
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("nicno", nicno);
        dw.SetSqlCommandParameters("Institue", Institue);
        dw.SetSqlCommandParameters("FacilityNat", FacilityNat);
        dw.SetSqlCommandParameters("LiableAmt", LiableAmt);
        dw.SetSqlCommandParameters("Instalment", Instalment);
        dw.SetSqlCommandParameters("UpdateLevel", UpdateLevel);
        return dw.Insert();
    }


    public int InsertIntoAppAsset(string appno, int asetid, string assetPar, string asetValue,
                                      string isObt)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO AppAssetDetails (AppNo,AssetId,AssetParticulars,AssetValue,IsObtained)
                       values (@appno,@asetid,@assetPar,@asetValue,@isObt)");
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("asetid", asetid);
        dw.SetSqlCommandParameters("assetPar", assetPar);
        dw.SetSqlCommandParameters("asetValue", asetValue);
        dw.SetSqlCommandParameters("isObt", isObt);
        return dw.Insert();
    }

    public DataTable GetAssetDetails(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"SELECT C.AssetId AS AssetId, * FROM AppAssetDetails A, AssetsCategories C 
                            WHERE AppNo=@appno AND C.AssetId*=A.AssetId");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();
    }

    public DataTable GetExistDetails(string appno, int asetid)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"SELECT AssetId FROM AppAssetDetails WHERE AppNo=@appno AND AssetId 
                            IN (SELECT AssetId FROM AssetsCategories) AND AssetId=@asetid");
        dw.SetDataAdapterParameters("appno", appno);
        dw.SetDataAdapterParameters("asetid", asetid);
        return dw.GetDataTable();
    }

    public int UpdateAssetDetails(string appno, int asetid, string assetPar, string asetValue,
                                      string isObt)
    {

        dw = new DataWorksClass(constring);
        dw.SetCommand(@"UPDATE AppAssetDetails SET AssetParticulars=@assetPar,AssetValue=@asetValue,
                       IsObtained=@isObt WHERE AppNo=@appno AND AssetId=@asetid");
        dw.SetSqlCommandParameters("assetPar", assetPar);
        dw.SetSqlCommandParameters("asetValue", asetValue);
        dw.SetSqlCommandParameters("isObt", isObt);
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("asetid", asetid);
        return dw.Update();
        
    }

    public DataTable GetOtherInvestments(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"SELECT Distinct A.NicNo AS NicNo,HolderType,FinanceIns,AcType,AmountIns 
                            FROM OtherInvestments O, AppHolder A WHERE A.AppNo=@appno AND A.AppNo*=O.AppNo 
                            AND A.NicNo*=O.NicNo ORDER BY HolderType");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();
    }

    public DataTable GetNSBInvestments(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"SELECT Distinct A.NicNo AS NicNo,HolderType,NSBAcType,NSBAcNo,NSBAmount
                            FROM NSBInvestments O, AppHolder A WHERE A.AppNo=@appno AND A.AppNo*=O.AppNo
                            AND A.NicNo*=O.NicNo ORDER BY HolderType");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();
    }

    public DataTable GetLiabilities(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"SELECT Distinct A.NicNo AS NicNo,HolderType,LaibleIns,FacilityNature,
                            LiableAmt, Instalment FROM Liabilities O, AppHolder A WHERE A.AppNo=@appno
                            AND A.AppNo*=O.AppNo AND A.NicNo*=O.NicNo ORDER BY HolderType");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();
    }

    public DataTable ExistOtherInvestment(string appno, string nicno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"SELECT * FROM OtherInvestments WHERE Appno=@appno AND NicNo=@nicno");
        dw.SetDataAdapterParameters("appno", appno);
        dw.SetDataAdapterParameters("nicno", nicno);
        return dw.GetDataTable();
    }

    public DataTable ExistNSBInvestments(string appno, string nicno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"SELECT * FROM NSBInvestments WHERE Appno=@appno AND NicNo=@nicno");
        dw.SetDataAdapterParameters("appno", appno);
        dw.SetDataAdapterParameters("nicno", nicno);
        return dw.GetDataTable();
    }

    public DataTable ExistLiabilities(string appno, string nicno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"SELECT * FROM Liabilities WHERE Appno=@appno AND NicNo=@nicno");
        dw.SetDataAdapterParameters("appno", appno);
        dw.SetDataAdapterParameters("nicno", nicno);
        return dw.GetDataTable();
    }

    public int UpdateOtherInvestments(string appno, string nicno, string FinanceIns, 
                                          string AcType, string AmountIns )
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"UPDATE OtherInvestments SET FinanceIns = @FinanceIns, AcType = @AcType, 
                       AmountIns=@AmountIns WHERE AppNo=@appno AND NicNo=@nicno");
        dw.SetSqlCommandParameters("FinanceIns", FinanceIns);
        dw.SetSqlCommandParameters("AcType", AcType);
        dw.SetSqlCommandParameters("AmountIns", AmountIns);
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("nicno", nicno);
        return dw.Update();
    }

    public int UpdateNSBInvestments(string appno, string nicno, string NSBAcType,
                                            string NSBAcNo, string NSBAmount)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"UPDATE NSBInvestments SET NSBAcType = @NSBAcType, NSBAcNo = @NSBAcNo, 
                       NSBAmount=@NSBAmount WHERE AppNo=@appno AND NicNo=@nicno");
        dw.SetSqlCommandParameters("NSBAcType", NSBAcType);
        dw.SetSqlCommandParameters("NSBAcNo", NSBAcNo);
        dw.SetSqlCommandParameters("NSBAmount", NSBAmount);
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("nicno", nicno);
        return dw.Update();
    }

    public int UpdateLiabilities(string appno, string nicno, string Institute, string FacilityNat,
                                     string LiableAmt,string Instalment)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"UPDATE Liabilities SET LaibleIns = @Institute, FacilityNature = @FacilityNat, 
                       LiableAmt=@LiableAmt, Instalment=@Instalment WHERE AppNo=@appno AND NicNo=@nicno");
        dw.SetSqlCommandParameters("Institute", Institute);
        dw.SetSqlCommandParameters("FacilityNat", FacilityNat);
        dw.SetSqlCommandParameters("LiableAmt", LiableAmt);
        dw.SetSqlCommandParameters("Instalment", Instalment);
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("nicno", nicno);
        return dw.Update();
    }
}
