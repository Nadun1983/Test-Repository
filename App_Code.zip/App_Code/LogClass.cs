﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.IO;

public class LogClass
{
    FunctionClass fc;
    string nowdate = DateTime.Now.ToString("yyyyMMdd");
    string nowtime = DateTime.Now.ToString("HHmmss");
    private string con = ConfigurationManager.ConnectionStrings["housdbString"].ToString();
    //refno = cracno/appno/transno/etc.....
    //insertparameters = inserted values of the data table: values should separated by ~ mark
    public void inputlogline(string refno,string datatable, string insertparameters, string userid,string brcode)
    {
        fc = new FunctionClass();
        DateTime sdate = fc.GetSystemDate("A");
        string sysdate = sdate.ToString("yyyyMMdd");
        writelog(nowdate + "|" + nowtime + "|" + sysdate + "|" + "I" + "|" + brcode + "|" + userid + "|" + refno + "|" + datatable + "|" + insertparameters + "|");
    }


    //insertparameters = inserted values of the data table: values should separated by ~ mark
    public void updatelogline(string refno, string datatable, string beforevalues, string aftervalues, string userid, string brcode)
    {
        fc = new FunctionClass();
        DateTime sdate = fc.GetSystemDate("A");
        string sysdate = sdate.ToString("yyyyMMdd");
        writelog(nowdate + "|" + nowtime + "|" + sysdate + "|" + "U" + "|" + brcode + "|" + userid + "|" + refno + "|" + datatable + "|" + beforevalues + "|" + aftervalues + "|");
    }


    //insertparameters = inserted values of the data table: values should separated by ~ mark
    public void deletelogline(string refno, string datatable, string wherevalues, string userid, string brcode)
    {
        fc = new FunctionClass();
        DateTime sdate = fc.GetSystemDate("A");
        string sysdate = sdate.ToString("yyyyMMdd");
        writelog(nowdate + "|" + nowtime + "|" + sysdate + "|" + "D" + "|" + brcode + "|" + userid + "|" + refno + "|" + datatable + "|" + wherevalues + "|");
    }
    //Any message
    public void logmessage(string userid, string message, string brcode)
    {
        fc = new FunctionClass();
        DateTime sdate = fc.GetSystemDate("A");
        string sysdate = sdate.ToString("yyyyMMdd");
        writelog(nowdate + "|" + nowtime + "|" + sysdate + "|" + "C" + "|" + brcode + "|" + userid + "|" + message + "|");
    }
    //System Log
    public void systemlogin(string userid, string pcip, string message, string brcode)
    {
        fc = new FunctionClass();
        DateTime sdate = fc.GetSystemDate("A");
        string sysdate = sdate.ToString("yyyyMMdd");
        writelog(nowdate + "|" + nowtime + "|" + sysdate + "|" + "L" + "|" + brcode + "|" + userid + "|" + pcip + "|" + message + "|");
    }
    //Page Access
    public void pageaccess(string userid, string page, string status, string brcode)
    {
        fc = new FunctionClass();
        DateTime sdate = fc.GetSystemDate("A");
        string sysdate = sdate.ToString("yyyyMMdd");
        writelog(nowdate + "|" + nowtime + "|" + sysdate + "|" + "P" + "|" + brcode + "|" + userid + "|" + page + "|" + status + "|");
    }


    private void writelog(string logline)
    {
        StreamWriter sw ;
        string logfilepath = @"C:\NCMSLogs\NCMSLog" + DateTime.Now.ToString("yyyyMMdd") + ".log";

        if (!File.Exists(logfilepath))
        {
            try
            {
                File.Create(logfilepath);
            }
            catch
            { }
        }
        else
        {
            try
            {
                using (sw = new StreamWriter(logfilepath, true))
                {
                    sw.BaseStream.Seek(0, SeekOrigin.End);
                    sw.WriteLine(logline);
                }
            }
            catch
            { }
        }
    }

    public DataTable GetBranches()
    {
        DataWorksClass dw = new DataWorksClass(con);
        dw.SetDataAdapter(@"SELECT [BranchNo], [BranchName] FROM [nsb_branch] order by branchname");
        return dw.GetDataTable();
    }
}
