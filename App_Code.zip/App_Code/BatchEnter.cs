﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

/// <summary>
/// Summary description for BatchEnter
/// </summary>
public class BatchEnter
{
    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ToString();
    //string reportString = ConfigurationManager.ConnectionStrings["reportCreditAdmin"].ToString();
    string crmastString = ConfigurationManager.ConnectionStrings["crmastString"].ToString();
    DataWorksClass dw;
    LastSerialClass ls;
    FunctionClass fc;
    DataTable dt;

    bool panelstatus;

    public bool Panelstatus
    {
        get{return this.panelstatus;}
    }

    public long GetBatchNo(DateTime date)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select max (batchno) from BatchHeader where batchdate=@batchdate");
        dw.SetSqlCommandParameters("batchdate", date);
        return long.Parse(dw.GetSingleData());
    }

    public int InsertBatchTransaction(string Batchno, DateTime BatchDate, string BatchType, string BatchDetail, string BatchUser, 
                                      DateTime Adddate,double Amount,string status)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into BatchHeader(Batchno,BatchDate,BatchType,BatchDetail,BatchUser,Adddate,status,Amount)
                          values (@Batchno,@BatchDate,@BatchType,@BatchDetail,@BatchUser,@Adddate,@status,@Amount)");
        dw.SetSqlCommandParameters("Batchno", Batchno);
        dw.SetSqlCommandParameters("BatchDate", BatchDate);
        dw.SetSqlCommandParameters("BatchType", BatchType);
        dw.SetSqlCommandParameters("BatchDetail", BatchDetail);
        dw.SetSqlCommandParameters("BatchUser", BatchUser);
        dw.SetSqlCommandParameters("Adddate", Adddate);
        dw.SetSqlCommandParameters("Amount", Amount);
        dw.SetSqlCommandParameters("status", status);
        return dw.Insert();
    }

    public DataTable GetBatchType(string Status)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select BatchType, BatchDetail from BatchType 
                            where Status=@Status order by refno");
        dw.SetDataAdapterParameters("Status", Status);
        return dw.GetDataTable();
    }

    public string GetHolderName(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select distinct rtrim(t.titledesc + ' ' + rtrim(m.initials)+' ' + rtrim(surname)) as custname
               from customermain m,crholder c, title t
               where m.nicno=c.nicno and t.titlecode=m.titlecode and c.cracno=@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return dw.GetSingleData();
    }

    public int InsertBatchTransaction(string BatchNo, DateTime BatchDate, string CrAcNo,DateTime TransDate, string AcSign, 
        double TrAmt, string TrDetail, string TaskId, string BatchType,string Status, bool IsGLUpdate,string Number,
        int BankName,int BranchName)
    {
        int oldtransNo = -99;
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO BatchTmp(BatchNo,BatchDate,CrAcNo,TransDate,AcSign,TrAmt,TrDetail,TaskId,oldtransNo,
                        BatchType,Status,IsGLUpdate,Number,BankName,BranchName)
                        VALUES (@BatchNo,@BatchDate,@CrAcNo,@TransDate,@AcSign,@TrAmt,@TrDetail,@TaskId,@oldtransNo,
                        @BatchType,@Status,@IsGLUpdate,@Number,@BankName,@BranchName)");
        dw.SetSqlCommandParameters("BatchNo", BatchNo);
        dw.SetSqlCommandParameters("BatchDate", BatchDate);
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        dw.SetSqlCommandParameters("TransDate", TransDate);
        dw.SetSqlCommandParameters("AcSign", AcSign);
        dw.SetSqlCommandParameters("TrAmt", TrAmt);
        dw.SetSqlCommandParameters("TrDetail", TrDetail);
        dw.SetSqlCommandParameters("TaskId", TaskId);
        dw.SetSqlCommandParameters("oldtransNo", oldtransNo);
        dw.SetSqlCommandParameters("BatchType", BatchType);
        dw.SetSqlCommandParameters("Status", Status);
        dw.SetSqlCommandParameters("IsGLUpdate", IsGLUpdate);
        dw.SetSqlCommandParameters("Number", Number);
        dw.SetSqlCommandParameters("BankName", BankName);
        dw.SetSqlCommandParameters("BranchName", BranchName);
        return dw.Insert();
    }   


    public string GetGlDescription(string cracno)
    {
       dw = new DataWorksClass(constring);
        dw.SetCommand(@"select gldesc from glcode where refglcode=@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return dw.GetSingleData();
    }

    public string GetDescripton(string cracno)
    {

        fc = new FunctionClass();
        string desc;
        switch (cracno.Substring(0, 1))
        {
            case "6":
                desc = GetHolderName(cracno);
                if (desc == "0")
                {
                    if (!fc.GetNicNo(cracno))
                    {
                        desc = GetHolderName(cracno);
                    }
                    else
                    {
                        this.panelstatus = true;
                        desc = "";
                    }
                }
                break;
            // can use to enter the NIC if there is no holder name
            case "9":
                desc = GetGlDescription(cracno);
                break;
            default:
                desc = "Error in Entry";
                break;
        }
        return desc;
    }


    public int SetTask(DropDownList ddlbatchtype, string cracno)
    {
        switch (cracno.Substring(0, 1))
        {
            case "6":
                ddlbatchtype.SelectedIndex = 0;
                break;

            case "9":
                ddlbatchtype.SelectedIndex = 4;
                break;

            default:
                ddlbatchtype.SelectedIndex = 4;
                break;
        }

        return ddlbatchtype.SelectedIndex;
    }


    public DataTable InsertRow(string cracno, string acsign, string taskid, string trDetail, double tramt, string transDate,
                               string dnumber, string dbankname, string dbranchname, DataTable dt)
    {
        DataRow dr;
        dr = dt.NewRow();
        dr["cracno"] = cracno;
        dr["acsign"] = acsign;
        dr["taskid"] = taskid;
        dr["trDetail"] = trDetail;
        dr["tramt"] = tramt;
        dr["transDate"] = transDate;
        dr["dnumber"] = dnumber;
        dr["dbankname"] = dbankname;
        dr["dbranchname"] = dbranchname;
        dt.Rows.Add(dr);
        return dt;
    }

     public DataTable SetDataTable(DataTable dt)
   {
       dt = new DataTable();
     
       DataColumn cracno;
       cracno = new DataColumn();
       cracno.DataType = Type.GetType("System.String");
       cracno.ColumnName = "cracno";
       dt.Columns.Add(cracno);

       DataColumn acsign;
       acsign = new DataColumn();
       acsign.DataType = Type.GetType("System.String");
       acsign.ColumnName = "acsign";
       dt.Columns.Add(acsign);

       DataColumn taskid;
       taskid = new DataColumn();
       taskid.DataType = Type.GetType("System.String");
       taskid.ColumnName = "taskid";
       dt.Columns.Add(taskid);

       DataColumn trDetail;
       trDetail = new DataColumn();
       trDetail.DataType = Type.GetType("System.String");
       trDetail.ColumnName = "trDetail";
       dt.Columns.Add(trDetail);

       DataColumn tramt;
       tramt = new DataColumn();
       tramt.DataType = Type.GetType("System.String");
       tramt.ColumnName = "tramt";
       dt.Columns.Add(tramt);

       DataColumn transDate;
       transDate = new DataColumn();
       transDate.DataType = Type.GetType("System.String");
       transDate.ColumnName = "transDate";
       dt.Columns.Add(transDate);

       DataColumn dnumber;
       dnumber = new DataColumn();
       dnumber.DataType = Type.GetType("System.String");
       dnumber.ColumnName = "dnumber";
       dt.Columns.Add(dnumber);

       DataColumn dbankname;
       dbankname = new DataColumn();
       dbankname.DataType = Type.GetType("System.String");
       dbankname.ColumnName = "dbankname";
       dt.Columns.Add(dbankname);

       DataColumn dbranchname;
       dbranchname = new DataColumn();
       dbranchname.DataType = Type.GetType("System.String");
       dbranchname.ColumnName = "dbranchname";
       dt.Columns.Add(dbranchname);

       return dt;
   }

    //vihanga 
     public DataTable GetBanks()
     {
         dw = new DataWorksClass(constring);
         dw.SetDataAdapter(@"select BankNo , BankName from Bank order by bankname");
         return dw.GetDataTable();
     }
    
    //vihanga 
     public DataTable GetBranch(/*string relevantBankNo*/)
     {
         dw = new DataWorksClass(constring);
         dw.SetDataAdapter(@"select branchno,branchname from branch order by branchname");
         return dw.GetDataTable();
     }

     public DataTable GetBranch(string bankno)
     {
         dw = new DataWorksClass(constring);
         dw.SetDataAdapter(@"select branchno,branchname from branch where bankno = @bankno order by branchname");
         dw.SetDataAdapterParameters("bankno", bankno);
         return dw.GetDataTable();
     }

    //vihanga
     public string GetBankName(string bankid)
     {
         dw = new DataWorksClass(constring);
         dw.SetCommand(@"select bankname from Bank where bankno=@bankid order by bankname");
         dw.SetSqlCommandParameters("bankid", bankid);
         return dw.GetSingleData();
     }

    //vihanga
     public string GetBranchName(string bankid, string branchNo)
     {
         dw = new DataWorksClass(constring);
         dw.SetCommand(@"select branchname from branch where bankno=@bankid and branchno=@branchNo order by branchname");
         dw.SetSqlCommandParameters("bankid",bankid);
         dw.SetSqlCommandParameters("branchNo", branchNo);
         return dw.GetSingleData();
     }

    //vihanga
     public DataTable GetLoanDetails(string cracno)
     {
         dw = new DataWorksClass(constring);
         dw.SetDataAdapter(@"select c.Nicno,(rtrim(c.initials) + ' ' + rtrim(c.surname)) as CustName , 
                            (rtrim(c.location)+' ' + rtrim(c.street) + ' ' + rtrim(c.city)) as Address ,
                            h.Instalment , h.Actoutbal as Outbal , 
                            (rtrim(year(h.lastcompletedduedate))+ '/' + rtrim(month(h.lastcompletedduedate))+'/'+
                            rtrim(day(h.lastcompletedduedate))) as DueDate,
                            (rtrim(year(h.lsttrdate))+ '/' + rtrim(month(h.lsttrdate))+'/'+rtrim(day(h.lsttrdate))) 
                            as LastTransActionDate from 
                            crholder cr, customermain c , housprop h
                            where cr.cracno=@cracno and c.nicno=cr.nicno and h.cracno=@cracno");
         dw.SetDataAdapterParameters("cracno", cracno);
         return dw.GetDataTable();
     }

    //vihanga
     public bool checkLoanClosed(string cracno)
     {
         dw = new DataWorksClass(constring);
         dt = new DataTable();
         double outbal=0;
            
         dw.SetDataAdapter(@"select actoutbal from housprop where cracno=@cracno");
         dw.SetDataAdapterParameters("cracno", cracno);
         dt = dw.GetDataTable();

         outbal = double.Parse(dt.Rows[0][0].ToString());

         if (outbal <= 0)
             return true;
         else
             return false;
         
     }

    //vihanga
     public DataTable GetGlAccDetails(string cracno)
     {
         dw = new DataWorksClass(constring);
         dw.SetDataAdapter(@"select gldesc as GlAccountdetails from glcode  where refglcode=@cracno");
         dw.SetDataAdapterParameters("cracno", cracno);
         return dw.GetDataTable();
     }

    //vihanga
     public DataTable GetBatchHeaderDetails(DateTime date)
     {
         dw = new DataWorksClass(constring);
         dw.SetDataAdapter(@"select * from BatchHeader where batchdate=@date and status<>'A'");
         dw.SetDataAdapterParameters("date", date);
         return dw.GetDataTable();
     }

     //vihanga 2010-04-16 
     //modify vihanga 2010-07-08
     public DataTable GetRelevantBatchData(string batchno)
     {
         dw = new DataWorksClass(constring);
         dw.SetDataAdapter(@"select b.Cracno,rtrim(day(b.TransDate))+ ' / ' + rtrim(month(b.TransDate))+' / ' +
                                rtrim(year(b.TransDate))  as TransDate,b.AcSign,b.TrAmt,b.Taskid,
                                b.BankName as BankNo,b.branchname as BranchNo,b.Number,b.RefNo,
                                (rtrim(m.initials) + ' ' + rtrim(m.surname) 
                                /*+ ' / ' + rtrim(m.location) + ','+rtrim(m.street)+','+rtrim(m.city) */
                                ) as OtherDetails from BatchTmp b ,crholder c,customermain m 
                                where b.batchno=@batchno and left(b.cracno,1)=6 and c.cracno = b.cracno 
                                and m.nicno = c.nicno and c.holdertype='P'
                                union 
                                select b.Cracno,rtrim(day(b.TransDate))+ ' / ' + rtrim(month(b.TransDate))+' / ' +
                                rtrim(year(b.TransDate))  as TransDate,b.AcSign,b.TrAmt,b.Taskid,
                                b.BankName as BankNo,b.branchname as BranchNo,b.Number,b.RefNo,
                                g.Gldesc as OtherDetails from BatchTmp b,glcode g 
                                where b.batchno=@batchno and left(b.cracno,1)=9 and g.refglcode = b.cracno
                                union 
                                select b.Cracno,rtrim(day(b.TransDate))+ ' / ' + rtrim(month(b.TransDate))+' / ' +
                                rtrim(year(b.TransDate))  as TransDate,b.AcSign,b.TrAmt,b.Taskid,
                                b.BankName as BankNo,b.branchname as BranchNo,b.Number,b.RefNo,
                                'INVALID NUMBER' as OtherDetails from BatchTmp b where  
                                b.batchno=@batchno and b.cracno=0 
                                union
                                select b.Cracno,rtrim(day(b.TransDate))+ ' / ' + rtrim(month(b.TransDate))+' / ' +
                                rtrim(year(b.TransDate))  as TransDate,b.AcSign,b.TrAmt,b.Taskid,
                                b.BankName as BankNo,b.branchname as BranchNo,b.Number,b.RefNo,
                                ('***NO DATA***') as OtherDetails from BatchTmp b 
                                where b.batchno=@batchno and b.cracno in 
                                (select cracno from batchtmp where batchno=@batchno and left(cracno,1)=6
                                and cracno not in (select cracno from crholder where holdertype='P'))
                                order by b.RefNo");
         dw.SetDataAdapterParameters("batchno", batchno);
         return dw.GetDataTable();
     }

//    //vihanga ******
//     public DataTable GetRelevantBatchData(string batchno)
//     {
//         dw = new DataWorksClass(constring);
//         dw.SetDataAdapter(@"select b.Cracno,
//                            rtrim(day(b.TransDate))+ ' / ' + rtrim(month(b.TransDate))+' / ' +
//                            rtrim(year(b.TransDate))  as TransDate,
//                            b.AcSign,b.TrAmt,b.Taskid,b.TrDetail,b.RefNo,
//                            (rtrim(m.initials) + ' ' + rtrim(m.surname) + ' / ' + rtrim(m.location) + ','+rtrim(m.street)+','
//                            +rtrim(m.city)) as OtherDetails 
//                            from BatchTmp b ,crholder c,customermain m where  
//                            b.batchno=@batchno and 
//                            left(b.cracno,1)=6 and c.cracno = b.cracno and m.nicno = c.nicno
//                            union 
//                            select b.Cracno,rtrim(day(b.TransDate))+ ' / ' + rtrim(month(b.TransDate))+' / ' +
//                            rtrim(year(b.TransDate))  as TransDate,b.AcSign,b.TrAmt,b.Taskid,b.TrDetail,b.RefNo,
//                            g.Gldesc as OtherDetails
//                            from BatchTmp b,glcode g 
//                            where b.batchno=@batchno and left(b.cracno,1)=9 and g.refglcode = b.cracno
//                            order by b.RefNo");
//         dw.SetDataAdapterParameters("batchno", batchno);
//         return dw.GetDataTable();
//     }

     //vihanga
     public int DeleteRecord(string refno)
     {
         dw = new DataWorksClass(constring);
         dw.SetCommand("delete from BatchTmp where refno=@refno");
         dw.SetSqlCommandParameters("refno", refno);
         return dw.Delete();
     }

     //vihanga
     public DataTable GetBatchHeaderMasterDetails(string batchno)
     {
         dw = new DataWorksClass(constring);
         dw.SetDataAdapter("select batchno,batchdate,batchtype,Amount from BatchHeader where batchno=@batchno");
         dw.SetDataAdapterParameters("batchno", batchno);
         return dw.GetDataTable();
     }

     //vihanga
     public string GetBatchHeaderBatchDetail(string batchno)
     {
         dw = new DataWorksClass(constring);
         dw.SetCommand(@"select batchdetail from BatchHeader where batchno=@batchno");
         dw.SetSqlCommandParameters("batchno", batchno);
         return dw.GetSingleData();
     }

     //vihanga
     public int UpdateBatchHeaderNew(string batchno, string batchdetail, double amount, DateTime batchdate)
     {
         dw = new DataWorksClass(constring);
         dw.SetCommand(@"update BatchHeader set batchdetail=@batchdetail,amount=@amount,batchdate=@batchdate where batchno=@batchno");
         dw.SetSqlCommandParameters("batchno", batchno);
         dw.SetSqlCommandParameters("batchdetail", batchdetail);
         dw.SetSqlCommandParameters("amount", amount);
         dw.SetSqlCommandParameters("batchdate", batchdate);
         return dw.Update();
     }

     //vihanga
     public int UpdateBatchTmpNew(string batchno, string trdetail, DateTime batchdate, string Number, string num, int bankname, int branchname)
     {
         dw = new DataWorksClass(constring);
         dw.SetCommand(@"update BatchTmp set trdetail=@trdetail,batchdate=@batchdate,number=@num,
                        bankname=@bankname,branchname=@branchname where 
                        trdetail like @Number + '|%'and batchno=@batchno");
         dw.SetSqlCommandParameters("batchno", batchno);
         dw.SetSqlCommandParameters("trdetail", trdetail);
         dw.SetSqlCommandParameters("batchdate", batchdate);
         dw.SetSqlCommandParameters("Number", Number);
         dw.SetSqlCommandParameters("number", num);
         dw.SetSqlCommandParameters("bankname", bankname);
         dw.SetSqlCommandParameters("branchname", branchname);
         return dw.Update();
     }

    //vihanga
     public DataTable GetGlNames()
     {
         dw = new DataWorksClass(constring);
         dw.SetDataAdapter(@"select gldesc,refglcode from glcode");
         return dw.GetDataTable();
     }

     //vihanga
     public DataTable GetBatchHeaderBatchDetail(string releBatchNo, string Number)
     {
         dw = new DataWorksClass(constring);
         dw.SetDataAdapter(@"select BatchDate,TrDetail,sum(tramt) as SumAmount from BatchTmp
                             where batchno=@releBatchNo and trdetail like @Number + '|%' group by batchdate,trdetail");
         dw.SetDataAdapterParameters("releBatchNo", releBatchNo);
         dw.SetDataAdapterParameters("Number", Number);
         return dw.GetDataTable();
     }

     //vihanga
     public bool validLoanNo(string cracno)
     {
         dw = new DataWorksClass(constring);
         string a = "";
         dw.SetCommand(@"select appno from crmast where cracno=@cracno");
         dw.SetSqlCommandParameters("cracno", cracno);
         a = dw.GetSingleData();
         try
         {
             if (a.Length > 5)
                 return true;
             else
                 return false;
         }
         catch (Exception invalidcracno)
         {
             return false;
         }
     }

     //vihanga
     public bool CheckBatchNo(string batchno)
     {
         dw = new DataWorksClass(constring);
         string tmp = "0";
         dw.SetCommand(@"select batchtype from BatchHeader where batchno=@batchno and status<>'A'");
         dw.SetSqlCommandParameters("batchno", batchno);
         tmp = dw.GetSingleData();

         if (tmp == "0")
             return false;
         else
             return true;
     }

     //vihanga
     public string GetNewGl(string oldglcode)
     {
         dw = new DataWorksClass(crmastString);
         dw.SetCommand(@"select newglcode from glcode where glcode=@oldglcode");
         dw.SetSqlCommandParameters("oldglcode", oldglcode);
         return dw.GetSingleData();
     }

     //vihanga
     public bool validateNumber(string bankname, string number)
     {
         string tmp = "0";
         dw = new DataWorksClass(constring);
         dw.SetCommand(@"select number from BatchTmp where bankname=@bankname and number=@number");
         dw.SetSqlCommandParameters("bankname",bankname);
         dw.SetSqlCommandParameters("number", number);
         tmp = dw.GetSingleData();
         if (tmp == "0")
             return false;
         else
             return true;
     }

     //vihanga
     public DataTable GetBatchDetails(string batchno)
     {
         dw = new DataWorksClass(constring);
         dw.SetDataAdapter(@"select distinct b.Refno,b.batchno, rtrim(bk.BankName)+' '+rtrim(b.bankname) as BankName,
                            b.bankname as BankCode,rtrim(br.BranchName)+' '+rtrim(b.branchname) as BranchName,
                            b.branchname as BranchNo,b.number,b.tramt,b.cracno,
                            h.Instalment, 
                            rtrim(day(h.Lastcompletedduedate))+ ' / ' + rtrim(month(h.Lastcompletedduedate))+' / ' +
                            rtrim(year(h.Lastcompletedduedate))  as Datedue, 
                            rtrim(day(b.TransDate))+ ' / ' + rtrim(month(b.TransDate))+' / ' +
                            rtrim(year(b.TransDate)) as OffDate
                            from BatchTmp b,housprop h,
                            Bank bk,branch br where 
                            h.cracno=b.cracno and bk.bankno=b.bankname and 
                            br.bankno=b.bankname and br.branchno=b.branchname and 
                            b.batchno=@batchno union all
                            select distinct b.Refno,b.batchno, rtrim(bk.BankName)+' '+rtrim(b.bankname) as BankName,
                            b.bankname as BankCode,rtrim(br.BranchName)+' '+rtrim(b.branchname) as BranchName,
                            b.branchname as BranchNo,b.number,b.tramt,b.cracno,0 as Instalment,
                            NULL as Datedue,rtrim(day(b.TransDate))+ ' / ' + rtrim(month(b.TransDate))+' / ' +
                            rtrim(year(b.TransDate)) as OffDate
                            from BatchTmp b,
                            glcode g,Bank bk,branch br where g.refglcode=b.cracno and
                            bk.bankno=b.bankname and br.bankno=b.bankname and 
                            br.branchno=b.branchname and b.batchno=@batchno
                            order by --b.refno
                            bankcode,branchno,number,b.refno");
         dw.SetDataAdapterParameters("batchno", batchno);
         return dw.GetDataTable();
     }

     //vihanga
     public string GetCustDetails(string cracno)
     {
         if (cracno.Substring(0, 1) == "6") //Loan number
         {
             string tmp = "";
             dt = new DataTable();
             dw = new DataWorksClass(constring);
             dw.SetDataAdapter(@"select rtrim(m.initials) + ' ' + rtrim(m.surname) as Details from crholder c,customermain m
                             where c.cracno=@cracno and m.nicno=c.nicno");
             dw.SetDataAdapterParameters("cracno", cracno);
             dt = dw.GetDataTable();

             for (int a = 0; a < dt.Rows.Count; a++)
             {
                 tmp += dt.Rows[a]["Details"].ToString();

                 if (dt.Rows.Count != (a + 1))
                     tmp += "\n";
             }

             return tmp;
         }
         else //gl number
         {
             string tmp = "";
             dw = new DataWorksClass(constring);
             dw.SetCommand(@"select gldesc from glcode where refglcode=@cracno");
             dw.SetSqlCommandParameters("cracno", cracno);
             tmp = dw.GetSingleData();
             return tmp;
         }

     }

    //vihanga
    public string GetBatchName(string batchno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select t.batchdetail from batchheader b,batchtype t
                        where b.batchno=@batchno and t.batchtype=b.batchtype");
        dw.SetSqlCommandParameters("batchno", batchno);
        return dw.GetSingleData();
    }


    public DataTable GetBatchReportTable(string batchnumber)
    {
        DataTable bindTable = new DataTable();
        DataTable tmpdata = new DataTable();
                
        fc = new FunctionClass();

        string Refno = "";
        string batchno = "";
        string BankName = "";
        string BankCode = "";
        string BranchName = "";
        string BranchNo = "";
        string number = "";
        double tramt = 0;
        double Instalment = 0;
        string Datedue = "";
        string Offdate = "";
        string oldLoanNo = "";

        tmpdata = GetBatchDetails(batchnumber);
        string cracno = "";
        string Detail = "";
        string tmpDetail = "";
        //create datatable
        bindTable = SetDataTableBatchReport(bindTable);

        for (int a = 0; a < tmpdata.Rows.Count; a++)
        {
            Refno = tmpdata.Rows[a]["Refno"].ToString();
            batchno = tmpdata.Rows[a]["batchno"].ToString();
            BankName = tmpdata.Rows[a]["BankName"].ToString();
            BankCode = tmpdata.Rows[a]["BankCode"].ToString();
            BranchName = tmpdata.Rows[a]["BranchName"].ToString();
            BranchNo = tmpdata.Rows[a]["BranchNo"].ToString();
            number = tmpdata.Rows[a]["number"].ToString();
            tramt = double.Parse(tmpdata.Rows[a]["tramt"].ToString());
            Instalment = double.Parse(tmpdata.Rows[a]["Instalment"].ToString());
            Datedue = tmpdata.Rows[a]["Datedue"].ToString();
            cracno = tmpdata.Rows[a]["cracno"].ToString();
            oldLoanNo = GetoldAcNo(cracno);
            Detail = GetCustDetails(cracno);
            Offdate = tmpdata.Rows[a]["Offdate"].ToString();

            tmpDetail = GetDetailUsingRefno(Refno);
            tmpDetail = GetNecDataFromtrDetail(tmpDetail);
            Detail = Detail + tmpDetail;

            bindTable = InsertRowBatchReport(Refno, batchno, BankName, BankCode, BranchName, BranchNo,
                        number, tramt, cracno, oldLoanNo, Instalment, Datedue, Detail, Offdate, bindTable);
        }

        return bindTable;
    }

    //155
    private string GetNecDataFromtrDetail(string tmpDetail)
    {
        string stringForarrays = "";
        try
        {
            string[] ArrayString = new string[5];
            ArrayString = tmpDetail.Split('|');
            stringForarrays = "| " + ArrayString[5].ToString();
        }
        catch (Exception er)
        {
            //
        }
        return stringForarrays;
    }

    private string GetDetailUsingRefno(string refno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select trdetail from batchtmp where refno=@refno");
        dw.SetSqlCommandParameters("refno", refno);
        return dw.GetSingleData();
    }

    private DataTable SetDataTableBatchReport(DataTable dt)
    {
        dt = new DataTable();

        DataColumn Refno;
        Refno = new DataColumn();
        Refno.DataType = Type.GetType("System.String");
        Refno.ColumnName = "Refno";
        dt.Columns.Add(Refno);

        DataColumn batchno;
        batchno = new DataColumn();
        batchno.DataType = Type.GetType("System.String");
        batchno.ColumnName = "batchno";
        dt.Columns.Add(batchno);

        DataColumn BankName;
        BankName = new DataColumn();
        BankName.DataType = Type.GetType("System.String");
        BankName.ColumnName = "BankName";
        dt.Columns.Add(BankName);

        DataColumn BankCode;
        BankCode = new DataColumn();
        BankCode.DataType = Type.GetType("System.String");
        BankCode.ColumnName = "BankCode";
        dt.Columns.Add(BankCode);

        DataColumn BranchName;
        BranchName = new DataColumn();
        BranchName.DataType = Type.GetType("System.String");
        BranchName.ColumnName = "BranchName";
        dt.Columns.Add(BranchName);

        DataColumn BranchNo;
        BranchNo = new DataColumn();
        BranchNo.DataType = Type.GetType("System.String");
        BranchNo.ColumnName = "BranchNo";
        dt.Columns.Add(BranchNo);

        DataColumn number;
        number = new DataColumn();
        number.DataType = Type.GetType("System.String");
        number.ColumnName = "number";
        dt.Columns.Add(number);


        DataColumn tramt;
        tramt = new DataColumn();
        tramt.DataType = Type.GetType("System.Decimal");
        tramt.ColumnName = "tramt";
        dt.Columns.Add(tramt);

        DataColumn cracno;
        cracno = new DataColumn();
        cracno.DataType = Type.GetType("System.String");
        cracno.ColumnName = "cracno";
        dt.Columns.Add(cracno);

        DataColumn oldLoanNo;
        oldLoanNo = new DataColumn();
        oldLoanNo.DataType = Type.GetType("System.String");
        oldLoanNo.ColumnName = "oldLoanNo";
        dt.Columns.Add(oldLoanNo);

        DataColumn Instalment;
        Instalment = new DataColumn();
        Instalment.DataType = Type.GetType("System.Decimal");
        Instalment.ColumnName = "Instalment";
        dt.Columns.Add(Instalment);

        DataColumn Datedue;
        Datedue = new DataColumn();
        Datedue.DataType = Type.GetType("System.String");
        Datedue.ColumnName = "Datedue";
        dt.Columns.Add(Datedue);

        DataColumn Detail;
        Detail = new DataColumn();
        Detail.DataType = Type.GetType("System.String");
        Detail.ColumnName = "Detail";
        dt.Columns.Add(Detail);

        DataColumn Offdate;
        Offdate = new DataColumn();
        Offdate.DataType = Type.GetType("System.String");
        Offdate.ColumnName = "Offdate";
        dt.Columns.Add(Offdate);

        return dt;
    }

    private DataTable InsertRowBatchReport(string Refno, string batchno, string BankName, string BankCode, string BranchName, string BranchNo, string number,
                               double tramt, string cracno, string oldLoanNo,double Instalment, string Datedue, string Detail, string Offdate, DataTable dt)
    {
        DataRow dr;
        dr = dt.NewRow();
        dr["Refno"] = Refno;
        dr["batchno"] = batchno;
        dr["BankName"] = BankName;
        dr["BankCode"] = BankCode;
        dr["BranchName"] = BranchName;
        dr["BranchNo"] = BranchNo;
        dr["number"] = number;
        dr["tramt"] = tramt;
        dr["cracno"] = cracno;
        dr["oldLoanNo"] = oldLoanNo;
        dr["Instalment"] = Instalment;
        dr["Datedue"] = Datedue;
        dr["Detail"] = Detail;
        dr["Offdate"] = Offdate;
        dt.Rows.Add(dr);
        return dt;
    }

    //
    public DataTable GetLen13Number()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select refno,cracno from batchtmp where len(cracno)=13");
        return dw.GetDataTable();
    }

    //
    public int correctBatchTmp(string refno, string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update batchtmp set cracno=@cracno where refno=@refno");
        dw.SetSqlCommandParameters("refno", refno);
        dw.SetSqlCommandParameters("cracno", cracno);
        return dw.Update();

    }

    public string ValidateOldNumber(string oldacno/*, string brachno*/)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select cracno from crmast where oldacno=@oldacno");
        dw.SetSqlCommandParameters("oldacno", oldacno);
        return dw.GetSingleData();
    }

    public DataTable GetRVSbatchReportTable(string batchno)
    {
        DataTable bindTable = new DataTable();
        DataTable tmpdata = new DataTable();
        fc = new FunctionClass();
       
        string Transdate = "";
        string acno = "";
        string acsign = "";
        double amount = 0;
        string oldacno = "";
        string trdetails = "";
        string acname = "";
        string refno = "";
        string trtype = "";
        double instalment = 0;

        tmpdata = GetRVSBatchDetails(batchno);
        string cracno = "";
        string Detail = "";

        //create datatable
        bindTable = SetDataTableRVSBatchReport(bindTable);

        for (int a = 0; a < tmpdata.Rows.Count; a++)
        {
            Transdate = tmpdata.Rows[a]["transdate"].ToString();
            acno = tmpdata.Rows[a]["acno"].ToString();
            refno = tmpdata.Rows[a]["refno"].ToString();
            acsign = tmpdata.Rows[a]["acsign"].ToString();
            trtype = tmpdata.Rows[a]["trtype"].ToString();
            amount = double.Parse(tmpdata.Rows[a]["amount"].ToString());
            trdetails = tmpdata.Rows[a]["trdetails"].ToString();
            //trdetails = trdetails.Substring(15, trdetails.Length - 15); change on 2010/07/07
            trdetails = trdetails.Substring(0, 16);

            if (acno.Substring(0, 1) == "6")
            {
                oldacno = GetoldAcNo(acno);
                instalment = Getinstalment(acno);
            }
            else
            {
                oldacno = "0";
                instalment = 0;
            }

            acname = GetCustDetails(acno);

            bindTable = InsertRowRVSBatchReport(Transdate, acno, refno, acsign, trtype, amount, instalment, trdetails, oldacno, acname, bindTable);
        }

        return bindTable;
    }

    private double Getinstalment(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select instalment from housprop where cracno=@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return double.Parse(dw.GetSingleData());
    }

    private DataTable InsertRowRVSBatchReport(string transdate,string acno,string refno,string acsign,string trtype,double amount,
                                              double instalment,string trdetails, string oldacno, string acname, DataTable dt)
    {
        DataRow dr;
        dr = dt.NewRow();
        dr["transdate"] = transdate;
        dr["acno"] = acno;
        dr["refno"] = refno;
        dr["acsign"] = acsign;
        dr["trtype"] = trtype;
        dr["amount"] = amount;
        dr["instalment"] = instalment;
        dr["trdetails"] = trdetails;
        dr["oldacno"] = oldacno;
        dr["acno"] = acno;
        dr["acname"] = acname;
        dt.Rows.Add(dr);
        return dt;
    }

    private string GetoldAcNo(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select oldacno from crmast where cracno=@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return dw.GetSingleData();
    }

    private DataTable SetDataTableRVSBatchReport(DataTable bindTable)
    {
        dt = new DataTable();
        
        DataColumn transdate;
        transdate = new DataColumn();
        transdate.DataType = Type.GetType("System.String");
        transdate.ColumnName = "transdate";
        dt.Columns.Add(transdate);

        DataColumn acno;
        acno = new DataColumn();
        acno.DataType = Type.GetType("System.String");
        acno.ColumnName = "acno";
        dt.Columns.Add(acno);

        DataColumn refno;
        refno = new DataColumn();
        refno.DataType = Type.GetType("System.String");
        refno.ColumnName = "refno";
        dt.Columns.Add(refno);

        DataColumn acsign;
        acsign = new DataColumn();
        acsign.DataType = Type.GetType("System.String");
        acsign.ColumnName = "acsign";
        dt.Columns.Add(acsign);

        DataColumn trtype;
        trtype = new DataColumn();
        trtype.DataType = Type.GetType("System.String");
        trtype.ColumnName = "trtype";
        dt.Columns.Add(trtype);

        DataColumn amount;
        amount = new DataColumn();
        amount.DataType = Type.GetType("System.Double");
        amount.ColumnName = "amount";
        dt.Columns.Add(amount);

        DataColumn instalment;
        instalment = new DataColumn();
        instalment.DataType = Type.GetType("System.Double");
        instalment.ColumnName = "instalment";
        dt.Columns.Add(instalment);       


        DataColumn trdetails;
        trdetails = new DataColumn();
        trdetails.DataType = Type.GetType("System.String");
        trdetails.ColumnName = "trdetails";
        dt.Columns.Add(trdetails);

        DataColumn oldacno;
        oldacno = new DataColumn();
        oldacno.DataType = Type.GetType("System.String");
        oldacno.ColumnName = "oldacno";
        dt.Columns.Add(oldacno);

        DataColumn acname;
        acname = new DataColumn();
        acname.DataType = Type.GetType("System.String");
        acname.ColumnName = "acname";
        dt.Columns.Add(acname);

        return dt;
    }


    private DataTable GetRVSBatchDetails(string batchno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select rtrim(day(transdate))+ ' / ' + rtrim(month(transdate))+' / ' +
                                    rtrim(year(transdate))  as transdate,cracno as acno,refno,acsign,taskid as trtype,
                                    tramt as amount,trdetail as trdetails
                                    from batchtmp where batchno=@batchno order by refno");
        dw.SetDataAdapterParameters("batchno", batchno);
        return dw.GetDataTable();
    }


    public DataTable GetBatchGlAmounts(string batchno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select b.cracno,g.gldesc,b.acsign, sum(b.tramt)as Amount 
                            from batchtmp b,glcode g
                            where left(b.cracno,1)=9 and b.batchno=@batchno and g.refglcode=b.cracno
                            group by b.cracno,g.gldesc,b.acsign union
                            select 0 as cracno,'Loan Accounts' as gldesc,b.acsign,sum(b.tramt)as Amount 
                            from batchtmp b
                            where left(b.cracno,1)=6 and b.batchno=@batchno group by b.acsign");
        dw.SetDataAdapterParameters("batchno", batchno);
        return dw.GetDataTable();
    }



    public string GetSelectBatchType(string batchno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select batchtype from batchheader where batchno=@batchno");
        dw.SetSqlCommandParameters("batchno", batchno);
        return dw.GetSingleData();
    }

    public string GetBatchDate(string batchno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select rtrim(day(batchdate))+ '/ ' + rtrim(month(batchdate)) + '/ ' + 
                       rtrim(year(batchdate)) as batchdate  from batchheader where batchno=@batchno");
        dw.SetSqlCommandParameters("batchno", batchno);
        return dw.GetSingleData();
    }

    public bool isBatchConfirm(string batchno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select distinct transno from batchtmp where batchno=@batchno");
        dw.SetSqlCommandParameters("batchno", batchno);
        string tmp = dw.GetSingleData();
        if (tmp.Length > 3)
            return true;
        else
            return false;
    }
    
    public int UpdateRecord(string Cracno, DateTime TransDate, string AcSign, double TrAmt, string Taskid, string bankname,string branchname,
                            string number,string trdetail,string refno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update batchtmp set Cracno=@Cracno,TransDate=@TransDate,AcSign=@AcSign,TrAmt=@TrAmt,Taskid=@Taskid,bankname=@bankname,
                       branchname=@branchname,number=@number,trdetail=@trdetail where refno=@refno");
        dw.SetSqlCommandParameters("Cracno", Cracno);
        dw.SetSqlCommandParameters("TransDate", TransDate);
        dw.SetSqlCommandParameters("AcSign", AcSign);
        dw.SetSqlCommandParameters("TrAmt", TrAmt);
        dw.SetSqlCommandParameters("Taskid", Taskid);
        dw.SetSqlCommandParameters("bankname", bankname);
        dw.SetSqlCommandParameters("branchname", branchname);
        dw.SetSqlCommandParameters("number", number);
        dw.SetSqlCommandParameters("trdetail", trdetail);
        dw.SetSqlCommandParameters("refno", refno);
        return dw.Update();
    }

    public DataTable GetRelevantBatchDataMain(string batchno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select distinct b.BatchNo,bk.bankname,b.Bankname as Bankcode,
                            br.branchname,b.BranchName as BranchCode,b.Number,sum(b.tramt) as Amount 
                            from batchtmp b ,bank bk ,branch br where b.batchno=@batchno and
                            bk.bankno=b.bankname and br.bankno=bk.bankno and br.branchno=b.BranchName
                            group by b.BatchNo,b.Bankname,b.BranchName,b.Number,bk.bankname,br.branchname");
        dw.SetDataAdapterParameters("batchno", batchno);
        return dw.GetDataTable();
    }

    public DataTable GetRelevantMasterData(string batchno, string BankName, string BranchName, string Number)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select distinct CONVERT(VARCHAR(10), BatchDate, 103) as BatchDate,
                            CONVERT(VARCHAR(10), TransDate, 103) as TransDate,BankName,BranchName,Number from batchtmp  
                            where batchno=@batchno and BankName=@BankName and BranchName=@BranchName and Number=@Number");
        dw.SetDataAdapterParameters("batchno", batchno);
        dw.SetDataAdapterParameters("bankname", BankName);
        dw.SetDataAdapterParameters("BranchName", BranchName);
        dw.SetDataAdapterParameters("Number", Number);
        return dw.GetDataTable();
    }

    public int UpdateRelevantMasterData(DateTime BatchDate, DateTime TransDate, string BankName, string BranchName,
                                        string Number, string batchno,string exisBatchNumber)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update batchtmp set BatchDate=@BatchDate,TransDate=@TransDate,BankName=@BankName,BranchName=@BranchName
                        ,Number=@Number where batchno=@batchno");
        dw.SetSqlCommandParameters("BatchDate", BatchDate);
        dw.SetSqlCommandParameters("TransDate", TransDate);
        dw.SetSqlCommandParameters("BankName", BankName);
        dw.SetSqlCommandParameters("BranchName", BranchName);
        dw.SetSqlCommandParameters("Number", Number);
        dw.SetSqlCommandParameters("batchno", batchno);
        dw.SetSqlCommandParameters("exisBatchNumber", exisBatchNumber);
        return dw.Update();
    }
 
    public void InsertBulkBatch(DataTable tmpDatatTable)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand();
        dw.InsertBulk(tmpDatatTable, "batchtmp");
    }

    //2010-04-22
    public DataTable GettmpTableBatch(string batchno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from tmptablebatch where batchno=@batchno order by refno");
        dw.SetDataAdapterParameters("batchno", batchno);
        return dw.GetDataTable();
    }
    
    //2010-04-22
    public int InsertRowtoTmpBatchTable(string cracno, string acsign, string taskid, string trdetail, double tramt, string trdate, string dnumber, string dbankname, string dbranchname, string batchno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into tmptablebatch(batchno,cracno,acsign,taskid,trdetail,tramt,trdate,dnumber,dbankname,dbranchname)
                        values( @batchno, @cracno, @acsign, @taskid, @trdetail, @tramt, @trdate, @dnumber, @dbankname, @dbranchname)");
        dw.SetSqlCommandParameters("batchno", batchno);
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("acsign", acsign);
        dw.SetSqlCommandParameters("taskid", taskid);
        dw.SetSqlCommandParameters("trdetail", trdetail);
        dw.SetSqlCommandParameters("tramt", tramt);
        dw.SetSqlCommandParameters("trdate", trdate);
        dw.SetSqlCommandParameters("dnumber", dnumber);
        dw.SetSqlCommandParameters("dbranchname", dbranchname);
        dw.SetSqlCommandParameters("dbankname", dbankname);
        return dw.Insert();
    }

    //2010-04-22
    public int deleteTmpRecords(string batchNo)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"delete from tmptablebatch where batchNo=@batchNo");
        dw.SetSqlCommandParameters("batchNo", batchNo);
        return dw.Delete();
    }

    //2010-04-22
    public double GettmpTableBatchCr(string batchno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select isnull((sum(tramt)),0) as Amount from tmptablebatch where acsign='CR' and batchno=@batchno");
        dw.SetSqlCommandParameters("batchno", batchno);
        return double.Parse(dw.GetSingleData());
    }

    //2010-04-22
    public double GettmpTableBatchDr(string batchno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select isnull((sum(tramt)),0) as Amount from tmptablebatch where acsign='DR' and batchno=@batchno");
        dw.SetSqlCommandParameters("batchno", batchno);
        return double.Parse(dw.GetSingleData());
    }

    //2010-04-22
    public int deleteTmpSingleRecord(string batchno, string refno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"delete from tmptablebatch where batchNo=@batchNo and refno=@refno");
        dw.SetSqlCommandParameters("batchno", batchno);
        dw.SetSqlCommandParameters("refno", refno);
        return dw.Delete();
    }

    //2010-04-22
    public bool validGLNo(string glcode)
    {
        dw = new DataWorksClass(crmastString);
        dw.SetCommand(@"select newglcode from glcode where glcode=@glcode");
        dw.SetSqlCommandParameters("glcode", glcode);
        string tmp = dw.GetSingleData();
        long tmpLong = 0;

        try
        {
            tmpLong = long.Parse(tmp);
            if (tmpLong == 0)
                return false;
            else
                return true;
        }
        catch (Exception e)
        {
            return false;
        }
    }

    //2010-04-23
    public bool validNewGLNo(string refglcode)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select refglcode from glcode where refglcode=@refglcode");
        dw.SetSqlCommandParameters("refglcode", refglcode);
        string tmp = dw.GetSingleData();
        long tmpLong = 0;

        try
        {
            tmpLong = long.Parse(tmp);
            if (tmpLong == 0)
                return false;
            else
                return true;
        }
        catch (Exception e)
        {
            return false;
        }        
    }

    //2010-04-25
    public DataTable GetChequeDetail(string number)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select b.BatchNo,b.Number,b.Status,bnk.bankname,b.bankname as Bankcode,br.branchname,
                            rtrim(day(b.BatchDate))+ '/ ' + rtrim(month(b.BatchDate)) + '/ ' + 
                            rtrim(year(b.BatchDate)) as BatchDate,b.BatchType
                            ,sum(b.tramt) as TotAmount 
                            from batchtmp b,bank bnk,branch br
                            where b.batchtype='CHQ' and b.isglupdate=0 and b.number=@number 
                            and br.bankno=b.bankname and 
                            br.branchno=b.branchname and bnk.bankno=b.bankname and b.status <> 'X'
                            group by b.BatchNo,b.Number,b.Status,bnk.bankname,br.branchname,
                            BatchDate,b.bankname,b.BatchType");
        dw.SetDataAdapterParameters("number", number);
        return dw.GetDataTable();
    }

    //2010-04-25
    public DataTable GetChequeRealizeDetail(string number)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select b.BatchNo,b.Number,b.Status,bnk.bankname,b.bankname as Bankcode,br.branchname,
                            rtrim(day(b.BatchDate))+ '/ ' + rtrim(month(b.BatchDate)) + '/ ' + 
                            rtrim(year(b.BatchDate)) as BatchDate,b.BatchType
                            ,sum(b.tramt) as TotAmount 
                            from batchtmp b,bank bnk,branch br
                            where b.batchtype='CHQ' and b.isglupdate=0 and b.BatchNo=@number 
                            and br.bankno=b.bankname and 
                            br.branchno=b.branchname and bnk.bankno=b.bankname and b.status <> 'X'
                            group by b.BatchNo,b.Number,b.Status,bnk.bankname,br.branchname,
                            BatchDate,b.bankname,b.BatchType");
        dw.SetDataAdapterParameters("number", number);
        return dw.GetDataTable();
    }

    //2010-04-25
    public bool isChequeConfirm(string number)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select distinct transno from batchtmp where number=@number");
        dw.SetSqlCommandParameters("number", number);
        string tmp = dw.GetSingleData();
        if (tmp.Length > 3)
            return true;
        else
            return false;
    }

    //2010-04-25
    public int changeChequeStatus(string number, string bankname, string status)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update batchtmp set status=@status where number=@number and bankname=@bankname");
        dw.SetSqlCommandParameters("number", number);
        dw.SetSqlCommandParameters("bankname", bankname);
        dw.SetSqlCommandParameters("status", status);
        return dw.Update();
    }

    //2010-04-26
    public DataTable recordsReadyToConfirm(string batchno, string batchtype)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select TrDetail,Acsign,TrAmt from batchtmp where batchno=@batchno and 
                            batchtype=@batchtype and status='A' and isglupdate=0");
        dw.SetDataAdapterParameters("batchno",batchno);
        dw.SetDataAdapterParameters("batchtype", batchtype);
        return dw.GetDataTable();
    }

    //2010-04-26
    public DataTable RealizeChequesReadyToConfirm(string batchno, string batchtype)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select Acsign,TrAmt from batchtmp where batchno=@batchno and 
                            batchtype=@batchtype and status='F' and isglupdate=0");
        dw.SetDataAdapterParameters("batchno", batchno);
        dw.SetDataAdapterParameters("batchtype", batchtype);
        return dw.GetDataTable();
    }

    //2010-04-26
    public DataTable GetChequeRealizeData(string batchno, string batchtype)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select distinct b.Refno,b.batchno, rtrim(bk.BankName)+' '+rtrim(b.bankname) as BankName,
                            b.bankname as BankCode,rtrim(br.BranchName)+' '+rtrim(b.branchname) as BranchName,
                            b.branchname as BranchNo,b.number,b.tramt,b.cracno,
                            h.Instalment, 
                            rtrim(day(h.Lastcompletedduedate))+ ' / ' + rtrim(month(h.Lastcompletedduedate))+' / ' +
                            rtrim(year(h.Lastcompletedduedate))  as Datedue, 
                            rtrim(day(b.TransDate))+ ' / ' + rtrim(month(b.TransDate))+' / ' +
                            rtrim(year(b.TransDate)) as OffDate
                            from BatchTmp b,housprop h, 
                            Bank bk,branch br where 
                            h.cracno=b.cracno and bk.bankno=b.bankname and 
                            br.bankno=b.bankname and br.branchno=b.branchname and 
                            b.batchno=@batchno  and b.isglupdate=0 and b.status<>'R'
                            union all
                            select distinct b.Refno,b.batchno, rtrim(bk.BankName)+' '+rtrim(b.bankname) as BankName,
                            b.bankname as BankCode,rtrim(br.BranchName)+' '+rtrim(b.branchname) as BranchName,
                            b.branchname as BranchNo,b.number,b.tramt,b.cracno,0 as Instalment,
                            NULL as Datedue,rtrim(day(b.TransDate))+ ' / ' + rtrim(month(b.TransDate))+' / ' +
                            rtrim(year(b.TransDate)) as OffDate
                            from BatchTmp b,
                            glcode g,Bank bk,branch br where 
                            g.refglcode=b.cracno and
                            bk.bankno=b.bankname and br.bankno=b.bankname and br.branchno=b.branchname 
                            and b.batchno=@batchno and b.isglupdate=0 and b.status<>'R' order by b.refno");
        dw.SetDataAdapterParameters("batchno", batchno);
        dw.SetDataAdapterParameters("batchtype", batchtype);
        return dw.GetDataTable();
    }

    //2010-04-26
    public DataTable GetChequeRealizeBatchReportTable(string batchnumber)
    {
        DataTable bindTable = new DataTable();
        DataTable tmpdata = new DataTable();

        fc = new FunctionClass();

        string Refno = "";
        string batchno = "";
        string BankName = "";
        string BankCode = "";
        string BranchName = "";
        string BranchNo = "";
        string number = "";
        double tramt = 0;
        double Instalment = 0;
        string Datedue = "";
        string Offdate = "";
        string oldLoanNo = "";

        tmpdata = GetChequeRealizeData(batchnumber, "CHQ");
        string cracno = "";
        string Detail = "";

        //create datatable
        bindTable = SetDataTableBatchReport(bindTable);

        for (int a = 0; a < tmpdata.Rows.Count; a++)
        {
            Refno = tmpdata.Rows[a]["Refno"].ToString();
            batchno = tmpdata.Rows[a]["batchno"].ToString();
            BankName = tmpdata.Rows[a]["BankName"].ToString();
            BankCode = tmpdata.Rows[a]["BankCode"].ToString();
            BranchName = tmpdata.Rows[a]["BranchName"].ToString();
            BranchNo = tmpdata.Rows[a]["BranchNo"].ToString();
            number = tmpdata.Rows[a]["number"].ToString();
            tramt = double.Parse(tmpdata.Rows[a]["tramt"].ToString());
            Instalment = double.Parse(tmpdata.Rows[a]["Instalment"].ToString());
            Datedue = tmpdata.Rows[a]["Datedue"].ToString();
            cracno = tmpdata.Rows[a]["cracno"].ToString();
            oldLoanNo = GetoldAcNo(cracno);
            Detail = GetCustDetails(cracno);
            Offdate = tmpdata.Rows[a]["Offdate"].ToString();

            bindTable = InsertRowBatchReport(Refno, batchno, BankName, BankCode, BranchName, BranchNo,
                        number, tramt, cracno, oldLoanNo, Instalment, Datedue, Detail, Offdate, bindTable);
        }

        InsertBulkChequeRealize(bindTable);

        return bindTable;
    }

    public void InsertBulkChequeRealize(DataTable bindTable)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand();
        dw.InsertBulk(bindTable, "ChequeRealizeDetails");
    }

    //2010-04-29
    public string GetNewLoanNumber(string oldacno)
    {
        string tmp = "";
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select Cracno from crmast where oldacno=@oldacno");
        dw.SetSqlCommandParameters("oldacno", oldacno);
        tmp = dw.GetSingleData();

        try
        {
            long cracno = long.Parse(tmp);
            return cracno.ToString();
        }

        catch (Exception er)
        {
            return oldacno;
        }

    }

    //2010-04-30
    public int UpdateBatchHeaderNew(string batchno, string batchtype, string status)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update batchheader set status=@status where batchno=@batchno and batchtype=@batchtype");
        dw.SetSqlCommandParameters("batchno", batchno);
        dw.SetSqlCommandParameters("batchtype", batchtype);
        dw.SetSqlCommandParameters("status", status);
        return dw.Update();
    }

    //2010-04-30
    public string GetBatchHeaderStatus(string batchno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select status from batchheader where batchno=@batchno");
        dw.SetSqlCommandParameters("batchno", batchno);
        return dw.GetSingleData();
    }
    
    //2010-07-08
    public string GetBatchTypeFromBatchtmp(string refno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select batchtype from batchtmp where refno=@refno");
        dw.SetSqlCommandParameters("refno", refno);
        return dw.GetSingleData();
    }

    public string getbatchTypeUsingBatchNo(string batchno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select batchtype from batchheader where batchno=@batchno");
        dw.SetSqlCommandParameters("batchno", batchno);
        return dw.GetSingleData();
    }

    public int changeBatchHeaderBatchDate(string batchno, DateTime batchdate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update batchheader set batchdate=@batchdate where batchno=@batchno");
        dw.SetSqlCommandParameters("batchno", batchno);
        dw.SetSqlCommandParameters("batchdate", batchdate);
        return dw.Update();
    }

    public int changeBatchTmpBatchDate(string batchno, DateTime batchdate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update batchtmp set batchdate=@batchdate where batchno=@batchno");
        dw.SetSqlCommandParameters("batchno", batchno);
        dw.SetSqlCommandParameters("batchdate", batchdate);
        return dw.Update();
    }

    public int deleteChequeRealize(string batchno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"delete from ChequeRealizeDetails where batchno=@batchno");
        dw.SetSqlCommandParameters("batchno", batchno);
        return dw.Delete();
    }

    #region MonthEndBatch
    public string MonthEndBatchTranfer(string dateKey, string user, string statusId)
    {
        //is done month end process
        if (IsMonthEndDone(dateKey))
        {
            dt = new DataTable();
            dt = GetGlData(statusId);
            string rows = insertBatchDate(dt, user, statusId);
            return rows;
        }
        else
        {
            return "Need to run The Interest Provision previously";
        }
    }

    private string insertBatchDate(DataTable dt, string user, string statusId)
    {
        DateTime batchdate = DateTime.Parse(dt.Rows[0][0].ToString());
        double trAmt = 0;
        string cracno, acSign, TaskId = "0";
        int Rows = 0;
        string Month = batchdate.Month.ToString();

        string Description = "0|7000|0308|RVS|" + user + "|MonthEndPro|" + Month;
        long batchno = GetBatchNo(batchdate) + 1;
        InsertBatchTransaction(batchno.ToString(), batchdate, "RVS", "MonthEnd", "BatchUser", System.DateTime.Now, 0, "X");

        for (int a = 0; a < dt.Rows.Count; a++)
        {
            trAmt = double.Parse(dt.Rows[a][1].ToString());
            cracno = dt.Rows[a][2].ToString();
            acSign = dt.Rows[a][4].ToString();
            TaskId = dt.Rows[a][5].ToString();
            Rows = InsertBatchTransaction(batchno.ToString(), batchdate, cracno, batchdate, acSign, trAmt, Description, TaskId, "RVS", "X", false, "NULL", 7000, 308);
        }

        //Update IntProvisionIndividual
        Rows = Rows + UpdateIntProvisionIndividual(batchdate, batchno, int.Parse(statusId));

        return Rows + "Rows Updated And Batch Number is " + batchno;
    }

    private int UpdateIntProvisionIndividual(DateTime trdate, long status, int statusId)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update ProvisionBatchDetails set status=@status where trdate=@trdate and status=@statusId");
        dw.SetSqlCommandParameters("trdate", trdate);
        dw.SetSqlCommandParameters("status", status);
        dw.SetSqlCommandParameters("statusId", statusId);
        return dw.Update();
    }

    private DataTable GetGlData(string status)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select* from ProvisionBatchDetails where status=@status");
        dw.SetDataAdapterParameters("status", status);
        return dw.GetDataTable();
    }

    private bool IsMonthEndDone(string datekey)
    {
        datekey = datekey.Substring(4, 4) + datekey.Substring(2, 2) + datekey.Substring(0, 2);
        dt = new DataTable();
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select count(*) from IntProvisionIndividual where datekey=@datekey");
        dw.SetSqlCommandParameters("datekey", datekey);
        int rows = int.Parse(dw.GetSingleData());
        if (rows > 0)
            return true;
        else
            return false;
    }

    #endregion

    #region monthend reversal
    public string insertBatchDataToRevesal(DataTable dt, string user, string oldbatchno)
    {
        fc = new FunctionClass();
        DateTime batchdate = fc.GetSystemDate("A");
        DateTime trdate = DateTime.Parse(dt.Rows[0][0].ToString());
        double trAmt = 0;
        string cracno, acSign, newacsign, TaskId = "0";
        int Rows = 0;
        string Month = batchdate.Month.ToString();

        string Description = "0|7000|0308|RVS|" + user + "|MonthEndReverse|" + Month;
        long batchno = GetBatchNo(batchdate) + 1;
        InsertBatchTransaction(batchno.ToString(), batchdate, "RVS", "MonthEnd", "BatchUser", System.DateTime.Now, 0, "X");

        for (int a = 0; a < dt.Rows.Count; a++)
        {
            trAmt = double.Parse(dt.Rows[a][5].ToString());
            cracno = dt.Rows[a][1].ToString();
            acSign = dt.Rows[a][3].ToString();
            TaskId = dt.Rows[a][4].ToString();
            if (acSign == "CR")
                newacsign = "DR";
            else
                newacsign = "CR";

            Rows = InsertBatchTransaction(batchno.ToString(), batchdate, cracno, batchdate, newacsign, trAmt, Description, TaskId, "RVS", "X", false, "NULL", 7000, 308);
        }

        //Update IntProvisionIndividual
        Rows = Rows + UpdateReverseStatus(trdate, batchno, oldbatchno);

        return Rows + "Rows Updated And Batch Number is " + batchno;
    }

    private int UpdateReverseStatus(DateTime trdate, long ReverseBatchno, string oldbatchno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update ProvisionBatchDetails set ReverseBatchno=@ReverseBatchno where trdate=@trdate and status=@oldbatchno");
        dw.SetSqlCommandParameters("trdate", trdate);
        dw.SetSqlCommandParameters("ReverseBatchno", ReverseBatchno);
        dw.SetSqlCommandParameters("oldbatchno", oldbatchno);
        return dw.Update();
    }

    #endregion

//For the purpose of Government Loans
    //---------------------------------------------- 2012/07/18 ----------------------------------------------------------
    public int GetLoanCategory(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select crcat from housprop where cracno=@cracno and actoutbal > 0");
        dw.SetSqlCommandParameters("cracno", cracno);
        return int.Parse(dw.GetSingleData());
    }

    public string GetAppNo(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select appno from crmast where cracno=@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return dw.GetSingleData();
    }

    public DataTable LoadGovernmentLoan(string appno, int crcat)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select appno,h.cracno,h.instalment,h.intrate,actoutbal,crdes
                            from crmast c, housprop h, crcategory r where appno=@appno and
                            c.cracno=h.cracno and actoutbal > 0 and h.crcat=4
                            and h.crcat=r.crcatcode order by h.cracno");
        dw.SetDataAdapterParameters("appno", appno);
        dw.SetDataAdapterParameters("crcat", crcat);
        return dw.GetDataTable();
    }
    //---------------------------------------------------------------------------------------------------------------------

}
