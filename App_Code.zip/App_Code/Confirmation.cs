using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// Summary description for Commision
/// </summary>
public class Confirmation
{
    public Confirmation()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    SqlConnection myconnection = new SqlConnection(ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString);
    private SqlDataAdapter sqlAdapter;
    private SqlCommand sqlCmd;
    private DataTable dt;

    string conString = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();
    DataWorksClass dw;

    public int SendConfirmationLetter(long AppNo, string IncomeType,string Status,string AddUser,DateTime SendDate,string NICNo, int UpdateLevel)
    {
        string sqlInsert;
        string sqlError;       

        sqlInsert = @"insert into IncomeConfirm (AppNo,IncomeType,SendDate,Status,AddUser,AddDate,NICNo,UpdateLevel) 
                      values(@AppNo,@IncomeType,@SendDate,@Status,@AddUser,@AddDate,@NICNo,@UpdateLevel)";

        sqlCmd = new SqlCommand(sqlInsert, myconnection);

        sqlCmd.Parameters.AddWithValue("AppNo",AppNo);       
        sqlCmd.Parameters.AddWithValue("IncomeType", IncomeType);
        sqlCmd.Parameters.AddWithValue("SendDate", SendDate);
        sqlCmd.Parameters.AddWithValue("Status", Status);
        sqlCmd.Parameters.AddWithValue("AddUser", AddUser);
        sqlCmd.Parameters.AddWithValue("AddDate", SendDate);
        sqlCmd.Parameters.AddWithValue("NICNo", NICNo);
        sqlCmd.Parameters.AddWithValue("UpdateLevel", UpdateLevel);

        int rowadd = 0;
        try
        {
            myconnection.Open();
            rowadd = sqlCmd.ExecuteNonQuery();
        }
        catch (Exception er)
        {
            sqlError = er.Message;
        }
        finally
        {
            myconnection.Close();
        }
        return rowadd;
    }

    public int ReceieveConfimationLetter(long AppNo, string ReferenceNo, DateTime RecvDate, string Status, DateTime ConfirmDate,
                                         int UpdateLevel, string NicNo)
    {
        //want to change ConfirmBy string to int

        string SqlUpdate;
        string SqlError;

        SqlUpdate = @"update IncomeConfirm set ReferenceNo=@ReferenceNo , RecvDate=@RecvDate ,  Status=@Status , 
                      ConfirmDate=@ConfirmDate where AppNo=@AppNo and UpdateLevel=@UpdateLevel and NicNo=@NicNo";

        sqlCmd = new SqlCommand(SqlUpdate, myconnection);

        sqlCmd.Parameters.AddWithValue("AppNo", AppNo);
        sqlCmd.Parameters.AddWithValue("ReferenceNo", ReferenceNo);
        sqlCmd.Parameters.AddWithValue("RecvDate", RecvDate);
        sqlCmd.Parameters.AddWithValue("Status", Status);        
        sqlCmd.Parameters.AddWithValue("ConfirmDate", ConfirmDate);
        sqlCmd.Parameters.AddWithValue("UpdateLevel", UpdateLevel);
        sqlCmd.Parameters.AddWithValue("NicNo", NicNo);

        int RowAdd = 0;
        try
        {
            myconnection.Open();
            RowAdd = sqlCmd.ExecuteNonQuery();
        }
        catch (Exception er)
        {
            SqlError = er.Message;
        }
        finally
        {
            myconnection.Close();
        }
        return RowAdd;
    }

    public DataTable GetApplicant(long AppNo)
    {
        string sqlSelect = @"select rtrim(Surname + Initials) as fullname , ah.NicNo as NIC from CustomerMain cm , appholder ah
                           where cm.NicNo=ah.NicNo and ah.AppNo=@AppNo
                            union
                            select rtrim(Surname + Initials) as fullname , ah.NicNo as NIC from CustomerMain cm , AppSecGarant ah
                            where cm.NicNo=ah.NicNo and ah.AppNo=@AppNo"; // changed 2011-08-17

        sqlAdapter = new SqlDataAdapter(sqlSelect, myconnection);

        sqlAdapter.SelectCommand.Parameters.AddWithValue("AppNo", AppNo);

        dt = new DataTable();

        try
        {
            myconnection.Open();
            sqlAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }
        finally
        {
            myconnection.Close();
        }

        return dt;

    }

    public int UpdateApproval(long AppNo)
    {
        string SqlUpdate;
        string SqlError;

        SqlUpdate = @"update ApprovalStatus set IsIncomeOK=1 where AppNo=@AppNo";

        sqlCmd = new SqlCommand(SqlUpdate, myconnection);

        sqlCmd.Parameters.AddWithValue("AppNo", AppNo);       

        int RowAdd = 0;

        try
        {
            myconnection.Open();
            RowAdd = sqlCmd.ExecuteNonQuery();
        }

        catch (Exception er)
        {
            SqlError = er.Message;
        }

        finally
        {
            myconnection.Close();
        }

        return RowAdd;
    }

    public DataTable GetIncomeDetails(long AppNo)
    {
        string sqlSelect;
        string Error;

        sqlSelect = @"select AppNo,CustNo,IncomeType,SendDate,RecvDate,Status, NICNo from IncomeConfirm 
                    where AppNo=@AppNo and updatelevel=-100";

        sqlAdapter = new SqlDataAdapter(sqlSelect, myconnection);

        sqlAdapter.SelectCommand.Parameters.AddWithValue("AppNo", AppNo);

        dt = new DataTable();

        try
        {
            myconnection.Open();
            sqlAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            Error = er.ToString();
        }
        finally
        {
            myconnection.Close();
        }

        return dt;
    }

    public int UpdateApprovalReject(long AppNo)
    {
        string sqlUpdate;
        string Error;

        sqlUpdate = @"update ApprovalStatus set IsIncomeOK=1 where AppNo=@AppNo";

        sqlCmd = new SqlCommand(sqlUpdate, myconnection);

        sqlCmd.Parameters.AddWithValue("AppNo", AppNo);

        int rowadded = -99;

        try
        {
            myconnection.Open();
            rowadded = sqlCmd.ExecuteNonQuery();
        }
        catch (Exception er)
        {
            Error = er.ToString();
        }
        finally
        {
            myconnection.Close();
        }

        return rowadded;
    }

    public int UpdateIncomeConfrmUser(long AppNo, string ConfirmBy)
    {
        string sqlUpdate;
        string Error;

        sqlUpdate = @"update IncomeConfirm set ConfirmBy=@ConfirmBy where AppNo=@AppNo";

        sqlCmd = new SqlCommand(sqlUpdate, myconnection);

        sqlCmd.Parameters.AddWithValue("AppNo", AppNo);
        sqlCmd.Parameters.AddWithValue("ConfirmBy", ConfirmBy);

        int rowadded = -99;

        try
        {
            myconnection.Open();
            rowadded = sqlCmd.ExecuteNonQuery();
        }
        catch (Exception err)
        {
            Error = err.ToString();
        }
        finally
        {
            myconnection.Close();
        }

        return rowadded;
    }

    //updates 2008/12/22 vihanga

    public int CheckSendConfLetter(long Appno, string nicno)
    {
        string sqlSelect;
        string Error;
        dt = new DataTable();

        sqlSelect = @"select * from IncomeConfirm where appno=@Appno and nicno=@nicno";

        sqlAdapter = new SqlDataAdapter(sqlSelect, myconnection);

        sqlAdapter.SelectCommand.Parameters.AddWithValue("Appno", Appno);
        sqlAdapter.SelectCommand.Parameters.AddWithValue("nicno", nicno);

        try
        {
            myconnection.Open();
            sqlAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            Error = er.ToString();
        }
        finally
        {
            myconnection.Close();
        }

        return (dt.Rows.Count);
    }

    //2011-08-17
    public bool isApplicant(long appno, string nicno)
    {
        dw = new DataWorksClass(conString);
        dt = new DataTable();
        dw.SetDataAdapter(@"select * from AppHolder where appno=@appno and nicno=@nicno");
        dw.SetDataAdapterParameters("appno", appno);
        dw.SetDataAdapterParameters("nicno", nicno);
        dt = dw.GetDataTable();
        if (dt.Rows.Count > 0)
            return true;
        else
            return false;
    }
}
