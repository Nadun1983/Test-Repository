using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data;
using System.Data.SqlClient;


/// <summary>
/// Summary description for cashier
/// </summary>
public class Recovery
{
    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();
    string Oldconstring = ConfigurationManager.ConnectionStrings["TestOld"].ConnectionString.ToString();
    string reportconstring = ConfigurationManager.ConnectionStrings["reporTString"].ConnectionString.ToString();
    private SqlDataAdapter sqldataadap;
    private SqlCommand sqlcmd;
    private DataTable dt;
    int RowAdded;
    DataWorksClass dw;
    FunctionClass fc;
    RecoveryProcesClass rpc;
    DateTime nextdue;

    public Recovery()
    {
        //
        // TODO: Add constructor logic here
        //
    }


    public string GetGracePeriod(string cracno)
    {
        string graceperiod = "0";
        dw = new DataWorksClass(constring);
        dw.SetCommand(@" select graceperiod from housprop  where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        graceperiod = dw.GetSingleData();
        return graceperiod;
    }

    public string GetRate(int ratecode)
    {
        string rate = "0";
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select RateAmt from RateCode where ratecode = @ratecode");
        dw.SetSqlCommandParameters("ratecode", ratecode);
        rate = dw.GetSingleData();
        return rate;
    }
    private double GetPenal(int count, double instalment, double penalinterest)
    {
        double penal = (instalment * penalinterest * count) / 1200;
        return penal;
    }

    public double CalculateIntAmount(double outbal, double intrate)
    {
        return Math.Round(outbal * intrate / 1200, 2);
    }

    public double CalculateCapital(double installment, double intAmount)
    {
        return installment - intAmount;
    }



    public int GetFactorial(int number)
    {
        int result = 1;
        while (number >= 1)
        {
            result = result * number;
            number--;
        }

        return result;
    }


    //2008-12-30
    //Get CashiersNames
    public DataTable GetCashierNames()
    {
        dt = new DataTable();
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select username,userid from users where status='A'");
        dt = dw.GetDataTable();
        return dt;
    }

    //Get Cash Box Names
    public DataTable GetCashBoxNames()
    {
        dt = new DataTable();
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select cashboxno from cashbox");
        dt = dw.GetDataTable();
        return dt;
    }

    //Get cash box begin bal as well as beginbal=previous day 'Dayend' balance
    public DataTable GetDayEndCashBoxBal(string cashboxno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select beginbal,ToDaycr,todaydr from cashbox where cashboxno=@cashboxno");
        dw.SetDataAdapterParameters("cashboxno", cashboxno);
        dt = dw.GetDataTable();
        return dt;
    }


    //update cashbox in the morning when cash Assing to CashBox and Cashier
    public int MorningUpdateCashBox(int cashboxno, double beginbal, string OfficerId)
    {
        int rowAdded;
        DateTime workdate = Convert.ToDateTime(System.DateTime.Now.ToShortDateString());
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update cashbox set workdate=@workdate , beginbal=@beginbal , 
                      todaycr=0 , todaydr=0 , OfficerId=@OfficerId , IsReleased='N'
                      where cashboxno=@cashboxno and status='A'");
        dw.SetSqlCommandParameters("workdate", workdate);
        dw.SetSqlCommandParameters("beginbal", beginbal);
        dw.SetSqlCommandParameters("cashboxno", cashboxno);
        dw.SetSqlCommandParameters("OfficerId", OfficerId);
        rowAdded = dw.Update();
        return rowAdded;
    }

    //update UserCash in the morning when cash Assing to CashBox and Cashier
    public int MorningUpdateUserCash(string userid, int cashboxno, DateTime workdate, double beginbal, string officergiven)
    {
        int rowAdded = 0;
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into usercash(userid,cashboxno,workdate,nooftime,beginbal,officergiven,updatelevel) values
                      (@userid,@cashboxno,@workdate,2,@beginbal,@officergiven,-100)");
        dw.SetSqlCommandParameters("userid", userid);
        dw.SetSqlCommandParameters("cashboxno", cashboxno);
        dw.SetSqlCommandParameters("workdate", workdate);
        dw.SetSqlCommandParameters("beginbal", beginbal);
        dw.SetSqlCommandParameters("officergiven", officergiven);
        rowAdded = dw.Insert();
        return rowAdded;
    }

    //Data to show when cashier view to accept the cash box
    public DataTable GetCashBoxDetailstoCashier(DateTime workdate, string userid)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select officergiven,cashboxno,beginbal from usercash 
                        where workdate=@workdate and userid=@userid");
        dw.SetDataAdapterParameters("workdate", workdate);
        dw.SetDataAdapterParameters("userid", userid);
        dt = dw.GetDataTable();
        return dt;
    }

    //Confirm Cashier Recv CashBox Update table cashbox , UserCash
    public int ConfrmCashierRecvCashBox(string officerrecv, int cashboxno)
    {
        int RowAdded = 0;
        DateTime workdate = Convert.ToDateTime(System.DateTime.Now.ToShortDateString());
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update usercash set officerrecv=@officerrecv where cashboxno=@cashboxno and workdate=@workdate 
                       and userid=@officerrecv");
        dw.SetSqlCommandParameters("cashboxno", cashboxno);
        dw.SetSqlCommandParameters("officerrecv", officerrecv);
        dw.SetSqlCommandParameters("workdate", workdate);
        RowAdded = dw.Update();
        return RowAdded;
    }

    public int ConfrmCashierRecvCashBoxusercash(string officerId, int cashboxno)
    {
        int RowAdded;
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update cashbox set isreleased='Y' , officerId=@officerId where cashboxno=@cashboxno");
        dw.SetSqlCommandParameters("cashboxno", cashboxno);
        dw.SetSqlCommandParameters("officerId", officerId);
        RowAdded = dw.Update();
        return RowAdded;
    }

    //2009-01-02
    //Cashier Assign EndAssignOfficer
    public int CashierEndAssignOfficer(int cashboxno, string EndAssingOfficer)
    {
        DateTime workdate = Convert.ToDateTime(System.DateTime.Now.ToShortDateString());
        int rowAdded;
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update usercash set EndAssingOfficer=@EndAssingOfficer where cashboxno=@cashboxno and workdate=@workdate");
        dw.SetSqlCommandParameters("cashboxno", cashboxno);
        dw.SetSqlCommandParameters("EndAssingOfficer", EndAssingOfficer);
        dw.SetSqlCommandParameters("workdate", workdate);
        rowAdded = dw.Update();
        return rowAdded;
    }

    //Cash Officer accept the Day End CashBox
    public int CashOfficerCashBoxDayEnd(int cashboxno, string EndAssingOfficer, double beginbal, double todaycr, double todaydr)
    {
        int RowAdded = 0;
        dw = new DataWorksClass(constring);
        DateTime workdate = Convert.ToDateTime(System.DateTime.Now.ToShortDateString());
        dw.SetCommand(@"update usercash set IsEndOfficerRecv=1 , todaycr=@todaycr , todaydr=@todaydr 
                       where cashboxno=@cashboxno and workdate=@workdate and EndAssingOfficer=@EndAssingOfficer and beginbal=@beginbal");
        dw.SetSqlCommandParameters("cashboxno", cashboxno);
        dw.SetSqlCommandParameters("EndAssingOfficer", EndAssingOfficer);
        dw.SetSqlCommandParameters("workdate", workdate);
        dw.SetSqlCommandParameters("beginbal", beginbal);
        dw.SetSqlCommandParameters("todaycr", todaycr);
        dw.SetSqlCommandParameters("todaydr", todaydr);
        RowAdded = dw.Update();
        return RowAdded;
    }

    public int CashOfficerCashBoxDayEndcashbox(int cashboxno, string officerId)
    {
        int RowAdded = 0;
        dw = new DataWorksClass(constring);
        DateTime workdate = Convert.ToDateTime(System.DateTime.Now.ToShortDateString());
        dw.SetCommand(@"update cashbox set isreleased='N' , officerId=@officerId where cashboxno=@cashboxno");
        dw.SetSqlCommandParameters("cashboxno", cashboxno);
        dw.SetSqlCommandParameters("officerId", officerId);
        RowAdded = dw.Update();
        return RowAdded;
    }

    //Assign InterCashier TransAction
    public int AssignInterCashierTransaction(string userid, string in_out, double amount, string refid)
    {
        DateTime adddate = Convert.ToDateTime(System.DateTime.Now.ToShortDateString());
        string addtime = System.DateTime.Now.ToShortTimeString();
        int Rowadded = 0;
        fc = new FunctionClass();
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into cashmvmnt values('A',@userid,@in_out,@amount,@refid,@adddate,@addtime,0)");
        dw.SetSqlCommandParameters("userid", userid);
        dw.SetSqlCommandParameters("in_out", in_out);
        dw.SetSqlCommandParameters("amount", amount);
        dw.SetSqlCommandParameters("refid", refid);
        dw.SetSqlCommandParameters("adddate", adddate);
        dw.SetSqlCommandParameters("addtime", addtime);
        Rowadded = dw.Insert();
        return Rowadded;
    }

    //Get Intercashier TYransaction Accept Details
    public DataTable GetInterCashierDetails(string refid)
    {
        dt = new DataTable();
        dw = new DataWorksClass(constring);
        DateTime adddate = Convert.ToDateTime(System.DateTime.Now.ToShortDateString());
        dw.SetDataAdapter(@"select userid,amount from cashmvmnt where refid=@refid and adddate=@adddate and isaccept=0");
        dw.SetDataAdapterParameters("refid", refid);
        dw.SetDataAdapterParameters("adddate", adddate);
        dt = dw.GetDataTable();
        return dt;
    }

    //Accept Intercashier Transaction
    public int AcceptInterCashierTransaction(string refid)
    {
        dt = new DataTable();
        dw = new DataWorksClass(constring);
        int Rowadded = 0;
        DateTime adddate = Convert.ToDateTime(System.DateTime.Now.ToShortDateString());
        dw.SetCommand(@"update cashmvmnt set isaccept=1 where refid=@refid and adddate=@adddate");
        dw.SetSqlCommandParameters("refid", refid);
        dw.SetSqlCommandParameters("adddate", adddate);
        Rowadded = dw.Update();
        return Rowadded;
    }

    //Check weather Loan fully Disbursed
    public string IsFullyDisbTrans(string cracno)
    {
        dt = new DataTable();
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select isdisbursed from housprop where cracno=@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return dw.GetSingleData();
    }

    //2009-03-13 vihanga **
    //Get Customer Details
    public DataTable GetCustomerdetails(string cracno)
    {
        dt = new DataTable();
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select cr.Cracno as LoanNumber ,rtrim(titledesc)+ ' ' + rTrim(c.INitials) + ' ' + rTrim(c.Surname) as [Name],
                            rtrim(c.location)+' '+rtrim(c.street)+' '+rtrim(c.city) as Address ,
                            c.NicNo, Holdertype, h.crperiod as Instalments from customermain c, appholder a , Crmast cr, title t,
                            housprop h
                            where c.nicno = a.nicno and a.appno = cr.appno and c.titlecode=t.titlecode and cr.cracno=@cracno
                            and  cr.cracno=h.cracno
                            order by holdertype");
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }



    // Edited  to update housprop at transaction *** *
    //    public int UpdateActHousprop(string cracno, long disbrefno, string taskid)
    //    {
    //        dt = new DataTable(); 
    //        double grantamount = GetGrantAmt(cracno);
    //        double capitalrecovered = GetCapitalRecovery(cracno, disbrefno, taskid);
    //        double ActOutbal = grantamount - capitalrecovered;
    //        dw = new DataWorksClass(constring);

    //        dt = GetPaymentHistoryData(cracno);
    //        if (dt.Rows.Count != 0)
    //        {
    //            DateTime LastCompletedDueDate = Convert.ToDateTime(dt.Rows[0][0].ToString());
    //            if (LastCompletedDueDate == DateTime.Parse("01/01/1900"))
    //           { 
    //                LastCompletedDueDate = GetDueDate(cracno);
    //            }
    //            int PaidInstalments = Convert.ToInt32(dt.Rows[0][1].ToString());

    //            DateTime workdate = Convert.ToDateTime(System.DateTime.Now.ToShortDateString());
    //            dw.SetCommand(@"update housprop set ActOutbal=@ActOutbal,
    //                            PaidInstalments=@PaidInstalments,
    //                            LastCompletedDueDate=@LastCompletedDueDate 
    //                            where cracno=@cracno");
    //            dw.SetSqlCommandParameters("ActOutbal", ActOutbal);
    //            dw.SetSqlCommandParameters("cracno", cracno);
    //            dw.SetSqlCommandParameters("LastCompletedDueDate", LastCompletedDueDate);
    //            dw.SetSqlCommandParameters("PaidInstalments", PaidInstalments);
    //            //dw.SetSqlCommandParameters("PenalValidDate", PenalValidDate);
    //            return dw.Update();
    //        }
    //        else
    //        {
    //            return 0;
    //        }
    //    }
    // Amila 78//2009
    public int UpdateHouspropCaprecovery(string cracno, string transno, string taskid, DateTime LstPaiddate, DateTime LstTrDate)
    {
        DateTime datedue = GetDatedue(cracno, transno);
        DateTime LastCompletedDueDate;
        fc = new FunctionClass();
        dt = new DataTable();

        double actoutbal = GetOutBal(cracno);
        double capitalrecovered = GetCapitalRecovery(cracno, transno, taskid, "CR") - GetCapitalRecovery(cracno, transno, taskid, "DR");
        actoutbal -= capitalrecovered;
        dw = new DataWorksClass(constring);
        int crcat = GetCategory(cracno);
        LastCompletedDueDate = fc.SetRecoveryProcessDate(LstTrDate, cracno);
        //if (crcat != 6)
        //{
        //    dt = GetPaymentHistoryData(cracno, "CAPD");
        //}
        //else
        //{
        //    dt = GetPaymentHistoryData(cracno, "INTR");
        //}
        //if (dt.Rows.Count != 0)
        //{
        //    LastCompletedDueDate = Convert.ToDateTime(dt.Rows[0]["Datedue"].ToString());
        //    string trstatus = dt.Rows[0]["trstatus"].ToString();
        //    switch (trstatus)
        //    {
        //        case "N":
        //            LastCompletedDueDate = LastCompletedDueDate;
        //            break;

        //        case "P":
        //            LastCompletedDueDate = LastCompletedDueDate;
        //            break;

        //        case "F":
        //            LastCompletedDueDate = LastCompletedDueDate;
        //            break;
        //    }
        //}
        //else
        //{
        //    LastCompletedDueDate = GetDueDate(cracno);
        //}

        // LastCompletedDueDate = GetLDatefromPaidDate(LstTrDate);

        int PaidInstalments = GetPaidInstalment(cracno, transno);
        DateTime penalvaliddate = fc.SetRecoveryProcessDate(LstTrDate, cracno);
        dw.SetCommand(@"update housprop set ActOutbal=@ActOutbal, outbal=@outbal, datedue=@datedue, penalvaliddate=@penalvaliddate,
                            PaidInstalments=@PaidInstalments, LstPaiddate=@LstPaiddate, LstTrDate=@LstTrDate,
                            LastCompletedDueDate=@LastCompletedDueDate 
                            where cracno=@cracno");
        dw.SetSqlCommandParameters("ActOutbal", actoutbal);
        dw.SetSqlCommandParameters("outbal", actoutbal);
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("LastCompletedDueDate", LastCompletedDueDate);
        dw.SetSqlCommandParameters("datedue", LastCompletedDueDate);
        dw.SetSqlCommandParameters("PaidInstalments", PaidInstalments);
        dw.SetSqlCommandParameters("LstPaiddate", LstPaiddate);
        dw.SetSqlCommandParameters("LstTrDate", LstTrDate);
        dw.SetSqlCommandParameters("penalvaliddate", penalvaliddate);
        return dw.Update();

    }

    //private DateTime GetLDatefromPaidDate(DateTime LstTrDate, DateTime lduedate)
    //{
    //    string lday = lduedate.Day.ToString("00");

    //}



    private int GetCategory(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select crcat from housprop where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return int.Parse(dw.GetSingleData());
    }

    private int GetPaidInstalment(string cracno, string transno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select PaidInstalments from housprop where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        int paidinst = int.Parse(dw.GetSingleData());

        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select count(tramt) as [count] from transassign where cracno = @cracno 
                        and transno = @transno and taskid = 'CAPD' and assignamt = tramt");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("transno", transno);
        paidinst += int.Parse(dw.GetSingleData());
        return paidinst;
    }

    //Amila - 7/8/2009
    public int UpdateActStatusinHousprop(string cracno, string transno, string taskid, DateTime LstPaiddate, DateTime LstTrDate)
    {
        DateTime LastCompletedDueDate;
        dt = new DataTable();
        rpc = new RecoveryProcesClass();
        fc = new FunctionClass();
        double actoutbal = GetOutBal(cracno);
        double capitalrecovered = GetCapitalRecovery(cracno, transno, taskid, "CR") - GetCapitalRecovery(cracno, transno, taskid, "DR");
        actoutbal -= capitalrecovered;
        dw = new DataWorksClass(constring);

        int crcat = GetCategory(cracno);

        string Buddhirectypr = rpc.getrectype(cracno);

        if (Buddhirectypr == "" || Buddhirectypr =="0") 
            Buddhirectypr = "NRC";

        if (Buddhirectypr == "IRC" || crcat == 6)
        {
            dt = GetPaymentHistoryData(cracno, "INTR");
        }
        else
        {
            dt = GetPaymentHistoryData(cracno, "CAPD");
        }

        if (dt.Rows.Count != 0)
        {
            LastCompletedDueDate = Convert.ToDateTime(dt.Rows[0]["Datedue"].ToString());
            string trstatus = dt.Rows[0]["trstatus"].ToString();
            switch (trstatus)
            {
                case "N":
                    LastCompletedDueDate = LastCompletedDueDate;
                    break;

                case "P":
                    LastCompletedDueDate = LastCompletedDueDate;
                    break;

                case "F":
                    LastCompletedDueDate = LastCompletedDueDate.AddMonths(1);
                    break;
            }
        }
        else
        {
            LastCompletedDueDate = GetDueDate(cracno);
        }

        int PaidInstalments = GetPaidInstalment(cracno, transno);
        DateTime penalvaliddate = fc.SetRecoveryProcessDate(LstTrDate, cracno);
        dw.SetCommand(@"update housprop set ActOutbal=@ActOutbal, penalvaliddate=@penalvaliddate,
                            PaidInstalments=@PaidInstalments, LstPaiddate=@LstPaiddate, LstTrDate=@LstTrDate,
                            LastCompletedDueDate=@LastCompletedDueDate 
                            where cracno=@cracno");
        dw.SetSqlCommandParameters("ActOutbal", actoutbal);
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("LastCompletedDueDate", LastCompletedDueDate);
        dw.SetSqlCommandParameters("PaidInstalments", PaidInstalments);
        dw.SetSqlCommandParameters("LstPaiddate", LstPaiddate);
        dw.SetSqlCommandParameters("LstTrDate", LstTrDate);
        dw.SetSqlCommandParameters("penalvaliddate", penalvaliddate);
        return dw.Update();
    }

    private double GetOutBal(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select actoutbal from housprop where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return double.Parse(dw.GetSingleData());
    }

    private DateTime GetDueDate(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select LastCompletedDueDate from housprop where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return DateTime.Parse(dw.GetSingleData());
    }

    //    public int UpdateActOutstandingBalance(string cracno, string transno, string taskid)
    //    {
    //        dt = new DataTable();
    //        double grantamount = GetGrantAmt(cracno);
    //        double capitalrecovered = GetCapitalRecovery(cracno, transno, taskid);
    //        double ActOutbal = grantamount - capitalrecovered;
    //        dw = new DataWorksClass(constring);

    //        dt = GetPaymentHistoryData(cracno);
    //        if (dt.Rows.Count != 0)
    //        {
    //            DateTime LastCompletedDueDate = Convert.ToDateTime(dt.Rows[0][0].ToString());
    //            int PaidInstalments = Convert.ToInt32(dt.Rows[0][1].ToString());

    //            DateTime workdate = Convert.ToDateTime(System.DateTime.Now.ToShortDateString());
    //            dw.SetCommand(@"update housprop set ActOutbal=@ActOutbal,
    //                            PaidInstalments=@PaidInstalments,
    //                            LastCompletedDueDate=@LastCompletedDueDate 
    //                            where cracno=@cracno");
    //            dw.SetSqlCommandParameters("ActOutbal", ActOutbal);
    //            dw.SetSqlCommandParameters("cracno", cracno);
    //            dw.SetSqlCommandParameters("LastCompletedDueDate", LastCompletedDueDate);
    //            dw.SetSqlCommandParameters("PaidInstalments", PaidInstalments);
    //            //dw.SetSqlCommandParameters("PenalValidDate", PenalValidDate);
    //            return dw.Update();
    //        }
    //        else
    //        {
    //            return 0;
    //        }
    //    }

    //public int UpdateOutstandingBalance(string cracno, string taskid)
    //{
    //    dt = new DataTable();
    //    double grantamount = GetGrantAmt(cracno);
    //    double capitalrecovered = GetCapitalRecovery(cracno, taskid);
    //    double outbal = grantamount - capitalrecovered;
    //    dw = new DataWorksClass(constring);
    //    DateTime workdate = Convert.ToDateTime(System.DateTime.Now.ToShortDateString());
    //    dw.SetCommand(@"update housprop set outbal=@outbal where cracno=@cracno");
    //    dw.SetSqlCommandParameters("outbal", outbal);
    //    dw.SetSqlCommandParameters("cracno", cracno);
    //          return dw.Update();
    //}


    // Change this Code *******
    private DataTable GetPaymentHistoryData(string cracno, string taskid)
    {
        dw = new DataWorksClass(constring);
        dt = new DataTable();
        dw.SetDataAdapter(@"select max(datedue) as datedue, trstatus from transassign where cracno=@cracno
                            and trstatus != 'C' and taskid=@taskid and trtype = 'I'
                            and transref = 'recv'
                            group by trstatus 
                            union
                            select  dateadd(month, 1, max(datedue)) as datedue, trstatus from 
                            transassign where cracno=@cracno 
                            and trstatus != 'C' and taskid=@taskid and trtype = 'I'
                            and transref = 'recv' and assignamt = tramt and trstatus = 'p'
                            group by trstatus 
                            order by datedue desc");
        dw.SetDataAdapterParameters("cracno", cracno);
        dw.SetDataAdapterParameters("taskid", taskid);
        return dw.GetDataTable();
    }


    //Edit 2009-05-26
    private double GetCapitalRecovery(string cracno, string transno, string taskid, string acsign)
    {
        dt = new DataTable();
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select isnull(sum(distinct g.tramt),0) from gltrans g, 
                        transassign t where g.transassignrefno = t.refno and t.taskid = @taskid 
                        and t.cracno = @cracno and g.transno=@transno and g.acsign = @acsign and 
                        right(g.refglcode,3) < '870'");

        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("taskid", taskid);
        dw.SetSqlCommandParameters("transno", transno);
        dw.SetSqlCommandParameters("acsign", acsign);
        return double.Parse(dw.GetSingleData());
    }


    private double GetArreas(string cracno, DateTime fromDate, DateTime toDate, string taskid)
    {
        dt = new DataTable();
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select (
                        select isnull(sum(distinct g.tramt),0) from gltrans g, 
                        transassign t where g.transassignrefno = t.refno and t.taskid = @taskid 
                        and t.cracno = @fromDate and g.trdate >= @fromDate and 
                        g.trdate <= @toDate' and g.acsign = 'CR' and 
                        right(g.refglcode,3) < '870') -
                        (select isnull(sum(distinct g.tramt),0) from gltrans g, 
                        transassign t where g.transassignrefno = t.refno and t.taskid = @taskid' 
                        and t.cracno = @cracno and g.trdate >= @fromDate and 
                        g.trdate <= @toDate and g.acsign = 'DR' and 
                        right(g.refglcode,3) < '870') ");

        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("taskid", taskid);
        dw.SetSqlCommandParameters("fromDate", fromDate);
        dw.SetSqlCommandParameters("toDate", toDate);
        return double.Parse(dw.GetSingleData());
    }

    private double GetGrantAmt(string cracno)//, string IsDisburse)
    {
        dt = new DataTable();
        dw = new DataWorksClass(constring);
        //dw.SetCommand(@"   select grantamt from crmast where cracno = @cracno");
        dw.SetCommand(@"select grantamt from crmast where cracno = @cracno");
        //dw.SetSqlCommandParameters("IsDisburse", IsDisburse);
        dw.SetSqlCommandParameters("cracno", cracno);
        return double.Parse(dw.GetSingleData());
    }

    //2009-03-15
    public DataTable GetHouspropDetails(string cracno)
    {
        dt = new DataTable();
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select cracno,Intrate,Instalment,OutBal,datedue,GracePeriod,Adduser,
                            adddate,LastCompletedDuedate,crperiod from housprop where cracno=@cracno");
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }


    //2009-03-15
    public int InsertDatatocrmastHistory(string cracno, double Intrate, double Instalment, double OutBal, DateTime datedue,
                                         int GracePeriod, string Adduser, DateTime adddate, DateTime LastCompletedDuedate, int crperiod)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into crmastHistory(cracno,Intrate,Instalment,OutBal,datedue,GracePeriod,Adduser,adddate,
                         LastCompletedDuedate,crperiod) values (@cracno,@Intrate,@Instalment,@OutBal,@datedue,@GracePeriod,
                         @Adduser,@adddate,@LastCompletedDuedate,@crperiod)");
        dw.SetSqlCommandParameters("crperiod", crperiod);
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("Intrate", Intrate);
        dw.SetSqlCommandParameters("Instalment", Instalment);
        dw.SetSqlCommandParameters("OutBal", OutBal);
        dw.SetSqlCommandParameters("datedue", datedue);
        dw.SetSqlCommandParameters("GracePeriod", GracePeriod);
        dw.SetSqlCommandParameters("Adduser", Adduser);
        dw.SetSqlCommandParameters("adddate", adddate);
        dw.SetSqlCommandParameters("LastCompletedDuedate", LastCompletedDuedate);
        return dw.Insert();
    }


    //2009-03-15
    public int UpdateHousprop(double Intrate, int crperiod, double Instalment, string cracno, string adduser)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update housprop set Intrate=@Intrate ,Instalment=@Instalment,crperiod=@crperiod,
                        adduser=@adduser where cracno=@cracno");
        dw.SetSqlCommandParameters("Intrate", Intrate);
        dw.SetSqlCommandParameters("crperiod", crperiod);
        dw.SetSqlCommandParameters("Instalment", Instalment);
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("adduser", adduser);
        return dw.Update();
    }

    public DateTime GetDatedue(string cracno, string transno)
    {
        DateTime datedue;
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select max(datedue) from transassign where cracno=@cracno and trstatus != 'C' and transno =@transno
                        and tramt = assignamt and taskid='CAPD'");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("transno", transno);
        try
        {
            datedue = DateTime.Parse(dw.GetSingleData());
        }
        catch
        {
            dw = new DataWorksClass(constring);
            dw.SetCommand(@"select lastcompletedduedate from housprop where cracno=@cracno");
            dw.SetSqlCommandParameters("cracno", cracno);
            datedue = DateTime.Parse(dw.GetSingleData());
        }
        return datedue;
    }
    public int UpdateHouspropDateDue(string cracno, string LastCompletedDueDate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update housprop set LastCompletedDueDate=@LastCompletedDueDate where cracno=@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("LastCompletedDueDate", LastCompletedDueDate);
        return dw.Update();
    }



    public DataTable GetShortFall(string cracno, string trstatus, DateTime paiddate)
    {
        dw = new DataWorksClass(Oldconstring);
        dt = new DataTable();
        dw.SetDataAdapter(@"select * from dbo.ShortFall where cracno=@cracno and trstatus =@trstatus and paiddate = @paiddate");
        dw.SetDataAdapterParameters("cracno", cracno);
        dw.SetDataAdapterParameters("trstatus", trstatus);
        dw.SetDataAdapterParameters("paiddate", paiddate);
        return dw.GetDataTable();
    }

    public int ChechkSecondRecord(string cracno, DateTime trdate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select count(*) from trans where trdate = @trdate and cracno=@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("trdate", trdate);
        return Convert.ToInt32(dw.GetSingleData());
    }

    public DataTable GetShortFallDetails(string trstatus, DateTime paiddate, string status)
    {
        dw = new DataWorksClass(Oldconstring);
        dw.SetDataAdapter(@"select s.*, i.intrate,  c.crcat from ShortFall s,crmast c,creditscheme h, 
                            interestcode i where 
                            trstatus != @trstatus and paiddate=@paiddate
                            and s.status=@status and s.cracno=c.cracno and c.schemno=h.schemno and
                            h.intcode=i.intcode ");
        dw.SetDataAdapterParameters("trstatus", trstatus);
        dw.SetDataAdapterParameters("paiddate", paiddate);
        dw.SetDataAdapterParameters("status", status);
        return dw.GetDataTable();
    }

    //edit bimali 20/07/2009
    public double GetTrAmtOfShortfall(long transno, DateTime datedue, string trcode)
    {
        double Tramt = 0;
        dw = new DataWorksClass(Oldconstring);
        dw.SetCommand(@"select transamt from recvtrans where transno=@transno and datedue=@datedue and trcode=@trcode");
        dw.SetSqlCommandParameters("transno", transno);
        dw.SetSqlCommandParameters("datedue", datedue);
        dw.SetSqlCommandParameters("trcode", trcode);
        Tramt = double.Parse(dw.GetSingleData());
        return Tramt;
    }

    public string GetMaxTransNo(string cracno)
    {
        string TransNo;
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select max(transNo) from TransAssign where  cracno=@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        TransNo = dw.GetSingleData();
        return TransNo;
    }
    public string GetTrStatus(string cracno, string TransNo)
    {
        string TrStatus;
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select TrStatus from TransAssign where  cracno=@cracno and  Transno=@Transno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("TransNo", TransNo);
        TrStatus = dw.GetSingleData();
        return TrStatus;
    }

    public DataTable GetExtPart(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select refno, system, AssignAmt, (AssignAmt - tramt) as extamt, taskid, trstatus from TransAssign where  
                            cracno=@cracno and (trstatus = 'n' or trstatus = 'p')");
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }

    //new 08/06/2009
    public double GetAssignedAmountToBePaid(string cracno, string TrStatus1, string TrStatus2,
                                           string TransRef)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select sum(assignamt) as AssignAmt
                            from TransAssign ta where ta.cracno = @cracno and 
                            (ta.TrStatus=@TrStatus1 or ta.TrStatus=@TrStatus2) 
                            and ta.TransRef = @TransRef and ta.taskid <> 'CAPD'");

        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("TrStatus1", TrStatus1);
        dw.SetSqlCommandParameters("TrStatus2", TrStatus2);
        dw.SetSqlCommandParameters("TransRef", TransRef);
        return double.Parse(dw.GetSingleData());
    }



    private DateTime GetMaxDateInTransAssign(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select LastCompletedDueDate as DateDue from housprop where cracno=@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return DateTime.Parse(dw.GetSingleData());
    }

    //08-06-2009 new
    public double GetAssignIntAmount(string cracno, string TrStatus,
                                          string TransRef)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select assignamt as AssignAmt
                            from TransAssign ta where ta.cracno = @cracno and 
                            (TrStatus=@TrStatus) and TransRef = @TransRef and taskid = 'INTR' and datedue=
                            (select max(DateDue) as MaxIntDateDue from TransAssign where cracno=@cracno and
                            TrStatus=@TrStatus and taskid='INTR' 
                            and TransRef = @TransRef)");

        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("TrStatus", TrStatus);
        dw.SetSqlCommandParameters("TransRef", TransRef);
        return double.Parse(dw.GetSingleData());
    }

    public DateTime getGrantdate(string cracno)
    {
        DateTime grantdate;
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select grantdate from crmast where cracno=@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        grantdate = Convert.ToDateTime(dw.GetSingleData());
        return grantdate;
    }



    //new 08/06/2009
    private double GetCapitalAssignedAmount(string cracno, string TrStatus1, string TrStatus2,
                                            string TransRef)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select sum(assignamt) as AssignAmt
                            from TransAssign ta where ta.cracno = @cracno and 
                            (ta.TrStatus=@TrStatus1 or ta.TrStatus=@TrStatus2) 
                            and ta.TransRef = @TransRef and ta.taskid = 'CAPD'");

        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("TrStatus1", TrStatus1);
        dw.SetSqlCommandParameters("TrStatus2", TrStatus2);
        dw.SetSqlCommandParameters("TransRef", TransRef);
        return double.Parse(dw.GetSingleData());
    }

    //new 08-06-2009 
    public double GetAssignCapAmount(string cracno, string TrStatus,
                                         string TransRef)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select assignamt as AssignAmt
                            from TransAssign ta where ta.cracno = @cracno and 
                            (TrStatus=@TrStatus) and TransRef = @TransRef and taskid = 'CAPD' and datedue=
                            (select max(DateDue) as MaxIntDateDue from TransAssign where cracno=@cracno and
                            TrStatus=@TrStatus and taskid='CAPD' 
                            and TransRef = @TransRef)");

        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("TrStatus", TrStatus);
        dw.SetSqlCommandParameters("TransRef", TransRef);
        return double.Parse(dw.GetSingleData());
    }

    public int UpdateOutBalInHourprop(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update housprop set OutBal=0.0,ActOutBal=0.0 where cracno=@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return dw.Update();
    }


    public int UpdateACStatusInCrMast(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update CrMast set AcStatus='C' WHERE cracno=@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return dw.Update();
    }



    //edit 12/06/2009
    public double GetPrematureSettlingCharges(string cracno, double outbal)
    {
        Recovery r = new Recovery();
        FunctionClass fc = new FunctionClass();
        DateTime grantdate;
        double preSettle = 0;
        int noOfdays = 0, noOfMonths = 0, noOfYears = 0;
        grantdate = r.getGrantdate(cracno);
        int crcat = r.getcrcat(cracno);
        DateTime today = fc.GetSystemDate("A");
        DateDifference df = new DateDifference(grantdate, today);
        noOfdays = df.Days;
        noOfMonths = df.Months;
        noOfYears = df.Years;

        //if (grantdate > DateTime.Parse("2016/04/01"))
        //{
        // Decide premature settlement - changed on 08/04/2016 according to the circular

        if (crcat == 11 || crcat == 9)
        {
            preSettle = 0.00;
        }
        else if (crcat == 19 || crcat == 16)
        {
            preSettle = outbal * 0.03;
        }
        else
        {
            if (grantdate > DateTime.Parse("2016/04/01"))
            {
                preSettle = outbal * 0.05;
            }
            else
            {
                if (noOfYears >= 5)
                    preSettle = 0.0;
                else if ((noOfYears < 5) && (noOfYears >= 3))
                    preSettle = outbal * 0.005;
                else if (noOfYears < 3)
                    preSettle = outbal * 0.01;
            }
        }
        //}
        //else
        //{
        //    if (crcat == 11 || crcat == 9 || crcat == 19 || crcat == 16)
        //    {
        //        preSettle = 0.00;
        //    }
        //    else
        //    {
        //        if (noOfYears >= 5)
        //            preSettle = 0.0;
        //        else if ((noOfYears < 5) && (noOfYears >= 3))
        //            preSettle = outbal * 0.005;
        //        else if (noOfYears < 3)
        //            preSettle = outbal * 0.01;
        //    }
        //}

        return (Math.Round(preSettle, 2));

    }

    public double GetTrAmt(string refno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select tramt from transassign where refno =@refno");
        dw.SetSqlCommandParameters("refno", refno);
        return double.Parse(dw.GetSingleData());
    }

    //edit 15/06/2009
    public int UpdateOutBalInHourprop(string cracno, double ActOutBal)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update housprop set ActOutBal=@ActOutBal where cracno=@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("ActOutBal", ActOutBal);
        return dw.Update();
    }



    //Get Normal Details From DataBase //edit 16/06/2009
    //    public DataTable GetnormalDetails(string cracno)
    //    {
    //        dw = new DataWorksClass(constring);
    //        dw.SetDataAdapter(@"select cm.grantamt as GrantAmt,hp.instalment as Installment, 
    //                            hp.intrate as InterestRate,
    //                            rtrim(cast(year(hp.DateDue) as nvarchar(5)))+ '/' + 
    //                            (cast(month(hp.DateDue) as nvarchar(5))) +  '/' +
    //                            (cast(day(hp.DateDue) as nvarchar(5))) as duedate,
    //                            rtrim(cast(year(cm.GrantDate) as nvarchar(5)))+ '/' + 
    //                            (cast(month(cm.GrantDate) as nvarchar(5))) +  '/' +
    //                            (cast(day(cm.GrantDate) as nvarchar(5))) as GrantDate,
    //                            rtrim(cast(year(hp.LstPaiddate) as nvarchar(5)))+ '/' + 
    //                            (cast(month(hp.LstPaiddate) as nvarchar(5))) +  '/' +
    //                            (cast(day(hp.LstPaiddate) as nvarchar(5))) as LstPaiddate,
    //                            rtrim(cast(year(hp.lastcompletedduedate) as nvarchar(5)))+ '/' + 
    //                            (cast(month(hp.lastcompletedduedate) as nvarchar(5))) +  '/' +
    //                            (cast(day(hp.lastcompletedduedate) as nvarchar(5))) as lastcompletedduedate,
    //                            cast(hp.ActOutBal as decimal(20,2)) As OutstandBal ,cast(hp.OutBal as decimal(20,2)) As OutBal, hp.crperiod
    //                            , cm.crcat                            
    //                            from crmast cm,housprop hp 
    //                            where cm.cracno=hp.cracno
    //                            and cm.cracno=@cracno");

    //        dw.SetDataAdapterParameters("cracno", cracno);
    //        dt = dw.GetDataTable();
    //        return dt;
    //    }



    // edit on 18/08/2009 Dilanka
    public DataTable GetnormalDetails(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select distinct cm.grantamt as GrantAmt, aprovdamt, hp.instalment as Installment, 
                                    hp.intrate as InterestRate,
                                    CONVERT(VARCHAR(10), hp.DateDue, 111) as DateDue,
                                    CONVERT(VARCHAR(10), cm.GrantDate, 111) as GrantDate,
                                    CONVERT(VARCHAR(10), hp.LstPaiddate, 111) as  LstPaiddate,
                                    CONVERT(VARCHAR(10), hp.lastcompletedduedate, 111) as lastcompletedduedate,
                                    CONVERT(VARCHAR(10), hp.LstPaiddate, 111) as lstrecoverydate,
                                    cast(hp.ActOutBal as decimal(20,2)) As OutstandBal ,cast(hp.OutBal as decimal(20,2)) 
                                    As OutBal, hp.crperiod, hp.crcat, r.CrDes  ,cp.Descrip                          
                                    from crmast cm,housprop hp, CrCategory r,CrCatPurpose cr,CrPurpose cp
                                    where cm.cracno=hp.cracno and hp.CrCat=r.CrCatCode and cm.CatPurposeId=cr.catpurposeid
                                    and cr.purposecode=cp.PurposeCode
                                    and cm.cracno=@cracno");
        dw.SetDataAdapterParameters("cracno", cracno);
        dt = dw.GetDataTable();
        return dt;
    }

    public double CalulateClosingAmount(double daysinterest, double prematsettlement, double othercharges, double caprecievable)
    {
        double closingbal = daysinterest + prematsettlement + othercharges + caprecievable;
        return (Math.Round(closingbal, 2));
    }


    ////calculate closing balance
    ////edit 08/06/2009 edit 12/06/2009 //edit 16/06/2009
    //public double CalulateClosingAmount(double Excess, string cracno, DateTime duedate, double outbal, double intrate, double otherPayment, DateTime trdate)
    //{

    //    Recovery r = new Recovery();
    //    double closingbal = 0, preSettle = 0;

    //    //preSettle = r.GetPrematureSettlingCharges(cracno, outbal);

    //    double interest = r.GetInterestAmountFortheMonth(cracno, duedate, outbal, intrate, trdate);

    //    closingbal = /*preSettle*/ + interest + outbal + Excess;
    //    return (Math.Round(closingbal, 2));
    //}



    //17/06/2009

    public int GetNoDaysForInterest(DateTime intdatedue, DateTime trdate)
    {
        int days = 0;
        fc = new FunctionClass();
        TimeSpan t = trdate.Subtract(intdatedue);
        days = t.Days;
        return days;
    }

    public DateTime GetMaxDueDateinTransAssign(string cracno)
    {
        DateTime duedateforclose;
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select datedue from housprop where cracno=@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        duedateforclose = Convert.ToDateTime(dw.GetSingleData());
        return duedateforclose;
    }

    public double PrematureRate(string cracno)
    {

        DateTime grantdate;
        double prematureRate = 0;
        fc = new FunctionClass();
        int noOfdays = 0, noOfMonths = 0, noOfYears = 0;
        grantdate = getGrantdate(cracno);
        int crcat = getcrcat(cracno);
        DateTime today = fc.GetSystemDate("A");
        DateDifference df = new DateDifference(grantdate, today);
        noOfdays = df.Days;
        noOfMonths = df.Months;
        noOfYears = df.Years;

        //if (grantdate > DateTime.Parse("2016/04/01"))
        //{
        // Decide premature settlement
        if (crcat == 11 || crcat == 9)
        {
            prematureRate = 0.00;

        }
        else if (crcat == 19 || crcat == 16)
        {
            prematureRate = 3;

        }
        else
        {
            if (grantdate > DateTime.Parse("2016/04/01"))
            {
                prematureRate = 5;
            }
            else
            {
                if (noOfYears >= 5)
                    prematureRate = 0;
                else if ((noOfYears < 5) && (noOfYears >= 3))
                    prematureRate = 0.5;
                else if (noOfYears < 3)
                    prematureRate = 1;
            }

        }
        //}
        //else
        //{
        //    if (crcat == 11 || crcat == 9 || crcat == 19 || crcat == 16)
        //    {
        //        prematureRate = 0.00;

        //    }
        //    else
        //    {
        //        if (noOfYears >= 5)
        //            prematureRate = 0;
        //        else if ((noOfYears < 5) && (noOfYears >= 3))
        //            prematureRate = 0.5;
        //        else if (noOfYears < 3)
        //            prematureRate = 1;
        //    }
        //}

        return (Math.Round(prematureRate, 2));

    }

    //get interesrt amount //edit 2009/06/22


    public double GetInterestAmountFortheMonth(int daysarreas, double outbal, double intrate)
    {
        double intfordays = Math.Round((outbal * daysarreas * intrate) / (100 * 365), 2);
        return intfordays;
    }

    //// Edited 29/072009
    public double GetCustomerPaymentForCapitalRec(double capitalrecovery, double assigncharges, double interetamt, double prematureamt)
    {
        double customerpayment = 0;
        customerpayment = capitalrecovery + assigncharges + interetamt + prematureamt;
        return (Math.Round(customerpayment, 2));
    }

    //// Edited 29/072009

    public double GetCustomerPaymentForCapitalRec(double capitalrecovery, double assigncharges, double intrate, double preintrate, int noofdays)
    {
        double customerpayment = 0;
        //customerpayment = (assigncharges * noofdays * intrate / 36500) - capitalrecovery - assigncharges) / ((preintrate / 100) + (noofdays * intrate / 36500) - 1);
        customerpayment = (assigncharges + (capitalrecovery * preintrate / 100) + ((capitalrecovery * intrate * noofdays) / 36500) + capitalrecovery);
        return (Math.Round(customerpayment, 2));
    }

    //new 16/06/2009 //edit 17/06/2009 --
    public double GetCapitalRecoveryAmt(double CustomerPayment, double AssignCharges, DateTime duedate,
                                        double intrate, string cracno, DateTime trdate)
    {
        int NoofDays = GetNoDaysForInterest(duedate, trdate);
        double Prematurerate = PrematureRate(cracno);
        double recoveryamt = (CustomerPayment - AssignCharges) / ((Prematurerate / 100) + ((intrate * NoofDays) / 36500) + 1);                       //((CustomerPayment - AssignCharges) * 100) / (100 + Prematurerate + ((NoofDays * intrate) / 365));
        return (Math.Round(recoveryamt, 2));
    }


    //vihanga 2009-08-02
    public DataTable GetcashmvmntDetails(string refid)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from cashmvmnt where  refid=@refid and isaccept <> 1");
        dw.SetDataAdapterParameters("refid", refid);
        return dw.GetDataTable();
    }

    public int Updatecashmvmnt(string refid)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update cashmvmnt set isaccept=1 where refid=@refid");
        dw.SetSqlCommandParameters("refid", refid);
        return dw.Update();
    }

    public string GetRecStatus(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select recstatus from housprop where cracno =@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return dw.GetSingleData();
    }


    public long GetDisbRefNo(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select disbrefno from housprop where cracno =@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return long.Parse(dw.GetSingleData());
    }

    public int UpdateRecStatus(string cracno, long disbrefno, string RecStatus, double CapAssign)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update housprop set RecStatus=@RecStatus, disbrefno = @disbrefno, CapAssign=@CapAssign where cracno=@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("RecStatus", RecStatus);
        dw.SetSqlCommandParameters("disbrefno", disbrefno);
        dw.SetSqlCommandParameters("CapAssign", CapAssign);
        return dw.Update();
    }

    public int UpdateRecStatus(string cracno, long disbrefno, string RecStatus)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update housprop set RecStatus=@RecStatus, disbrefno = @disbrefno where cracno=@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("RecStatus", RecStatus);
        dw.SetSqlCommandParameters("disbrefno", disbrefno);
        return dw.Update();
    }

    internal int UpdatePenalValidDate(string cracno, DateTime penalvaliddate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update housprop set penalvaliddate=@penalvaliddate where cracno=@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("penalvaliddate", penalvaliddate);
        return dw.Update();
    }

    public DataTable GetCrCategory()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from CrCategory");
        return dw.GetDataTable();
    }

    internal string GetRecstatus(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select recstatus from housprop where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return dw.GetSingleData();
    }

    public DataTable getPurpose(int crcatcode)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select cp.descrip,cct.purposecode from crcatpurpose cct, crpurpose cp 
                                where cp.purposecode = cct.purposecode and cct.crcatcode = @crcatcode");
        dw.SetDataAdapterParameters("crcatcode", crcatcode);
        return dw.GetDataTable();
    }


    public DataTable GetCracnobyPeriod(DateTime trdate, int recptperiod)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"SELECT cracno from housprop where cracno in (
                            select distinct cracno 
                            from gltrans where trdate = @trdate
                            and left(cracno,1) = '6') and recptperiod = @recptperiod");
        dw.SetDataAdapterParameters("trdate", trdate);
        dw.SetDataAdapterParameters("recptperiod", recptperiod);
        return dw.GetDataTable();
    }


    public DateTime GetPrePaidDate(string cracno, DateTime operationdate)
    {
        fc = new FunctionClass();
        string opdate = fc.GetDateKeyinDate(operationdate).ToString();
        dw = new DataWorksClass(reportconstring);
        dw.SetCommand(@"select max(operationdate) as operationdate from DailyHousProp 
                        where cracno = @cracno and operationdate<@operationdate ");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("operationdate", opdate);
        return fc.GetDateinKeyDate(dw.GetSingleData());

    }

    // Predeep 20100303
    public DataTable getCustName(string cracno)
    {
        dt = new DataTable();
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select rtrim(titledesc)+ ' ' + rTrim(c.INitials) + ' ' + rTrim(c.Surname) as [Name],
        rtrim(c.location)+' '+rtrim(c.street)+' '+rtrim(c.city) as Address 
        from customermain c, appholder a , crmast cr, title t
        where c.nicno = a.nicno and a.appno = cr.appno and c.titlecode=t.titlecode and cr.cracno=@cracno");
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }


    public DataTable GetCustomerdetailsAppno(string cracno)
    {
        dt = new DataTable();
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select cr.Cracno ,a.NicNo, a.Holdertype, cr.appno from appholder a , Crmast cr
                            where  a.appno = cr.appno  and cr.cracno=@cracno
                            order by a.holdertype
                            ");
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }


    internal int getcrcat(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select crcat from housprop where cracno =@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return int.Parse(dw.GetSingleData());
    }


    public DataTable GetGovtShedule(string cracno, double actoutbal1, double grantamt, double intrate, double instalment, int crperiod, DateTime GrantDate)
    {
        DataTable dt = new DataTable();
        //dt = SetAmtzDataTable(dt);
        DateTime ProcessDate;
        fc = new FunctionClass();
        double intamount = 0, capital = 0;
        double outbal = 0, TatalInstalment = 0, TatalInterest = 0;
        int serialno = 0;
        double custintrate = 4.00, GovtInterestRate = 7.00;
        DataTable basicRec = new DataTable(); //Loan Number Table       
        double CustInterest = 0.00, GovtInterest = 0.00, CustCapital = 0.00, CustInstalment = 0.00, GovtInstalment = 0.00;
        int refno = 1;
        ProcessDate = DateTime.Now;
        ProcessDate = nextdue;

        DateTime newdate = getnewdate(cracno);

        if (intrate == 11.00)
        {
            // - -------------------------
            intrate = 11.00;
            GovtInterestRate = 7.00;
            custintrate = 4.00;
            DateTime nextdue1 = nextdue;


            
            //instalment = Math.Round(grantamt * (intrate / (12 * 100)) / (1 - (1 / Math.Pow((double)((1 + (intrate / (12 * 100)))), crperiod))), 2);
            //double roundinstalment = instalment;
            //int newroundinstalment;
            //roundinstalment = instalment % 10;
            //if (roundinstalment == 0)
            //    newroundinstalment = ((int)(instalment / 10)) * 10;
            //else
            //    newroundinstalment = ((int)(instalment / 10) + 1) * 10;

            double newactoutbal1 = Math.Round((actoutbal1), 2);
            while (newactoutbal1 > 0)
            {
                //instalment = grantamt * (intrate / (12 * 100)) / (1 - (1 / Math.Pow((double)((1 + (intrate / (12 * 100)))), crperiod)));

                intamount = Math.Round(CalculateIntAmount(newactoutbal1, intrate), 2);
                CustInterest = Math.Round(CalculateIntAmount(newactoutbal1, custintrate), 2);
                GovtInterest = Math.Round((intamount - CustInterest), 2);
                capital = Math.Round(CalculateCapital(Math.Round(instalment), intamount, '1', '1', newactoutbal1), 2);
                CustInstalment = capital + CustInterest;
                GovtInstalment = GovtInterest;
                newactoutbal1 -= capital;
                newactoutbal1 = Math.Round(newactoutbal1, 2);
                TatalInstalment = CustInstalment + GovtInstalment;
                TatalInterest = CustInterest + GovtInterest;
                //dt = InsertRow(refno.ToString(), capital, intamount, LoanAmt, dt);
                //refno = refno + 1;
                InsertGovtShedule(cracno, newdate, TatalInterest, CustInterest, GovtInterest, capital, CustInstalment, GovtInstalment, newactoutbal1, TatalInstalment);
                newdate = newdate.AddMonths(1);
            }
        }
        else
        {
        }
        return dt;
    }

    private DateTime getnewdate(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select '2017-01-'+ cast(day(datedue) as varchar(2)) as Numberdate from housprop where cracno=@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return DateTime.Parse(dw.GetSingleData());
        
    }

    private double InsertGovtShedule(string cracno, DateTime newdate, double TatalInterest, double CustInterest, double GovtInterest, double capital, double CustInstalment, double GovtInstalment, double newactoutbal1, double TatalInstalment)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO GovtShedule (cracno,DateDue,TatalInterest,CustInterest,GovtInterest,CustCapital,CustInstalment,GovtInstalment,Outbal,TatalInstalment) VALUES
                       (@cracno,@grantdate,@TatalInterest,@CustInterest ,@GovtInterest,@capital,@CustInstalment,@GovtInstalment,@LoanAmt,@TatalInstalment)");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("grantdate", newdate);
        dw.SetSqlCommandParameters("TatalInterest", TatalInterest);
        dw.SetSqlCommandParameters("CustInterest", CustInterest);
        dw.SetSqlCommandParameters("GovtInterest", GovtInterest);
        dw.SetSqlCommandParameters("capital", capital);
        dw.SetSqlCommandParameters("CustInstalment", CustInstalment);
        dw.SetSqlCommandParameters("GovtInstalment", GovtInstalment);
        dw.SetSqlCommandParameters("LoanAmt", newactoutbal1);
        dw.SetSqlCommandParameters("TatalInstalment", TatalInstalment);
        return dw.Insert();
    }

    private double CalculateCapital(double installment, double intAmount, int crcat, int crpurposecode, double outbal)
    {
        if (crcat != 6)
        {
            if (installment >= outbal)
            {
                return Math.Round(outbal, 2);
            }
            else
            {
                return Math.Round(installment - intAmount, 2);
            }
        }
        else
        {
            return 0;
        }
    }
}
