﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

/// <summary>
/// Summary description for DailyAnalisis
/// </summary>
public class DailyAnalisisBranch
{

    string branchconstring = ConfigurationManager.ConnectionStrings["TDBBranchesConString"].ConnectionString.ToString();
    //string crmastString = ConfigurationManager.ConnectionStrings["crmastString"].ConnectionString.ToString();
    private DataTable dt;
    DataWorksClass dw;

    public DailyAnalisisBranch()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public DataTable getDailyAnalisisData(string datekey)
    {
        dw = new DataWorksClass(branchconstring);
        dw.SetDataAdapter(@"select @datekey,SUM(h.ActOutBal) as Actoutbal,SUM(c.GrantAmt) as GrantAmt,SUM(c.Aprovdamt) as Aprovdamt,
                            SUM(a.CrAmt) as CrAmt,SUM((c.Aprovdamt)-(c.GrantAmt)) as ApprovednotGranted, c.CatPurposeId From HousProp h, crmast c, Crapp a where 
                            h.CrAcNo=c.CrAcNo and h.ActOutBal > 0.00 and c.Appno= a.AppNo
                            group by c.CatPurposeId
                            order by c.CatPurposeId");
        dw.SetDataAdapterParameters("datekey", datekey);
        dt = dw.GetDataTable();
        return dt;
    }

    public DataTable getdailybalance(string datekey)
    {
        dw = new DataWorksClass(branchconstring);
        dw.SetDataAdapter(@"select @datekey,cr.CrDes  as 'LoanCategory',SUM(d.CrAmt) as CrAmt,SUM(AprovedAmt) as Aprovdamt ,
                            SUM(ApprovednotGranted) as ApprovednotGranted,
                            SUM(d.GrantAmt) as GrantAmt,SUM(ActOutBal) as ActOutBal From 
                            DailyAnalisis d, CrCatPurpose c, CrCategory cr
                            where d.Datekey=@datekey and c.CatPurposeId=d.catpurposeid and c.crcatcode !=5
                            and c.crcatcode=cr.CrCatCode
                            group by cr.CrDes
                            --order by cr.CrDes
                            union
                            select @datekey,cr.Descrip as 'LoanCategory',SUM(d.CrAmt) as CrAmt,SUM(AprovedAmt) as Aprovdamt ,
                            SUM(ApprovednotGranted) as ApprovednotGranted,
                            SUM(d.GrantAmt) as GrantAmt,SUM(ActOutBal) as ActOutBal From 
                            DailyAnalisis d, CrCatPurpose c, CrPurpose cr
                            where d.Datekey=@datekey and c.CatPurposeId=d.catpurposeid and c.crcatcode =5
                            and c.purposecode=cr.PurposeCode and cr.PurposeCode in (40,41,42,43,45,46,47,48)
                            group by cr.Descrip
                            --order by cr.Descrip
                            union
                            select @datekey,'Other Personal Loans' as 'LoanCategory',SUM(d.CrAmt) as CrAmt,SUM(AprovedAmt) as Aprovdamt ,
                            SUM(ApprovednotGranted) as ApprovednotGranted,
                            SUM(d.GrantAmt) as GrantAmt,SUM(ActOutBal) as ActOutBal From 
                            DailyAnalisis d, CrCatPurpose c, CrPurpose cr
                            where d.Datekey=@datekey and c.CatPurposeId=d.catpurposeid and c.crcatcode =5
                            and c.purposecode=cr.PurposeCode and cr.PurposeCode not in (40,41,42,43,45,46,47,48)
                            order by LoanCategory");
        dw.SetDataAdapterParameters("datekey", datekey);
        dt = dw.GetDataTable();
        return dt;
       
    }

    public DataTable getAnalisis(string fromdate, string todate)
    {
        dw = new DataWorksClass(branchconstring);
        dw.SetDataAdapter(@"select A.LoanCategory,A.ActOutBal as Balance,(A.ActOutBal-tab1.ActOutBal) as ForTheDaydiff,
                            A.CrAmt as CrAmount,A.Aprovdamt as ApprovedAmt,A.ApprovednotGranted as ApprovednotGrantedAmt,A.GrantAmt as GrantedAmount from 
                            (select LoanCategory,ActOutBal,CrAmt,Aprovdamt,ApprovednotGranted,GrantAmt From Dailybalance 
                            where datekey=@fromdate)  tab1,Dailybalance as A
                            where tab1.LoanCategory = A.LoanCategory and datekey=@todate");
        dw.SetDataAdapterParameters("fromdate", fromdate);
        dw.SetDataAdapterParameters("todate", todate);
        dt = dw.GetDataTable();
        return dt;

    }

    public int getcount(string datekey)
    {
        dw = new DataWorksClass(branchconstring);
        dw.SetCommand(@"select COUNT(*) from DailyAnalisis where Datekey =@Datekey");
        dw.SetSqlCommandParameters("datekey", datekey);
        return int.Parse(dw.GetSingleData());
    }
}
