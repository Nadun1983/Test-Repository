using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Data.SqlClient;
//using System.

/// <summary>
/// Summary description for InsertReptors
/// </summary>
public class InsertReportsTemp
{
    DataWorksClass dw;
    DataTable dt;
    FunctionClass fc;
    static DataTable disbSummery;
    static DataTable dailyproof;
    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();
    string oldconstring = ConfigurationManager.ConnectionStrings["TestOld"].ConnectionString.ToString();
    string reportconstring = ConfigurationManager.ConnectionStrings["reporTString"].ConnectionString.ToString();
    int arreasmonths;
    double arreasamount;
    double penaltot, capitaltot, inttot;

    public InsertReportsTemp()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    //    private double GetSumTrans(string taskid, string cracno, string acsign, string trdate)
    //    {
    //        dw = new DataWorksClass(constring);
    //        dw.SetCommand(@"select isnull(sum(g.tramt),0) as tramt from transassign t, gltrans g
    //                        where t.refno = g.transassignrefno
    //                        and  t.cracno = @cracno
    //                        and g.trstatus != 'c' and g.acsign = @acsign
    //                        and t.taskid =@taskid and g.trdate=@trdate and right(g.refglcode,3)<'900' and t.transref<>'DISB'");
    //        dw.SetSqlCommandParameters("cracno", cracno);
    //        dw.SetSqlCommandParameters("acsign", acsign);
    //        dw.SetSqlCommandParameters("taskid", taskid);
    //        dw.SetSqlCommandParameters("trdate", trdate);
    //        return double.Parse(dw.GetSingleData());
    //    }

    private double GetSumTrans(string refcode, string cracno, string acsign, string trdate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select sum(tramt) from gltrans 
                        where right(left(refglcode,14),8) = @refcode
                        and trdate = @trdate and cracno = @cracno
                        and acsign = @acsign
                        and trstatus != 'C'");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("acsign", acsign);
        dw.SetSqlCommandParameters("refcode", refcode);
        dw.SetSqlCommandParameters("trdate", trdate);
        return double.Parse(dw.GetSingleData());
    }

    private double GetSumTrans(string cracno, string trdate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select (select isnull(sum(g.tramt),0) as tramt from transassign t, gltrans g
                        where t.refno = g.transassignrefno
                        and  t.cracno = @cracno
                        and g.trstatus != 'c' and g.acsign = 'CR'
                        and t.taskid ='CAPD' and g.trdate=@trdate1
                        and right(g.refglcode,3)<'900' and t.transref<>'DISB')
                        -
                        (select isnull(sum(g.tramt),0) as tramt from transassign t, gltrans g
                        where t.refno = g.transassignrefno
                        and  t.cracno = @cracno
                        and g.trstatus != 'c' and g.acsign = 'DR'
                        and t.taskid ='CAPD' and g.trdate=@trdate2
                        and right(g.refglcode,3)<'900' and t.transref<>'DISB')");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("trdate1", trdate);
        dw.SetSqlCommandParameters("trdate2", trdate);
        return double.Parse(dw.GetSingleData());
    }

    private double GetSumTrans(string cracno, string acsign, string trdate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select isnull(sum(tramt),0) from gltrans 
                        where right(left(refglcode,14),6) = '100001'
                        and trdate = @trdate and cracno = @cracno
                        and acsign = @acsign
                        and trstatus != 'C'");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("acsign", acsign);
        dw.SetSqlCommandParameters("trdate", trdate);
        return double.Parse(dw.GetSingleData());
    }


    private string DateKey(string date)
    {
        return date.Substring(4, 4) + date.Substring(2, 2) + date.Substring(0, 2);
    }


    //public void GetHousProp(string startDate, string endDate)
    //{
    //    DataTable temp = new DataTable();
    //    temp = SetDataTableHP(temp);
    //    fc = new FunctionClass();
    //    dt = new DataTable();
    //    string startd = DateKey(startDate);
    //    DateTime trdate = fc.GetDateinDateKey(endDate);
    //    dt = GetPreviousHouspropData(startd, trdate);

    //    for (int i = 0; dt.Rows.Count > i; i++)
    //    {

    //        DateTime predatedue = DateTime.Parse(dt.Rows[i]["LastCompletedDueDate"].ToString());
    //        DateTime LastCompletedDueDate;
    //        string cracno = dt.Rows[i]["cracno"].ToString();

    //        string OperationDate = DateKey(endDate);
    //        double preoutbal = double.Parse(dt.Rows[i]["actoutbal"].ToString());
    //        int LoanStatusCode = int.Parse(dt.Rows[i]["LoanStatusCode"].ToString());
    //        double IntRate = double.Parse(dt.Rows[i]["IntRate"].ToString());
    //        double Instalment = double.Parse(dt.Rows[i]["Instalment"].ToString());
    //        int GracePeriod = int.Parse(dt.Rows[i]["GracePeriod"].ToString());
    //        int CrPeriod = int.Parse(dt.Rows[i]["CrPeriod"].ToString());
    //        int CrCat = int.Parse(dt.Rows[i]["CrCat"].ToString());
    //        double actoutbal = double.Parse(dt.Rows[i]["actoutbal"].ToString());
    //        double tramt = GetSumTrans(cracno, trdate);
    //        DateTime datedue = DateTime.Parse(dt.Rows[i]["datedue"].ToString());
    //        bool IsTrans;

    //        if (tramt != 0)
    //        {
    //            IsTrans = true;
    //            try
    //            {
    //                LastCompletedDueDate = GetDatedue(cracno);
    //            }
    //            catch
    //            {
    //                LastCompletedDueDate = DateTime.Parse(dt.Rows[i]["LastCompletedDueDate"].ToString());
    //            }
    //            actoutbal = actoutbal - tramt;
    //        }
    //        else
    //        {
    //            LastCompletedDueDate = DateTime.Parse(dt.Rows[i]["LastCompletedDueDate"].ToString());
    //            IsTrans = false;
    //        }

    //        //InsertDailyHousProp(OperationDate, cracno, LastCompletedDueDate, LoanStatusCode, IntRate, Instalment, actoutbal,
    //        //   GracePeriod, CrPeriod, CrCat, IsTrans, preoutbal, predatedue, datedue);

    //        temp = InsertDailyHousProp(OperationDate, cracno, LastCompletedDueDate, LoanStatusCode, IntRate, Instalment, actoutbal,
    //        GracePeriod, CrPeriod, CrCat, IsTrans, preoutbal, predatedue, datedue, temp);
    //    }
    //    //InsertDailyHousProp(OperationDate, cracno, LastCompletedDueDate, LoanStatusCode, IntRate, Instalment, actoutbal,
    //    //    GracePeriod, CrPeriod, CrCat, IsTrans, preoutbal, predatedue,datedue);

    //    dw = new DataWorksClass(reportconstring);
    //    dw.SetCommand();
    //    dw.InsertBulk(temp, "DailyHousProp");

    //}
    private DateTime GetDatedue(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select max(datedue) from transassign 
                        where cracno = @cracno and trstatus != 'C' 
                        and tramt = assignamt and taskid = 'CAPD' and transref<>'DISB'");
        dw.SetSqlCommandParameters("cracno", cracno);
        return DateTime.Parse(dw.GetSingleData());
    }

    private void InsertNotUpdatedAccounts(string startdate, string enddate)
    {
        DataTable dt = new DataTable();
        dt = GetNotUpdatedAccounts(startdate, enddate);
        dw = new DataWorksClass(reportconstring);
        dw.SetCommand();
        dw.InsertBulk(dt, "DailyHousProp");
    }

    private DataTable GetNotUpdatedAccounts(string startdate, string enddate)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select @enddate as OperationDate,dh.cracno,dh.LastCompletedDueDate,dh.LoanStatusCode,h.IntRate,h.Instalment,dh.actoutbal,
                            dh.datedue,h.GracePeriod,h.CrPeriod,h.CrCat,0 as IsTrans,dh.actoutbal,dh.predatedue
                            from CreditReportsDb.ReportUser.DailyHousProp dh, housprop h
                            where OperationDate=@startdate and h.cracno = dh.cracno and h.cracno not in (
                            select cracno from disbbalsum where grantdate=@enddate and scheduleno = 1 and transamt > 0
                            union
                            select distinct cracno from gltrans where trdate = @enddate and left(cracno,1) = '6') ");
        dw.SetDataAdapterParameters("startdate", startdate);
        dw.SetDataAdapterParameters("enddate", enddate);
        return dw.GetDataTable();
    }

    private void InsertUpdatedAccounts(string startdate, string enddate, DataTable dt)
    {
        int arreasmonths = 0;
        double arreasamount = 0;
        DataTable crcatdata = new DataTable();
        DataTable dt1, temp;
        temp = new DataTable();
        foreach (DataRow dr in dt.Rows)
        {
            DateTime predatedue = DateTime.Parse(dr["LastCompletedDueDate"].ToString());
            DateTime LastCompletedDueDate;
            string cracno = dr["cracno"].ToString();

            double preoutbal = double.Parse(dr["actoutbal"].ToString());
            DateTime datedue = DateTime.Parse(dr["DateDue"].ToString());
            int LoanStatusCode = int.Parse(dr["LoanStatusCode"].ToString());
            double IntRate = double.Parse(dr["IntRate"].ToString());
            double Instalment = double.Parse(dr["Instalment"].ToString());
            int GracePeriod = int.Parse(dr["GracePeriod"].ToString());
            int CrPeriod = int.Parse(dr["CrPeriod"].ToString());
            int CrCat = int.Parse(dr["CrCat"].ToString());
            double actoutbal = double.Parse(dr["actoutbal"].ToString());
            string refcode = CrCat.ToString("00") + "100001";
            double cramt = GetSumTrans(cracno, "CR", enddate);
            double dramt = GetSumTrans(cracno, "DR", enddate);

            int newcrcat = GetNewCrCat(cracno, enddate, CrCat);
            if (newcrcat != CrCat)
            {
                CrCat = newcrcat;
            }

           
            bool IsTrans;
          
            if (cramt != 0 || dramt != 0)
            {
                IsTrans = true;
                dt1 = new DataTable();
                dt1 = GetPaymentHistoryData(cracno, enddate);
                if (dt1.Rows.Count != 0)
                {
                    try
                    {
                        LastCompletedDueDate = Convert.ToDateTime(dt1.Rows[0]["Datedue"].ToString());
                    }
                    catch
                    {
                        LastCompletedDueDate = DateTime.Parse(dr["LastCompletedDueDate"].ToString());
                    }
                    string trstatus = dt1.Rows[0]["trstatus"].ToString();
                    switch (trstatus)
                    {
                        case "F":
                            LastCompletedDueDate = LastCompletedDueDate.AddMonths(1);
                            break;
                    }
                }
                else
                {
                    LastCompletedDueDate = GetDueDate(cracno, predatedue);
                }

                actoutbal = actoutbal - (cramt - dramt);
            }
            else
            {
                LastCompletedDueDate = DateTime.Parse(dr["LastCompletedDueDate"].ToString());
                IsTrans = false;
            }

            InsertDailyHousprop(enddate, cracno, LastCompletedDueDate, LoanStatusCode, IntRate, Instalment, actoutbal, datedue,
               GracePeriod, CrPeriod, CrCat, IsTrans, preoutbal, predatedue);


        }
    }

    private int GetNewCrCat(string cracno, string trdate, int crcat)
    {
        int newcrcat;
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select crcat  from housprop where cracno in (
                        select cracno from HouspropHistry where cracno = @cracno 
                        and changedate =  @trdate)");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("trdate", trdate);

        newcrcat = int.Parse(dw.GetSingleData());
        if (newcrcat == 0)
        {
            newcrcat = crcat;
        }

        return newcrcat;
    }
    private DataTable GetCrCat(string cracno, string trdate)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select right(left(refglcode,8),2) as crcat from gltrans where cracno = @cracno
                            and right(left(refglcode,8),2) != '00' and trdate=@trdate ");
        dw.SetDataAdapterParameters("cracno", cracno);
        dw.SetDataAdapterParameters("trdate", trdate);
        return dw.GetDataTable();
    }

    private DataTable GetFutureCracno()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select '20090831' as operationdate, c.cracno, '19000101' as LastCompletedDueDate, 1 as LoanStatusCode, c.intrate, c.instalment, 0 as actoutbal
                            , '19000101' as datedue,1 as graceperiod,0 as crperiod,0 as crcat,0 as istrans,
                            0 as preoutbal,'19000101' as predatedue from housprop h, crmast c
                            where h.cracno = c.cracno and h.cracno not in 
                            (select cracno from tdbold.creditadmin.housprop)");
        return dw.GetDataTable();
    }


    private void InsertFutureCracno(DataTable dt)
    {
        foreach (DataRow dr in dt.Rows)
        {
            DateTime predatedue = DateTime.Parse("01/01/1900");
            string cracno = dr["cracno"].ToString();

            double preoutbal = double.Parse(dr["actoutbal"].ToString());
            DateTime datedue = DateTime.Parse("01/01/1900");
            int LoanStatusCode = int.Parse(dr["LoanStatusCode"].ToString());
            double IntRate = double.Parse(dr["IntRate"].ToString());
            double Instalment = double.Parse(dr["Instalment"].ToString());
            int GracePeriod = int.Parse(dr["GracePeriod"].ToString());
            int CrPeriod = int.Parse(dr["CrPeriod"].ToString());
            int CrCat = int.Parse(dr["CrCat"].ToString());
            double actoutbal = double.Parse(dr["actoutbal"].ToString());
            string refcode = CrCat.ToString("00") + "100001";
            bool IsTrans = false;
            string datekey = dr["operationdate"].ToString();

            InsertDailyHousprop(datekey, cracno, predatedue, LoanStatusCode, IntRate, Instalment, actoutbal, datedue,
                GracePeriod, CrPeriod, CrCat, IsTrans, preoutbal, predatedue);

        }

    }

    //private void InsertDisbursedAccounts(string startdate, string enddate)
    //{
    //    DataTable dt = new DataTable();
    //    dt = GetDisbursedAccounts(enddate);
    //    dw = new DataWorksClass(reportconstring);
    //    dw.SetCommand();
    //    dw.InsertBulk(dt, "DailyHousProp");
    //}

    private void InsertDisbursedAccounts(string startdate, string enddate)
    {
        DataTable dt1, temp;
        dt = GetDisbursedAccounts(enddate);
        temp = new DataTable();
        foreach (DataRow dr in dt.Rows)
        {
            DateTime predatedue = DateTime.Parse(dr["LastCompletedDueDate"].ToString());
            DateTime LastCompletedDueDate;
            string cracno = dr["cracno"].ToString();

            DateTime datedue = DateTime.Parse(dr["DateDue"].ToString());
            int LoanStatusCode = int.Parse(dr["LoanStatusCode"].ToString());
            double IntRate = double.Parse(dr["IntRate"].ToString());
            double Instalment = double.Parse(dr["Instalment"].ToString());
            int GracePeriod = int.Parse(dr["GracePeriod"].ToString());
            int CrPeriod = int.Parse(dr["CrPeriod"].ToString());
            int CrCat = int.Parse(dr["CrCat"].ToString());
            double actoutbal = double.Parse(dr["actoutbal"].ToString());
            LastCompletedDueDate = DateTime.Parse(dr["LastCompletedDueDate"].ToString());
            double preoutbal = GetPreOutBal(cracno, startdate);
            actoutbal += preoutbal;
            InsertDailyHousprop(enddate, cracno, LastCompletedDueDate, LoanStatusCode, IntRate, Instalment, actoutbal, datedue,
                 GracePeriod, CrPeriod, CrCat, true, preoutbal, predatedue);

            //InsertDailyHousProp(OperationDate, cracno, LastCompletedDueDate, LoanStatusCode, IntRate, Instalment, actoutbal,
            //    GracePeriod, CrPeriod, CrCat, IsTrans, preoutbal, predatedue,datedue);
        }
    }

    private double GetPreOutBal(string cracno, string OperationDate)
    {
        dw = new DataWorksClass(reportconstring);
        dw.SetCommand(@"select actoutbal from dailyhousprop where cracno = @cracno and OperationDate=@OperationDate");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("OperationDate", OperationDate);
        return double.Parse(dw.GetSingleData());
    }

    private DataTable GetDisbAccounts(string enddate)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select h.cracno, d.grantdate as LastCompletedDueDate, 1 as LoanStatusCode, 
                            h.IntRate,h.Instalment, 1 as GracePeriod, DATEADD(m,1,d.grantdate) as datedue,
                            0 as actoutbal, h.CrPeriod, h.CrCat
                            from crmast c, disbbalsum d, housprop h 
                            where d.grantdate = @enddate
                            and c.cracno = d.cracno
                            and c.cracno = h.cracno
                            and d.transamt > 0
                            order by c.cracno ");
        dw.SetDataAdapterParameters("enddate", enddate);
        return dw.GetDataTable();
    }

    private DataTable GetUpdatedAccounts(string startdate, string enddate)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select cracno, LastCompletedDueDate, 1 as LoanStatusCode, 
                            IntRate,Instalment, 1 as GracePeriod, datedue, actoutbal, CrPeriod, CrCat  
                            from CreditReportsDb.ReportUser.DailyHousProp
                            where OperationDate=@startdate and cracno in
                            (select distinct cracno from gltrans where trdate = @enddate and left(cracno,1) = '6')");
        dw.SetDataAdapterParameters("startdate", startdate);
        dw.SetDataAdapterParameters("enddate", enddate);
        return dw.GetDataTable();
    }


    private DataTable GetDisbursedAccounts(string enddate)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select @enddate as OperationDate, c.cracno, d.grantdate as LastCompletedDueDate, 1 as LoanStatusCode, 
                            c.IntRate,c.Instalment, d.transamt as actoutbal, DATEADD(m,1,d.grantdate) as datedue,1 as GracePeriod, 
                            c.CrPeriod, c.CrCat, 1 as IsTrans, 0 as preoutbal, d.grantdate as preduedate
                            from crmast c, disbbalsum d  
                            where d.grantdate = @enddate
                            and c.cracno = d.cracno
                            and d.transamt > 0");
        dw.SetDataAdapterParameters("enddate", enddate);
        return dw.GetDataTable();
    }

    public void GetHousProp(string number)
    {

        DataTable temp = new DataTable();
        temp = SetDataTableHP(temp);
        fc = new FunctionClass();
        DataTable dates = new DataTable();
        //dates = GetDates(number);
        DataTable dt1;
        //for (int i = 0; dates.Rows.Count > i; i++)
        //{
        //    string startdateS, enddateS;
        //    if (i == 0)
        //    {
        //        startdateS = "20090731";
        //        enddateS = dates.Rows[i]["datekey"].ToString().Trim();
        //    }
        //    else
        //    {
        //        startdateS = dates.Rows[i - 1]["datekey"].ToString().Trim();
        //        enddateS = dates.Rows[i]["datekey"].ToString().Trim();
        //    }
        //    DateTime startdateD = fc.GetDateinKeyDate(startdateS);
        //    DateTime enddateD = fc.GetDateinKeyDate(enddateS);
        //    string startdate = fc.GetDateKeyinDate(startdateD).ToString();
            //GetGlAbstact(startdateS, enddateS);


            //InsertNotUpdatedAccounts(startdateS, enddateS);



            ////InsertDisbursedAccounts(startdateS, enddateS);
            //dt = new DataTable();
            ////Get Updated Accounts
            //dt = GetUpdatedAccounts(startdateS, enddateS);
            //InsertUpdatedAccounts(startdateS, enddateS, dt);
            ////Get Disbursed accounts
            //dt = new DataTable();
            //dt = GetDisbAccounts(startdateS, enddateS);
            //InsertUpdatedAccounts(startdateS, enddateS, dt);

            ////Get transaction daily proof sheet - recovery
            ////GetDailyProof(enddateD, "RECV", "OTHR", "DISB");

            ////Get daily disbursement proof sheet
            ////GetDailyDusburseSummary(enddateD);

            ////Get daily GL transaction summery
            ////GetGLTransactionSummeryReport("0308", startdate, enddateS);

            ////DataTable futuredata = new DataTable();
            ////futuredata = GetFutureCracno();
            ////InsertFutureCracno(futuredata);

            //GetTrial(startdateS, enddateS);

            //InsertChanges(enddateS);
            InsertNewAccounts(number);


       // }
    }

    private void InsertNewAccounts(string cracno)
    {
        FunctionClass fc = new FunctionClass();
        dt = new DataTable();
        dt = GetnewAccountNumbers(cracno); //Dumi
        foreach (DataRow dr in dt.Rows)
        {
            DateTime operationdate = DateTime.Parse(dr["changedate"].ToString());
            DataTable tempdates = new DataTable();
            string operationdateS = fc.GetDateKeyinDate(operationdate).ToString();
            tempdates = GetLagerDates(operationdateS);
            cracno = dr["cracno"].ToString();
            DateTime ldatedue = DateTime.Parse(dr["LastCompletedDueDate"].ToString());
            int loanstatuscode = 0;
            double intrate = double.Parse(dr["intrate"].ToString());
            double instalment = double.Parse(dr["instalment"].ToString());
            double actoutbal = double.Parse(dr["newoutbal"].ToString());
            DateTime datedue = DateTime.Parse(dr["datedue"].ToString());
            int graceperiod = 1;
            int crperiod = int.Parse(dr["crperiod"].ToString());
            int crcat = int.Parse(dr["crcat"].ToString());
            double preoutbal = double.Parse(dr["actoutbal"].ToString());
            if (preoutbal != 0)
            {
                preoutbal -= actoutbal;
            }

            DateTime predatedue = DateTime.Parse(dr["LastCompletedDueDate"].ToString());
            bool istrans = true;

            InsertDailyHousprop(operationdateS, cracno, ldatedue, loanstatuscode, intrate, instalment,
                   actoutbal, datedue, graceperiod, crperiod, crcat, istrans, preoutbal, predatedue);

            DataTable temddates = new DataTable();

            temddates = GetLagerDates(operationdateS);
            for (int i = 0; temddates.Rows.Count > i; i++)
            {
                string startdateS, enddateS;

                startdateS = temddates.Rows[i]["datekey"].ToString().Trim();
                try
                {
                    enddateS = temddates.Rows[i + 1]["datekey"].ToString().Trim();
                    DataTable tempdata = new DataTable();
                    //Get Updated Accounts
                    tempdata = GetAccountDetails(cracno, startdateS);
                    InsertUpdatedAccounts(startdateS, enddateS, tempdata);
                }
                catch
                {
                    //
                }
               
            }
        }
    }

    private DataTable GetAccountDetails(string cracno, string OperationDate)
    {
        dw = new DataWorksClass(reportconstring);
        dw.SetDataAdapter(@"select * from  dailyhousprop where cracno = @cracno and OperationDate=@OperationDate");
        dw.SetDataAdapterParameters("cracno", cracno);
        dw.SetDataAdapterParameters("OperationDate", OperationDate);
        return dw.GetDataTable();
    }

    private DataTable GetLagerDates(string datekey)
    {
        dw = new DataWorksClass(reportconstring);
        dw.SetDataAdapter(@"select * from  calendar where datekey >= @datekey order by datekey");
        dw.SetDataAdapterParameters("datekey", datekey);
        return dw.GetDataTable();
    }

    private DataTable GetnewAccountNumbers(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from housprophistry where cracno=@cracno and actoutbal != newoutbal");
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }

    public void GetGLTransactionSummeryReport(string branchcode, string opendate, string closedate)
    {
        fc = new FunctionClass();
        dt = new DataTable();

        dt = GetGLAbstractRecords1(opendate);

        string datekey = closedate; //fc.GetDateKeyinDate(fc.GetDateinDateKey(closedate)).ToString();
        double closingbal;
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            double creditamt = 0, debitamt = 0;
            string refglcode = dt.Rows[i]["refglcode"].ToString();
            string gldes = dt.Rows[i]["gldesc"].ToString();
            string glcode = dt.Rows[i]["glcode"].ToString();
            double openingbal = double.Parse(dt.Rows[i]["curbal"].ToString());
            if (refglcode == "903081000000994")
            {
                double tramt = GetSumCashTransactions(refglcode, closedate, "CR");
                creditamt += tramt;
                tramt = GetSumCashTransactions(refglcode, closedate, "DR");
                debitamt -= tramt;
                closingbal = openingbal + creditamt + debitamt;
            }
            else
            {
                double tramt = GetSumTransactions(refglcode, closedate, "CR");
                creditamt += tramt;
                tramt = GetSumTransactions(refglcode, closedate, "DR");
                debitamt -= tramt;
                closingbal = openingbal + creditamt + debitamt;
            }
            InsertGLAbstract1(datekey, refglcode, glcode, gldes, closingbal);
            InsertDailyGLTransaction(datekey, branchcode, refglcode, gldes, openingbal, debitamt, creditamt, closingbal);
        }
    }

    private int InsertDailyGLTransaction(string Date, string BranchCode, string RefGlCode, string GlDesc,
                                         double OpenBal, double Debit, double Credit, double CloseBal)
    {
        dw = new DataWorksClass(reportconstring);
        dw.SetCommand(@"insert into DailyGLTransaction(Date,BranchCode,RefGlCode,GlDesc,OpenBal,Debit,Credit,CloseBal)
                        values(@Date,@BranchCode,@RefGlCode,@GlDesc,@OpenBal,@Debit,@Credit,@CloseBal)");
        dw.SetSqlCommandParameters("Date", Date);
        dw.SetSqlCommandParameters("BranchCode", BranchCode);
        dw.SetSqlCommandParameters("RefGlCode", RefGlCode);
        dw.SetSqlCommandParameters("GlDesc", GlDesc);
        dw.SetSqlCommandParameters("OpenBal", OpenBal);
        dw.SetSqlCommandParameters("Debit", Debit);
        dw.SetSqlCommandParameters("Credit", Credit);
        dw.SetSqlCommandParameters("CloseBal", CloseBal);
        return dw.Insert();
    }

    public void GetDailyDusburseSummary(DateTime date)
    {
        dt = new DataTable();
        fc = new FunctionClass();
        string transno;

        //vihanga 2009-07-27
        dt = GetTransactionsForDisbursement(date, "DISB");
        disbSummery = new DataTable();
        disbSummery = AddColumsToDailyDisbSummery(disbSummery);
        foreach (DataRow dr in dt.Rows)
        {
            transno = dr["transno"].ToString();
            GetDisbursementSummeryDetails(transno, fc.GetDateKeyinDate(date).ToString());
        }

        dw = new DataWorksClass(reportconstring);
        dw.SetCommand();
        dw.InsertBulk(disbSummery, "DisbursementSummery");
    }

    private void GetDisbursementSummeryDetails(string transno, string date)
    {
        fc = new FunctionClass();

        string cracno = "0";
        decimal tramt = 0, BOC = 0, title = 0, Interest = 0, Inspecsion = 0, Legal = 0, FireInsu = 0, Retain = 0, Penal = 0, Others = 0;
        dt = GetTrAmt(transno);
        decimal totAmt = 0;
        foreach (DataRow dr in dt.Rows)
        {
            string taskid = dr["taskid"].ToString();
            tramt = decimal.Parse(dr["tramt"].ToString());
            switch (taskid)
            {
                case "CAPD":
                    totAmt += tramt;
                    BOC += tramt;
                    break;

                case "INTR":
                    Interest += tramt;
                    BOC -= tramt;
                    break;

                case "INSN900000":
                    Inspecsion += tramt;
                    BOC -= tramt;
                    break;

                case "INSE900000":
                    Inspecsion += tramt;
                    BOC -= tramt;
                    break;


                case "INSD900000":
                    Inspecsion += tramt;
                    BOC -= tramt;
                    break;
                case "LCHN":
                    Legal += tramt;
                    BOC -= tramt;
                    break;

                case "LCHN900000":
                    Legal += tramt;
                    BOC -= tramt;
                    break;

                case "LCHE900000":
                    Legal += tramt;
                    BOC -= tramt;
                    break;

                case "LCHD900000":
                    Legal += tramt;
                    BOC -= tramt;
                    break;

                case "LCCN":
                    Legal += tramt;
                    BOC -= tramt;
                    break;

                case "LCCE":
                    Legal += tramt;
                    BOC -= tramt;
                    break;

                case "FSLD900000":
                    FireInsu += tramt;
                    BOC -= tramt;
                    break;

                case "FJSD900000":
                    FireInsu += tramt;
                    BOC -= tramt;
                    break;

                case "FUAD900000":
                    FireInsu += tramt;
                    BOC -= tramt;
                    break;

                case "FCED900000":
                    FireInsu += tramt;
                    BOC -= tramt;
                    break;

                case "FEID900000":
                    FireInsu += tramt;
                    BOC -= tramt;
                    break;

                case "FALD900000":
                    FireInsu += tramt;
                    BOC -= tramt;
                    break;

                case "RTAI900000":
                    Retain += tramt;
                    BOC -= tramt;
                    break;

                case "TCEE900000":
                    title += tramt;
                    BOC -= tramt;
                    break;

                case "TCEN900000":
                    title += tramt;
                    BOC -= tramt;
                    break;

                case "TEIE900000":
                    title += tramt;
                    BOC -= tramt;
                    break;
                case "TEIN900000":
                    title += tramt;
                    BOC -= tramt;
                    break;

                case "TJSE900000":
                    title += tramt;
                    BOC -= tramt;
                    break;

                case "TJSN900000":
                    title += tramt;
                    BOC -= tramt;
                    break;

                case "TSLE900000":
                    title += tramt;
                    BOC -= tramt;
                    break;

                case "TSLN900000":
                    title += tramt;
                    BOC -= tramt;
                    break;

                case "TUAN900000":
                    title += tramt;
                    BOC -= tramt;
                    break;

                case "TUAE900000":
                    title += tramt;
                    BOC -= tramt;
                    break;

                    //Disbursement Title
                case "TCED900000":
                    title += tramt;
                    BOC -= tramt;
                    break;
                case "TEID900000":
                    title += tramt;
                    BOC -= tramt;
                    break;
                case "TJSD900000":
                    title += tramt;
                    BOC -= tramt;
                    break;
                case "TSLD900000":
                    title += tramt;
                    BOC -= tramt;
                    break;
                case "TUAD900000":
                    title += tramt;
                    BOC -= tramt;
                    break;

                case "PNLR":
                    Penal += tramt;
                    BOC -= tramt;
                    break;

                default:
                    Others += tramt;
                    BOC -= tramt;
                    break;

            }




        }

        DataRow rowDescription;
        rowDescription = disbSummery.NewRow();
        rowDescription["Date"] = date;
        rowDescription["ReportID"] = "02";
        rowDescription["BranchCode"] = "0308";
        rowDescription["NoofACs"] = "1";
        cracno = dt.Rows[0]["cracno"].ToString();
        if ((cracno.Length == 12) || (cracno.Length == 13))
        {
            cracno = GetAppNo(cracno);
        }
        rowDescription["Appno"] = cracno;
        rowDescription["BOC"] = Math.Round(BOC, 2);
        rowDescription["Interest"] = Math.Round(Interest, 2);
        rowDescription["Inspection"] = Math.Round(Inspecsion, 2);
        rowDescription["Legal"] = Math.Round(Legal, 2);
        rowDescription["FireInsu"] = Math.Round(FireInsu, 2);
        rowDescription["Retain"] = Math.Round(Retain, 2);
        rowDescription["Penal"] = Math.Round(Penal, 2);
        rowDescription["Others"] = Math.Round(Others, 2);
        rowDescription["Total"] = Math.Round(totAmt, 2);
        rowDescription["Title"] = Math.Round(title, 2);

        disbSummery.Rows.Add(rowDescription);


    }

    private string GetAppNo(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select appno from crmast where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return dw.GetSingleData();
    }

    private DataTable GetTrAmt(string transno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select taskid, transno, tramt, cracno from TransAssign 
                             where transno=@transno and (trstatus='F' or trstatus='P')");
        dw.SetDataAdapterParameters("transno", transno);
        return dw.GetDataTable();

    }

    private DataTable GetTransactionsForDisbursement(DateTime date, string transref)
    {
        dw = new DataWorksClass(constring);

        //dw.SetDataAdapter(@"select distinct transno from crtransjrnl where trdate=@trdate and TrStatus='A'");       

        dw.SetDataAdapter(@" select distinct t.transno from transassign t where 
			t.transno in (select distinct transno from gltrans where trdate=@trdate and TrStatus<>'C') and
			t.transref=@transref");

        dw.SetDataAdapterParameters("trdate", date);
        dw.SetDataAdapterParameters("transref", transref);
        return dw.GetDataTable();
    }

    private void GetDailyProof(DateTime date, string transref1, string transref2, string transref3)
    {
        dt = new DataTable();
        fc = new FunctionClass();
        dt = GetTransactions(date, transref1, transref2, transref3);

        foreach (DataRow dr in dt.Rows)
        {
            string transno = dr["transno"].ToString();
            string cracno = dr["cracno"].ToString();
            string transref = dr["transref"].ToString();
            GetDailyProofData(transno, date, cracno, transref);
        }
    }

    private DataTable GetTransactions(DateTime date, string transref1, string transref2, string transref3)
    {
        dw = new DataWorksClass(constring);

        //dw.SetDataAdapter(@"select distinct transno from crtransjrnl where trdate=@trdate and TrStatus='A'");       

        dw.SetDataAdapter(@" select distinct g.transno, t.cracno as cracno,t.transref from transassign t, gltrans g
                            where t.refno=g.transassignrefno and g.trstatus<>'C' and g.trdate=@trdate
                            and (t.transref=@transref1 or t.transref=@transref2 or t.transref=@transref3) 
                            order by g.transno,t.cracno");

        // dw.SetDataAdapter(@" select distinct g.transno, t.cracno as cracno,t.transref from transassign t, gltrans g
        //                     where t.refno=g.transassignrefno and g.trstatus<>'C' and g.trdate=@trdate
        //                     and (t.transref=@transref1 or t.transref=@transref2 or t.transref=@transref3)  and
        //                     t.CrAcNo not in (select CrAcNo 
        //from CreditReportsDb.ReportUser.DailyProofSheetReportRecovery 
        //where CurrentDate='20190729') order by g.transno,t.cracno");

        dw.SetDataAdapterParameters("trdate", date);
        dw.SetDataAdapterParameters("transref1", transref1);
        dw.SetDataAdapterParameters("transref2", transref2);
        dw.SetDataAdapterParameters("transref3", transref3);
        return dw.GetDataTable();
    }

    private void GetDailyProofData(string transno, DateTime trdate, string cracno, string transref)
    {
        dailyproof = new DataTable();
        dailyproof = AddColumsToDailyProofSheet(dailyproof);
        DataRow rowDescription;
        rowDescription = dailyproof.NewRow();

        fc = new FunctionClass();

        double instalment = 0, penal = 0, capital = 0, interest = 0, intrate = 0, outbal = 0,
           tramt = 0, othercut = 0, totcap = 0;

        string BranchCode = "0308", TransNo, CrDes, acsign, TrDetail;  //change this to int
        double totAmt = 0;
        int CrCatcode;
        DateTime datedue;

        DateTime duedate = new DateTime();
        DateTime nextduedate = new DateTime();
        dt = new DataTable();

        TrDetail = GetBatchTempDescriptions(cracno, transno);
        switch (transref)
        {
            case "RECV":
                dt = GetTransactions(transno, cracno, trdate);
                break;

            case "OTHR":

                if (cracno.Substring(0, 1) == "6")
                {

                    dt = GetTransactions(transno, cracno, trdate);
                }
                if (cracno.Substring(0, 1) == "9")
                {
                    dt = GetDirectGLTransactions(transno, cracno, trdate);
                }
                break;

            case "DISB":
                if (cracno.Substring(0, 1) == "6")
                {
                    dt = GetTransactions(transno, cracno, trdate);
                }
                break;
        }

        //BranchCode = Session["brcode"].ToString();
        if (dt.Rows.Count > 0)
        {
            //TransNo = dt.Rows[0]["transno"].ToString();
            CrCatcode = int.Parse(dt.Rows[0]["CrCat"].ToString());
            CrDes = dt.Rows[0]["CrDes"].ToString();

            //cracno = dt.Rows[0]["cracno"].ToString();
            instalment = double.Parse(dt.Rows[0]["instalment"].ToString());
            intrate = double.Parse(dt.Rows[0]["intrate"].ToString());
            outbal = double.Parse(dt.Rows[0]["outbal"].ToString());
            try
            {
                nextduedate = DateTime.Parse(dt.Rows[0]["Nextdatedue"].ToString());
                datedue = DateTime.Parse(dt.Rows[0]["datedue"].ToString());
            }
            catch
            {
                datedue = DateTime.Parse("01/01/1900");
                nextduedate = DateTime.Parse("01/01/1900");
            }

            //nextduedate 


            foreach (DataRow dr in dt.Rows)
            {
                string taskid = dr["taskid"].ToString();
                acsign = dr["acsign"].ToString();
                tramt = double.Parse(dr["tramt"].ToString());
                if (acsign == "CR")
                {
                    switch (taskid)
                    {
                        case "PNLR":
                            penal += tramt;
                            break;

                        case "INTR":
                            interest += tramt;
                            break;

                        case "CAPD":
                            capital += tramt;
                            break;

                        case "PSOC900000":
                            othercut += tramt;
                            break;

                        default:
                            othercut += tramt;
                            break;
                    }
                    totAmt += tramt;
                }
                else
                {
                    switch (taskid)
                    {
                        case "PNLR":
                            penal -= tramt;
                            break;

                        case "INTR":
                            interest -= tramt;
                            break;

                        case "CAPD":
                            capital -= tramt;
                            break;

                        case "PSOC900000":
                            othercut -= tramt;
                            break;
                        default:
                            othercut -= tramt;
                            break;
                    }
                    totAmt -= tramt;
                }

            }
            totAmt = Math.Round(totAmt, 2);
            interest = Math.Round(interest, 2);
            penal = Math.Round(penal, 2);
            capital = Math.Round(capital, 2);
            string datekey = fc.GetDateKeyinDate(trdate).ToString();

            InsertRecoveryDFailyProofSheet(datekey, "01", 308, transno, cracno, instalment, intrate,
                                           datedue, outbal, totAmt, penal, interest, capital, othercut, nextduedate, 0, CrCatcode, CrDes, TrDetail);
        }
    }

    private int InsertRecoveryDFailyProofSheet(string CurrentDate, string ReportID, int BranchCode, string TransNo, string CrAcNo, double Instalment,
                                              double IntRate, DateTime DateDue, double OutBal, double TrAmt, double Penal, double Interest,
                                              double Capital, double OtherCut, DateTime NextDue, double CurBal, int CrCat, string CrDes,
                                              string TrDetail)
    {
        dw = new DataWorksClass(reportconstring);
        dw.SetCommand(@"insert into DailyProofSheetReportRecovery(CurrentDate,ReportID,BranchCode,TransNo,CrAcNo,Instalment,IntRate,
                      DateDue,OutBal,TrAmt,Penal,Interest,Capital,OtherCut,NextDue,CurBal,CrCat,CrDes,TrDetail) values
                      (@CurrentDate,@ReportID,@BranchCode,@TransNo,@CrAcNo,@Instalment,@IntRate,@DateDue,
                      @OutBal,@TrAmt,@Penal,@Interest,@Capital,@OtherCut,@NextDue,@CurBal,@CrCat,@CrDes,@TrDetail)");
        dw.SetSqlCommandParameters("CurrentDate", CurrentDate);
        dw.SetSqlCommandParameters("ReportID", ReportID);
        dw.SetSqlCommandParameters("BranchCode", BranchCode);
        dw.SetSqlCommandParameters("TransNo", TransNo);
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        dw.SetSqlCommandParameters("Instalment", Instalment);
        dw.SetSqlCommandParameters("IntRate", IntRate);
        dw.SetSqlCommandParameters("DateDue", DateDue);
        dw.SetSqlCommandParameters("OutBal", OutBal);
        dw.SetSqlCommandParameters("TrAmt", TrAmt);
        dw.SetSqlCommandParameters("Penal", Penal);
        dw.SetSqlCommandParameters("Interest", Interest);
        dw.SetSqlCommandParameters("Capital", Capital);
        dw.SetSqlCommandParameters("OtherCut", OtherCut);
        dw.SetSqlCommandParameters("NextDue", NextDue);
        dw.SetSqlCommandParameters("CurBal", CurBal);
        dw.SetSqlCommandParameters("CrCat", CrCat);
        dw.SetSqlCommandParameters("CrDes", CrDes);
        dw.SetSqlCommandParameters("TrDetail", TrDetail);
        return dw.Insert();
    }

    private DataTable GetDirectGLTransactions(string transno, string cracno, DateTime trdate)
    {

        dw = new DataWorksClass(oldconstring);
        dw.SetDataAdapter(@"SELECT DISTINCT T.CrCat AS CrCat,0.0 as intrate,T.TaskId,g.TransNo as transno,T.CrAcNo AS CrAcNo,
                            0.0 as Instalment,G.TrAmt As TrAmt,'1900/01/01' as datedue,
                            0.0 as outbal,
                            '1900/01/01' as Nextdatedue,C.CrDes,G.Acsign as AcSign
                            FROM TDB.CreditAdmin.TransAssign T, TDB.CreditAdmin.GLtrans G,
                            TDB.CreditAdmin.CrCategory C
                            WHERE T.RefNo=G.TransAssignRefNo AND T.Transref='OTHR' AND g.TransNo=@transno
                            AND T.CrCat=C.CrCatCode
                            AND T.CrACNo=@cracno AND left(T.CrAcno,1)=9  and right(left(T.cracno,8),2)!= '00'
                            and g.trdate = @trdate
                            --ORDER BY M.CrACno,T.DateDue, T.Taskid desc
                            ");
        dw.SetDataAdapterParameters("transno", transno);
        dw.SetDataAdapterParameters("cracno", cracno);
        dw.SetDataAdapterParameters("trdate", trdate);
        return dw.GetDataTable();

    }

//    private DataTable GetTransactions(string transno, string cracno, string trdate, string operationdate)
//    {

//        dw = new DataWorksClass(constring);
//        dw.SetDataAdapter(@"SELECT DISTINCT t.CrCat AS CrCat, t.IntRate as intrate, t.TaskId, t.TransNo as transno, t.CrAcNo AS CrAcNo, 
//                            h.Instalment, t.TrAmt As TrAmt, h.lastcompletedduedate as datedue,
//                            h.ActOutBal as outbal,
//                            h.lastcompletedduedate as Nextdatedue, C.CrDes, 
//                            case when t.trtype = 'I' then 'CR' 
//                            else 'DR' end as AcSign
//                            FROM CreditReportsDb.reportuser.dailyhousprop H,
//                            TDBBranches.CreditAdmin.TransAssign T, TDBBranches.CreditAdmin.CrCategory C
//                            WHERE t.CrAcNo=H.CrAcNo AND 
//                            T.CrCat=C.CrCatCode and t.transno = @transno
//                            AND t.CrACNo=@CrACNo and t.trdate = @trdate
//                            and h.operationdate = @operationdate
//                            ORDER BY t.CrACno,t.DateDue, t.Taskid desc");
//        dw.SetDataAdapterParameters("transno", transno);
//        dw.SetDataAdapterParameters("cracno", cracno);
//        dw.SetDataAdapterParameters("trdate", trdate);
//        dw.SetDataAdapterParameters("operationdate", operationdate);
//        return dw.GetDataTable();

//    }


    private DataTable GetTransactions(string transno, string cracno, DateTime trdate)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"SELECT DISTINCT T.CrCat AS CrCat,M.IntRate as intrate,T.TaskId,g.TransNo as transno,M.CrAcNo AS CrAcNo, g.gltransno,
                            M.Instalment,G.TrAmt As TrAmt,hp.lastcompletedduedate as datedue,
                            hp.ActOutBal as outbal,
                            h.lastcompletedduedate as Nextdatedue,C.CrDes,G.Acsign as AcSign
                            FROM TDB.CreditAdmin.CrMast M, TDB.CreditAdmin.HousProp Hp,
                            TDB.CreditAdmin.TransAssign T, TDB.CreditAdmin.GLtrans G,
                            TDB.CreditAdmin.HousProp H,TDB.CreditAdmin.CrCategory C
                            WHERE M.CrAcNo=Hp.CrAcNo AND 
                            M.CrAcNo=T.CrAcNo AND
                            T.RefNo=G.TransAssignRefNo 
                            AND M.CrAcNo=H.CrAcNo AND T.CrCat=C.CrCatCode and g.transno = @transno
                            AND T.CrACNo=@CrACNo and right(left(refglcode,8),2) <> '00' 
							and g.trdate = @trdate
                            --ORDER BY M.CrACno,T.DateDue, T.Taskid desc
                            ");
        dw.SetDataAdapterParameters("transno", transno);
        dw.SetDataAdapterParameters("cracno", cracno);
        dw.SetDataAdapterParameters("trdate", trdate);
        return dw.GetDataTable();

    }
    
    private string GetBatchTempDescriptions(string cracno, string transno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select TrDetail from batchtmp where cracno=@cracno and transno=@transno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("transno", transno);
        return dw.GetSingleData();
    }

    public void GetHousProp(string startdateS, string enddateS)
    {
        DataTable temp = new DataTable();
        temp = SetDataTableHP(temp);
        fc = new FunctionClass();
        DataTable dates = new DataTable();
        DataTable dt1;

        DateTime startdateD = fc.GetDateinKeyDate(startdateS);
        DateTime enddateD = fc.GetDateinKeyDate(enddateS);
        string startdate = fc.GetDateKeyinDate(startdateD).ToString();
        GetGlAbstact(startdateS, enddateS);
        InsertNotUpdatedAccounts(startdateS, enddateS);

        //InsertDisbursedAccounts(startdateS, enddateS);
        dt = new DataTable();
        //Get Updated Accounts
        dt = GetUpdatedAccounts(startdateS, enddateS);
        InsertUpdatedAccounts(startdateS, enddateS, dt);
        //Get Disbursed accounts
        dt = new DataTable();
        dt = GetDisbAccounts(enddateS);
        InsertUpdatedAccounts(startdateS, enddateS, dt);

        //Get transaction daily proof sheet - recovery
        GetDailyProof(enddateD, "RECV", "OTHR", "DISB");

        //Get daily disbursement proof sheet
        GetDailyDusburseSummary(enddateD);

        //Get daily GL transaction summery
        GetGLTransactionSummeryReport("0308", startdate, enddateS);



    }

    private void InsertChanges(string enddateS)
    {
        DataTable catcanges = new DataTable();
        catcanges = GetChanges(enddateS);
        foreach (DataRow dr in catcanges.Rows)
        {
            string cracno = dr["cracno"].ToString();
            int newcategory = int.Parse(GetVaule(dr, "crcat", "newcrcat"));
            double newoutbal = double.Parse(GetVaule(dr, "actoutbal", "newoutbal"));
            double newintrate = double.Parse(GetVaule(dr, "intrate", "newintrate"));
            int newcrperiod = int.Parse(GetVaule(dr, "crperiod", "newcrperiod"));
            double newinstallment = double.Parse(GetVaule(dr, "instalment", "newinstalment"));
            DateTime NewLastCompletedDueDate = DateTime.Parse(GetVaule(dr, "LastCompletedDueDate", "NewLastCompletedDueDate"));
            UpdateChanges(cracno, newcategory, newcrperiod, newintrate, newoutbal, NewLastCompletedDueDate,enddateS);
        }
    }

    private string GetVaule(DataRow dr, string value, string newvalue)
    {
        string fvalue;
        if (dr[newvalue].ToString() == "")
        {
            fvalue = dr[value].ToString();
        }
        else
        {
            if (dr[value].ToString() == dr[newvalue].ToString())
            {
                fvalue = dr[value].ToString();
            }
            else
            {
                fvalue = dr[newvalue].ToString();
            }
        }
        return fvalue;
    }

    private void UpdateChanges(string cracno, int newcrcat, int newcrperiod, double newintrate, double newoutbal, DateTime NewLastCompletedDueDate, string enddateS)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update CreditReportsDb.reportuser.DailyHousProp set intrate=@newintrate,
                        crperiod=@newcrperiod, actoutbal=@newoutbal, crcat=@newcrcat, LastCompletedDueDate=@NewLastCompletedDueDate
                        where operationdate >=  @enddateS and cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("newcrcat", newcrcat);
        dw.SetSqlCommandParameters("newcrperiod", newcrperiod);
        dw.SetSqlCommandParameters("newintrate", newintrate);
        dw.SetSqlCommandParameters("newoutbal", newoutbal);
        dw.SetSqlCommandParameters("NewLastCompletedDueDate", NewLastCompletedDueDate);
        dw.SetSqlCommandParameters("enddateS", enddateS);
        dw.Update();
    }

    private DataTable GetChanges(string enddateS)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select cracno, intrate, newintrate,
                            crperiod, newcrperiod, 
                            actoutbal, newoutbal, 
                            crcat, newcrcat, 
                            instalment,newinstalment,
                            LastCompletedDueDate , NewLastCompletedDueDate 
                            from HouspropHistry where changedate = @enddateS");
        dw.SetDataAdapterParameters("enddateS", enddateS);
        return dw.GetDataTable();
    }

    public string GetHousProp(string startdateS, string enddateS, int procno)
    {
        DataTable temp = new DataTable();
        temp = SetDataTableHP(temp);
        fc = new FunctionClass();
        DataTable dates = new DataTable();
        DataTable dt1;
        DateTime startdateD = fc.GetDateinKeyDate(startdateS);
        DateTime enddateD = fc.GetDateinKeyDate(enddateS);
        string startdate = fc.GetDateKeyinDate(startdateD).ToString();

        string returnString = "";

        switch (procno)
        {
            case 0:
                //check is already send for this date
                //if (ChechIsalreadysend(enddateS))
                //{
                //    returnString = "This process is already send";
                //    break;
                //}
                //else
                //{

                    ////Get GL Abstract & Get daily GL transaction summery
                    //GetGlAbstact(startdateS, enddateS);

                    //Get Trial
                    GetTrial(startdateS, enddateS);

                    ////Get transaction daily proof sheet - recovery
                    GetDailyProof(enddateD, "RECV", "OTHR", "DISB");

                    ////Get daily disbursement proof sheet
                    GetDailyDusburseSummary(enddateD);

                    //Get daily GL transaction summery
                    GetGLTransactionSummeryReport("0308", startdate, enddateS);

                    returnString = "Successfully Send the Report Process";
                    break;
                //}
            case 1:
                //check this is the month end date/check is interest provision send
                if (ChechIsalreadysend(enddateS))
                {
                    //Delete existing reports in the table DailyGLTransaction , DailyProofSheetReportRecovery , GLAbstract
                    DeleteDataInTable("ReportUser.DailyGLTransaction", enddateS);
                    DeleteDataInTable("ReportUser.DailyProofSheetReportRecovery", enddateS);
                    DeleteDataInTable("ReportUser.GLAbstract", enddateS);


                    ////Get GL Abstract & Get daily GL transaction summery
                    GetGlAbstact(startdateS, enddateS);

                    ////Get transaction daily proof sheet - recovery
                    GetDailyProof(enddateD, "RECV", "OTHR", "DISB");

                    //Get daily GL transaction summery
                    GetGLTransactionSummeryReport("0308", startdate, enddateS);

                    returnString = "Successfully Send the MONTH END Report Process";
                    break;
                }
                else
                {
                    returnString = "You have n't run the normal report Process...";
                    break;
                }

            case 2:
                dt = new DataTable();
                dt = GetDataFromInterestProvision(enddateS);
                returnString = ProcessSpecificProvision(dt, enddateS) + "send Valuation process";
                break;

            case 3:
                returnString = PropertyBaseLoanDetail(enddateS);
                break;
        }

        return returnString;


    }


    #region specifcprovisioncalculation
    private DataTable GetDataFromInterestProvision(string datekey)
    {
        fc = new FunctionClass();
        DateTime datedue = fc.GetDateinKeyDate(datekey);
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select distinct I.cracno,c.appno,Name,c.GrantAmt,I.actoutbal,
                            datediff(day,I.datedue,@datedue) as ArreasDays,
                            datediff(month,I.datedue,@datedue) as arreasMonths,cc.crdes,
                            L.statusname,i.statusid,I.datedue
                            from IntProvisionIndividual I, LoanStatus L, CrMast C,crcategory cc, housprop h
                            where I.datekey=@datekey and I.StatusId=L.statusId and 
                            cc.crcatcode=h.crcat and I.cracno=C.cracno and h.cracno=c.cracno order by i.cracno");
        //I.statusId !=6 and I.statusId !=1 and I.cracno=C.cracno order by i.cracno");
        dw.SetDataAdapterParameters("datedue", datedue);
        dw.SetDataAdapterParameters("datekey", datekey);
        return dw.GetDataTable();
    }

    private string ProcessSpecificProvision(DataTable dt, string DateKey)
    {
        fc = new FunctionClass();
        try
        {
            dw = new DataWorksClass(reportconstring);

            DataTable insertDt = new DataTable();
            insertDt = setInsertTable(insertDt);

            DataTable dt2 = new DataTable();
            string appno, cracno, name, statusName, crdes, valuertype = "";
            double provisionAmt = 0;
            double outbal, FSV, grantamt = 0;
            int statusId, ArreasMonth, arreasDays = 0;
            DateTime duedate, DateOfVal = System.DateTime.Now;

            for (int a = 0; a < dt.Rows.Count; a++)
            {
                cracno = dt.Rows[a][0].ToString();
                appno = dt.Rows[a][1].ToString();
                name = dt.Rows[a][2].ToString();
                grantamt = double.Parse(dt.Rows[a][3].ToString());
                outbal = double.Parse(dt.Rows[a][4].ToString());
                arreasDays = int.Parse(dt.Rows[a][5].ToString());
                ArreasMonth = int.Parse(dt.Rows[a][6].ToString());
                crdes = dt.Rows[a][7].ToString();
                statusName = dt.Rows[a][8].ToString();
                statusId = int.Parse(dt.Rows[a][9].ToString());
                duedate = DateTime.Parse(dt.Rows[a][10].ToString());

                dt2 = GetValuationData(appno);
                if (dt2.Rows.Count > 0)
                {
                    FSV = double.Parse(dt2.Rows[0][2].ToString());
                    DateOfVal = DateTime.Parse(dt2.Rows[0][1].ToString());
                    valuertype = dt2.Rows[0][3].ToString();
                }
                else
                {
                    FSV = 0;
                    DateOfVal = fc.GetDateinKeyDate("19000101");
                }

                if ((FSV > 0) && (outbal > 0))
                {
                    provisionAmt = getProvisonAmt(outbal, FSV, ArreasMonth, statusId);
                    if (provisionAmt < 0)
                        provisionAmt = 0;
                }
                else
                {
                    provisionAmt = 0;
                }

                insertDt = inserDataRow(cracno, appno, name, grantamt, outbal, arreasDays, ArreasMonth,
                    crdes, statusName, statusId, duedate, valuertype, FSV, DateOfVal, provisionAmt, DateKey, insertDt);
            }

            //delete valProvision
            deletevalprovision(DateKey);

            dw = new DataWorksClass(reportconstring);
            dw.SetCommand();
            dw.InsertBulk(insertDt, "valProvision");

            return insertDt.Rows.Count.ToString();
        }
        catch (Exception er)
        {
            return "ERROR" + er.ToString();
        }
    }

    private void deletevalprovision(string DateKey)
    {
        dw = new DataWorksClass(reportconstring);
        dw.SetCommand("delete from valProvision where datekey=@datekey");
        dw.SetSqlCommandParameters("DateKey", DateKey);
        dw.Delete();
    }

    private double getProvisonAmt(double outbal, double FSV, int ArreasMonth, int statusId)
    {
        double returnVal = 0;
        if ((statusId == 1) || (statusId == 2))
        {
            return returnVal;
        }
        else if (statusId == 3) //Substandard
        {
            returnVal = (outbal - (FSV * 0.75)) * 0.2;
        }
        else if (statusId == 4) //Doubtful
        {
            returnVal = (outbal - (FSV * 0.75)) * 0.5;
        }
        else if (statusId == 5) //Loss
        {
            if((ArreasMonth>=18) && (ArreasMonth<=28))
            {
                returnVal = (outbal - (FSV * 0.75)) * 1;
            }
            else if ((ArreasMonth >= 29) && (ArreasMonth <= 40))
            {
                returnVal = (outbal - (FSV * 0.6)) * 1;
            }
            else if ((ArreasMonth >= 41) && (ArreasMonth <= 52))
            {
                returnVal = (outbal - (FSV * 0.5)) * 1;
            }
            else if ((ArreasMonth >= 53) && (ArreasMonth <= 64))
            {
                returnVal = (outbal - (FSV * 0.4)) * 1;
            }
            else if ((ArreasMonth >= 65))
            {
                returnVal = (outbal - (FSV * 0.25)) * 1;
            }
        }
        return returnVal;
    }

    private DataTable GetValuationData(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select distinct appno,dateofval,forceval,valuertype from valuation where appno=@appno 
                            and dateofval=(select max(dateofval) from valuation where appno=@appno)");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();
    }

    private DataTable setInsertTable(DataTable insertDt)
    {
        dt = new DataTable();

        DataColumn cracno;
        cracno = new DataColumn();
        cracno.DataType = Type.GetType("System.String");
        cracno.ColumnName = "cracno";
        dt.Columns.Add(cracno);

        DataColumn appno;
        appno = new DataColumn();
        appno.DataType = Type.GetType("System.String");
        appno.ColumnName = "appno";
        dt.Columns.Add(appno);

        DataColumn name;
        name = new DataColumn();
        name.DataType = Type.GetType("System.String");
        name.ColumnName = "name";
        dt.Columns.Add(name);

        DataColumn grantamt;
        grantamt = new DataColumn();
        grantamt.DataType = Type.GetType("System.Double");
        grantamt.ColumnName = "grantamt";
        dt.Columns.Add(grantamt);

        DataColumn outbal;
        outbal = new DataColumn();
        outbal.DataType = Type.GetType("System.Double");
        outbal.ColumnName = "outbal";
        dt.Columns.Add(outbal);

        DataColumn arreasDays;
        arreasDays = new DataColumn();
        arreasDays.DataType = Type.GetType("System.Int32");
        arreasDays.ColumnName = "arreasDays";
        dt.Columns.Add(arreasDays);

        DataColumn ArreasMonth;
        ArreasMonth = new DataColumn();
        ArreasMonth.DataType = Type.GetType("System.Int32");
        ArreasMonth.ColumnName = "ArreasMonth";
        dt.Columns.Add(ArreasMonth);


        DataColumn crdes;
        crdes = new DataColumn();
        crdes.DataType = Type.GetType("System.String");
        crdes.ColumnName = "crdes";
        dt.Columns.Add(crdes);

        DataColumn statusName;
        statusName = new DataColumn();
        statusName.DataType = Type.GetType("System.String");
        statusName.ColumnName = "statusName";
        dt.Columns.Add(statusName);

        DataColumn statusId;
        statusId = new DataColumn();
        statusId.DataType = Type.GetType("System.Int32");
        statusId.ColumnName = "statusId";
        dt.Columns.Add(statusId);

        DataColumn duedate;
        duedate = new DataColumn();
        duedate.DataType = Type.GetType("System.DateTime");
        duedate.ColumnName = "duedate";
        dt.Columns.Add(duedate);

        DataColumn valuertype;
        valuertype = new DataColumn();
        valuertype.DataType = Type.GetType("System.String");
        valuertype.ColumnName = "valuertype";
        dt.Columns.Add(valuertype);

        DataColumn FSV;
        FSV = new DataColumn();
        FSV.DataType = Type.GetType("System.Double");
        FSV.ColumnName = "FSV";
        dt.Columns.Add(FSV);

        DataColumn DateOfVal;
        DateOfVal = new DataColumn();
        DateOfVal.DataType = Type.GetType("System.DateTime");
        DateOfVal.ColumnName = "DateOfVal";
        dt.Columns.Add(DateOfVal);

        DataColumn provisionAmt;
        provisionAmt = new DataColumn();
        provisionAmt.DataType = Type.GetType("System.Double");
        provisionAmt.ColumnName = "provisionAmt";
        dt.Columns.Add(provisionAmt);

        DataColumn DateKey;
        DateKey = new DataColumn();
        DateKey.DataType = Type.GetType("System.String");
        DateKey.ColumnName = "DateKey";
        dt.Columns.Add(DateKey);

        return dt;
    }
    private DataTable inserDataRow(string cracno, string appno, string name, double grantamt, double outbal,
        int arreasDays, int ArreasMonth, string crdes, string statusName, int statusId, DateTime duedate,
        string valuertype, double FSV, DateTime DateOfVal, double provisionAmt, string DateKey, DataTable insertDt)
    {
        DataRow dr;
        dr = insertDt.NewRow();
        dr["cracno"] = cracno;
        dr["appno"] = appno;
        dr["name"] = name;
        dr["grantamt"] = grantamt;
        dr["outbal"] = outbal;
        dr["arreasDays"] = arreasDays;
        dr["ArreasMonth"] = ArreasMonth;
        dr["crdes"] = crdes;
        dr["statusName"] = statusName;
        dr["statusId"] = statusId;
        dr["duedate"] = duedate;
        dr["valuertype"] = valuertype;
        dr["FSV"] = FSV;
        dr["DateOfVal"] = DateOfVal;
        dr["provisionAmt"] = provisionAmt;
        dr["DateKey"] = DateKey;
        insertDt.Rows.Add(dr);
        return insertDt;
    }

    #endregion

    #region PropertyBaseLoanDetails

    private string PropertyBaseLoanDetail(string enddateS)
    {
        return "0";
        //DataTable tempDataTable = new DataTable();
        //tempDataTable = setTempDataTable(tempDataTable);
        //dt = new DataTable();
        //dt = GetDistinctPlanNoLotNo();
        //DataTable dtAppNos = new DataTable();
        //DataTable dtCracnos = new DataTable();

        ////Variables
        //string lotNo = "";
        //string planNo = "0";
        //string SurveyName = "";
        //string appNos = "";
        //decimal totGrantAmt = 0;
        //string maxAppNoValuer = "";
        //string maxAppNoFSV = "";
        //string primaryHoldNIC = "";
        //string NPLloanNos = "";
        //string PLloanNos = "";
        //string planDate = "";
        //string landExtend = "";
        //string landName = "";
        //string landAddress = "";
        //string TotalStatus = "";

        //for (int a = 0; a < dt.Rows.Count; a++)
        //{
        //    lotNo = dt.Rows[a][0].ToString();

        //    dtAppNos = GetPAppNo(lotNo);

        //    for (int b = 0; b < dtAppNos.Rows.Count; b++)
        //    {
        //        appNos = appNos + dtAppNos.Rows[b][0].ToString() + " | ";

        //        dtCracnos = GetCracNo(dtAppNos.Rows[b][0].ToString());
        //        for (int c = 0; c < dtCracnos.Rows.Count; c++)
        //        {
                    
        //        }
        //    }
        //}
    }

    private DataTable GetCracNo(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select cracno from crmast where appno=@appno");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();
    }

    private DataTable GetPAppNo(string value)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select appno from hpsec where (rtrim(planNo)+ ' | ' + rtrim(LotNo))=@value");
        dw.SetDataAdapterParameters("value", value);
        return dw.GetDataTable();
    }

    private DataTable GetDistinctPlanNoLotNo()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select distinct (rtrim(planNo)+ ' | ' + rtrim(LotNo)) from hpsec");
        return dw.GetDataTable();
    }

    private DataTable InsertRow(string lotNo, string planNo, string SurveyName, string appNos, decimal totGrantAmt,
        string maxAppNoValuer, string maxAppNoFSV, string primaryHoldNIC, string NPLloanNos, string PLloanNos,
         string planDate, string landExtend, string landName, string landAddress, string TotalStatus, DataTable dt)
    {
        DataRow dr;
        dr = dt.NewRow();
        dr["lotNo"] = lotNo;
        dr["planNo"] = planNo;
        dr["SurveyName"] = SurveyName;
        dr["appNos"] = appNos;
        dr["totGrantAmt"] = totGrantAmt;
        dr["maxAppNoValuer"] = maxAppNoValuer;
        dr["maxAppNoFSV"] = maxAppNoFSV;
        dr["primaryHoldNIC"] = primaryHoldNIC;
        dr["NPLloanNos"] = NPLloanNos;
        dr["PLloanNos"] = PLloanNos;
        dr["planDate"] = planDate;
        dr["landExtend"] = landExtend;
        dr["landName"] = landName;
        dr["landAddress"] = landAddress;
        dr["TotalStatus"] = TotalStatus;
        dt.Rows.Add(dr);
        return dt;
    }

    private DataTable setTempDataTable(DataTable tempDataTable)
    {
        tempDataTable = new DataTable();

        DataColumn lotNo;
        lotNo = new DataColumn();
        lotNo.DataType = Type.GetType("System.String");
        lotNo.ColumnName = "lotNo";
        dt.Columns.Add(lotNo);

        DataColumn planNo;
        planNo = new DataColumn();
        planNo.DataType = Type.GetType("System.String");
        planNo.ColumnName = "planNo";
        dt.Columns.Add(planNo);

        DataColumn SurveyName;
        SurveyName = new DataColumn();
        SurveyName.DataType = Type.GetType("System.String");
        SurveyName.ColumnName = "SurveyName";
        dt.Columns.Add(SurveyName);

        DataColumn appNos;
        appNos = new DataColumn();
        appNos.DataType = Type.GetType("System.String");
        appNos.ColumnName = "appNos";
        dt.Columns.Add(appNos);
        
        DataColumn totGrantAmt;
        totGrantAmt = new DataColumn();
        totGrantAmt.DataType = Type.GetType("System.Decimal");
        totGrantAmt.ColumnName = "totGrantAmt";
        dt.Columns.Add(totGrantAmt);

        DataColumn maxAppNoValuer;
        maxAppNoValuer = new DataColumn();
        maxAppNoValuer.DataType = Type.GetType("System.Decimal");
        maxAppNoValuer.ColumnName = "maxAppNoValuer";
        dt.Columns.Add(maxAppNoValuer);

        DataColumn maxAppNoFSV;
        maxAppNoFSV = new DataColumn();
        maxAppNoFSV.DataType = Type.GetType("System.String");
        maxAppNoFSV.ColumnName = "maxAppNoFSV";
        dt.Columns.Add(maxAppNoFSV);

        DataColumn primaryHoldNIC;
        primaryHoldNIC = new DataColumn();
        primaryHoldNIC.DataType = Type.GetType("System.String");
        primaryHoldNIC.ColumnName = "primaryHoldNIC";
        dt.Columns.Add(primaryHoldNIC);

        DataColumn NPLloanNos;
        NPLloanNos = new DataColumn();
        NPLloanNos.DataType = Type.GetType("System.String");
        NPLloanNos.ColumnName = "NPLloanNos";
        dt.Columns.Add(NPLloanNos);

        DataColumn PLloanNos;
        PLloanNos = new DataColumn();
        PLloanNos.DataType = Type.GetType("System.String");
        PLloanNos.ColumnName = "PLloanNos";
        dt.Columns.Add(PLloanNos);

        DataColumn planDate;
        planDate = new DataColumn();
        planDate.DataType = Type.GetType("System.String");
        planDate.ColumnName = "planDate";
        dt.Columns.Add(planDate);

        DataColumn landExtend;
        landExtend = new DataColumn();
        landExtend.DataType = Type.GetType("System.String");
        landExtend.ColumnName = "landExtend";
        dt.Columns.Add(landExtend);

        DataColumn landName;
        landName = new DataColumn();
        landName.DataType = Type.GetType("System.String");
        landName.ColumnName = "landName";
        dt.Columns.Add(landName);

        DataColumn landAddress;
        landAddress = new DataColumn();
        landAddress.DataType = Type.GetType("System.String");
        landAddress.ColumnName = "landAddress";
        dt.Columns.Add(landAddress);

        DataColumn TotalStatus;
        TotalStatus = new DataColumn();
        TotalStatus.DataType = Type.GetType("System.String");
        TotalStatus.ColumnName = "TotalStatus";
        dt.Columns.Add(TotalStatus);

        return tempDataTable;
    }

    #endregion

    private bool ChechIsalreadysend(string operationdate)
    {
        dw = new DataWorksClass(reportconstring);
        dw.SetCommand(@"select count(*) from ReportUser.DailyHousProp where operationdate=@operationdate");
        dw.SetSqlCommandParameters("operationdate", operationdate);
        int a = int.Parse(dw.GetSingleData());

        if (a > 0)
            return true;
        else
            return false;
    }

    //2011-07-01
    private void DeleteDataInTable(string TableName, string date)
    {
        dw = new DataWorksClass(reportconstring);
        dw.SetCommand(@"delete from @TableName where date=@date");
        dw.SetSqlCommandParameters("TableName",TableName);
        dw.SetSqlCommandParameters("date", date);
        dw.Delete();
    }

    //private void UpdateReschedule(string branchcode, string startdateS, string enddateS)
    //{
    //    DataTable dt = new DataTable();
    //    dt = GetChangesfromHistry(enddateS);
    //    foreach (DataRow dr in dt.Rows)
    //    {
    //        double newintrate = double.Parse(dr["newintrate"].ToString());
    //        int newcrcat = int.Parse(dr["newcrcat"].ToString());
    //        double newinstalment = double.Parse(dr["newinstalment"].ToString());
    //        string cracno = dr["cracno"].ToString();
    //        UpdateChanges(
    //    }
    //}

    //private DataTable GetChangesfromHistry(string enddateS)
    //{
    //    dw = new DataWorksClass(constring);
    //    dw.SetDataAdapter(@"select cracno, newintrate, newcrcat, newinstalment from housprophistry where trdate = @trdate");
    //    dw.SetDataAdapterParameters("trdate", enddateS);
    //    return dw.GetDataTable();
    //}

    private void GetTrial(string startdateS, string enddateS)
    {
        //Get Trial

        InsertNotUpdatedAccounts(startdateS, enddateS);
        dt = new DataTable();

        //Get Updated Accounts
        dt = GetUpdatedAccounts(startdateS, enddateS);
        InsertUpdatedAccounts(startdateS, enddateS, dt);

        //InserUpdatedAccounts(startdateS, enddateS);

        //Get Disbursed accounts
        dt = new DataTable();
        dt = GetDisbAccounts(enddateS);
        InsertUpdatedAccounts(startdateS, enddateS, dt);

        //InsertChanges(enddateS);
    }

    private void InserUpdatedAccounts(string startdateS, string enddateS)
    {
        DataTable dt = new DataTable();
        dt = GetTransAccounts(enddateS);
        foreach (DataRow dr in dt.Rows)
        {
            string cracno = dr["cracno"].ToString();
            InsertHousprop(cracno, startdateS, enddateS);
        }
    }

    private void InsertHousprop(string cracno, string startdate, string enddate)
    {
        DataTable dt = new DataTable();
        dt = GetDHouspropData(cracno, startdate);
        if (dt.Rows.Count > 0)
        {
            //Inserthousprop(cracno, dt.Rows[0], enddate);
        }
        else
        {
            DataTable tempdata = new DataTable();
            tempdata = GetHouspropData(cracno);
            double actoutbal = 0;
            double intrate = double.Parse(tempdata.Rows[0]["intrate"].ToString());
            double instalment = double.Parse(tempdata.Rows[0]["instalment"].ToString());
            int graceperiod = int.Parse(tempdata.Rows[0]["graceperiod"].ToString());
            int crperiod = int.Parse(tempdata.Rows[0]["crperiod"].ToString());
            int crcat = int.Parse(tempdata.Rows[0]["crcat"].ToString());
            DateTime lastcompletedduedate = DateTime.Parse(tempdata.Rows[0]["lastcompletedduedate"].ToString());
            DateTime datedue = DateTime.Parse(tempdata.Rows[0]["datedue"].ToString());
            dt = new DataTable();
            dt = SetDataTable(dt);


            dt = InsertRow(cracno, actoutbal, intrate, instalment, graceperiod, crperiod, crcat, lastcompletedduedate, datedue, dt);
            Inserthousprop(cracno, dt.Rows[0], enddate);
        }
    }


    private DataTable InsertRow(string cracno, double actoutbal, double IntRate,
    double Instalment, int GracePeriod, int CrPeriod, int crcat, DateTime lastcompletedduedate, DateTime datedue, DataTable dt)
    {
        DataRow dr;
        dr = dt.NewRow();
        dr["actoutbal"] = actoutbal;
        dr["LoanStatusCode"] = 1;
        dr["IntRate"] = IntRate;
        dr["Instalment"] = Instalment;
        dr["GracePeriod"] = GracePeriod;
        dr["CrPeriod"] = CrPeriod;
        dr["crcat"] = crcat;
        dr["lastcompletedduedate"] = lastcompletedduedate;
        dr["datedue"] = datedue;
        dt.Rows.Add(dr);
        return dt;
    }

    private DataTable SetDataTable(DataTable dt)
    {
        dt = new DataTable();

        DataColumn actoutbal;
        actoutbal = new DataColumn();
        actoutbal.DataType = Type.GetType("System.Double");
        actoutbal.ColumnName = "actoutbal";
        dt.Columns.Add(actoutbal);


        DataColumn datedue;
        datedue = new DataColumn();
        datedue.DataType = Type.GetType("System.DateTime");
        datedue.ColumnName = "datedue";
        dt.Columns.Add(datedue);

        DataColumn lastcompletedduedate;
        lastcompletedduedate = new DataColumn();
        lastcompletedduedate.DataType = Type.GetType("System.DateTime");
        lastcompletedduedate.ColumnName = "lastcompletedduedate";
        dt.Columns.Add(lastcompletedduedate);

        DataColumn IntRate;
        IntRate = new DataColumn();
        IntRate.DataType = Type.GetType("System.Double");
        IntRate.ColumnName = "IntRate";
        dt.Columns.Add(IntRate);


        DataColumn Instalment;
        Instalment = new DataColumn();
        Instalment.DataType = Type.GetType("System.Double");
        Instalment.ColumnName = "Instalment";
        dt.Columns.Add(Instalment);


        DataColumn GracePeriod;
        GracePeriod = new DataColumn();
        GracePeriod.DataType = Type.GetType("System.Int32");
        GracePeriod.ColumnName = "GracePeriod";
        dt.Columns.Add(GracePeriod);

        DataColumn CrPeriod;
        CrPeriod = new DataColumn();
        CrPeriod.DataType = Type.GetType("System.Int32");
        CrPeriod.ColumnName = "CrPeriod";
        dt.Columns.Add(CrPeriod);

        DataColumn crcat;
        crcat = new DataColumn();
        crcat.DataType = Type.GetType("System.Int32");
        crcat.ColumnName = "crcat";
        dt.Columns.Add(crcat);

        DataColumn LoanStatusCode;
        LoanStatusCode = new DataColumn();
        LoanStatusCode.DataType = Type.GetType("System.Int32");
        LoanStatusCode.ColumnName = "LoanStatusCode";
        dt.Columns.Add(LoanStatusCode);

        return dt;
    }

    private int Inserthousprop(string cracno, DataRow dr, string enddate)
    {
        DateTime LastCompletedDueDate;
        DateTime predatedue = DateTime.Parse(dr["lastcompletedduedate"].ToString());
        DateTime datedue = DateTime.Parse(dr["datedue"].ToString());
        double preoutbal = double.Parse(dr["actoutbal"].ToString());
        int LoanStatusCode = int.Parse(dr["LoanStatusCode"].ToString());
        double IntRate = double.Parse(dr["IntRate"].ToString());
        double Instalment = double.Parse(dr["Instalment"].ToString());
        int GracePeriod = int.Parse(dr["GracePeriod"].ToString());
        int CrPeriod = int.Parse(dr["CrPeriod"].ToString());
        int CrCat = int.Parse(dr["CrCat"].ToString());
        double actoutbal = double.Parse(dr["actoutbal"].ToString());
        string refcode = CrCat.ToString("00") + "100001";
        double cramt = GetSumTrans(cracno, "CR", enddate);
        double dramt = GetSumTrans(cracno, "DR", enddate);

        int newcrcat = GetNewCrCat(cracno, enddate, CrCat);
        if (newcrcat != CrCat)
        {
        }


        bool IsTrans;

        if (cramt != 0 || dramt != 0)
        {
            IsTrans = true;
            DataTable dt1 = new DataTable();
            dt1 = GetPaymentHistoryData(cracno, enddate);
            if (dt1.Rows.Count != 0)
            {
                try
                {
                    LastCompletedDueDate = Convert.ToDateTime(dt1.Rows[0]["Datedue"].ToString());
                }
                catch
                {
                    LastCompletedDueDate = DateTime.Parse(dr["LastCompletedDueDate"].ToString());
                }
                string trstatus = dt1.Rows[0]["trstatus"].ToString();
                switch (trstatus)
                {
                    case "F":
                        LastCompletedDueDate = LastCompletedDueDate.AddMonths(1);
                        break;
                }
            }
            else
            {
                LastCompletedDueDate = GetDueDate(cracno, predatedue);
            }

            actoutbal = actoutbal - (cramt - dramt);
        }
        else
        {
            LastCompletedDueDate = DateTime.Parse(dr["LastCompletedDueDate"].ToString());
            IsTrans = false;
        }

        return InsertDailyHousprop(enddate, cracno, LastCompletedDueDate, LoanStatusCode, IntRate, Instalment, actoutbal, datedue,
           GracePeriod, CrPeriod, CrCat, IsTrans, preoutbal, predatedue);
    }


    private DataTable GetDHouspropData(string cracno, string operationdate)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select dh.cracno, dh.LastCompletedDueDate, 1 as LoanStatusCode, 
                            h.IntRate, h.Instalment, 1 as GracePeriod, h.datedue, dh.actoutbal, h.CrPeriod, h.CrCat  
                            from CreditReportsDb.ReportUser.DailyHousProp dh, tdb.creditadmin.housprop h
                            where h.cracno = dh.cracno 
                            and dh.cracno = @cracno 
                            and operationdate=@operationdate");
        dw.SetDataAdapterParameters("cracno", cracno);
        dw.SetDataAdapterParameters("operationdate", operationdate);
        return dw.GetDataTable();
    }


    private DataTable GetHouspropData(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from HousProp where cracno = @cracno");
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }


    private DataTable GetTransAccounts(string enddateS)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select distinct cracno from gltrans where trdate = @trdate and left(cracno,1) = '6' and cracno = '603086024069' ");
        dw.SetDataAdapterParameters("trdate", enddateS);
        return dw.GetDataTable();
    }

    private DataTable GetPreviousHouspropData(string OperationDate, DateTime GrantDate)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select LastCompletedDueDate,cracno, actoutbal,LoanStatusCode,IntRate,Instalment,
                            GracePeriod,CrPeriod,CrCat,datedue
                            from CreditReportsDb.ReportUser.DailyHousProp
                            where actOutBal != 0 and OperationDate=@OperationDate and cracno not in
                            (select cracno from disbbalsum where grantdate=@GrantDate) 
                            union
                            select d.grantdate as LastCompletedDueDate,d.cracno, d.transamt + isnull(h.actoutbal,0) as actoutbal,0 as LoanStatusCode,
                            c.IntRate,c.Instalment,
                            1 as GracePeriod,c.CrPeriod,c.CrCat,
                            dateadd(month,1,d.grantdate) as datedue
                            from disbbalsum d, CrMast c, CreditReportsDb.ReportUser.DailyHousProp h
                            where d.grantdate=@GrantDate
                            and d.cracno=c.cracno
                            and d.cracno*=h.cracno
                            and h.operationdate=@OperationDate order by cracno desc");
        dw.SetDataAdapterParameters("OperationDate", OperationDate);
        dw.SetDataAdapterParameters("GrantDate", GrantDate);
        return dw.GetDataTable();
    }

    private DataTable SetDataTableHP(DataTable dt)
    {
        dt = new DataTable();
        DataColumn OperationDate;
        OperationDate = new DataColumn();
        OperationDate.DataType = Type.GetType("System.String");
        OperationDate.ColumnName = "OperationDate";
        dt.Columns.Add(OperationDate);

        DataColumn cracno;
        cracno = new DataColumn();
        cracno.DataType = Type.GetType("System.String");
        cracno.ColumnName = "cracno";
        dt.Columns.Add(cracno);


        DataColumn LastCompletedDueDate;
        LastCompletedDueDate = new DataColumn();
        LastCompletedDueDate.DataType = Type.GetType("System.DateTime");
        LastCompletedDueDate.ColumnName = "LastCompletedDueDate";
        dt.Columns.Add(LastCompletedDueDate);


        DataColumn LoanStatusCode;
        LoanStatusCode = new DataColumn();
        LoanStatusCode.DataType = Type.GetType("System.String");
        LoanStatusCode.ColumnName = "LoanStatusCode";
        dt.Columns.Add(LoanStatusCode);


        DataColumn IntRate;
        IntRate = new DataColumn();
        IntRate.DataType = Type.GetType("System.String");
        IntRate.ColumnName = "IntRate";
        dt.Columns.Add(IntRate);

        DataColumn Instalment;
        Instalment = new DataColumn();
        Instalment.DataType = Type.GetType("System.String");
        Instalment.ColumnName = "Instalment";
        dt.Columns.Add(Instalment);


        DataColumn actoutbal;
        actoutbal = new DataColumn();
        actoutbal.DataType = Type.GetType("System.String");
        actoutbal.ColumnName = "actoutbal";
        dt.Columns.Add(actoutbal);
        DataColumn datedue;
        datedue = new DataColumn();
        datedue.DataType = Type.GetType("System.DateTime");
        datedue.ColumnName = "datedue";
        dt.Columns.Add(datedue);


        DataColumn GracePeriod;
        GracePeriod = new DataColumn();
        GracePeriod.DataType = Type.GetType("System.String");
        GracePeriod.ColumnName = "GracePeriod";
        dt.Columns.Add(GracePeriod);


        DataColumn CrPeriod;
        CrPeriod = new DataColumn();
        CrPeriod.DataType = Type.GetType("System.String");
        CrPeriod.ColumnName = "CrPeriod";
        dt.Columns.Add(CrPeriod);

        DataColumn CrCat;
        CrCat = new DataColumn();
        CrCat.DataType = Type.GetType("System.String");
        CrCat.ColumnName = "CrCat";
        dt.Columns.Add(CrCat);

        DataColumn IsTrans;
        IsTrans = new DataColumn();
        IsTrans.DataType = Type.GetType("System.String");
        IsTrans.ColumnName = "IsTrans";
        dt.Columns.Add(IsTrans);


        DataColumn preoutbal;
        preoutbal = new DataColumn();
        preoutbal.DataType = Type.GetType("System.String");
        preoutbal.ColumnName = "preoutbal";
        dt.Columns.Add(preoutbal);


        DataColumn predatedue;
        predatedue = new DataColumn();
        predatedue.DataType = Type.GetType("System.DateTime");
        predatedue.ColumnName = "predatedue";
        dt.Columns.Add(predatedue);

        return dt;


    }


    private DataTable GetHouspropData(DateTime GrantDate)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select LastCompletedDueDate,H.cracno, actoutbal,LoanStatusCode,H.IntRate,C.Instalment,
                            GracePeriod,C.CrPeriod,CrCat,datedue
                            from TDBOld.CreditAdmin.Housprop H, TDBOld.CreditAdmin.CrMast C
                            where h.cracno=c.cracno and actOutBal != 0 and C.cracno not in
                            (select cracno from disbbalsum where grantdate=@GrantDate) 
                            union
                            select d.grantdate as LastCompletedDueDate,d.cracno, d.transamt + isnull(h.actoutbal,0) as actoutbal,0 as LoanStatusCode,
                            c.IntRate,c.Instalment,
                            1 as GracePeriod,c.CrPeriod,c.CrCat,
                            dateadd(month,1,d.grantdate) as datedue
                            from disbbalsum d, CrMast c, CreditReportsDb.ReportUser.DailyHousProp h
                            where d.grantdate=@GrantDate
                            and d.cracno=c.cracno
                            and d.cracno*=h.cracno");
        dw.SetDataAdapterParameters("GrantDate", GrantDate);
        return dw.GetDataTable();
    }

    private DataTable GetPaymentHistoryData(string cracno, string trdate)
    {
        dw = new DataWorksClass(constring);
        dt = new DataTable();
        dw.SetDataAdapter(@"select max(datedue) as datedue, trstatus from transassign where cracno=@cracno 
                            and trstatus != 'C' and taskid='CAPD' and trtype = 'I' and trdate<=@trdate
                            group by trstatus order by datedue desc");
        dw.SetDataAdapterParameters("cracno", cracno);
        dw.SetDataAdapterParameters("trdate", trdate);
        return dw.GetDataTable();
    }

    private DataTable GetDates(string number)
    {
        dw = new DataWorksClass(reportconstring);
        dt = new DataTable();
        dw.SetDataAdapter(@"select * from calendar  where number=@number order by datekey");
        dw.SetDataAdapterParameters("number", number);
        return dw.GetDataTable();
    }



    private DateTime GetDueDate(string cracno, DateTime predatedue)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select LastCompletedDueDate from housprop where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        try
        {
            predatedue = DateTime.Parse(dw.GetSingleData());
        }
        catch
        {
            predatedue = predatedue;
        }
        return predatedue;
    }

    private DataTable InsertDailyHousProp(string OperationDate, string cracno, DateTime LastCompletedDueDate,
                        int LoanStatusCode, double IntRate, double Instalment, double actoutbal, int GracePeriod,
                        int CrPeriod, int CrCat, bool IsTrans, double preoutbal, DateTime predatedue, DateTime datedue, DataTable dt)
    {
        DataRow dr;
        dr = dt.NewRow();
        dr["OperationDate"] = OperationDate;
        dr["cracno"] = cracno;
        dr["LastCompletedDueDate"] = LastCompletedDueDate;
        dr["LoanStatusCode"] = LoanStatusCode;
        dr["IntRate"] = IntRate;
        dr["Instalment"] = Instalment;
        dr["actoutbal"] = actoutbal;
        dr["datedue"] = datedue;
        dr["GracePeriod"] = GracePeriod;
        dr["CrPeriod"] = CrPeriod;
        dr["CrCat"] = CrCat;
        dr["IsTrans"] = IsTrans;
        dr["preoutbal"] = preoutbal;
        dr["predatedue"] = predatedue;

        dt.Rows.Add(dr);
        return dt;
    }

    private int InsertDailyHousprop(string OperationDate, string CrAcNo, DateTime LastCompletedDueDate, int LoanStatusCode,
                           double IntRate, double Instalment, double actoutbal, DateTime DateDue, int GracePeriod,
                            int CrPeriod, int CrCat, bool IsTrans, double preoutbal, DateTime predatedue)
    {
        dw = new DataWorksClass(reportconstring);
        dw.SetCommand(@"INSERT INTO DailyHousProp
           (OperationDate,CrAcNo,LastCompletedDueDate,LoanStatusCode,IntRate,Instalment,
           actoutbal,DateDue,GracePeriod,CrPeriod,CrCat,IsTrans,preoutbal,predatedue)
                 VALUES
           (@OperationDate,@CrAcNo,@LastCompletedDueDate,@LoanStatusCode,@IntRate,@Instalment,
            @actoutbal,@DateDue,@GracePeriod,@CrPeriod,@CrCat,@IsTrans,@preoutbal,@predatedue)");
        dw.SetSqlCommandParameters("OperationDate", OperationDate);
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        dw.SetSqlCommandParameters("LastCompletedDueDate", LastCompletedDueDate);
        dw.SetSqlCommandParameters("LoanStatusCode", LoanStatusCode);
        dw.SetSqlCommandParameters("IntRate", IntRate);
        dw.SetSqlCommandParameters("Instalment", Instalment);
        dw.SetSqlCommandParameters("actoutbal", actoutbal);
        dw.SetSqlCommandParameters("DateDue", DateDue);
        dw.SetSqlCommandParameters("GracePeriod", GracePeriod);
        dw.SetSqlCommandParameters("CrPeriod", CrPeriod);
        dw.SetSqlCommandParameters("CrCat", CrCat);
        dw.SetSqlCommandParameters("IsTrans", IsTrans);
        dw.SetSqlCommandParameters("preoutbal", preoutbal);
        dw.SetSqlCommandParameters("predatedue", predatedue);
        return dw.Insert();

    }

    private int InsertDailyHousprop(string OperationDate, string CrAcNo, DateTime LastCompletedDueDate, int LoanStatusCode,
                           double IntRate, double Instalment, double actoutbal, DateTime DateDue, int GracePeriod,
                            int CrPeriod, int CrCat, bool IsTrans, double preoutbal, DateTime predatedue, int ArreasMonths, double ArreasAmount)
    {
        dw = new DataWorksClass(reportconstring);
        dw.SetCommand(@"INSERT INTO DailyHousProp
           (OperationDate,CrAcNo,LastCompletedDueDate,LoanStatusCode,IntRate,Instalment,
           actoutbal,DateDue,GracePeriod,CrPeriod,CrCat,IsTrans,preoutbal,predatedue,ArreasMonths,ArreasAmount)
                 VALUES
           (@OperationDate,@CrAcNo,@LastCompletedDueDate,@LoanStatusCode,@IntRate,@Instalment,
            @actoutbal,@DateDue,@GracePeriod,@CrPeriod,@CrCat,@IsTrans,@preoutbal,@predatedue,@ArreasMonths,@ArreasAmount)");
        dw.SetSqlCommandParameters("OperationDate", OperationDate);
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        dw.SetSqlCommandParameters("LastCompletedDueDate", LastCompletedDueDate);
        dw.SetSqlCommandParameters("LoanStatusCode", LoanStatusCode);
        dw.SetSqlCommandParameters("IntRate", IntRate);
        dw.SetSqlCommandParameters("Instalment", Instalment);
        dw.SetSqlCommandParameters("actoutbal", actoutbal);
        dw.SetSqlCommandParameters("DateDue", DateDue);
        dw.SetSqlCommandParameters("GracePeriod", GracePeriod);
        dw.SetSqlCommandParameters("CrPeriod", CrPeriod);
        dw.SetSqlCommandParameters("CrCat", CrCat);
        dw.SetSqlCommandParameters("IsTrans", IsTrans);
        dw.SetSqlCommandParameters("preoutbal", preoutbal);
        dw.SetSqlCommandParameters("predatedue", predatedue);
        dw.SetSqlCommandParameters("ArreasMonths", ArreasMonths);
        dw.SetSqlCommandParameters("ArreasAmount", ArreasAmount);
        return dw.Insert();
    }    

    public void GetGlAbstact(string startdate, string enddate)
    {
        string branchcode = "0308";
        double debitamt = 0, creditamt = 0, closingbal = 0;
        dt = new DataTable();
        dt = GetGLAbstractRecords1(startdate);
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            double openingbal = double.Parse(dt.Rows[i]["curbal"].ToString());
            string refglcode = dt.Rows[i]["refglcode"].ToString();
            string glcode = dt.Rows[i]["glcode"].ToString();
            string gldesc = dt.Rows[i]["gldesc"].ToString();
            if (refglcode == "903081000000994")
            { }
            creditamt = GetSumTransactions(refglcode, enddate, "CR");
            closingbal = openingbal + creditamt;
            debitamt = GetSumTransactions(refglcode, enddate, "DR");
            closingbal -= debitamt;
            //InsertGLAbstract(DateKey(enddate), refglcode, glcode, gldesc, openingbal);
            //InsertGLAbstract1(enddate, refglcode, glcode, gldesc, closingbal);
            //InsertDailyGLTransaction(enddate, branchcode, refglcode, gldesc, openingbal, debitamt, creditamt, closingbal);

            //InsertGLAbstractT(DateKey(enddate), refglcode, glcode, gldesc, openingbal);
        }
    }

    public void GetGlAbstact(string startdate, string enddate, int procno)
    {
        double tramt;
        dt = new DataTable();
        dt = GetGLAbstractRecords1(startdate);
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            double openingbal = double.Parse(dt.Rows[i]["curbal"].ToString());
            string refglcode = dt.Rows[i]["refglcode"].ToString();
            string glcode = dt.Rows[i]["glcode"].ToString();
            string gldesc = dt.Rows[i]["gldesc"].ToString();
            if (refglcode == "903081000000925")
            { 
            
            }
            tramt = GetSumTransactions(refglcode, enddate, "CR");
            openingbal += tramt;
            tramt = GetSumTransactions(refglcode, enddate, "DR");
            openingbal -= tramt;
            //InsertGLAbstract(DateKey(enddate), refglcode, glcode, gldesc, openingbal);
            InsertGLAbstract1(enddate + procno, refglcode, glcode, gldesc, openingbal);
            //InsertGLAbstractT(DateKey(enddate), refglcode, glcode, gldesc, openingbal);
        }
    }

    private double GetSumTransactions(string refglcode, string enddate, string acsign)
    {
        fc = new FunctionClass();
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select isnull(sum(tramt),0) as tramt from gltrans where trdate = @trdate and 
                        refglcode = @refglcode and acsign = @acsign and trstatus !='C'");
        dw.SetSqlCommandParameters("trdate", enddate);
        dw.SetSqlCommandParameters("refglcode", refglcode);
        dw.SetSqlCommandParameters("acsign", acsign);
        return double.Parse(dw.GetSingleData());
    }

    private double GetSumCashTransactions(string refglcode, string enddate, string acsign)
    {
        fc = new FunctionClass();
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select (
                        select isnull(sum(-tramt),0) as tramt from gltrans 
                        where trdate = @trdate and 
                        refglcode = @refglcode
                        and left(batchno,1) = '9'
                        and acsign = 'CR' and trstatus !='C')
                        +
                        (select isnull(sum(tramt),0) as tramt from gltrans 
                        where trdate = @trdate and 
                        refglcode = @refglcode
                        and acsign = @acsign and trstatus !='C')");
        dw.SetSqlCommandParameters("trdate", enddate);
        dw.SetSqlCommandParameters("refglcode", refglcode);
        dw.SetSqlCommandParameters("acsign", acsign);
        return double.Parse(dw.GetSingleData());
    }

    private void InsertGLAbstract1(string OperationDate, string RefGlCode, string GlCode, string GlDesc, double CurBal)
    {
        dw = new DataWorksClass(reportconstring);
        dw.SetCommand(@"INSERT INTO GLAbstract (OperationDate,RefGlCode,GlCode,GlDesc,CurBal)
                        VALUES (@OperationDate,@RefGlCode,@GlCode, @GlDesc,@CurBal)");
        dw.SetSqlCommandParameters("OperationDate", OperationDate);
        dw.SetSqlCommandParameters("RefGlCode", RefGlCode);
        dw.SetSqlCommandParameters("GlCode", GlCode);
        dw.SetSqlCommandParameters("GlDesc", GlDesc);
        dw.SetSqlCommandParameters("CurBal", CurBal);
        dw.Insert();
    }

    private DataTable GetGLAbstractRecords1(string OperationDate)
    {
        dw = new DataWorksClass(reportconstring);
        dw.SetDataAdapter(@"select RefGlCode, curbal, glcode, gldesc  from 
                            GLAbstract where OperationDate=@OperationDate");
        dw.SetDataAdapterParameters("OperationDate", OperationDate);
        return dw.GetDataTable();
    }

    private DataTable AddColumsToDailyProofSheet(DataTable dt)
    {
        // Create Description
        DataColumn CurrentDate = new DataColumn();
        CurrentDate.DataType = System.Type.GetType("System.String");
        CurrentDate.ColumnName = "CurrentDate";
        CurrentDate.DefaultValue = "CurrentDate";
        dt.Columns.Add(CurrentDate);

        // Create Description
        DataColumn ReportID = new DataColumn();
        ReportID.DataType = System.Type.GetType("System.String");
        ReportID.ColumnName = "ReportID";
        ReportID.DefaultValue = "ReportID";
        dt.Columns.Add(ReportID);

        // Create Description
        DataColumn BranchCode = new DataColumn();
        BranchCode.DataType = System.Type.GetType("System.String");
        BranchCode.ColumnName = "BranchCode";
        BranchCode.DefaultValue = "BranchCode";
        dt.Columns.Add(BranchCode);

        // Create Description
        DataColumn TransNo = new DataColumn();
        TransNo.DataType = System.Type.GetType("System.String");
        TransNo.ColumnName = "TransNo";
        TransNo.DefaultValue = "TransNo";
        dt.Columns.Add(TransNo);

        // Create Description
        DataColumn CrAcNo = new DataColumn();
        CrAcNo.DataType = System.Type.GetType("System.String");
        CrAcNo.ColumnName = "CrAcNo";
        CrAcNo.DefaultValue = "CrAcNo";
        dt.Columns.Add(CrAcNo);

        // Create Description
        DataColumn Instalment = new DataColumn();
        Instalment.DataType = System.Type.GetType("System.String");
        Instalment.ColumnName = "Instalment";
        Instalment.DefaultValue = "Instalment";
        dt.Columns.Add(Instalment);

        // Create Description
        DataColumn IntRate = new DataColumn();
        IntRate.DataType = System.Type.GetType("System.String");
        IntRate.ColumnName = "IntRate";
        IntRate.DefaultValue = "IntRate";
        dt.Columns.Add(IntRate);

        // Create Description
        DataColumn DateDue = new DataColumn();
        DateDue.DataType = System.Type.GetType("System.String");
        DateDue.ColumnName = "DateDue";
        DateDue.DefaultValue = "DateDue";
        dt.Columns.Add(DateDue);

        // Create Description
        DataColumn OutBal = new DataColumn();
        OutBal.DataType = System.Type.GetType("System.String");
        OutBal.ColumnName = "OutBal";
        OutBal.DefaultValue = "OutBal";
        dt.Columns.Add(OutBal);

        // Create Description
        DataColumn TrAmt = new DataColumn();
        TrAmt.DataType = System.Type.GetType("System.String");
        TrAmt.ColumnName = "TrAmt";
        TrAmt.DefaultValue = "TrAmt";
        dt.Columns.Add(TrAmt);


        // Create Description
        DataColumn Penal = new DataColumn();
        Penal.DataType = System.Type.GetType("System.String");
        Penal.ColumnName = "Penal";
        Penal.DefaultValue = "Penal";
        dt.Columns.Add(Penal);

        // Create Description
        DataColumn Interest = new DataColumn();
        Interest.DataType = System.Type.GetType("System.String");
        Interest.ColumnName = "Interest";
        Interest.DefaultValue = "Interest";
        dt.Columns.Add(Interest);

        // Create Description
        DataColumn Capital = new DataColumn();
        Capital.DataType = System.Type.GetType("System.String");
        Capital.ColumnName = "Capital";
        Capital.DefaultValue = "Capital";
        dt.Columns.Add(Capital);


        // Create Description
        DataColumn OtherCut = new DataColumn();
        OtherCut.DataType = System.Type.GetType("System.String");
        OtherCut.ColumnName = "OtherCut";
        OtherCut.DefaultValue = "OtherCut";
        dt.Columns.Add(OtherCut);

        // Create Description
        DataColumn NextDue = new DataColumn();
        NextDue.DataType = System.Type.GetType("System.String");
        NextDue.ColumnName = "Nextdatedue";
        NextDue.DefaultValue = "Nextdatedue";
        dt.Columns.Add(NextDue);

        // Create Description
        DataColumn CurBal = new DataColumn();
        CurBal.DataType = System.Type.GetType("System.String");
        CurBal.ColumnName = "CurBal";
        CurBal.DefaultValue = "CurBal";
        dt.Columns.Add(CurBal);


        DataColumn CrCat = new DataColumn();
        CrCat.DataType = System.Type.GetType("System.String");
        CrCat.ColumnName = "CrCat";
        CurBal.DefaultValue = "CrCat";
        dt.Columns.Add(CrCat);


        DataColumn CrDes = new DataColumn();
        CrDes.DataType = System.Type.GetType("System.String");
        CrDes.ColumnName = "CrDes";
        CrDes.DefaultValue = "CrDes";
        dt.Columns.Add(CrDes);


        // Create an array for DataColumn objects.
        DataColumn[] keys = new DataColumn[1];
        keys[0] = TransNo;
        //analysis.PrimaryKey = keys;
        // Return the new DataTable.
        return dt;
    }

    private DataTable AddColumsToDailyDisbSummery(DataTable dt)
    {
        // Create Description
        DataColumn Date = new DataColumn();
        Date.DataType = System.Type.GetType("System.String");
        Date.ColumnName = "Date";
        Date.DefaultValue = "Date";
        dt.Columns.Add(Date);

        // Create Description
        DataColumn ReportID = new DataColumn();
        ReportID.DataType = System.Type.GetType("System.String");
        ReportID.ColumnName = "ReportID";
        ReportID.DefaultValue = "ReportID";
        dt.Columns.Add(ReportID);

        // Create Description
        DataColumn BranchCode = new DataColumn();
        BranchCode.DataType = System.Type.GetType("System.String");
        BranchCode.ColumnName = "BranchCode";
        BranchCode.DefaultValue = "BranchCode";
        dt.Columns.Add(BranchCode);

        // Create Description
        DataColumn NoofACs = new DataColumn();
        NoofACs.DataType = System.Type.GetType("System.String");
        NoofACs.ColumnName = "NoofACs";
        NoofACs.DefaultValue = "NoofACs";
        dt.Columns.Add(NoofACs);

        // Create Description
        DataColumn Appno = new DataColumn();
        Appno.DataType = System.Type.GetType("System.String");
        Appno.ColumnName = "Appno";
        Appno.DefaultValue = "Appno";
        dt.Columns.Add(Appno);

        // Create Description
        DataColumn BOC = new DataColumn();
        BOC.DataType = System.Type.GetType("System.String");
        BOC.ColumnName = "BOC";
        BOC.DefaultValue = "BOC";
        dt.Columns.Add(BOC);

        // Create Description
        DataColumn Interest = new DataColumn();
        Interest.DataType = System.Type.GetType("System.String");
        Interest.ColumnName = "Interest";
        Interest.DefaultValue = "Interest";
        dt.Columns.Add(Interest);

        // Create Description
        DataColumn Inspection = new DataColumn();
        Inspection.DataType = System.Type.GetType("System.String");
        Inspection.ColumnName = "Inspection";
        Inspection.DefaultValue = "Inspection";
        dt.Columns.Add(Inspection);

        // Create Description
        DataColumn Legal = new DataColumn();
        Legal.DataType = System.Type.GetType("System.String");
        Legal.ColumnName = "Legal";
        Legal.DefaultValue = "Legal";
        dt.Columns.Add(Legal);

        // Create Description
        DataColumn FireInsu = new DataColumn();
        FireInsu.DataType = System.Type.GetType("System.String");
        FireInsu.ColumnName = "FireInsu";
        FireInsu.DefaultValue = "FireInsu";
        dt.Columns.Add(FireInsu);


        // Create Description
        DataColumn Retain = new DataColumn();
        Retain.DataType = System.Type.GetType("System.String");
        Retain.ColumnName = "Retain";
        Retain.DefaultValue = "Retain";
        dt.Columns.Add(Retain);

        // Create Description
        DataColumn Penal = new DataColumn();
        Penal.DataType = System.Type.GetType("System.String");
        Penal.ColumnName = "Penal";
        Penal.DefaultValue = "Penal";
        dt.Columns.Add(Penal);

        // Create Description
        DataColumn Others = new DataColumn();
        Others.DataType = System.Type.GetType("System.String");
        Others.ColumnName = "Others";
        Others.DefaultValue = "Others";
        dt.Columns.Add(Others);


        // Create Description
        DataColumn Title = new DataColumn();
        Title.DataType = System.Type.GetType("System.String");
        Title.ColumnName = "Title";
        Title.DefaultValue = "Title";
        dt.Columns.Add(Title);


        // Create Description
        DataColumn Total = new DataColumn();
        Total.DataType = System.Type.GetType("System.String");
        Total.ColumnName = "Total";
        Total.DefaultValue = "Total";
        dt.Columns.Add(Total);



        // Create an array for DataColumn objects.
        //DataColumn[] keys = new DataColumn[1];
        // keys[0] = Appno;
        //analysis.PrimaryKey = keys;
        // Return the new DataTable.
        return dt;
    }

    internal void get31stTrial()
    {
        DataTable hpcracno = new DataTable();
        hpcracno = GetHPCracno();

        foreach (DataRow dr in hpcracno.Rows)
        {
            string cracno = dr["cracno"].ToString();

            dt = new DataTable();
            dt = Get31Transasctions(cracno);
            if (dt.Rows.Count == 0)
            {
                dt = SetDatatableHPData(cracno);
            }
            InsertDailyHousPropBulk(dt);
        }
    }

    private DataTable SetDatatableHPData(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select '20090731' as OperationDate 
                                      ,@cracno as CrAcNo
                                      ,'19000101' as datedue
                                      ,'1' as LoanStatusCode
                                      ,0 as IntRate
                                      ,0 as Instalment
                                      ,0 as outbal
                                      ,'19000101' as DateDue
                                      ,1 as GracePeriod
                                      ,0 as CrPeriod
                                      ,0 as CrCat
                                      ,0 as IsTrans
                                      ,0 as preoutbal
                                      ,'19000101' as predatedue
	                                  ,0 as arreasmonths
	                                  ,0 as ArreasAmount");
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }

    private void InsertDailyHousPropBulk(DataTable dt)
    {
        dw = new DataWorksClass(reportconstring);
        dw.SetCommand();
        dw.InsertBulk(dt, "DailyHousProp");
    }

    private DataTable GetHPCracno()
    {

        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select distinct cracno from housprop");
        return dw.GetDataTable();
    }

    private DataTable Get31Transasctions(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select '20090731' as OperationDate 
                                      ,h.CrAcNo
                                      ,h.datedue
                                      ,'1' as LoanStatusCode
                                      ,cm.IntRate
                                      ,h.Instalment
                                      ,h.outbal
                                      ,h.DateDue
                                      ,1 as GracePeriod
                                      ,cm.CrPeriod
                                      ,cm.CrCat
                                      ,0 as IsTrans
                                      ,outbal as preoutbal
                                      ,datedue as predatedue
	                                  ,datediff(month, datedue, '20090731') as arreasmonths
	                                  ,(datediff(month, datedue, '20090731') * h.instalment-(select isnull(sum(shortamt),0)  
                                from ShortFall where 
                                trstatus != 'PP' and paiddate='19000101'
                                and status='A' and cracno = @cracno))as ArreasAmount
                                from housprop h, crmast cm
                                 where  h.cracno = @cracno
                                and h.cracno = cm.cracno");
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }

    internal void UpdateTrialArreas(string number)
    {
        fc = new FunctionClass();
        DataTable hpcracno = new DataTable();
        hpcracno = GetHPCracno();

        DataTable arreas = new DataTable();

        foreach (DataRow dr in hpcracno.Rows)
        {
            string cracno = dr["cracno"].ToString();

            DataTable dates = new DataTable();
            dates = GetDates(number);
            for (int i = 0; dates.Rows.Count > i; i++)
            {
                string startdateS, enddateS;
                if (i == 0)
                {
                    startdateS = "20090731";
                    enddateS = dates.Rows[i]["datekey"].ToString().Trim();
                }
                else
                {
                    startdateS = dates.Rows[i - 1]["datekey"].ToString().Trim();
                    enddateS = dates.Rows[i]["datekey"].ToString().Trim();
                }
                // Get arreas to be updated
                //GetArreas(cracno,,);
                UpdateArreas(arreasmonths, arreasamount, cracno, enddateS);
            }
        }
    }

    private void UpdateArreas(int arreasmonths, double arreasamount, string operationdate, string cracno)
    {
        dw = new DataWorksClass(reportconstring);
        dw.SetCommand(@"update dailyhousprop set  ArreasMonths=@ArreasMonths, ArreasAmount=@ArreasAmount 
                        where operationdate=@operationdate and cracno = @cracno ");
        dw.SetSqlCommandParameters("operationdate", operationdate);
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("ArreasMonths", arreasmonths);
        dw.SetSqlCommandParameters("ArreasAmount", arreasamount);
        dw.Update();
    }

    private void GetArreas(string cracno, DateTime operationdate, DateTime trdate, double instalment, double shartfall, DateTime datedue)
    {
        arreasmonths = GetArreasInstalments(operationdate, trdate);
        string penalrate = GetPenalInt("PEN", datedue);
        arreasamount = (arreasmonths * instalment) + GetPenal(arreasmonths, penalrate, instalment) - shartfall;
    }

    private string GetPenalInt(string ratetype, DateTime datedue)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select rateamt from ratecode where ratetype='PEN' 
                        and (DateFrom<=@datedue and DateTo>=@datedue)");
        dw.SetSqlCommandParameters("ratetype", ratetype);
        dw.SetSqlCommandParameters("datedue", datedue);
        return dw.GetSingleData();
    }


    private double GetPenal(int arreasmonths, string penalrate, double instalment)
    {
        double penal;
        penal = (((arreasmonths) / 2) * arreasmonths) * instalment;
        return penal;
    }
    public int GetArreasInstalments(DateTime grantDate, DateTime DateDue)
    {
        int noofyears = 0;
        int noOfmonth = 0;
        int noOfDate = 0;

        int preyear = grantDate.Year;
        int curyear = DateDue.Year;
        int premonth = grantDate.Month;
        int curmonth = DateDue.Month;
        int preDate = grantDate.Day;
        int curDate = DateDue.Day;

        noofyears = curyear - preyear;
        noOfDate = curDate - preDate;


        if (premonth == curmonth)
        {
            noOfmonth = noofyears * 12;
        }
        else
        {
            noOfmonth = curmonth - premonth;
            noOfmonth = noOfmonth + (noofyears * 12);
        }

        if (noOfDate < 0)
        {
            noOfmonth = noOfmonth - 1;
        }
        return noOfmonth;
    }


    internal void UpdateChanges()
    {
        DataTable dt = new DataTable();
        dt = GetDates("0");
        foreach (DataRow dr in dt.Rows)
        {
            string enddateS = dr["datekey"].ToString();
            InsertChanges(enddateS);
        }
    }

    internal string DeleteReportProcess(string dateKey)
    {
        dw = new DataWorksClass(reportconstring);
        dw.SetCommand(@"delete from ReportUser.DailyHousProp where operationdate=@datekey");
        dw.SetSqlCommandParameters("datekey", dateKey);
        dw.Delete();

        dw = new DataWorksClass(reportconstring);
        dw.SetCommand(@"delete from ReportUser.DailyGLTransaction where date=@datekey");
        dw.SetSqlCommandParameters("datekey", dateKey);
        dw.Delete();

        dw = new DataWorksClass(reportconstring);
        dw.SetCommand(@"delete from ReportUser.DailyProofSheetReportRecovery where currentdate=@datekey");
        dw.SetSqlCommandParameters("datekey", dateKey);
        dw.Delete();

        dw = new DataWorksClass(reportconstring);
        dw.SetCommand(@"delete from ReportUser.DisbursementSummery where date=@datekey");
        dw.SetSqlCommandParameters("datekey", dateKey);
        dw.Delete();

        dw = new DataWorksClass(reportconstring);
        dw.SetCommand(@"delete from ReportUser.GLAbstract where operationdate=@datekey");
        dw.SetSqlCommandParameters("datekey", dateKey);
        dw.Delete();

        return "Successfully Delete " + dateKey.ToString();
    }

    internal string GetDateDeleteReportProcess()
    {
        dw = new DataWorksClass(reportconstring);
        dw.SetCommand(@"select max(operationdate) from ReportUser.DailyHousProp");
        string datekey = dw.GetSingleData();
        return datekey;
    }
}
