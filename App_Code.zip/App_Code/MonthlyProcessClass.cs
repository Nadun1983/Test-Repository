﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

/// <summary>
/// Summary description for MonthlyProcessClass
/// </summary>
public class MonthlyProcessClass
{

    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();
    string reportconstring = ConfigurationManager.ConnectionStrings["reporTString"].ConnectionString.ToString();
    DataWorksClass dw;
    DataTable InsuranceDt;
	public MonthlyProcessClass()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public DataTable getSalaryBatchData()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"exec getSalaryBatchData");
        return dw.GetDataTable();
    }

    public DataTable getCentralLiabilityData()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"exec spCentralSystem");
        return dw.GetDataTable();
    }

    public DataTable getDailyGLData(string datekey, string indate, string ismonthend)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"exec spCreditDayEndGL @datekey, @indate, @ismonthend");
        dw.SetDataAdapterParameters("datekey", datekey);
        dw.SetDataAdapterParameters("indate", indate);
        dw.SetDataAdapterParameters("ismonthend", ismonthend);
        return dw.GetDataTable();
    }

    public DataTable getArreasData(string datekey, DateTime indate)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"exec spArreasData @datekey, @indate");
        dw.SetDataAdapterParameters("datekey", datekey);
        dw.SetDataAdapterParameters("indate", indate);
        return dw.GetDataTable();
    }

    private DataTable GetTransactionsForInsurance(DateTime date, string transref1, string transref2, string transref3)
    {
        dw = new DataWorksClass(constring);

        dw.SetDataAdapter(@" select distinct t.transno from transassign t where 
			                 t.transno in (select distinct transno from gltrans where trdate=@trdate and TrStatus<>'C') and
			                 t.transref in (@transref1, @transref2, @transref3) 
                             and transno is not NULL and LEFT(cracno,1) != '6' and LEFT(t.taskid,1) in ('T','F')");

        dw.SetDataAdapterParameters("trdate", date);
        dw.SetDataAdapterParameters("transref1", transref1);
        dw.SetDataAdapterParameters("transref2", transref2);
        dw.SetDataAdapterParameters("transref3", transref3);
        return dw.GetDataTable();
    }

    public void GetDailyInsuranceSummary(DateTime date)
    {
        DataTable dt = new DataTable();
        FunctionClass fc = new FunctionClass();
        string transno;

        //vihanga 2009-07-27
        dt = GetTransactionsForInsurance(date, "DISB", "APPN", "APPE");
        InsuranceDt = new DataTable();
        InsuranceDt = AddColumsToDailyDisbSummery(InsuranceDt);
        if (dt.Rows.Count > 0)
        {
            foreach (DataRow dr in dt.Rows)
            {
                string indate = fc.GetDateKeyinDate(date).ToString();
                transno = dr["transno"].ToString();
                GetInsuranceSummeryDetails(transno, date, indate);
            }

            dw = new DataWorksClass(reportconstring);
            dw.SetCommand();
            dw.InsertBulk(InsuranceDt, "InsuranceSummery");
        }

    }

    private void GetInsuranceSummeryDetails(string transno, DateTime date, string indate)
    {
        FunctionClass fc = new FunctionClass();

        string appno = "0";
        decimal TitleSLIC = 0, TitleAllianz = 0, TitleAIA = 0, TitleCeylinco = 0, TitleJanashakthi = 0, TitleUnion = 0, FireSLIC = 0,
                FireAllianz = 0, FireAIA = 0, FireCeylinco = 0, FireJanashakthi = 0, FireUnion = 0, TitleSLIC_Comm = 0, TitleAllianzComm = 0,
                TitleAIAComm = 0, TitleCeylincoComm = 0, TitleJanashakthiComm = 0, TitleUnionComm = 0, FireSLIC_Comm = 0, FireAllianzComm = 0,
                FireAIAComm = 0, FireCeylincoComm = 0, FireJanashakthiComm = 0, FireUnionComm = 0, TotalTitle = 0, TotalFire = 0,
                TotalCommision = 0, tramt = 0, tramtComm = 0, DTASoftLogic = 0, DTASoftLogicComm = 0, TotalDTA = 0;
        DataTable dt = GetTrAmt(transno);
        if (dt.Rows.Count > 0)
        {
            decimal totAmt = 0;
            foreach (DataRow dr in dt.Rows)
            {
                string taskid = dr["taskid"].ToString();
                tramt = decimal.Parse(dr["tramt"].ToString());
                tramtComm = decimal.Parse(dr["tramt"].ToString());
                switch (taskid)
                {
                    case "TALD900000":
                        TitleAllianzComm += (tramtComm * getCommissionAmt("TAL")) / 100;
                        TitleAllianz += tramt;
                        break;

                    case "TCED900000":
                        TitleCeylincoComm += (tramtComm * getCommissionAmt("TCE")) / 100;
                        TitleCeylinco += tramt;
                        break;

                    case "TCEE900000":
                        TitleCeylincoComm += (tramtComm * getCommissionAmt("TCE")) / 100;
                        TitleCeylinco += tramt;
                        break;


                    case "TCEN900000":
                        TitleCeylincoComm += (tramtComm * getCommissionAmt("TCE")) / 100;
                        TitleCeylinco += tramt;
                        break;

                    case "TEID900000":
                        TitleAIAComm += (tramtComm * getCommissionAmt("TEI")) / 100;
                        TitleAIA += tramt;
                        break;

                    case "TEIE900000":
                        TitleAIAComm += (tramtComm * getCommissionAmt("TEI")) / 100;
                        TitleAIA += tramt;
                        break;

                    case "TEIN900000":
                        TitleAIAComm += (tramtComm * getCommissionAmt("TEI")) / 100;
                        TitleAIA += tramt;
                        break;

                    case "TJSD900000":
                        TitleJanashakthiComm += (tramtComm * getCommissionAmt("TJS")) / 100;
                        TitleJanashakthi += tramt;
                        break;

                    case "TJSN900000":
                        TitleJanashakthiComm += (tramtComm * getCommissionAmt("TJS")) / 100;
                        TitleJanashakthi += tramt;
                        break;

                    case "TJSE900000":
                        TitleJanashakthiComm += (tramtComm * getCommissionAmt("TJS")) / 100;
                        TitleJanashakthi += tramt;
                        break;

                    case "TSLD900000":
                        TitleSLIC_Comm += (tramtComm * getCommissionAmt("TSL")) / 100;
                        TitleSLIC += tramt;
                        break;

                    case "TSLN900000":
                        TitleSLIC_Comm += (tramtComm * getCommissionAmt("TSL")) / 100;
                        TitleSLIC += tramt;
                        break;

                    case "TSLE900000":
                        TitleSLIC_Comm += (tramtComm * getCommissionAmt("TSL")) / 100;
                        TitleSLIC += tramt;
                        break;

                    case "TUAD900000":
                        TitleUnionComm += (tramtComm * getCommissionAmt("TUA")) / 100;
                        TitleUnion += tramt;
                        break;

                    case "TUAE900000":
                        TitleUnionComm += (tramtComm * getCommissionAmt("TUA")) / 100;
                        TitleUnion += tramt;
                        break;

                    case "TUAN900000":
                        TitleUnionComm += (tramtComm * getCommissionAmt("TUA")) / 100;
                        TitleUnion += tramt;
                        break;

                    case "FSLD900000":
                        FireSLIC_Comm += (tramtComm * getCommissionAmt("FSL")) / 100;
                        FireSLIC += tramt;
                        break;

                    case "FJSD900000":
                        FireJanashakthiComm += (tramtComm * getCommissionAmt("FJS")) / 100;
                        FireJanashakthi += tramt;
                        break;

                    case "FUAD900000":
                        FireUnionComm += (tramtComm * getCommissionAmt("FUA")) / 100;
                        FireUnion += tramt;
                        break;

                    case "FCED900000":
                        FireCeylincoComm += (tramtComm * getCommissionAmt("FCE")) / 100;
                        FireCeylinco += tramt;
                        break;

                    case "FEID900000":
                        FireAIAComm += (tramtComm * getCommissionAmt("FEI")) / 100;
                        FireAIA += tramt;
                        break;

                    case "FALD900000":
                        FireAllianzComm += (tramtComm * getCommissionAmt("FAL")) / 100;
                        FireAllianz += tramt;
                        break;

                    case "TSID900000":
                        DTASoftLogicComm += (tramtComm * getCommissionAmt("TSI")) / 100;
                        DTASoftLogic += tramt;
                        break;

                    case "TSIN900000":
                        DTASoftLogicComm += (tramtComm * getCommissionAmt("TSI")) / 100;
                        DTASoftLogic += tramt;
                        break;

                    case "TSIE900000":
                        DTASoftLogicComm += (tramtComm * getCommissionAmt("TSI")) / 100;
                        DTASoftLogic += tramt;
                        break;

                }
                //TotalTitle = TitleAllianz + TitleCeylinco + TitleAIA + TitleJanashakthi + TitleSLIC + TitleUnion;
                //TotalFire = 

            }

            DataRow rowDescription;
            rowDescription = InsuranceDt.NewRow();
            rowDescription["Date"] = indate;
            rowDescription["BranchCode"] = "0308";
            appno = dt.Rows[0]["cracno"].ToString();
            rowDescription["AppNo"] = appno;
            rowDescription["TitleSLIC"] = Math.Round(TitleSLIC, 2);
            rowDescription["TitleAllianz"] = Math.Round(TitleAllianz, 2);
            rowDescription["TitleAIA"] = Math.Round(TitleAIA, 2);
            rowDescription["TitleCeylinco"] = Math.Round(TitleCeylinco, 2);
            rowDescription["TitleJanashakthi"] = Math.Round(TitleJanashakthi, 2);
            rowDescription["TitleUnion"] = Math.Round(TitleUnion, 2);
            rowDescription["FireSLIC"] = Math.Round(FireSLIC, 2);
            rowDescription["FireAllianz"] = Math.Round(FireAllianz, 2);
            rowDescription["FireAIA"] = Math.Round(FireAIA, 2);
            rowDescription["FireCeylinco"] = Math.Round(FireCeylinco, 2);
            rowDescription["FireJanashakthi"] = Math.Round(FireJanashakthi, 2);
            rowDescription["FireUnion"] = Math.Round(FireUnion, 2);
            rowDescription["DTASoftLogic"] = Math.Round(DTASoftLogic, 2);

            rowDescription["TitleSLIC_Comm"] = Math.Round(TitleSLIC_Comm, 2);
            rowDescription["TitleAllianzComm"] = Math.Round(TitleAllianzComm, 2);
            rowDescription["TitleAIAComm"] = Math.Round(TitleAIAComm, 2);
            rowDescription["TitleCeylincoComm"] = Math.Round(TitleCeylincoComm, 2);
            rowDescription["TitleJanashakthiComm"] = Math.Round(TitleJanashakthiComm, 2);
            rowDescription["TitleUnionComm"] = Math.Round(TitleUnionComm, 2);
            rowDescription["FireSLIC_Comm"] = Math.Round(FireSLIC_Comm, 2);
            rowDescription["FireAllianzComm"] = Math.Round(FireAllianzComm, 2);
            rowDescription["FireAIAComm"] = Math.Round(FireAIAComm, 2);
            rowDescription["FireCeylincoComm"] = Math.Round(FireCeylincoComm, 2);
            rowDescription["FireJanashakthiComm"] = Math.Round(FireJanashakthiComm, 2);
            rowDescription["FireUnionComm"] = Math.Round(FireUnionComm, 2);
            rowDescription["DTASoftLogicComm"] = Math.Round(DTASoftLogicComm, 2);

            rowDescription["TotalTitle"] = Math.Round(TotalTitle, 2);
            rowDescription["TotalFire"] = Math.Round(TotalFire, 2);
            rowDescription["TotalCommision"] = Math.Round(TotalCommision, 2);


            InsuranceDt.Rows.Add(rowDescription);
        }
        else
        { }


    }

    private decimal getCommissionAmt(string TaskId)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select CommisionPercentage from CommisionDetails where TaskId=@TaskId");
        dw.SetSqlCommandParameters("TaskId", TaskId);
        return decimal.Parse(dw.GetSingleData());
    }

    private DataTable GetTrAmt(string transno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select taskid, transno, tramt, cracno from TransAssign 
                            where transno=@transno and (trstatus='F' or trstatus='P') 
                            and LEFT(cracno,1) != '6'");
        dw.SetDataAdapterParameters("transno", transno);
        //dw.SetDataAdapterParameters("date", date);
        return dw.GetDataTable();

    }

    private DataTable AddColumsToDailyDisbSummery(DataTable dt)
    {
        // Create Description
        DataColumn Date = new DataColumn();
        Date.DataType = System.Type.GetType("System.String");
        Date.ColumnName = "Date";
        Date.DefaultValue = "Date";
        dt.Columns.Add(Date);

        // Create Description
        DataColumn BranchCode = new DataColumn();
        BranchCode.DataType = System.Type.GetType("System.String");
        BranchCode.ColumnName = "BranchCode";
        BranchCode.DefaultValue = "BranchCode";
        dt.Columns.Add(BranchCode);

        // Create Description
        DataColumn AppNo = new DataColumn();
        AppNo.DataType = System.Type.GetType("System.String");
        AppNo.ColumnName = "AppNo";
        AppNo.DefaultValue = "AppNo";
        dt.Columns.Add(AppNo);

        // Create Description
        DataColumn TitleSLIC = new DataColumn();
        TitleSLIC.DataType = System.Type.GetType("System.String");
        TitleSLIC.ColumnName = "TitleSLIC";
        TitleSLIC.DefaultValue = "TitleSLIC";
        dt.Columns.Add(TitleSLIC);

        // Create Description
        DataColumn TitleAllianz = new DataColumn();
        TitleAllianz.DataType = System.Type.GetType("System.String");
        TitleAllianz.ColumnName = "TitleAllianz";
        TitleAllianz.DefaultValue = "TitleAllianz";
        dt.Columns.Add(TitleAllianz);

        // Create Description
        DataColumn TitleAIA = new DataColumn();
        TitleAIA.DataType = System.Type.GetType("System.String");
        TitleAIA.ColumnName = "TitleAIA";
        TitleAIA.DefaultValue = "TitleAIA";
        dt.Columns.Add(TitleAIA);

        // Create Description
        DataColumn TitleCeylinco = new DataColumn();
        TitleCeylinco.DataType = System.Type.GetType("System.String");
        TitleCeylinco.ColumnName = "TitleCeylinco";
        TitleCeylinco.DefaultValue = "TitleCeylinco";
        dt.Columns.Add(TitleCeylinco);

        // Create Description
        DataColumn TitleJanashakthi = new DataColumn();
        TitleJanashakthi.DataType = System.Type.GetType("System.String");
        TitleJanashakthi.ColumnName = "TitleJanashakthi";
        TitleJanashakthi.DefaultValue = "TitleJanashakthi";
        dt.Columns.Add(TitleJanashakthi);

        // Create Description
        DataColumn TitleUnion = new DataColumn();
        TitleUnion.DataType = System.Type.GetType("System.String");
        TitleUnion.ColumnName = "TitleUnion";
        TitleUnion.DefaultValue = "TitleUnion";
        dt.Columns.Add(TitleUnion);

        // Create Description
        DataColumn FireSLIC = new DataColumn();
        FireSLIC.DataType = System.Type.GetType("System.String");
        FireSLIC.ColumnName = "FireSLIC";
        FireSLIC.DefaultValue = "FireSLIC";
        dt.Columns.Add(FireSLIC);


        // Create Description
        DataColumn FireAllianz = new DataColumn();
        FireAllianz.DataType = System.Type.GetType("System.String");
        FireAllianz.ColumnName = "FireAllianz";
        FireAllianz.DefaultValue = "FireAllianz";
        dt.Columns.Add(FireAllianz);

        // Create Description
        DataColumn FireAIA = new DataColumn();
        FireAIA.DataType = System.Type.GetType("System.String");
        FireAIA.ColumnName = "FireAIA";
        FireAIA.DefaultValue = "FireAIA";
        dt.Columns.Add(FireAIA);

        // Create Description
        DataColumn FireCeylinco = new DataColumn();
        FireCeylinco.DataType = System.Type.GetType("System.String");
        FireCeylinco.ColumnName = "FireCeylinco";
        FireCeylinco.DefaultValue = "FireCeylinco";
        dt.Columns.Add(FireCeylinco);


        // Create Description
        DataColumn FireJanashakthi = new DataColumn();
        FireJanashakthi.DataType = System.Type.GetType("System.String");
        FireJanashakthi.ColumnName = "FireJanashakthi";
        FireJanashakthi.DefaultValue = "FireJanashakthi";
        dt.Columns.Add(FireJanashakthi);

        // Create Description
        DataColumn FireUnion = new DataColumn();
        FireUnion.DataType = System.Type.GetType("System.String");
        FireUnion.ColumnName = "FireUnion";
        FireUnion.DefaultValue = "FireUnion";
        dt.Columns.Add(FireUnion);

        // Create Description
        DataColumn DTASoftLogic = new DataColumn();
        DTASoftLogic.DataType = System.Type.GetType("System.String");
        DTASoftLogic.ColumnName = "DTASoftLogic";
        DTASoftLogic.DefaultValue = "DTASoftLogic";
        dt.Columns.Add(DTASoftLogic);

        // Create Description
        DataColumn TitleSLIC_Comm = new DataColumn();
        TitleSLIC_Comm.DataType = System.Type.GetType("System.String");
        TitleSLIC_Comm.ColumnName = "TitleSLIC_Comm";
        TitleSLIC_Comm.DefaultValue = "TitleSLIC_Comm";
        dt.Columns.Add(TitleSLIC_Comm);

        // Create Description
        DataColumn TitleAllianzComm = new DataColumn();
        TitleAllianzComm.DataType = System.Type.GetType("System.String");
        TitleAllianzComm.ColumnName = "TitleAllianzComm";
        TitleAllianzComm.DefaultValue = "TitleAllianzComm";
        dt.Columns.Add(TitleAllianzComm);

        // Create Description
        DataColumn TitleAIAComm = new DataColumn();
        TitleAIAComm.DataType = System.Type.GetType("System.String");
        TitleAIAComm.ColumnName = "TitleAIAComm";
        TitleAIAComm.DefaultValue = "TitleAIAComm";
        dt.Columns.Add(TitleAIAComm);

        // Create Description
        DataColumn TitleCeylincoComm = new DataColumn();
        TitleCeylincoComm.DataType = System.Type.GetType("System.String");
        TitleCeylincoComm.ColumnName = "TitleCeylincoComm";
        TitleCeylincoComm.DefaultValue = "TitleCeylincoComm";
        dt.Columns.Add(TitleCeylincoComm);

        // Create Description
        DataColumn TitleJanashakthiComm = new DataColumn();
        TitleJanashakthiComm.DataType = System.Type.GetType("System.String");
        TitleJanashakthiComm.ColumnName = "TitleJanashakthiComm";
        TitleJanashakthiComm.DefaultValue = "TitleJanashakthiComm";
        dt.Columns.Add(TitleJanashakthiComm);

        // Create Description
        DataColumn TitleUnionComm = new DataColumn();
        TitleUnionComm.DataType = System.Type.GetType("System.String");
        TitleUnionComm.ColumnName = "TitleUnionComm";
        TitleUnionComm.DefaultValue = "TitleUnionComm";
        dt.Columns.Add(TitleUnionComm);

        // Create Description
        DataColumn FireSLIC_Comm = new DataColumn();
        FireSLIC_Comm.DataType = System.Type.GetType("System.String");
        FireSLIC_Comm.ColumnName = "FireSLIC_Comm";
        FireSLIC_Comm.DefaultValue = "FireSLIC_Comm";
        dt.Columns.Add(FireSLIC_Comm);

        // Create Description
        DataColumn FireAllianzComm = new DataColumn();
        FireAllianzComm.DataType = System.Type.GetType("System.String");
        FireAllianzComm.ColumnName = "FireAllianzComm";
        FireAllianzComm.DefaultValue = "FireAllianzComm";
        dt.Columns.Add(FireAllianzComm);

        // Create Description
        DataColumn FireAIAComm = new DataColumn();
        FireAIAComm.DataType = System.Type.GetType("System.String");
        FireAIAComm.ColumnName = "FireAIAComm";
        FireAIAComm.DefaultValue = "FireAIAComm";
        dt.Columns.Add(FireAIAComm);

        // Create Description
        DataColumn FireCeylincoComm = new DataColumn();
        FireCeylincoComm.DataType = System.Type.GetType("System.String");
        FireCeylincoComm.ColumnName = "FireCeylincoComm";
        FireCeylincoComm.DefaultValue = "FireCeylincoComm";
        dt.Columns.Add(FireCeylincoComm);

        // Create Description
        DataColumn FireJanashakthiComm = new DataColumn();
        FireJanashakthiComm.DataType = System.Type.GetType("System.String");
        FireJanashakthiComm.ColumnName = "FireJanashakthiComm";
        FireJanashakthiComm.DefaultValue = "FireJanashakthiComm";
        dt.Columns.Add(FireJanashakthiComm);

        // Create Description
        DataColumn FireUnionComm = new DataColumn();
        FireUnionComm.DataType = System.Type.GetType("System.String");
        FireUnionComm.ColumnName = "FireUnionComm";
        FireUnionComm.DefaultValue = "FireUnionComm";
        dt.Columns.Add(FireUnionComm);

        // Create Description
        DataColumn DTASoftLogicComm = new DataColumn();
        DTASoftLogicComm.DataType = System.Type.GetType("System.String");
        DTASoftLogicComm.ColumnName = "DTASoftLogicComm";
        DTASoftLogicComm.DefaultValue = "DTASoftLogicComm";
        dt.Columns.Add(DTASoftLogicComm);

        // Create Description
        DataColumn TotalTitle = new DataColumn();
        TotalTitle.DataType = System.Type.GetType("System.String");
        TotalTitle.ColumnName = "TotalTitle";
        TotalTitle.DefaultValue = "TotalTitle";
        dt.Columns.Add(TotalTitle);

        // Create Description
        DataColumn TotalFire = new DataColumn();
        TotalFire.DataType = System.Type.GetType("System.String");
        TotalFire.ColumnName = "TotalFire";
        TotalFire.DefaultValue = "TotalFire";
        dt.Columns.Add(TotalFire);

        // Create Description
        DataColumn TotalCommision = new DataColumn();
        TotalCommision.DataType = System.Type.GetType("System.String");
        TotalCommision.ColumnName = "TotalCommision";
        TotalCommision.DefaultValue = "TotalCommision";
        dt.Columns.Add(TotalCommision);

        return dt;
    }

    public DataTable GetInsuranceCompanyDetails()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select distinct C.refcode, C.TaskDescription as TaskDescription
                            from CREDITBRDB.TDBBranches.CreditAdmin.GlCode G, 
                            CREDITBRDB.TDBBranches.CreditAdmin.CommisionDetails C 
                            where SUBSTRING(refglcode,6,10)=C.refcode");
        return dw.GetDataTable();
    }

    public DataTable GetCreditDivCompanyDetails()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select distinct refcode, TaskDescription from CommisionDetails where 
                            refcode is not null");
        return dw.GetDataTable();
    }

    public decimal GetCommissionAmt(string refcode)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select CommisionPercentage/100 from CREDITBRDB.TDBBranches.CreditAdmin.CommisionDetails 
                        where refcode=@refcode");
        dw.SetSqlCommandParameters("refcode", refcode);
        return decimal.Parse(dw.GetSingleData());
    }

    public decimal CreditDivCommissionAmt(string refcode)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select CommisionPercentage/100 from CommisionDetails 
                        where refcode=@refcode");
        dw.SetSqlCommandParameters("refcode", refcode);
        return decimal.Parse(dw.GetSingleData());
    }

}
