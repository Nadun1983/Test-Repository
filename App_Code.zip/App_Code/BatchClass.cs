﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Data.SqlClient;
using Microsoft.SqlServer.Server;

/// <summary>
/// Summary description for BatchClass
/// </summary>
public class BatchClass
{
    CrTransClass ctc;
    DataWorksClass dw;
    FunctionClass fc;
    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString;
    string oldhousdbString = ConfigurationManager.ConnectionStrings["oldhousdbString"].ConnectionString;

    public BatchClass()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    //2009-06-03 vihanga
    public int InsertTransAssign(string CrAcNo, string taskid, double AssignAmt, string TrStatus, string AddUser,
                                 DateTime AddDate, string TransRef, string trtype, int disbrefno, string system, string description)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO TransAssign (CrAcNo,taskid,AssignAmt,TrStatus,AddUser,AddDate,TransRef,trtype,disbrefno,system,description)
                       values (@CrAcNo,@taskid,@AssignAmt,@TrStatus,@AddUser,@AddDate,@TransRef,@trtype,@disbrefno,@system,@description)");
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        dw.SetSqlCommandParameters("taskid", taskid);
        dw.SetSqlCommandParameters("AssignAmt", AssignAmt);
        dw.SetSqlCommandParameters("TrStatus", TrStatus);
        dw.SetSqlCommandParameters("AddUser", AddUser);
        dw.SetSqlCommandParameters("AddDate", AddDate);
        dw.SetSqlCommandParameters("TransRef", TransRef);
        dw.SetSqlCommandParameters("trtype", trtype);
        dw.SetSqlCommandParameters("disbrefno", disbrefno);
        dw.SetSqlCommandParameters("system", system);
        dw.SetSqlCommandParameters("description", description);
        return dw.Insert();
    }
    //2009-06-03
    public int InsertintoBatchHeader(DateTime batchdate, long batchno, string status, double batchTotal, string adduser, DateTime adddate, string batchdetail, int PaymentMode, string Transref, string batchtype)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into BatchHeader(batchdate,batchno,status,batchTotal,adduser,adddate,batchdetail,PaymentMode,Transref,batchtype) 
                        values(@batchdate,@batchno,@status,@batchTotal,@adduser,@adddate,@batchdetail,@PaymentMode,@Transref,@batchtype)");
        dw.SetSqlCommandParameters("batchdate", batchdate);
        dw.SetSqlCommandParameters("batchno", batchno);
        dw.SetSqlCommandParameters("status", status);
        dw.SetSqlCommandParameters("batchTotal", batchTotal);
        dw.SetSqlCommandParameters("adduser", adduser);
        dw.SetSqlCommandParameters("adddate", adddate);
        dw.SetSqlCommandParameters("batchdetail", batchdetail);
        dw.SetSqlCommandParameters("PaymentMode", PaymentMode);
        dw.SetSqlCommandParameters("Transref", Transref);
        dw.SetSqlCommandParameters("batchtype", batchtype);
        return dw.Insert();
    }


    //2009-06-03 vihanga
    public DataTable GetBatchDataToEdit(string disbrefno, string trstatus)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select refno,assignamt,cracno,description from transassign where disbrefno=@disbrefno and trstatus=@trstatus");
        dw.SetDataAdapterParameters("disbrefno", disbrefno);
        dw.SetDataAdapterParameters("trstatus", trstatus);
        return dw.GetDataTable();
    }

    //2009-06-03 vihanga
    public int UpdateBatchData(string refno, string cracno, double assignamt, string description)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update transassign set cracno=@cracno,assignamt=@assignamt,description=@description where refno=@refno");
        dw.SetSqlCommandParameters("refno", refno);
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("assignamt", assignamt);
        dw.SetSqlCommandParameters("description", description);
        return dw.Update();
    }


    //2009-06-05 vihanga
    public DataTable GetPaymentModeDetails(string status)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select gldescription,paymentid from paymentmode where status=@status");
        dw.SetDataAdapterParameters("status", status);
        return dw.GetDataTable();
    }

    //2009-06-05 vihanga
    public int InsertBatchTmpRecords(long BatchNo, DateTime BatchDate, string CrAcNo, DateTime TransDate,
               string AcSign, double TrAmt, string TrDetail, int IsGLUpdate, string Status, string taskid,
        string oldtransno, string BatchType)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into BatchTmp(BatchNo,BatchDate,CrAcNo,TransDate,AcSign,TrAmt,TrDetail,IsGLUpdate,Status,taskid,oldtransno, BatchType) 
                        values (@BatchNo,@BatchDate,@CrAcNo,@TransDate,@AcSign,@TrAmt,@TrDetail,@IsGLUpdate,@Status,@taskid,@oldtransno, @BatchType)");
        dw.SetSqlCommandParameters("BatchNo", BatchNo);
        dw.SetSqlCommandParameters("BatchDate", BatchDate);
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        dw.SetSqlCommandParameters("TransDate", TransDate);
        dw.SetSqlCommandParameters("AcSign", AcSign);
        dw.SetSqlCommandParameters("TrAmt", TrAmt);
        dw.SetSqlCommandParameters("TrDetail", TrDetail);
        dw.SetSqlCommandParameters("IsGLUpdate", IsGLUpdate);
        dw.SetSqlCommandParameters("Status", Status);
        dw.SetSqlCommandParameters("taskid", taskid);
        dw.SetSqlCommandParameters("oldtransno", oldtransno);
        dw.SetSqlCommandParameters("BatchType", BatchType);
        return dw.Insert();
    }

    //2009-06-08 vihanga
    public DataTable GetGLAccTranserData(long BatchNo)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select b.BAtchDetail,b.PaymentMode,b.Transref,b.BatchNo,b.AddDate from BatchHeader b, PaymentMode p
                            where b.BatchNo=@BatchNo and p.paymentid=b.PaymentMode");
        dw.SetDataAdapterParameters("BatchNo", BatchNo);
        return dw.GetDataTable();
    }

    //2009-06-08 vihanga
    public DataTable GetGlAccTranserDataToEdit(long batchnum, string status)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select cracno,transdate,tramt,trdetail from batchtmp where status=@status and isglupdate = 0 and batchno=@batchnum");
        dw.SetDataAdapterParameters("batchnum", batchnum);
        dw.SetDataAdapterParameters("status", status);
        return dw.GetDataTable();
    }


    //2009-06-09 vihanga
    public DataTable GetCustomerDetails(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select rtrim(rtrim(cm.initials) + ' ' + rtrim(cm.surname)) as CustomerName ,
                            h.Instalment,h.OutBal,h.DateDue from housprop h,crholder c,customermain cm
                            where h.cracno=@cracno and c.cracno=h.cracno and cm.nicno=c.nicno");
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }



    public DataTable DisplayGLBatchDetails(string trstatus, int disbrefno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select Cracno,AssignAmt,AddDate,TransRef,DisbRefno as BatchNo 
                            from transassign where trstatus=@trstatus and disbrefno=@disbrefno");
        dw.SetDataAdapterParameters("trstatus", trstatus);
        dw.SetDataAdapterParameters("disbrefno", disbrefno);
        return dw.GetDataTable();
    }


    public int InactiveBatch(string batchno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update transassign set trstatus='I' where disbrefno=@batchno)");
        dw.SetSqlCommandParameters("batchno", batchno);
        return dw.Update();
    }


    public DataTable GetGlCodes()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select refglcode,glcode,gldesc from glcode");
        return dw.GetDataTable();
    }

    //Amila - 05/06/2009
    //    public DataTable GeBatchTempData(DateTime batchdate, string status)
    //    {
    //        dw = new DataWorksClass(constring);
    //        dw.SetDataAdapter(@"select bh.batchno, bh.adduser, bh.batchtype,  bh.transref, bt.* from BatchHeader bh, BatchTmp bt
    //                            where bh.batchno=bt.batchno and bh.batchdate = @batchdate and
    //                            bt.status=@status");
    //        dw.SetDataAdapterParameters("batchdate", batchdate);
    //        dw.SetDataAdapterParameters("status", status);
    //        return dw.GetDataTable();
    //    }



    //Amila - 05/06/2009
    public DataTable GetBatchTempData(DateTime batchdate, string status)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select bh.batchno, bh.adduser, bt.* from BatchHeader bh, BatchTmp bt
                            where bh.batchno=bt.batchno and bh.batchdate = @batchdate and
                            bt.status=@status");
        dw.SetDataAdapterParameters("batchdate", batchdate);
        dw.SetDataAdapterParameters("status", status);
        return dw.GetDataTable();
    }

    public DataTable GetBatchData(DateTime batchdate, string transref)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from batchheader where batchdate=@batchdate and transref=@transref");
        dw.SetDataAdapterParameters("batchdate", batchdate);
        dw.SetDataAdapterParameters("transref", transref);
        return dw.GetDataTable();
    }


    public string GetGlAccountName(long glcode)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select gldesc from glcode where glcode=@glcode");
        dw.SetSqlCommandParameters("glcode", glcode);
        return dw.GetSingleData();
    }


    public string CheckBatchNo(string glcode)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select refglcode from glcode where refglcode=@glcode");
        dw.SetSqlCommandParameters("glcode", glcode);
        return dw.GetSingleData();
    }

    public int BatchReference(long batchno, int transType)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into batchreference(batchno,transType) values(@batchno,@transType)");
        dw.SetSqlCommandParameters("batchno", batchno);
        dw.SetSqlCommandParameters("transType", transType);
        return dw.Insert();
    }

    public DataTable GetTransData(string system, string disbrefno, string trstatus)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select cracno, trtype, transref, taskid,  trstatus,
                            sum(assignamt) as tramt from TransAssign 
                            where disbrefno = @disbrefno AND system = @system, and trstatus=@trstatus 
                            group by cracno, trtype, transref, taskid,  trstatus");
        dw.SetDataAdapterParameters("system", system);
        dw.SetDataAdapterParameters("disbrefno", disbrefno);

        return dw.GetDataTable();
    }


    //    //2009-06-03 vihanga
    //    public int InsertTransAssign(string CrAcNo, string taskid, double AssignAmt, string TrStatus, string AddUser,
    //                                 DateTime AddDate, string TransRef, string trtype, int disbrefno, string system, string description)
    //    {
    //        dw = new DataWorksClass(constring);
    //        dw.SetCommand(@"INSERT INTO TransAssign (CrAcNo,taskid,AssignAmt,TrStatus,AddUser,AddDate,TransRef,trtype,disbrefno,system,description)
    //                       values (@CrAcNo,@taskid,@AssignAmt,@TrStatus,@AddUser,@AddDate,@TransRef,@trtype,@disbrefno,@system,@description)");
    //        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
    //        dw.SetSqlCommandParameters("taskid", taskid);
    //        dw.SetSqlCommandParameters("AssignAmt", AssignAmt);
    //        dw.SetSqlCommandParameters("TrStatus", TrStatus);
    //        dw.SetSqlCommandParameters("AddUser", AddUser);
    //        dw.SetSqlCommandParameters("AddDate", AddDate);
    //        dw.SetSqlCommandParameters("TransRef", TransRef);
    //        dw.SetSqlCommandParameters("trtype", trtype);
    //        dw.SetSqlCommandParameters("disbrefno", disbrefno);
    //        dw.SetSqlCommandParameters("system", system);
    //        dw.SetSqlCommandParameters("description", description);
    //        return dw.Insert();
    //    }
    //2009-06-03
    public int InsertintoBatchHeader(DateTime batchdate, long batchno, string status, double batchTotal, string adduser, DateTime adddate, string batchdetail)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into BatchHeader(batchdate,batchno,status,batchTotal,adduser,adddate,batchdetail) 
                        values(@batchdate,@batchno,@status,@batchTotal,@adduser,@adddate,@batchdetail)");
        dw.SetSqlCommandParameters("batchdate", batchdate);
        dw.SetSqlCommandParameters("batchno", batchno);
        dw.SetSqlCommandParameters("status", status);
        dw.SetSqlCommandParameters("batchTotal", batchTotal);
        dw.SetSqlCommandParameters("adduser", adduser);
        dw.SetSqlCommandParameters("adddate", adddate);
        dw.SetSqlCommandParameters("batchdetail", batchdetail);

        return dw.Insert();
    }

    ////2009-06-03 vihanga
    //public double GetBatchAmountDetails(string trtype, int disbrefno)
    //{
    //    dw = new DataWorksClass(constring);
    //    dw.SetCommand(@"select sum(assignamt) as amount from transassign where trtype=@trtype and disbrefno=@disbrefno");
    //    dw.SetSqlCommandParameters("trtype", trtype);
    //    dw.SetSqlCommandParameters("disbrefno", disbrefno);
    //    return Convert.ToDouble(dw.GetSingleData());
    //}

    ////2009-06-03 vihanga
    //public int ConfirmBatch(int disbrefno, string trstatus)
    //{
    //    dw = new DataWorksClass(constring);
    //    dw.SetCommand(@"update transassign set trstatus=@trstatus where disbrefno=@disbrefno");
    //    dw.SetSqlCommandParameters("trstatus", trstatus);
    //    dw.SetSqlCommandParameters("disbrefno", disbrefno);
    //    return dw.Update();
    //}

    ////2009-06-03 vihanga
    //public DataTable GetBatchDataToEdit(string disbrefno, string trstatus)
    //{
    //    dw = new DataWorksClass(constring);
    //    dw.SetDataAdapter(@"select refno,assignamt,cracno,description from transassign where disbrefno=@disbrefno and trstatus=@trstatus");
    //    dw.SetDataAdapterParameters("disbrefno", disbrefno);
    //    dw.SetDataAdapterParameters("trstatus", trstatus);
    //    return dw.GetDataTable();
    //}

    ////2009-06-03 vihanga
    //public int UpdateBatchData(string refno, string cracno, double assignamt, string description)
    //{
    //    dw = new DataWorksClass(constring);
    //    dw.SetCommand(@"update transassign set cracno=@cracno,assignamt=@assignamt,description=@description where refno=@refno");
    //    dw.SetSqlCommandParameters("refno", refno);
    //    dw.SetSqlCommandParameters("cracno", cracno);
    //    dw.SetSqlCommandParameters("assignamt", assignamt);
    //    dw.SetSqlCommandParameters("description", description);
    //    return dw.Update();
    //}



    //2009-06-03
    public int InsertintoBatchHeader(DateTime batchdate, long batchno, string status, double batchTotal, string adduser, DateTime adddate, string batchdetail, int PaymentMode, string Transref)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into BatchHeader(batchdate,batchno,status,batchTotal,adduser,adddate,batchdetail,PaymentMode,Transref) 
                        values(@batchdate,@batchno,@status,@batchTotal,@adduser,@adddate,@batchdetail,@PaymentMode,@Transref)");
        dw.SetSqlCommandParameters("batchdate", batchdate);
        dw.SetSqlCommandParameters("batchno", batchno);
        dw.SetSqlCommandParameters("status", status);
        dw.SetSqlCommandParameters("batchTotal", batchTotal);
        dw.SetSqlCommandParameters("adduser", adduser);
        dw.SetSqlCommandParameters("adddate", adddate);
        dw.SetSqlCommandParameters("batchdetail", batchdetail);
        dw.SetSqlCommandParameters("PaymentMode", PaymentMode);
        dw.SetSqlCommandParameters("Transref", Transref);
        return dw.Insert();
    }


    ////2009-06-05 vihanga
    //public DataTable GetPaymentModeDetails(string status)
    //{
    //    dw = new DataWorksClass(constring);
    //    dw.SetDataAdapter(@"select description,paymentid from paymentmode where status=@status");
    //    dw.SetDataAdapterParameters("status", status);
    //    return dw.GetDataTable();
    //}

    //2009-06-05 vihanga
    public int InsertBatchTmpRecords(long BatchNo, DateTime BatchDate, string CrAcNo, DateTime TransDate,
                      string AcSign, string TrType, double TrAmt, string TrDetail, int IsGLUpdate, string Status)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into BatchTmp(BatchNo,BatchDate,CrAcNo,TransDate,AcSign,TrType,TrAmt,TrDetail,IsGLUpdate,Status) 
                        values (@BatchNo,@BatchDate,@CrAcNo,@TransDate,@AcSign,@TrType,@TrAmt,@TrDetail,@IsGLUpdate,@Status)");
        dw.SetSqlCommandParameters("BatchNo", BatchNo);
        dw.SetSqlCommandParameters("BatchDate", BatchDate);
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        dw.SetSqlCommandParameters("TransDate", TransDate);
        dw.SetSqlCommandParameters("AcSign", AcSign);
        dw.SetSqlCommandParameters("TrType", TrType);
        dw.SetSqlCommandParameters("TrAmt", TrAmt);
        dw.SetSqlCommandParameters("TrDetail", TrDetail);
        dw.SetSqlCommandParameters("IsGLUpdate", IsGLUpdate);
        dw.SetSqlCommandParameters("Status", Status);
        return dw.Insert();
    }

    //    //2009-06-08 vihanga
    //    public DataTable GetGLAccTranserData(long BatchNo)
    //    {
    //        dw = new DataWorksClass(constring);
    //        dw.SetDataAdapter(@"select b.BAtchDetail,b.PaymentMode,b.Transref,b.BatchNo,b.AddDate from BatchHeader b, PaymentMode p
    //                            where b.BatchNo=@BatchNo and p.paymentid=b.PaymentMode");
    //        dw.SetDataAdapterParameters("BatchNo", BatchNo);
    //        return dw.GetDataTable();
    //    }

    ////2009-06-08 vihanga
    //public DataTable GetGlAccTranserDataToEdit(long batchnum, string status)
    //{
    //    dw = new DataWorksClass(constring);
    //    dw.SetDataAdapter(@"select cracno,transdate,tramt,trdetail from batchtmp where status=@status and isglupdate = 0 and batchno=@batchnum");
    //    dw.SetDataAdapterParameters("batchnum", batchnum);
    //    dw.SetDataAdapterParameters("status", status);
    //    return dw.GetDataTable();
    //}

    public void InsertBatchData(DateTime batchdate)
    {
        DataTable dt = new DataTable();
        dw = new DataWorksClass(oldhousdbString);
        dw.SetDataAdapter(@"select convert(varchar(4), year(batchdate)) +
                            convert(varchar(2), month(batchdate)) + 
                            convert(varchar(2), day(batchdate)) + convert(varchar(6), batchno) 
                            as batchNo,c.batchdate,c.cracno,c.transdate,c.acsign,cast(c.transamt as  decimal(18,2)),rtrim(rtrim(c.transdetail) + ' | ' + rtrim(c.action)
                        + ' | ' + rtrim(c.trgensec) + ' | ' + rtrim(c.transuser)) as trdetails ,
                        case when c.trcode = '9' then 'Normal' 
                        when c.trcode = '6' then 'CAPD'   
                        when c.trcode = '10' then 'INTR'   
                        when c.trcode = '116' then 'PNLR'   
                        else 'OTHR' end as taskid , 
                        c.transno as oldtransno, action as  batchtype, 'X' as status
                        from crtransjrnl c, transcat t 
                        where c.batchdate = @batchdate and 
                        (c.action = 'RVS' or c.action = 'BAV' or c.action = 'CHQ' and c.action = 'CSH' or c.action = 'JRN') 
                        and t.trcode=c.trcode");
        dw.SetDataAdapterParameters("batchdate", batchdate);
        dt = dw.GetDataTable();
        dw = new DataWorksClass(constring);
        dw.SetCommand();
        dw.InsertBulk(dt, "BatchTmp");

    }


    public void InsertBatchData(string batchno, DateTime batchdate)
    {
        DataTable dt = new DataTable();
        dw = new DataWorksClass(oldhousdbString);
        dw.SetDataAdapter(@"select  convert(varchar(4), year(batchdate)) +
                            convert(varchar(2), month(batchdate)) + 
                            convert(varchar(2), day(batchdate)) + convert(varchar(6), batchno) 
                            as batchNo,c.batchdate,c.cracno,c.transdate,c.acsign, 
                            cast(c.transamt as  decimal(18,2)) as tramt,
                            rtrim(rtrim(c.transdetail) + ' | ' + rtrim(c.action)
                            + ' | ' + rtrim(c.trgensec) + ' | ' + rtrim(c.transuser)) as trdetails ,
                            case when c.trcode = '9' then 'Normal' 
                            when c.trcode = '6' then 'CAPD'   
                            when c.trcode = '10' then 'INTR'   
                            when c.trcode = '116' then 'PNLR'   
                            else 'OTHR' end as taskid , 
                            c.transno as oldtransno, 
                            action as  batchtype, 'X' as status
                            from crtransjrnl c
                            where c.batchdate = @batchdate and batchno = @batchno");
        dw.SetDataAdapterParameters("batchno", batchno);
        dw.SetDataAdapterParameters("batchdate", batchdate);
        dt = dw.GetDataTable();
        dw = new DataWorksClass(constring);
        dw.SetCommand();
        dw.InsertBulk(dt, "BatchTmp");
    }




    public void InsertBatch(DateTime batchdate, string action, int code)
    {
        DataTable dt = new DataTable();
        dw = new DataWorksClass(oldhousdbString);
        dw.SetDataAdapter(@" select substring(CONVERT(VARCHAR(8), batchdate, 112), 0, 10)  + 
                            CONVERT(char(10), @code),
                            c.batchdate,c.cracno,c.transdate,c.acsign, 
                            cast(c.transamt as  decimal(18,2)) as tramt,
                            rtrim(rtrim(c.transdetail) + ' | ' + rtrim(c.action)
                            + ' | ' + rtrim(c.trgensec) + ' | ' + rtrim(c.transuser)) as trdetails ,
                            case when c.trcode = '9' then 'Normal' 
                            when c.trcode = '6' then 'CAPD'   
                            when c.trcode = '10' then 'INTR'   
                            when c.trcode = '116' then 'PNLR'   
                            else 'OTHR' end as taskid , 
                            c.transno as oldtransno, 
                            action as  batchtype, 'X' as status
                            from crtransjrnl c
                            where c.batchdate = @batchdate and action = @action and istrans != 'Y'");
        dw.SetDataAdapterParameters("batchdate", batchdate);
        dw.SetDataAdapterParameters("action", action);
        dw.SetDataAdapterParameters("code", code);
        dt = dw.GetDataTable();
        dw = new DataWorksClass(constring);
        dw.SetCommand();
        dw.InsertBulk(dt, "BatchTmp");
    }


    public void UpdateBatchinOldSystem(DateTime batchdate, string action, string istrans)
    {
        DataTable dt = new DataTable();
        dw = new DataWorksClass(oldhousdbString);
        dw.SetCommand(@"update crtransjrnl set istrans = @istrans 
                            where batchdate = @batchdate and action = @action and istrans = 'N'");
        dw.SetSqlCommandParameters("batchdate", batchdate);
        dw.SetSqlCommandParameters("action", action);
        dw.SetSqlCommandParameters("istrans", istrans);
        dw.Update();
    }


    public void UpdateBatchinOldSystem(DateTime batchdate, int batchno, string istrans)
    {
        DataTable dt = new DataTable();
        dw = new DataWorksClass(oldhousdbString);
        dw.SetCommand(@"update crtransjrnl set istrans = @istrans 
                            where batchdate = @batchdate and batchno = @batchno and istrans = 'N'");
        dw.SetSqlCommandParameters("batchdate", batchdate);
        dw.SetSqlCommandParameters("batchno", batchno);
        dw.SetSqlCommandParameters("istrans", istrans);
        dw.Update();
    }

    public void UpdateBatchinOldSystem(DateTime batchdate, int batchno, string action, string istrans)
    {
        DataTable dt = new DataTable();
        dw = new DataWorksClass(oldhousdbString);
        dw.SetCommand(@"update crtransjrnl set istrans = @istrans 
                            where batchdate = @batchdate and batchno != @batchno 
                            and action=@action and istrans = 'N'");
        dw.SetSqlCommandParameters("batchdate", batchdate);
        dw.SetSqlCommandParameters("batchno", batchno);
        dw.SetSqlCommandParameters("istrans", istrans);
        dw.SetSqlCommandParameters("action", action);
        dw.Update();
    }



    public void InsertBatch(DateTime batchdate, string action, int code, int batchno)
    {
        DataTable dt = new DataTable();
        dw = new DataWorksClass(oldhousdbString);
        dw.SetDataAdapter(@" select substring(CONVERT(VARCHAR(8), batchdate, 112), 0, 10)  + 
                            CONVERT(char(10), @code),
                            c.batchdate,c.cracno,c.transdate,c.acsign, 
                            cast(c.transamt as  decimal(18,2)) as tramt,
                            rtrim(rtrim(c.transdetail) + ' | ' + rtrim(c.action)
                            + ' | ' + rtrim(c.trgensec) + ' | ' + rtrim(c.transuser)) as trdetails ,
                            case when c.trcode = '9' then 'Normal' 
                            when c.trcode = '6' then 'CAPD'   
                            when c.trcode = '10' then 'INTR'   
                            when c.trcode = '116' then 'PNLR'   
                            else 'OTHR' end as taskid , 
                            c.transno as oldtransno, 
                            action as  batchtype, 'X' as status
                            from crtransjrnl c
                            where c.batchdate = @batchdate and action = @action 
                            and batchno = @batchno ");
        dw.SetDataAdapterParameters("batchdate", batchdate);
        dw.SetDataAdapterParameters("action", action);
        dw.SetDataAdapterParameters("code", code);
        dw.SetDataAdapterParameters("batchno", batchno);
        dt = dw.GetDataTable();
        dw = new DataWorksClass(constring);
        dw.SetCommand();
        dw.InsertBulk(dt, "BatchTmp");
    }



    public void InsertCashierGLBatchData(string batchno, DateTime batchdate)
    {
        DataTable dt = new DataTable();
        dw = new DataWorksClass(oldhousdbString);
        dw.SetDataAdapter(@"select substring(CONVERT(VARCHAR(8), batchdate, 112), 0, 10) + 
                            CONVERT(char(10), batchNo) 
                            as batchNo,c.batchdate,c.cracno,c.transdate,c.acsign, 
                            cast(c.transamt as  decimal(18,2)) as tramt,
                            rtrim(rtrim(c.transdetail) + ' | ' + rtrim(c.action)
                            + ' | ' + rtrim(c.trgensec) + ' | ' + rtrim(c.transuser)) as trdetails ,
                            case when c.trcode = '9' then 'Normal' 
                            when c.trcode = '6' then 'CAPD'   
                            when c.trcode = '10' then 'INTR'   
                            when c.trcode = '116' then 'PNLR'   
                            else 'OTHR' end as taskid ,
                            c.transno as oldtransno, 
                            action as  batchtype, 'X' as status
                            from crtransjrnl c
                            where c.batchdate = @batchdate and batchno = @batchno and left(cracno,1) ='9' 
                            and c.trgensec = 'tel' and c.transtatus='A'");
        dw.SetDataAdapterParameters("batchno", batchno);
        dw.SetDataAdapterParameters("batchdate", batchdate);
        dt = dw.GetDataTable();
        for (int i = 0; dt.Rows.Count > i; i++)
        {
            batchno = dt.Rows[i]["batchno"].ToString();
            string cracno = dt.Rows[i]["cracno"].ToString();
            DateTime transdate = DateTime.Parse(dt.Rows[i]["transdate"].ToString());
            string acsign = dt.Rows[i]["acsign"].ToString();
            double tramt = double.Parse(dt.Rows[i]["tramt"].ToString());
            string trdetails = dt.Rows[i]["trdetails"].ToString();
            string taskid = dt.Rows[i]["taskid"].ToString();
            string oldtransno = dt.Rows[i]["oldtransno"].ToString();
            string batchtype = dt.Rows[i]["batchtype"].ToString();
            string status = dt.Rows[i]["status"].ToString();


            InsertBatchTmpRecords(long.Parse(batchno), batchdate, cracno, transdate, acsign, tramt, trdetails, 0, "X", taskid, oldtransno, "CSH");
            switch (acsign)
            {
                case "CR":
                    acsign = "DR";
                    break;

                case "DR":
                    acsign = "CR";
                    break;
            }
            cracno = "903085465050";
            InsertBatchTmpRecords(long.Parse(batchno), batchdate, cracno, transdate, acsign, tramt, trdetails, 0, "X", taskid, oldtransno, "CSH");
        }


        //dw = new DataWorksClass(constring);
        //dw.SetCommand();
        ////dw.InsertBulk(dt, "BatchTmp");
    }



    public void InsertBatchDataChq(string batchno, DateTime batchdate)
    {
        DataTable dt = new DataTable();
        dw = new DataWorksClass(oldhousdbString);
        dw.SetDataAdapter(@"select convert(varchar(4), year(batchdate)) +
                            convert(varchar(2), month(batchdate)) + 
                            convert(varchar(2), day(batchdate)) + convert(varchar(6), batchno) 
                            as batchNo, BatchDate,CrAcNo,TransDate,acsign,
                            transamt,transdetail,''as taskid,transno as olldTransNo,
                            action, 'X' as status, null as IsGlUpd  from crtransjrnl 
                            where batchno = @batchno and batchdate = @batchdate and 
                            left(cracno,1) = '9'");
        dw.SetDataAdapterParameters("batchno", batchno);
        dw.SetDataAdapterParameters("batchdate", batchdate);
        dt = dw.GetDataTable();
        dw = new DataWorksClass(constring);
        dw.SetCommand();
        dw.InsertBulk(dt, "BatchTmp");

    }




    public void InsertBatchHeaderData(DateTime batchdate)
    {
        DataTable dt = new DataTable();
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select distinct batchno, @batchdate, 'A' 
                            from batchtmp where batchdate = @batchdate");
        dw.SetDataAdapterParameters("batchdate", batchdate);
        dt = dw.GetDataTable();
        dw = new DataWorksClass(constring);
        dw.SetCommand();
        dw.InsertBulk(dt, "BatchHeader");
    }


    public void InsertBatchHeaderData(DateTime batchdate, long batchno, string Status)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into batchheader (batchdate,batchno,Status) values (@batchdate,@batchno,@Status)");
        dw.SetSqlCommandParameters("batchdate", batchdate);
        dw.SetSqlCommandParameters("batchno", batchno);
        dw.SetSqlCommandParameters("Status", Status);
        dw.Insert();
    }


    public void InsertBatchHeaderDataAll(DateTime batchdate, int batchno)
    {
        DataTable dt = new DataTable();
        dw = new DataWorksClass(oldhousdbString);
        dw.SetDataAdapter(@"select substring(CONVERT(VARCHAR(8), batchdate, 112), 0, 10)  + 
                            CONVERT(char(10), batchno) as batchno, 
                            c.batchdate,c.cracno,c.transdate,c.acsign, 
                            cast(c.transamt as  decimal(18,2)) as tramt,
                            rtrim(rtrim(c.transdetail) + ' | ' + rtrim(c.action)
                            + ' | ' + rtrim(c.trgensec) + ' | ' + rtrim(c.transuser)) as trdetails ,
                            case when c.trcode = '9' then 'Normal' 
                            when c.trcode = '6' then 'CAPD'
                            when c.trcode = '10' then 'INTR'
                            when c.trcode = '116' then 'PNLR'
                            else 'OTHR' end as taskid , 
                            c.transno as oldtransno, 
                            action as  batchtype, 'X' as status
                            from crtransjrnl c
                            where c.batchdate = @batchdate and action = 'RVS' 
                            and batchno != @batchno and istrans!='Y'");
        dw.SetDataAdapterParameters("batchdate", batchdate);
        dw.SetDataAdapterParameters("batchno", batchno);
        dt = dw.GetDataTable();
        dw = new DataWorksClass(constring);
        dw.SetCommand();
        dw.InsertBulk(dt, "BatchTmp");
    }


    public DataTable GetBatchHeaders(DateTime Batchdate)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select distinct batchno from BatchHeader 
                            where Batchdate= @Batchdate");
        dw.SetDataAdapterParameters("Batchdate", Batchdate);
        return dw.GetDataTable();
    }


    public DataTable GetBatchHeadersAll(DateTime Batchdate)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from BatchHeader 
                            where Batchdate= @Batchdate");
        dw.SetDataAdapterParameters("Batchdate", Batchdate);
        return dw.GetDataTable();
    }

    //2009-06-23 Amila
    public DataTable GetBatchData(string batchno, DateTime batchdate, bool IsGLUpdate)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select refno, batchno, cracno, CONVERT(VARCHAR(10), batchdate, 101) AS batchdate, 
                            CONVERT(VARCHAR(10), transdate, 101) AS trdate, tramt, acsign, trdetail, taskid, batchtype
                            from batchtmp where batchno=@batchno and batchdate=@batchdate
                            and IsGLUpdate=@IsGLUpdate order by acsign desc, transdate ");
        //IsGLUpdate is null 
        dw.SetDataAdapterParameters("batchno", batchno);
        dw.SetDataAdapterParameters("batchdate", batchdate);
        dw.SetDataAdapterParameters("IsGLUpdate", IsGLUpdate);
        return dw.GetDataTable();
    }

    public DataTable GetBatchData(string batchno, bool IsGLUpdate, string Status, string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select batchno, cracno, transdate, tramt, acsign, trdetail, taskid, status, 
                            batchtype, batchdate,oldtransno, refno
                            from batchtmp where batchno=@batchno and IsGLUpdate=@IsGLUpdate and 
                            Status=@Status and cracno =@cracno
                            order by transdate");
        //IsGLUpdate is null 
        dw.SetDataAdapterParameters("batchno", batchno);
        dw.SetDataAdapterParameters("IsGLUpdate", IsGLUpdate);
        dw.SetDataAdapterParameters("Status", Status);
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }

    //2009-06-23 Amila
    public DataTable GetBatchSummeryData(string batchno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select acsign, sum(tramt) from batchtmp where batchno = @batchno  
                            group by acsign order by acsign");
        dw.SetDataAdapterParameters("batchno", batchno);
        return dw.GetDataTable();
    }

    //2009-06-23 Amila
    public DataTable GetBatchSummeryData(string batchno, string status)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select acsign, sum(tramt) from batchtmp where batchno = @batchno  and status = @status 
                            group by acsign order by acsign");
        dw.SetDataAdapterParameters("batchno", batchno);
        return dw.GetDataTable();
    }

    public DataTable GetBatchCorrectionData(string batchno, string status)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from batchtmp where batchno = @batchno  and status = @status");
        dw.SetDataAdapterParameters("batchno", batchno);
        dw.SetDataAdapterParameters("status", status);
        return dw.GetDataTable();
    }


    //2009-06-23 Amila
    public DataTable GetTransSummeryDataTemp(string disbrefno, DateTime trdate)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select disbrefno,  rtrim(cast(DAY(trdate) as nvarchar(5)))+ '/' + 
                            (cast(month(trdate) as nvarchar(5))) +  '/' +
                            (cast(year(trdate) as nvarchar(5))) as trdate, 
                            trtype, sum(tramt) from transassigntemp 
                            where disbrefno=@disbrefno and trdate=@trdate
                            group by  disbrefno, trdate, trtype");
        dw.SetDataAdapterParameters("disbrefno", disbrefno);
        dw.SetDataAdapterParameters("trdate", trdate);
        return dw.GetDataTable();
    }


    //2009-06-23 Amila
    public DataTable GetTransSummeryData(string disbrefno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select t.trtype as [Account Sign], sum(t.tramt) [Amount] from
                            (select trtype, tramt 
                            from transassign where trstatus = 'N'
                            and disbrefno = @disbrefno  and cracno!= 903080000000000
                            union ALL
                            select trtype, tramt 
                            from transassigntmp where 
                            disbrefno = @disbrefno 
                            and refno in (select refno from transassign where disbrefno = @disbrefno 
                            and  trstatus = 'P'  and cracno!= 903080000000000) ) as t 
                            group by t.trtype");
        dw.SetDataAdapterParameters("disbrefno", disbrefno);
        return dw.GetDataTable();
    }


    //2009-06-03 vihanga
    public int UpdateBatchTmp(long batchno, string cracno, string status)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update batchtmp set status=@status where batchno=@batchno and cracno=@cracno");
        dw.SetSqlCommandParameters("status", status);
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("batchno", batchno);
        return dw.Update();
    }



    public int UpdateBatchTmp(string batchno, DateTime batchdate, bool IsGLUpdate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update batchtmp set IsGLUpdate=@IsGLUpdate where batchno=@batchno and batchdate=@batchdate");
        dw.SetSqlCommandParameters("batchno", batchno);
        dw.SetSqlCommandParameters("batchdate", batchdate);
        dw.SetSqlCommandParameters("IsGLUpdate", IsGLUpdate);
        return dw.Update();
    }

    //2009-06-23 vihanga New
    public DataTable ViewBatchData(string batchno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter("select * from batchtmp where batchno=@batchno");
        dw.SetDataAdapterParameters("batchno", batchno);
        return dw.GetDataTable();
    }

    public DataTable GetBatchData(string cracno, long batchno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter("select * from batchtmp where cracno=@cracno and batchno=@batchno");
        dw.SetDataAdapterParameters("batchno", batchno);
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }


    public DataTable GetErrorData(string batchno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select disbrefno as batchno, tramt, trtype, Description 
                            from transassign where disbrefno=@batchno and left(cracno,1) = '9'");
        dw.SetDataAdapterParameters("batchno", batchno);
        return dw.GetDataTable();
    }

    public int DeleteTransAssign(string refno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"delete from transassign where refno = @refno");
        dw.SetSqlCommandParameters("refno", refno);
        return dw.Delete();
    }

    public DataTable GetBatchData(string batchno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from transassign where disbrefno=@batchno 
                            and transno is null and tramt !=0");
        dw.SetDataAdapterParameters("batchno", batchno);
        return dw.GetDataTable();
    }


    //public string GetBatchNo(string batchid)
    //{
    //    switch (batchid)
    //    {
    //        case "BAV":

    //            break;

    //        case "CHQ":

    //            break;
    //    }
    //}


    public string GetTransNo(string batchno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select distinct transno from batchtmp where batchno = @batchno");
        dw.SetSqlCommandParameters("batchno", batchno);
        return dw.GetSingleData();
    }

    // Future Work
    //private string BackupDatabase(string userName, string password, string serverName, string databaseName, string backupFileLocation)
    //{
    //    try
    //    {
    //        ServerConnection conn = new ServerConnection(serverName, userName, password);

    //        Microsoft.SqlServer.Server server = new Server(conn);
    //        server.ConnectionContext.Connect();


    //        Backup backup = new Backup();
    //        backup.Action = BackupActionType.Database;
    //        backup.Database = databaseName;
    //        backup.Initialize = true;
    //        backup.Incremental = false;

    //        BackupDeviceItem backupDeviceItem = new BackupDeviceItem(backupFileLocation, DeviceType.File);
    //        backup.Devices.Add(backupDeviceItem);

    //        //BACKUP
    //        backup.SqlBackup(server);
    //        backup.Devices.Remove(backupDeviceItem);

    //        return string.Empty;
    //    }
    //    catch (Exception exception)
    //    {
    //        return exception.Message;
    //    }
    //}

    public object GetTransSummeryDataLGTrans(string batchno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select acsign, sum(tramt) from gltrans where batchno=@batchno 
                            and trstatus != 'C'
                            group by acsign
                            order by acsign");
        dw.SetDataAdapterParameters("batchno", batchno);
        return dw.GetDataTable();
    }

    public DataTable GetHeaderData(DateTime batchdate)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select distinct batchno as batchno from batchtmp where batchdate=@batchdate");
        dw.SetDataAdapterParameters("batchdate", batchdate);
        return dw.GetDataTable();
    }

    private DataTable GetLen13Number(DateTime batchdate)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select refno,cracno from batchtmp where len(cracno)=13 and batchdate =@batchdate");
        dw.SetDataAdapterParameters("batchdate", batchdate);
        return dw.GetDataTable();
    }


    private int correctBatchTmp(string refno, string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update batchtmp set cracno=@cracno where refno=@refno");
        dw.SetSqlCommandParameters("refno", refno);
        dw.SetSqlCommandParameters("cracno", cracno);
        return dw.Update();

    }

    public void Correct13Numbers(DateTime date)
    {
        DataTable dt = new DataTable();
        string refno = "";
        string cracno = "";
        dt = GetLen13Number(date);
        int row = 0;

        for (int a = 0; a < dt.Rows.Count; a++)
        {
            refno = dt.Rows[a]["refno"].ToString();
            cracno = dt.Rows[a]["cracno"].ToString();
            cracno = cracno.Substring(0, 5) + cracno.Substring(6, 7);
            row += correctBatchTmp(refno, cracno);

        }
    }

    /// <summary>
    /// //////////////////////////////////////////////////////////////////////////////////
    /// </summary>
    /// <param name="batchno"></param>
    /// <param name="batchtype"></param>
    /// <param name="status"></param>
    /// <returns></returns>
    public DataTable GetBatchData(string batchno, string batchtype, string status)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select refno, cracno as [Account no],  CONVERT(VARCHAR(10), transdate, 105) as [Off date], acsign, 
                            tramt, trdetail, taskid from batchtmp where batchno=@batchno and status = @status and batchtype=@batchtype
                            order by acsign");
        dw.SetDataAdapterParameters("batchno", batchno);
        dw.SetDataAdapterParameters("status", status);
        dw.SetDataAdapterParameters("batchtype", batchtype);
        return dw.GetDataTable();
    }

    public int InsertBatchTransaction(string BatchNo, DateTime BatchDate, string CrAcNo, DateTime TransDate, string AcSign,
double TrAmt, string TrDetail, string TaskId, string BatchType, string Status, bool IsGLUpdate, string Number,
int BankName, int BranchName)
    {
        int oldtransNo = -99;
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO BatchTmp(BatchNo,BatchDate,CrAcNo,TransDate,AcSign,TrAmt,TrDetail,TaskId,oldtransNo,
                        BatchType,Status,IsGLUpdate,Number,BankName,BranchName)
                        VALUES (@BatchNo,@BatchDate,@CrAcNo,@TransDate,@AcSign,@TrAmt,@TrDetail,@TaskId,@oldtransNo,
                        @BatchType,@Status,@IsGLUpdate,@Number,@BankName,@BranchName)");
        dw.SetSqlCommandParameters("BatchNo", BatchNo);
        dw.SetSqlCommandParameters("BatchDate", BatchDate);
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        dw.SetSqlCommandParameters("TransDate", TransDate);
        dw.SetSqlCommandParameters("AcSign", AcSign);
        dw.SetSqlCommandParameters("TrAmt", TrAmt);
        dw.SetSqlCommandParameters("TrDetail", TrDetail);
        dw.SetSqlCommandParameters("TaskId", TaskId);
        dw.SetSqlCommandParameters("oldtransNo", oldtransNo);
        dw.SetSqlCommandParameters("BatchType", BatchType);
        dw.SetSqlCommandParameters("Status", Status);
        dw.SetSqlCommandParameters("IsGLUpdate", IsGLUpdate);
        dw.SetSqlCommandParameters("Number", Number);
        dw.SetSqlCommandParameters("BankName", BankName);
        dw.SetSqlCommandParameters("BranchName", BranchName);
        return dw.Insert();
    }

    public int InsertBatchTransaction(string BatchNo, DateTime BatchDate, string CrAcNo, DateTime TransDate, string AcSign,
    double TrAmt, string TrDetail, string TaskId, string BatchType, string Status)
    {
        int oldtransNo = -99;
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO BatchTmp(BatchNo,BatchDate,CrAcNo,TransDate,AcSign,TrAmt,TrDetail,TaskId,oldtransNo,
                        BatchType,Status)
                        VALUES (@BatchNo,@BatchDate,@CrAcNo,@TransDate,@AcSign,@TrAmt,@TrDetail,@TaskId,@oldtransNo,
                        @BatchType,@Status)");
        dw.SetSqlCommandParameters("BatchNo", BatchNo);
        dw.SetSqlCommandParameters("BatchDate", BatchDate);
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        dw.SetSqlCommandParameters("TransDate", TransDate);
        dw.SetSqlCommandParameters("AcSign", AcSign);
        dw.SetSqlCommandParameters("TrAmt", TrAmt);
        dw.SetSqlCommandParameters("TrDetail", TrDetail);
        dw.SetSqlCommandParameters("TaskId", TaskId);
        dw.SetSqlCommandParameters("oldtransNo", oldtransNo);
        dw.SetSqlCommandParameters("BatchType", BatchType);
        dw.SetSqlCommandParameters("Status", Status);
        return dw.Insert();
    }

    public string GetReportURL(string reportid)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select ReportUrl from batchreports where reportid = @reportid");
        dw.SetSqlCommandParameters("reportid", reportid);
        return dw.GetSingleData();
    }

    //2009-06-03 vihanga
    //public DataTable GetBatchDataToEdit(string disbrefno, string trstatus)
    //{
    //    dw = new DataWorksClass(constring);
    //    dw.SetDataAdapter(@"select refno,assignamt,cracno,description from transassign where disbrefno=@disbrefno and trstatus=@trstatus");
    //    dw.SetDataAdapterParameters("disbrefno", disbrefno);
    //    dw.SetDataAdapterParameters("trstatus", trstatus);
    //    return dw.GetDataTable();
    //}

    public int UpdateRecord(string refno, string status)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update batchtmp set status=@status where refno = @refno");
        dw.SetSqlCommandParameters("refno", refno);
        dw.SetSqlCommandParameters("status", status);
        return dw.Update();
    }

    public DataTable GetBatchSummery(string batchno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select acsign, sum(tramt) as tramt from batchtmp where batchno = @batchno
                            group by acsign");
        dw.SetDataAdapterParameters("batchno", batchno);
        return dw.GetDataTable();
    }

    public DataTable GetReports(string batchtype)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select ReportName, ReportUrl, ReportId from batchreports where batchtype = @batchtype");
        dw.SetDataAdapterParameters("batchtype", batchtype);
        return dw.GetDataTable();
    }

    public int UpdateHeaderRecord(string batchno, string batchtype, string status, string newstatus)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update batchheader set status=@newstatus where batchno = @batchno and batchtype=@batchtype and status=@status");
        dw.SetSqlCommandParameters("batchno", batchno);
        dw.SetSqlCommandParameters("batchtype", batchtype);
        dw.SetSqlCommandParameters("status", status);
        dw.SetSqlCommandParameters("newstatus", newstatus);
        return dw.Update();
    }

    //public int UpdateRecord(string refno, string status)
    //{
    //    dw = new DataWorksClass(constring);
    //    dw.SetCommand(@"update batchtmp set status=@status where refno = @refno");
    //    dw.SetSqlCommandParameters("refno", refno);
    //    dw.SetSqlCommandParameters("status", status);
    //    return dw.Update();
    //}


    public int UpdateRecord(string batchno, string batchtype, string status, string newstatus)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update batchtmp set status=@newstatus where batchno = @batchno and batchtype=@batchtype and status=@status");
        dw.SetSqlCommandParameters("batchno", batchno);
        dw.SetSqlCommandParameters("batchtype", batchtype);
        dw.SetSqlCommandParameters("status", status);
        dw.SetSqlCommandParameters("newstatus", newstatus);
        return dw.Update();
    }

//    public DataTable GetBatchData(string batchno, string batchtype, string status)
//    {
//        dw = new DataWorksClass(constring);
//        dw.SetDataAdapter(@"select refno, cracno as [Account no],  CONVERT(VARCHAR(10), transdate, 105) as [Off date], acsign, 
//                            tramt, trdetail, taskid from batchtmp where batchno=@batchno and status = @status and batchtype=@batchtype
//                            order by acsign");
//        dw.SetDataAdapterParameters("batchno", batchno);
//        dw.SetDataAdapterParameters("status", status);
//        dw.SetDataAdapterParameters("batchtype", batchtype);
//        return dw.GetDataTable();
//    }

    public DataTable GetBatchData(string batchno, string status)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select refno, cracno as [Account no],  CONVERT(VARCHAR(10), transdate, 105) as [Off date], acsign, 
                            tramt, trdetail, taskid from batchtmp where batchno=@batchno and status = @status
                            order by acsign");
        dw.SetDataAdapterParameters("batchno", batchno);
        dw.SetDataAdapterParameters("status", status);
        return dw.GetDataTable();
    }

    public DataTable GetBatchHeaderData(DateTime batchdate, string status)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from batchheader where batchdate = @batchdate and
                            status=@status");
        dw.SetDataAdapterParameters("batchdate", batchdate);
        dw.SetDataAdapterParameters("status", status);
        return dw.GetDataTable();
    }

    public DataTable getvauturedata(string trdate)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select cracno,AcSign,TrAmt,GlDesc,Transno,RefNo From batchtmp b,glcode G where batchdate =@batchdate
                                    and batchtype='RVS' and Number not like 'SLIP%' and G.refglcode=b.cracno 
                                    and len(cracno)= 15
                                    UNION
                                    select cracno,AcSign,TrAmt,TrDetail,Transno,RefNo From batchtmp  where batchdate =@batchdate
                                    and batchtype='RVS' and Number not like 'SLIP%' 
                                    and len(cracno) != 15 and TrDetail not like 'InetTrans%'
                                    UNION
                                    select Cracno,AcSign,Amount as TrAmt, G.GlDesc as Name,Transno,SerialNo from CashierTransaction c,glcode G where 
                                    SysDate=@batchdate and G.refglcode=c.cracno 
                                    and len(cracno)= 15
                                    UNION
                                    select Cracno,AcSign,Amount as TrAmt, other as Name,Transno,SerialNo from CashierTransaction  where 
                                    SysDate=@batchdate
                                    and len(cracno) != 15
                                    order by acsign desc,cracno");
        dw.SetDataAdapterParameters("batchdate", trdate);
        return dw.GetDataTable();
    }

    public DataTable Getcasher(string trdate1)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * From CashierTransaction where SysDate=@batchdate
                                        and left(batchno,1)=9 and batchno not in (
                                        select batchno From Gltrans where TrDate=@batchdate and left(batchno,1) =9)");
        dw.SetDataAdapterParameters("batchdate", trdate1);
        return dw.GetDataTable();
    }
}
