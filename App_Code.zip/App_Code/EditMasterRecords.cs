﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data;
using System.Data.SqlClient;

/// <summary>
/// Summary description for EditMasterRecords
/// </summary>
public class EditMasterRecords
{
    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();
    DataTable dt;
    DataWorksClass dw;
    FunctionClass fc;
    DateTime ldatedue, nextdue;

    public DateTime DateDue
    {
        get
        {
            return this.ldatedue;
        }
    }

    public DateTime NextDue
    {
        get
        {
            return this.nextdue;
        }
    }

	public EditMasterRecords()
	{
		//
		// TODO: Add constructor logic here
		//
	}


    public DataTable GetMasterData(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select distinct c.aprovdamt,c.grantamt,c.acstatus,c.appno,c.cracno,h.intrate,h.instalment,h.outbal,c.closedate,
                            c.duenotice,c.noticedate,c.catpurposeid,c.isdisburse,h.actoutbal,h.datedue,h.lastcompletedduedate,c.grantdate,
                            h.graceperiod,h.lsttrdate,h.lstpaiddate,h.lstreptdate,h.recptperiod,h.yearbeginbal,h.adduser,h.adddate,
                            h.lastcompletedduedate,h.isdisbursed,h.crperiod,h.loanstatuscode,h.paidinstalments,h.penalvaliddate,h.recstatus,
                            h.disbrefno,h.crcat from crmast c, housprop h where c.cracno=h.cracno and c.cracno=@cracno");
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }


    public int InsertHouspropHistry(DateTime TrDate, string cracno, DateTime ChangeDate, double IntRate, double Instalment, double OutBal, DateTime DateDue,
                                        int GracePeriod, DateTime LstTrDate, DateTime LstPaiddate, DateTime LstReptdate, int RecptPeriod,
                                        double YearBeginbal, string adduser, DateTime Adddate, DateTime LastCompletedDueDate, string IsDisbursed,
                                        int CrPeriod, int LoanStatusCode, int PaidInstalments, double ActOutBal, DateTime penalvaliddate,
                                        string recstatus, string ChangeUser,
                                        double NewInstalment, double NewIntRate, DateTime NewLastCompletedDueDate, int NewCrPeriod,
                                        double NewOutBal, int CrCat, int NewCrCat, string PrevCracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into HouspropHistry(TrDate, cracno,ChangeDate,IntRate,Instalment,OutBal,DateDue,GracePeriod,LstTrDate,LstPaiddate,
                         LstReptdate,RecptPeriod,YearBeginbal,AddUser,Adddate,LastCompletedDueDate,IsDisbursed,
                          CrPeriod,LoanStatusCode,PaidInstalments,ActOutBal,penalvaliddate,recstatus,ChangeUser,
                          NewInstalment, NewIntRate, NewLastCompletedDueDate, NewCrPeriod,NewOutBal, CrCat, NewCrCat,PrevCracno) 
                        values (@TrDate,@cracno,@ChangeDate,@IntRate,@Instalment,@OutBal,@DateDue,@GracePeriod,@LstTrDate,@LstPaiddate,
                         @LstReptdate,@RecptPeriod,@YearBeginbal,@AddUser,@Adddate,@LastCompletedDueDate,@IsDisbursed,
                          @CrPeriod,@LoanStatusCode,@PaidInstalments,@ActOutBal,@penalvaliddate,@recstatus,@ChangeUser,
                          @NewInstalment,@NewIntRate,@NewLastCompletedDueDate,@NewCrPeriod,@NewOutBal,@CrCat,@NewCrCat,@PrevCracno)");
        dw.SetSqlCommandParameters("TrDate", TrDate);
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("ChangeDate", ChangeDate);
        dw.SetSqlCommandParameters("IntRate", IntRate);
        dw.SetSqlCommandParameters("Instalment", Instalment);
        dw.SetSqlCommandParameters("OutBal", OutBal);
        dw.SetSqlCommandParameters("DateDue", DateDue);
        dw.SetSqlCommandParameters("GracePeriod", GracePeriod);
        dw.SetSqlCommandParameters("LstTrDate", LstTrDate);
        dw.SetSqlCommandParameters("LstPaiddate", LstPaiddate);
        dw.SetSqlCommandParameters("LstReptdate", LstReptdate);
        dw.SetSqlCommandParameters("RecptPeriod", RecptPeriod);
        dw.SetSqlCommandParameters("YearBeginbal", YearBeginbal);
        dw.SetSqlCommandParameters("AddUser", adduser);
        dw.SetSqlCommandParameters("Adddate", Adddate);
        dw.SetSqlCommandParameters("LastCompletedDueDate", LastCompletedDueDate);
        dw.SetSqlCommandParameters("IsDisbursed", IsDisbursed);
        dw.SetSqlCommandParameters("CrPeriod", CrPeriod);
        dw.SetSqlCommandParameters("LoanStatusCode", LoanStatusCode);
        dw.SetSqlCommandParameters("PaidInstalments", PaidInstalments);
        dw.SetSqlCommandParameters("ActOutBal", ActOutBal);
        dw.SetSqlCommandParameters("penalvaliddate", penalvaliddate);
        dw.SetSqlCommandParameters("recstatus", recstatus);
        dw.SetSqlCommandParameters("ChangeUser", ChangeUser);
        dw.SetSqlCommandParameters("NewInstalment", NewInstalment);
        dw.SetSqlCommandParameters("NewIntRate", NewIntRate);
        dw.SetSqlCommandParameters("NewLastCompletedDueDate", NewLastCompletedDueDate);
        dw.SetSqlCommandParameters("NewCrPeriod", NewCrPeriod);
        dw.SetSqlCommandParameters("NewOutBal", NewOutBal);
        dw.SetSqlCommandParameters("CrCat", CrCat);
        dw.SetSqlCommandParameters("NewCrCat", NewCrCat);
        dw.SetSqlCommandParameters("PrevCracno", PrevCracno);
        return dw.Insert();
    }

    public int InsertDatatocrmastHistory(string cracno, string Changedate, string Intrate, string Appno, string AcStatus, string CrPeriod,
                                         string Aprovdamt, string GrantAmt, string GrantDate, string instalment, string CloseDate,
                                         string DueNotice, string Noticedate, string CatPurposeId, string IsDisburse, string ChangeUser)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into CrMastHistry(cracno,Changedate,Intrate,Appno,AcStatus,CrPeriod,Aprovdamt,GrantAmt,
                         GrantDate,instalment,CloseDate,DueNotice,Noticedate,CatPurposeId,IsDisburse,ChangeUser) 
                        values (@cracno,@Changedate,@Intrate,@Appno,@AcStatus,@CrPeriod,@Aprovdamt,@GrantAmt,
                         @GrantDate,@instalment,@CloseDate,@DueNotice,@Noticedate,@CatPurposeId,@IsDisburse,@ChangeUser)");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("Changedate", Changedate);
        dw.SetSqlCommandParameters("Intrate", Intrate);
        dw.SetSqlCommandParameters("Appno", Appno);
        dw.SetSqlCommandParameters("AcStatus", AcStatus);
        dw.SetSqlCommandParameters("CrPeriod", CrPeriod);
        dw.SetSqlCommandParameters("Aprovdamt", Aprovdamt);
        dw.SetSqlCommandParameters("GrantAmt", GrantAmt);
        dw.SetSqlCommandParameters("GrantDate", GrantDate);
        dw.SetSqlCommandParameters("instalment", instalment);
        dw.SetSqlCommandParameters("CloseDate", CloseDate);
        dw.SetSqlCommandParameters("DueNotice", DueNotice);
        dw.SetSqlCommandParameters("Noticedate", Noticedate);
        dw.SetSqlCommandParameters("CatPurposeId", CatPurposeId);
        dw.SetSqlCommandParameters("IsDisburse", IsDisburse);
        dw.SetSqlCommandParameters("ChangeUser", ChangeUser);
        return dw.Insert();
    }


   public int UpdateMasterDataInHousprop(string cracno, double intrate, double Instalment, double outbal,
                        DateTime DateDue, DateTime LastCompletedDueDate, int CrPeriod, double ActOutBal, DateTime penalvaliddate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update housprop set cracno=@cracno ,intrate=@intrate,Instalment=@Instalment,
                        outbal=@outbal,DateDue=@DateDue ,LastCompletedDueDate=@LastCompletedDueDate,
                        CrPeriod=@CrPeriod,ActOutBal=@ActOutBal,penalvaliddate=@penalvaliddate where cracno=@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("intrate", intrate);
        dw.SetSqlCommandParameters("Instalment", Instalment);
        dw.SetSqlCommandParameters("outbal", outbal);
        dw.SetSqlCommandParameters("DateDue", DateDue);
        dw.SetSqlCommandParameters("LastCompletedDueDate", LastCompletedDueDate);
        dw.SetSqlCommandParameters("CrPeriod", CrPeriod);
        dw.SetSqlCommandParameters("ActOutBal", ActOutBal);
        dw.SetSqlCommandParameters("penalvaliddate", penalvaliddate);
        return dw.Update();
    }

    public int UpdateMasterDataInCrMast(DateTime GrantDate,string cracno, double intrate, double Instalment, double outbal, double GrantAmt,
                        DateTime DateDue, DateTime LastCompletedDueDate, int CrPeriod, double ActOutBal)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update crmast set GrantDate=@GrantDate,intrate=@intrate,
                        GrantAmt=@GrantAmt ,GrantDate=@GrantDate,
                        CrPeriod=@CrPeriod where cracno=@cracno");
        dw.SetSqlCommandParameters("GrantDate", GrantDate);
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("intrate", intrate);
        dw.SetSqlCommandParameters("Instalment", Instalment);
        dw.SetSqlCommandParameters("GrantAmt", GrantAmt);
        dw.SetSqlCommandParameters("outbal", outbal);
        dw.SetSqlCommandParameters("DateDue", DateDue);
        dw.SetSqlCommandParameters("LastCompletedDueDate", LastCompletedDueDate);
        dw.SetSqlCommandParameters("CrPeriod", CrPeriod);
        dw.SetSqlCommandParameters("ActOutBal", ActOutBal);
        return dw.Update();
    }
    

    public DataTable GetCancellRecord(string cracno, string transno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select refno,transno, cracno, tramt,assignamt,taskid,datedue, intrate, crcat from transassign 
                                where cracno=@cracno and transno >= @transno and trtype ='I' 
                                order by  datedue desc,taskid ");
        dw.SetDataAdapterParameters("cracno", cracno);
        dw.SetDataAdapterParameters("transno", transno);
        return dw.GetDataTable();
    }

    public DataTable GetCancellTrans(string cracno, string transno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select distinct transno from transassign 
                                where cracno=@cracno and transno > @transno and trtype ='I' 
                                order by transno");
        dw.SetDataAdapterParameters("cracno", cracno);
        dw.SetDataAdapterParameters("transno", transno);
        return dw.GetDataTable();
    }

    private DataTable SetDataTable(DataTable dt)
    {
        dt = new DataTable();

        DataColumn refno;
        refno = new DataColumn();
        refno.DataType = Type.GetType("System.String");
        refno.ColumnName = "refno";
        dt.Columns.Add(refno);

        DataColumn cracno;
        cracno = new DataColumn();
        cracno.DataType = Type.GetType("System.String");
        cracno.ColumnName = "cracno";
        dt.Columns.Add(cracno);

        DataColumn TrStatus;
        TrStatus = new DataColumn();
        TrStatus.DataType = Type.GetType("System.String");
        TrStatus.ColumnName = "trstatus";
        dt.Columns.Add(TrStatus);


        DataColumn datedue;
        datedue = new DataColumn();
        datedue.DataType = Type.GetType("System.String");
        datedue.ColumnName = "datedue";
        dt.Columns.Add(datedue);


        DataColumn assignamt;
        assignamt = new DataColumn();
        assignamt.DataType = Type.GetType("System.String");
        assignamt.ColumnName = "assignamt";
        dt.Columns.Add(assignamt);

        DataColumn tramt;
        tramt = new DataColumn();
        tramt.DataType = Type.GetType("System.String");
        tramt.ColumnName = "tramt";
        dt.Columns.Add(tramt);

        DataColumn dcTaskId;
        dcTaskId = new DataColumn();
        dcTaskId.DataType = Type.GetType("System.String");
        dcTaskId.ColumnName = "TaskId";
        dt.Columns.Add(dcTaskId);

        DataColumn outbal;
        outbal = new DataColumn();
        outbal.DataType = Type.GetType("System.String");
        outbal.ColumnName = "outbal";
        dt.Columns.Add(outbal);
        return dt;
    }


    private DataTable SetDataTable1(DataTable dt)
    {
        dt = new DataTable();
        DataColumn cracno;
        cracno = new DataColumn();
        cracno.DataType = Type.GetType("System.String");
        cracno.ColumnName = "cracno";
        dt.Columns.Add(cracno);

        DataColumn TrStatus;
        TrStatus = new DataColumn();
        TrStatus.DataType = Type.GetType("System.String");
        TrStatus.ColumnName = "trstatus";
        dt.Columns.Add(TrStatus);


        DataColumn datedue;
        datedue = new DataColumn();
        datedue.DataType = Type.GetType("System.String");
        datedue.ColumnName = "datedue";
        dt.Columns.Add(datedue);


        DataColumn assignamt;
        assignamt = new DataColumn();
        assignamt.DataType = Type.GetType("System.String");
        assignamt.ColumnName = "assignamt";
        dt.Columns.Add(assignamt);

        DataColumn tramt;
        tramt = new DataColumn();
        tramt.DataType = Type.GetType("System.String");
        tramt.ColumnName = "tramt";
        dt.Columns.Add(tramt);

        DataColumn dcTaskId;
        dcTaskId = new DataColumn();
        dcTaskId.DataType = Type.GetType("System.String");
        dcTaskId.ColumnName = "TaskId";
        dt.Columns.Add(dcTaskId);

        return dt;
    }




  private DataTable InsertRow(string refno, string cracno, double assignamt, double tramt, string datedue,
  string trstatus, string taskid, DataTable dt)
    {
        DataRow dr;
        dr = dt.NewRow();
        dr["refno"] = refno;
        dr["cracno"] = cracno;
        dr["assignamt"] = assignamt;
        dr["tramt"] = tramt;
        dr["datedue"] = datedue;
        dr["trstatus"] = trstatus;
        dr["taskid"] = taskid;
        dt.Rows.Add(dr);
        return dt;
    }


  public DataTable SetShortfall(DataTable dt, double tramt)
  {
      DataTable shortfall = new DataTable();
      shortfall = SetDataTable(shortfall);
      
      for (int i = 0; dt.Rows.Count > i; i++)
      {
          string cracno = dt.Rows[i]["cracno"].ToString();
          string transno = dt.Rows[i]["transno"].ToString();
          double tmpAmt = double.Parse(dt.Rows[i]["tramt"].ToString());
          string refno = dt.Rows[i]["refno"].ToString();
          double tmptramt = GetTmpTrAmt(cracno, transno, refno);
          DateTime datedue = DateTime.Parse(dt.Rows[i]["datedue"].ToString());
          if (tramt >= tmpAmt)
          {
              tramt -= tmpAmt;
              ldatedue = datedue;
              nextdue = ldatedue;
          }
          else
          {
              tramt -= tmptramt;
              string taskid = dt.Rows[i]["taskid"].ToString();

              shortfall = InsertRow("0", cracno, tmptramt, tmptramt, datedue.ToString(), "N", taskid, shortfall);
              try
              {
                  DateTime tmpdatedue = DateTime.Parse(dt.Rows[i - 1]["datedue"].ToString());
                  if (datedue == tmpdatedue)
                  {
                      shortfall = InsertRow("0", cracno, tmptramt, tmptramt, datedue.ToString(), "N", taskid, shortfall);
                      cracno = dt.Rows[i - 1]["cracno"].ToString();
                      transno = dt.Rows[i - 1]["transno"].ToString();
                      tmpAmt = double.Parse(dt.Rows[i - 1]["tramt"].ToString());
                      refno = dt.Rows[i - 1]["refno"].ToString();
                      tmptramt = GetTmpTrAmt(cracno, transno, refno);
                      datedue = DateTime.Parse(dt.Rows[i - 1]["datedue"].ToString());
                      shortfall = InsertRow("0", cracno, tmptramt, tmptramt, datedue.ToString(), "N", taskid, shortfall);
                  }
              }
              catch
              {
                  //
              }


              try
              {
                  DateTime tmpdatedue = DateTime.Parse(dt.Rows[i - 2]["datedue"].ToString());
                  if (datedue == tmpdatedue)
                  {
                      shortfall = InsertRow("0", cracno, tmptramt, tmptramt, datedue.ToString(), "N", taskid, shortfall);
                      cracno = dt.Rows[i - 1]["cracno"].ToString();
                      transno = dt.Rows[i - 1]["transno"].ToString();
                      tmpAmt = double.Parse(dt.Rows[i - 1]["tramt"].ToString());
                      refno = dt.Rows[i - 1]["refno"].ToString();
                      tmptramt = GetTmpTrAmt(cracno, transno, refno);
                      datedue = DateTime.Parse(dt.Rows[i - 1]["datedue"].ToString());

                  }
              }
              catch
              {
                  //
              }
              ldatedue = datedue;
              nextdue = ldatedue.AddMonths(1);
          }
      }

      return shortfall;
  }
    private double GetTmpTrAmt(string cracno, string transno, string transassignrefno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select tramt from gltrans
                        where transno = @transno and cracno=@cracno
                        and refglcode != 903081000000994 and acsign = 'CR' 
                        and transassignrefno=@transassignrefno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("transno", transno);
        dw.SetSqlCommandParameters("transassignrefno", transassignrefno);
        return double.Parse(dw.GetSingleData());
    }

    public double GetTrAmt(string cracno, string transno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select sum(tramt) as tramt from gltrans 
                        where transno >= @transno and cracno=@cracno
                        and refglcode != 903081000000994 and acsign = 'CR'");
        dw.SetSqlCommandParameters("transno", transno);
        dw.SetSqlCommandParameters("cracno", cracno);
        return double.Parse(dw.GetSingleData());
    }

    public double UpdateDatedue(string cracno, DateTime datedue, DateTime lastcompletedduedate, DateTime penalvaliddate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update housprop set datedue=@datedue, lastcompletedduedate=@lastcompletedduedate, penalvaliddate=@penalvaliddate
                        where cracno=@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("datedue", datedue);
        dw.SetSqlCommandParameters("penalvaliddate", penalvaliddate);
        dw.SetSqlCommandParameters("lastcompletedduedate", lastcompletedduedate);
        return dw.Update();
    }


    public double UpdateReversal(string cracno, string trstatus, string transno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update Transassign set trstatus=@trstatus 
                        where cracno=@cracno and trstatus != 'C' 
                        and transno >= @transno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("trstatus", trstatus);
        dw.SetSqlCommandParameters("transno", transno);
        return dw.Update();
    }


    public double UpdateReversal(string refno, string trstatus)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update Transassign set trstatus=@trstatus 
                        where refno=@refno and trstatus != 'C'");
        dw.SetSqlCommandParameters("refno", refno);
        dw.SetSqlCommandParameters("trstatus", trstatus);
        return dw.Update();
    }

    public DataTable GetShorfall(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select refno, (assignamt - tramt) as shortfall, taskid, datedue from transassign 
                                where cracno=@cracno and tramt!= assignamt and trtype ='I' and
                                trstatus != 'C' and system is null   
                                order by datedue");
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }


    public void clearShortFall(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update transassign set trstatus = 'C'
                                where cracno=@cracno and tramt!= assignamt and trtype ='I'");

        dw.SetDataAdapterParameters("cracno", cracno);
        dw.Update();
    }

    public DataTable GetCrcatIntRate(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select intrate, crcat from crmast
                                where cracno=@cracno");
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }

    public void insertLogEntry(string Refno, string Cracno, double Amount, string TaskID, DateTime AddTime, string UserID)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO SFLogEntry
                            (Refno ,UserID ,AddTime ,TaskID ,Amount ,Cracno)
                         VALUES ()");
        dw.SetSqlCommandParameters("Refno", Refno);
        dw.SetSqlCommandParameters("UserID", UserID);
        dw.SetSqlCommandParameters("AddTime", AddTime);
        dw.SetSqlCommandParameters("TaskID", TaskID);
        dw.SetSqlCommandParameters("Amount", Amount);
        dw.SetSqlCommandParameters("Cracno", Cracno);
        dw.Insert();
    }
    public DataTable GetEditRecord(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select refno,transno, cracno, assignamt,tramt,taskid,datedue, intrate, crcat from transassign 
                            where cracno=@cracno and trtype ='I' and tramt != assignamt and trstatus !='C' and 
                            (System is null or system != 'M') order by  datedue desc,taskid");
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }

    public double GetTrAmtSF(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select sum(g.tramt) as tramt from gltrans g, transassign t
                        where g.cracno=@cracno and t.trstatus !='F' and 
						g.refglcode != 903081000000994 and g.acsign = 'CR' and 
						t.assignamt != t.tramt and 
						t.refno=g.transassignrefno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return double.Parse(dw.GetSingleData());   
    }
    public DataTable SetShortfall1(DataTable dt)
    {
        DataTable shortfall = new DataTable();
        shortfall = SetDataTable1(shortfall);
        for (int i = 0; shortfall.Rows.Count > i; i++)
        {
            string cracno = dt.Rows[i]["cracno"].ToString();
            double tmpAmt = double.Parse(dt.Rows[i]["tramt"].ToString());
            string refno = dt.Rows[i]["refno"].ToString();
            //double tmptramt = GetTmpTrAmt(cracno, transno, refno);
            DateTime datedue = DateTime.Parse(dt.Rows[i]["datedue"].ToString());
            //if (tramt >= tmpAmt)
            //{
            //    tramt -= tmpAmt;
            //    ldatedue = datedue;
            //    nextdue = ldatedue;
            //}
            //else
            //{
                //tramt -= tmptramt;
                string taskid = dt.Rows[i]["taskid"].ToString();

                shortfall = InsertRow("0", cracno, tmpAmt, tmpAmt, datedue.ToString(), "N", taskid, shortfall);
                try
                {
                    DateTime tmpdatedue = DateTime.Parse(dt.Rows[i - 1]["datedue"].ToString());
                    if (datedue == tmpdatedue)
                    {
                        shortfall = InsertRow("0", cracno, tmpAmt, tmpAmt, datedue.ToString(), "N", taskid, shortfall);
                        cracno = dt.Rows[i - 1]["cracno"].ToString();
                        tmpAmt = double.Parse(dt.Rows[i - 1]["tramt"].ToString());
                        refno = dt.Rows[i - 1]["refno"].ToString();
                        //tmpAmt = GetTmpTrAmt(cracno, transno, refno);
                        datedue = DateTime.Parse(dt.Rows[i - 1]["datedue"].ToString());
                        shortfall = InsertRow("0", cracno, tmpAmt, tmpAmt, datedue.ToString(), "N", taskid, shortfall);
                    }
                }
                catch
                {
                    //
                }


                try
                {
                    DateTime tmpdatedue = DateTime.Parse(dt.Rows[i - 2]["datedue"].ToString());
                    if (datedue == tmpdatedue)
                    {
                        shortfall = InsertRow("0", cracno, tmpAmt, tmpAmt, datedue.ToString(), "N", taskid, shortfall);
                        cracno = dt.Rows[i - 1]["cracno"].ToString();
                        tmpAmt = double.Parse(dt.Rows[i - 1]["tramt"].ToString());
                        refno = dt.Rows[i - 1]["refno"].ToString();
                       // tmptramt = GetTmpTrAmt(cracno, transno, refno);
                        datedue = DateTime.Parse(dt.Rows[i - 1]["datedue"].ToString());

                    }
                }
                catch
                {
                    //
                }
                ldatedue = datedue;
                nextdue = ldatedue.AddMonths(1);
            
        }

        return shortfall;
    }

    public void updatecancelSF(string cracno,string refno, double tramt)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update transassign set TrStatus = 'C', AssignAmt=@TrAmt
                                where cracno=@cracno and refno=@refno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("refno", refno);
        dw.SetSqlCommandParameters("tramt", tramt);
        dw.Update();
    }

    public void updatedatedueforSF(string cracno, DateTime LastCompletedduedate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update housprop set datedue = @LastCompletedduedate where cracno=@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("LastCompletedduedate", LastCompletedduedate);
        dw.Update();
    }

    public DateTime GetDueDateforSF(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select LastCompletedDueDate from housprop where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return DateTime.Parse(dw.GetSingleData());
    }

    public DataTable GetReciptDate(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select cracno,crperiod, crcat , recptperiod from housprop where cracno=@cracno");
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }


    public void UpdateReciptPeriod(string cracno,string recptperiod)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update housprop set recptperiod = @recptperiod where cracno=@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("recptperiod", recptperiod);
        dw.Update();
    }
}
