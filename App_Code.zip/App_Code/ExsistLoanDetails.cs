﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for ExsistLoanDetails
/// </summary>
public class ExsistLoanDetails
{
    private string constring = ConfigurationManager.ConnectionStrings["housdbString"].ToString();
    private string crmastconnection = ConfigurationManager.ConnectionStrings["crmastString"].ToString();
    DataWorksClass dw;

    public ExsistLoanDetails()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public int InsertDataToCrApp(string appno)
    {
        dw = new DataWorksClass(crmastconnection);
        dw.SetCommand(@"INSERT INTO TDB.CreditAdmin.CrApp (AppNo, RecvDate, CrAmt, Status, BoqAmount, RedemPurchaseAmt,ApprovedAmt
                        ,IsApproved, ApprovDate, ClientType, IsDisbTr, AppCat, SecurityType)
                        SELECT AppNo, RecvDate, CrAmt, Status, BoqAmount, RedemPurchaseAmt,ApprovedAmt
                        ,IsApproved, ApprovDate, ClientType, IsDisbTr, AppCat, SecurityType FROM CrApp WHERE (AppNo = @AppNo)");
        dw.SetSqlCommandParameters("appno", appno);
        return dw.Insert();
    }

    public int InsertDataToAppHolder(string appno)
    {
        DataTable dt = new DataTable();
        dt = GetExistAppHolder(appno, "S");
        if (dt.Rows.Count > 0)
        {
            dw = new DataWorksClass(crmastconnection);
            dw.SetCommand(@"INSERT INTO TDB.CreditAdmin.AppHolder (AppNo, HolderType, NicNo, HoldRelation,IsAdditional)
                        SELECT AppNo, HolderType, C.NicNo, HoldRelation,IsAdditional FROM AppHolder A, CustomerMain C
                        WHERE A.AppNo=@appno AND A.CustNo=C.CustNo AND A.HolderType='P'");
            dw.SetSqlCommandParameters("appno", appno);
            return dw.Insert();
        }
        else
        {
            dw = new DataWorksClass(crmastconnection);
            dw.SetCommand(@"INSERT INTO TDB.CreditAdmin.AppHolder (AppNo, HolderType, NicNo, HoldRelation,IsAdditional)
                        SELECT AppNo, HolderType, C.NicNo, HoldRelation,IsAdditional FROM AppHolder A, CustomerMain C
                        WHERE A.AppNo=@appno AND A.CustNo=C.CustNo");
            dw.SetSqlCommandParameters("appno", appno);
            return dw.Insert();
        }
        
       
    }


    //private string CheckSecondaryHolder(string appno)
    //{
    //    dw = new DataWorksClass(constring);
    //    dw.SetCommand(@"SELECT HolderType FROM AppHolder WHERE  ");
    //}

    public int InsertDataToCrHolder(string cracno,string appno)
    {
        
        DataTable dt = new DataTable();
        dt = GetExistCrHolder(appno, "S");
        if (dt.Rows.Count > 0)
        {
            dw = new DataWorksClass(crmastconnection);
            dw.SetCommand(@"INSERT INTO TDB.CreditAdmin.CrHolder SELECT CrAcNo,A.AppNo,HolderType,HolderCount,M.NicNo,M.CustNo,
                        HoldRelation,IsAdditional FROM CrMast C, AppHolder A, CustomerMain M WHERE A.AppNo=C.AppNo AND A.CustNo=M.CustNo
                        AND C.CracNo=@cracno AND A.HolderType='P'");
            dw.SetSqlCommandParameters("cracno", cracno);
            return dw.Insert();
        }
        else
        {
            dw = new DataWorksClass(crmastconnection);
            dw.SetCommand(@"INSERT INTO TDB.CreditAdmin.CrHolder SELECT CrAcNo,A.AppNo,HolderType,HolderCount,M.NicNo,M.CustNo,
                        HoldRelation,IsAdditional FROM CrMast C, AppHolder A, CustomerMain M WHERE A.AppNo=C.AppNo AND A.CustNo=M.CustNo
                        AND C.CracNo=@cracno");
            dw.SetSqlCommandParameters("cracno", cracno);
            return dw.Insert();
        }
        
        
    }

    public DataTable GetCategoryDetails(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select catpurposeid,crcat,grantamt,intrate from crmast where cracno=@cracno");
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }

    public int InsertDataToAppcategory(string appno, double intrate, int crpurposeid, double amount, int crcat)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into Appcategory  values (null,@appno,@intrate,@crpurposeid,@amount,@crcat,-100)");
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("intrate", intrate);
        dw.SetSqlCommandParameters("crpurposeid", crpurposeid);
        dw.SetSqlCommandParameters("amount", amount);
        dw.SetSqlCommandParameters("crcat", crcat);
        return dw.Insert();
    }

    public DataTable GetExistLoanDetails(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"SELECT DISTINCT CM.CrAcNo, AprovdAmt, GrantDate,cm.IntRate, CM.Instalment AS Instalment,
                            OutBal,CASE R.HolderType WHEN 'P' THEN 'Primary Holder' ELSE 'Secondary Holder'
                            END AS HolderType FROM AppHolder A, HousProp H, CrHolder R, CrMast CM
                            WHERE A.NicNo=R.NicNo AND CM.CrAcNo=R.CrAcNo AND CM.CrAcNo=H.CrAcNo AND
                            R.HolderType='P' AND A.AppNo=@appno");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();
    }

    public string Getappno(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select appno from crmast where cracno=@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return dw.GetSingleData();
    }

    public int InsertPrimaryHolderDataHolder(string cracno, string appno, string nicno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into CrHolder values(@cracno,@appno,'P',NULL,@nicno,NULL,'Primary Holder',NULL)");
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("nicno", nicno);
        return dw.Insert();
    }

    //vihanga 2009-09-20
    public DataTable GetLoanNumbers(int recptperiod)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select distinct cracno from housprop where actoutbal <> 0 and recptperiod=@recptperiod");
        dw.SetDataAdapterParameters("recptperiod", recptperiod);
        return dw.GetDataTable();
    }

    //vihanga 2009-09-20
    public DataTable GetAddressChangeDetails(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select m.location,m.street,m.city,m.homeno,m.mobile,h.recptperiod,m.nicno ,
                            rtrim(rtrim(m.initials)+' ' + rtrim(surname)) as custname from customermain m,housprop h,crholder c
                            where h.cracno=c.cracno and m.nicno=c.nicno and c.cracno=@cracno");
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }

    //vihanga 2009-09-20
    public int InsertAddressChange(string location, string street, string city, string homeno, string mobile, int recptperiod, string changeuser
                                  , DateTime changeDate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into AddressChange values(@location, @street, @city, @homeno, @mobile, @recptperiod,@changeuser,@changeDate)");
        dw.SetSqlCommandParameters("location", location);
        dw.SetSqlCommandParameters("street", street);
        dw.SetSqlCommandParameters("city", city);
        dw.SetSqlCommandParameters("homeno", homeno);
        dw.SetSqlCommandParameters("mobile", mobile);
        dw.SetSqlCommandParameters("recptperiod", recptperiod);
        dw.SetSqlCommandParameters("changeuser", changeuser);
        dw.SetSqlCommandParameters("changeDate", changeDate);
        return dw.Insert();
    }

    //vihanga 2009-09-20
    public int UpdateRecptperiod(string cracno, int recptperiod)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update housprop set recptperiod=@recptperiod where cracno=@cracno");
        dw.SetSqlCommandParameters("recptperiod", recptperiod);
        dw.SetSqlCommandParameters("cracno", cracno);
        return dw.Update();
    }

    //vihanga 2009-09-20
    public int UpdateCustomermainAddress(string location, string street, string city, string homeno, string mobile, string nicno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update customermain set location=@location, street=@street, city=@city, homeno=@homeno, mobile=@mobile 
                          where nicno=@nicno");
        dw.SetSqlCommandParameters("location", location);
        dw.SetSqlCommandParameters("street", street);
        dw.SetSqlCommandParameters("city", city);
        dw.SetSqlCommandParameters("homeno", homeno);
        dw.SetSqlCommandParameters("mobile", mobile);
        dw.SetSqlCommandParameters("nicno", nicno);
        return dw.Update();
    }

    public string GetExistAppno(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select * from crapp where appno = @appno");
        dw.SetSqlCommandParameters("appno", appno);
        return dw.GetSingleData();
    }

    public DataTable GetExistAppHolder(string appno, string holdertype)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select appno,nicno from appholder where appno = @appno and holdertype=@holdertype");
        dw.SetDataAdapterParameters("appno", appno);
        dw.SetDataAdapterParameters("holdertype", holdertype);
        return dw.GetDataTable();
    }

    public DataTable GetExistCrHolder(string appno, string holdertype)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from crholder where appno = @appno and holdertype=@holdertype");
        dw.SetDataAdapterParameters("appno", appno);
        dw.SetDataAdapterParameters("holdertype", holdertype);
        return dw.GetDataTable();
    }

    public DataTable GetOldAppHolder(string appno)
    {
        dw = new DataWorksClass(crmastconnection);
        dw.SetDataAdapter(@"select appno,nicno from appholder where appno = @appno and holdertype='P'");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();
    }

    public DataTable GetOldCrHolder(string appno)
    {
        dw = new DataWorksClass(crmastconnection);
        dw.SetDataAdapter(@"select * from crholder where appno = @appno and holdertype='P'");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();
    }

    public string GetExistCustomerMain(string nicno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select * from CustomerMain where nicno = @nicno");
        dw.SetSqlCommandParameters("nicno", nicno);
        return dw.GetSingleData();
    }
    public DataTable GetNICFrom515(string appno)
    {
        dw = new DataWorksClass(crmastconnection);
        dw.SetDataAdapter(@"select c.nicno,a.custno,a.holdertype from appholder a,CustomerMain c 
                            where appno=@appno and a.custno=c.custno and a.holdertype='P'");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();
    }

    public int InsertCustomerMain(string nicno, string custno)
    {

        dw = new DataWorksClass(crmastconnection);
        dw.SetCommand(@"INSERT INTO TDB.creditadmin.Customermain( 
                                    CustNo,NicNo,TitleCode,Surname,Initials
                                    ,Othername,Location,Street,City,HomeNo,DoBirth)
                                select
                                    CustNo,NicNo,TitleCode,Surname,Initials
                                    ,Othername,Location,Street,City,TeleNo,DoBirth
                                from customermain where nicno = @nicno and custno=@custno");
        dw.SetSqlCommandParameters("nicno", nicno);
        dw.SetSqlCommandParameters("custno", custno);
        return dw.Insert();
    }

    public int InsertCustomerSub(string nicno, string custno)
    {

        dw = new DataWorksClass(crmastconnection);
        dw.SetCommand(@"INSERT INTO TDB.CreditAdmin.Customersub
                                   (CustNo,NicNo,EpfNo,Profesion,TotIncome
                                   ,TotExpen,othincome,spnicno,SpTitleCode
                                   ,SpInitials,SpSurName,SpOthName,SpDob
                                   ,SpProf,SpIncome)
                            SELECT 
                                   cs.CustNo,cm.nicno,cs.EpfNo,cs.Profesion,cs.TotIncom
                                  ,cs.TotExpen,cs.OthIncome,cs.SpNic,cs.SpTitleCode
                                  ,cs.SpInitials,cs.SpSurName,cs.SpOthName,cs.SpDob
                                  ,cs.SpProf,cs.SpIncome
                            FROM CustomerSub cs, customermain cm where cm.nicno = @nicno and cm.custno = cs.custno
                            and cs.custno=@custno");
        dw.SetSqlCommandParameters("nicno", nicno);
        dw.SetSqlCommandParameters("custno", custno);
        return dw.Insert();
    }

    public int UpdateCrHolderNIC(string appno, string nicno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update crholder set nicno = @nicno where appno = @appno and holdertype='P'");
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("nicno", nicno);
        return dw.Update();
    }

    public int UpdateAppHolderNIC(string appno, string nicno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update appholder set nicno = @nicno where appno = @appno and holdertype='P'");
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("nicno", nicno);
        return dw.Update();
    }


    public string GetCustNo(string appno)
    {
        DataTable dt = new DataTable();
        dw = new DataWorksClass(crmastconnection);
        dw.SetDataAdapter(@"select * from appholder where appno = @appno and holdertype = 'P'");
        dw.SetDataAdapterParameters("appno", appno);
        dt =  dw.GetDataTable();
        string custno;
        try
        {
            custno = dt.Rows[0]["custno"].ToString().ToString();
        }
        catch
        {
            custno = "";
        }
        return custno;
    }

    public int InsertCustomerMainDataCorrectNIC(string nicno, string custno)
    {

        dw = new DataWorksClass(crmastconnection);
        dw.SetCommand(@"INSERT INTO TDB.creditadmin.Customermain( 
                                    CustNo,NicNo,TitleCode,Surname,Initials
                                    ,Othername,Location,Street,City,HomeNo,DoBirth)
                                select
                                    @custno as CustNo,@nicno as NicNo,TitleCode,Surname,Initials
                                    ,Othername,Location,Street,City,TeleNo,DoBirth
                                from customermain where custno = @custno");
        dw.SetSqlCommandParameters("nicno", nicno);
        dw.SetSqlCommandParameters("custno", custno);
        return dw.Insert();
    }

    public int InsertCustomerSubDataCorrectNIC(string nicno, string custno)
    {

        dw = new DataWorksClass(crmastconnection);
        dw.SetCommand(@"INSERT INTO TDB.CreditAdmin.Customersub
                                   (CustNo,NicNo,EpfNo,Profesion,TotIncome
                                   ,TotExpen,othincome,spnicno,SpTitleCode
                                   ,SpInitials,SpSurName,SpOthName,SpDob
                                   ,SpProf,SpIncome)
                            SELECT 
                                   @custno as CustNo,@nicno as NicNo,cs.EpfNo,cs.Profesion,cs.TotIncom
                                  ,cs.TotExpen,cs.OthIncome,cs.SpNic,cs.SpTitleCode
                                  ,cs.SpInitials,cs.SpSurName,cs.SpOthName,cs.SpDob
                                  ,cs.SpProf,cs.SpIncome
                            FROM CustomerSub cs, customermain cm 
                            where cm.nicno = @nicno and cm.custno = cs.custno and cm.custno=@custno");
        dw.SetSqlCommandParameters("nicno", nicno);
        dw.SetSqlCommandParameters("custno", custno);
        return dw.Insert();
    }

    public int WithoutNicDataToAppH(string appno, string nicno)
    {
        dw = new DataWorksClass(crmastconnection);
        dw.SetCommand(@"INSERT INTO TDB.CreditAdmin.AppHolder 
                        (AppNo, HolderType, NicNo, HoldRelation,IsAdditional)
                        SELECT AppNo, HolderType, @nicno as NicNo, HoldRelation,IsAdditional 
                        FROM AppHolder A, CustomerMain C
                        WHERE A.AppNo=@appno AND A.CustNo=C.CustNo");
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("nicno", nicno);
        return dw.Insert();
    }

    public int WithoutNicDataToCrHolder(string cracno, string nicno)
    {
        dw = new DataWorksClass(crmastconnection);
        dw.SetCommand(@"INSERT INTO TDB.CreditAdmin.CrHolder 
                        SELECT CrAcNo,A.AppNo,HolderType,HolderCount,@nicno as NicNo,M.CustNo,
                        HoldRelation,IsAdditional FROM CrMast C, AppHolder A, CustomerMain M 
                        WHERE A.AppNo=C.AppNo AND A.CustNo=M.CustNo
                        AND C.CracNo=@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("nicno", nicno);
        return dw.Insert();
    }


    public DataTable getprintedloans(string fromcracno, string tocracno, DateTime fdate, DateTime tdate)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select h.cracno,r.NicNo from HousProp h, crmast c, Gltrans g, CrHolder r,Customermain cm where 
                                    h.ActOutBal > 0.00 and h.CrAcNo=r.CrAcNo and r.HolderType='P'
                                    and h.CrCat in(1,4,5,10,13,18,19,21) and c.GrantAmt = c.Aprovdamt and c.CrAcNo=h.CrAcNo
                                    and h.RecptPeriod=3 and c.CrAcNo=g.CrAcNo and h.CrAcNo=g.CrAcNo
                                    and g.TrDate >= @fdate and g.TrDate <= @tdate 
                                    and r.NicNo > @fromcracno and r.NicNo < @tocracno
				    and cm.NicNo=r.NicNo and cm.Email not like '%@%'
                                    group by h.cracno,r.NicNo
                                    order by r.NicNo");
        dw.SetDataAdapterParameters("fromcracno", fromcracno);
        dw.SetDataAdapterParameters("tocracno", tocracno);
        dw.SetDataAdapterParameters("fdate", fdate);
        dw.SetDataAdapterParameters("tdate", tdate);
        return dw.GetDataTable();

    }

}
