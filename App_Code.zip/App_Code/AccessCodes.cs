using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// Summary description for AccessCodes
/// </summary>
public class AccessCodes
{
    SqlConnection myconnection = new SqlConnection(ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString);
    //DataSet ds = new DataSet();
    DataWorksClass dw;
    RegistryEditor re;
    DataTable dt, prgnames;
    LastSerialClass lc;
    FunctionClass fc;
    DayStartClass ds;
    Encryption enc;

    public string BrancCode
    {
        get
        {
            return dt.Rows[0]["brcode"].ToString();
        }
    }



    public string Password
    {
        get
        {
            return dt.Rows[0]["paswd"].ToString();
        }
    }
   
    public string BrancName
    {
        get
        {
            return dt.Rows[0]["branchname"].ToString();
        }
    }

    public string UserId
    {
        get
        {
            return dt.Rows[0]["userid"].ToString();
        }
    }

    public string UserName
    {
        get
        {
            return dt.Rows[0]["UserName"].ToString();
        }
    }



    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();

    public DataTable GetProgramNames(string userid, string password, bool isinlist, string ProgramLevel)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"SELECT P.PrgId AS PrgId, PrgDescription, PrgName, UserName,BrCode,BranchName, 
                     CategoryId,ProgramLevel
                     FROM PrgAccess P, 
                     ProgramNames N,Users U, Nsb_Branch B 
                     WHERE U.UserId = @UserId AND paswd=@paswd AND 
                     U.UserId = P.UserId AND P.PrgId=N.PrgId AND U.BrCode=B.BranchNo AND U.Status='A' AND
                     N.IsinList = @IsinList AND U.Status='A' and ProgramLevel=@ProgramLevel and N.PrgStatus='A'
                    ORDER BY RecordsOrder");
        dw.SetDataAdapterParameters("IsinList", isinlist);
        dw.SetDataAdapterParameters("UserId", userid);
        dw.SetDataAdapterParameters("paswd", password);
        dw.SetDataAdapterParameters("ProgramLevel", ProgramLevel);
        return dw.GetDataTable();
    }



    public DataTable CheckUser(string userid, string paswd,string usermode)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"SELECT u.brcode, u.paswd, u.username, u.userid,u.usermode,
                            b.branchname from users u, nsb_branch b 
                            where u.brcode = b.BranchNo and u.userid=@userid 
                            and u.paswd=@paswd and u.usermode=@usermode");
        dw.SetDataAdapterParameters("userid", userid);
        dw.SetDataAdapterParameters("paswd", paswd);
        dw.SetDataAdapterParameters("usermode", usermode);
        return dw.GetDataTable();
    }


    public DataTable CheckUser(string userid, string paswd)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"SELECT u.brcode, u.paswd, u.username, u.userid,u.usermode,
                            b.branchname from users u, nsb_branch b 
                            where u.brcode = b.BranchNo and u.userid=@userid 
                            and u.paswd=@paswd");
        dw.SetDataAdapterParameters("userid", userid);
        dw.SetDataAdapterParameters("paswd", paswd);
        return dw.GetDataTable();
    }
   
    //public string GetUserMode1(string OperationDate, int BranchCode)
    //{
    //    dw = new DataWorksClass(constring);
    //    dw.SetCommand(@"select UserMode from OperationCalendarBranch where OperationDate=@OperationDate and BranchCode=@BranchCode");
    //    dw.SetSqlCommandParameters("OperationDate", OperationDate);
    //    dw.SetSqlCommandParameters("BranchCode", BranchCode);
    //    return dw.GetSingleData();
    //}

    public string GetUserMode(string username, string password)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select UserMode from users where userid=@userid and paswd=@paswd");
        dw.SetSqlCommandParameters("userid", username);
        dw.SetSqlCommandParameters("paswd", password);
        return dw.GetSingleData();
    }


    public DataTable GetBranchDetails(string userid, string paswd)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"SELECT userid,u.brcode AS brcode,branchname from users u, nsb_branch n 
                        where userid=@userid and paswd=@paswd and u.brcode=n.brcode");
        dw.SetSqlCommandParameters("userid", userid);
        dw.SetSqlCommandParameters("paswd", paswd);
        return dw.GetDataTable();
    }

    public DataSet GetRedirectURL(string prgid)
    {
        string sql = "SELECT * FROM ProgramNames WHERE PrgId='" + prgid + "'";
        

        SqlDataAdapter da = new SqlDataAdapter(sql, myconnection);
        DataSet ds = new DataSet();
        try
        {
            myconnection.Open();
            da.Fill(ds, sql);
        }
        catch (Exception er)
        {

        }
        finally
        {
            da.Dispose();
            myconnection.Close();
        }

        return ds;
    }

    public DataSet LoadAllPrgNames(bool isinlist)
    {
        string sql = @"SELECT * FROM ProgramNames WHERE IsinList=@IsinList ORDER BY PrgDescription";
        
        SqlDataAdapter da = new SqlDataAdapter(sql, myconnection);

        da.SelectCommand.Parameters.AddWithValue("IsinList", isinlist);

        DataSet ds = new DataSet();
        try
        {
            myconnection.Open();
            da.Fill(ds, sql);
        }
        catch (Exception er)
        {

        }
        finally
        {
            da.Dispose();
            myconnection.Close();
        }

        return ds;
    }

    public DataSet ShowAllPrograms()
    {
        string sql = " SELECT * FROM ProgramNames WHERE PrgDescription IS NOT NULL ORDER BY RecordsOrder";
        

        SqlDataAdapter da = new SqlDataAdapter(sql, myconnection);
        DataSet ds = new DataSet();
        try
        {
            myconnection.Open();
            da.Fill(ds, sql);
        }
        catch (Exception er)
        {

        }
        finally
        {
            da.Dispose();
            myconnection.Close();
        }

        return ds;
    }

    public DataSet GetExistUserName(string userid)
    {
        string sql = "SELECT * FROM Users WHERE UserId='" + userid + "'";
        
        SqlDataAdapter da = new SqlDataAdapter(sql, myconnection);
        DataSet ds = new DataSet();
        try
        {
            myconnection.Open();
            da.Fill(ds, sql);
        }
        catch (Exception er)
        {

        }
        finally
        {
            da.Dispose();
            myconnection.Close();
        }

        return ds;
    }


    public int InsertUserDetails(string userid, string status, string passwd, int epfno, string username, string desig, string usermode,
                                 bool isadmin, string brcode, int updatelevel, string addUser, DateTime addDate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO Users (UserId,Status,PasWd,EpfNo,UserName,Designation,UserMode,IsAdmin,BrCode,UpdateLevel,addUser,addDate)
                        VALUES(@userid,@status,@passwd,@epfno,@username,@desig,@usermode,@isadmin,@brcode,@updatelevel,@addUser,@addDate)");
        dw.SetSqlCommandParameters("userid", userid);
        dw.SetSqlCommandParameters("status", status);
        dw.SetSqlCommandParameters("passwd", passwd);
        dw.SetSqlCommandParameters("epfno", epfno);
        dw.SetSqlCommandParameters("username", username);
        dw.SetSqlCommandParameters("usermode", usermode);
        dw.SetSqlCommandParameters("desig", desig);
        dw.SetSqlCommandParameters("isadmin", isadmin);
        dw.SetSqlCommandParameters("brcode", brcode);
        dw.SetSqlCommandParameters("updatelevel", updatelevel);
        dw.SetSqlCommandParameters("addUser", addUser);
        dw.SetSqlCommandParameters("addDate", addDate);
        return dw.Insert();
    }

//    public int InsertUserDetails(string userid, string status, string passwd, int epfno, string username,
//                                     string desig, string usermode, bool isadmin, string brcode, int updatelevel)
//    {
//        dw = new DataWorksClass(constring);
//        dw.SetCommand(@"INSERT INTO Users (UserId,Status,PasWd,EpfNo,UserName,Designation,UserMode,
//                        IsAdmin,BrCode,UpdateLevel)
//                        VALUES(@userid,@status,@passwd,@epfno,@username,@desig,@usermode,@isadmin,@brcode,@updatelevel)");
//        dw.SetSqlCommandParameters("userid", userid);
//        dw.SetSqlCommandParameters("status", status);
//        dw.SetSqlCommandParameters("passwd", passwd);
//        dw.SetSqlCommandParameters("epfno", epfno);
//        dw.SetSqlCommandParameters("username", username);
//        dw.SetSqlCommandParameters("usermode", usermode);
//        dw.SetSqlCommandParameters("desig", desig);
//        dw.SetSqlCommandParameters("isadmin", isadmin);
//        dw.SetSqlCommandParameters("brcode", brcode);
//        dw.SetSqlCommandParameters("updatelevel", updatelevel);
//        return dw.Insert();
//    }


    public DataSet InsertPrgAccessDet(string userid, int prgid, int ulevel)
    {
        string sql = "INSERT INTO PrgAccess (UserId,PrgId,UpdateLevel) VALUES ('"+userid+"', "+prgid+","+ulevel+")";
        SqlDataAdapter da = new SqlDataAdapter(sql, myconnection);
        DataSet ds = new DataSet();
        try
        {
            myconnection.Open();
            da.Fill(ds, sql);
        }
        catch (Exception er)
        {

        }
        finally
        {
            da.Dispose();
            myconnection.Close();
        }

        return ds;
    }

    public DataSet LoadUserDet()
    {
        string sql = "SELECT * FROM Users WHERE Status='A'";
        SqlDataAdapter da = new SqlDataAdapter(sql, myconnection);
        DataSet ds = new DataSet();
        try
        {
            myconnection.Open();
            da.Fill(ds, sql);
        }
        catch (Exception er)
        {

        }
        finally
        {
            da.Dispose();
            myconnection.Close();
        }

        return ds;
    }

    public DataSet GetExistPrgId(string userid, int prgid)
    {
        string sql = " SELECT PrgId FROM prgAccess WHERE PrgId IN "+ 
                     " (SELECT PrgId FROM ProgramNames) AND UserId = '"+userid+"' "+
                     " AND PrgId = "+prgid+" ";
        SqlDataAdapter da = new SqlDataAdapter(sql, myconnection);
        DataSet ds = new DataSet();
        try
        {
            myconnection.Open();
            da.Fill(ds, sql);
        }
        catch (Exception er)
        {

        }
        finally
        {
            da.Dispose();
            myconnection.Close();
        }

        return ds;
    }

    public DataSet DeleteUsersPrgId(string userid, int prgid)
    {
        string sql = "DELETE FROM PrgAccess WHERE UserId='"+userid+"' AND PrgId="+prgid+"";
        SqlDataAdapter da = new SqlDataAdapter(sql, myconnection);
        DataSet ds = new DataSet();
        try
        {
            myconnection.Open();
            da.Fill(ds, sql);
        }
        catch (Exception er)
        {

        }
        finally
        {
            da.Dispose();
            myconnection.Close();
        }

        return ds;
    }

    public DataSet GetSubProgramIds(int prgId)
    {
        string sql = "SELECT * FROM ProgramNames WHERE SubId = "+prgId+" ";
        SqlDataAdapter da = new SqlDataAdapter(sql, myconnection);
        DataSet ds = new DataSet();
        try
        {
            myconnection.Open();
            da.Fill(ds, sql);
        }
        catch (Exception er)
        {

        }
        finally
        {
            da.Dispose();
            myconnection.Close();
        }

        return ds;
    }

    public DataSet ShowSubPrgIds(string username)
    {
        string sql = " SELECT P.PrgId AS PrgId,PrgDescription, P.CategoryId AS CategoryId "+
                     " FROM ProgramNames P, PrgAccess A WHERE A.PrgId=P.SubId AND UserId='"+username+"'";
        SqlDataAdapter da = new SqlDataAdapter(sql, myconnection);
        DataSet ds = new DataSet();
        try
        {
            myconnection.Open();
            da.Fill(ds, sql);
        }
        catch (Exception er)
        {

        }
        finally
        {
            da.Dispose();
            myconnection.Close();
        }

        return ds;
    }



    #region Validation

    public bool CheckDisbAuthority(string UserId, double disbamount)
    {
        bool status;
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select MaxDisbAmount from users where UserId=@UserId");
        dw.SetSqlCommandParameters("UserId", UserId);
        double approvalamt = double.Parse(dw.GetSingleData());
        if (approvalamt >= disbamount)
        {
            status = true;
        }
        else
        {
            status = false;
        }
        return status;

    }

    private string GetBranchCode(string userid, string ip, string brcode)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select distinct BrCode from users u, nsb_branch b where userid =@userid
                        and b.lowerIp<= @ip and b.upperip >= @ip");
        dw.SetSqlCommandParameters("userid", userid);
        dw.SetSqlCommandParameters("ip", ip);
        string tablebrcode = dw.GetSingleData();
        if (brcode != tablebrcode)
        {
            brcode = "0";
        }
        return brcode;

    }

    public string GetBranchCode(string userid)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select BrCode from users where userid =@userid");
        dw.SetSqlCommandParameters("userid", userid);
        return dw.GetSingleData();
    }

    //public bool GetAdminStatus(string userid)
    //{
    //    dw = new DataWorksClass(constring);
    //    dw.SetCommand(@"select IsAdmin from users where userid =@userid");
    //    dw.SetSqlCommandParameters("userid", userid);
    //    return bool.Parse(dw.GetSingleData());
    //}




    private string SetIP(string ip)
    {
        string[] val = new string[4];
        string output = "";
        val = ip.Split('.');
        for (int i = 0; val.Length>i; i++)
        {
            output += val[i].PadLeft(3, '0');
        }
        return output;
    }

    public bool GetAccess(string refno, string user, string ip)
    {

        ip = SetIP(ip);
        re = new RegistryEditor();
        if (re.RegKey == null)
        {
            return false;
        }
        else
        {
            string brcode = re.ReadMyTestRegKey();
            if (GetBranchCode(user, ip, brcode) != "0")
            {
                switch (refno.Length)
                {
                    case 11:
                        refno = refno.PadLeft(12, '0');
                        break;

                    case 12:
                        refno = refno;
                        break;

                    case 13:
                        if (refno.Substring(0, 1) == "6")
                        {
                            refno = refno.Substring(1);
                        }
                        else
                        {
                            refno = "0000";
                        }
                        break;
                    case 15:
                        if (refno.Substring(0, 1) == "9")
                        {
                            refno = refno.Substring(1);
                        }
                        else
                        {
                            refno = "0000";
                        }
                        break;
                    default:
                        refno = "0000";
                        break;
                }
                if (refno.Substring(0, 4) == brcode)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }

        }

    }


    ////////public string GetLogin(string user, string password, string ip)
    ////////{
    ////////    lc = new LastSerialClass();
    ////////    string usermode = "X";
    ////////    dt = new DataTable();
    ////////    re = new RegistryEditor();
    ////////    fc = new FunctionClass();
    ////////    if (re.RegKey == null)
    ////////    {
    ////////        usermode = "R";
    ////////    }
    ////////    else
    ////////    {
    ////////        user = "0000" + user;
    ////////        dt = CheckUser(user, password, usermode);
    ////////        if (dt.Rows.Count == 0)
    ////////        {
    ////////            string brcode = re.ReadMyTestRegKey();
    ////////            user = user.Substring(4);
    ////////            user = brcode + user;
    ////////            dt = CheckUser(user, password);
    ////////            if (dt.Rows.Count != 0)
    ////////            {
    ////////                ip = SetIP(ip);
    ////////                usermode = dt.Rows[0]["usermode"].ToString();
    ////////                long userstatus = lc.GetMaxNumber("UserMode", true);
    ////////                switch (userstatus)
    ////////                {
    ////////                    case 0:
    ////////                        usermode = "T"; // Transaction Initiated wait for 5 sec
    ////////                        break;

    ////////                    case 1:

    ////////                        //string OperationDate = fc.GetSystemDateKey("N");
    ////////                        //int BranchCode = Convert.ToInt32(dt.Rows[0]["brcode"].ToString());
    ////////                        usermode = GetUserMode(user, password);

    ////////                        if (usermode == "S")
    ////////                        {
    ////////                            if (GetBranchCode(user, ip, brcode) != "0")
    ////////                            {
    ////////                                usermode = dt.Rows[0]["usermode"].ToString();
    ////////                            }
    ////////                            else
    ////////                            {
    ////////                                usermode = "C";
    ////////                            }
    ////////                            break;
    ////////                        }
    ////////                        else
    ////////                        {
    ////////                            usermode = "Z"; // Not Authorised
    ////////                        }
    ////////                        break;

    ////////                    case 2:


    ////////                        if (usermode == "M")
    ////////                        {
    ////////                            if (GetBranchCode(user, ip, brcode) != "0")
    ////////                            {
    ////////                                usermode = dt.Rows[0]["usermode"].ToString();
    ////////                            }
    ////////                            else
    ////////                            {
    ////////                                usermode = "C"; // Not Authorised
    ////////                            }

    ////////                        }
    ////////                        else
    ////////                        {
    ////////                            if (usermode == "A")
    ////////                            {
    ////////                                if (GetBranchCode(user, ip, brcode) != "0")
    ////////                                {
    ////////                                    usermode = dt.Rows[0]["usermode"].ToString();
    ////////                                }
    ////////                                else
    ////////                                {
    ////////                                    usermode = "C"; // Not Authorised
    ////////                                }
    ////////                            }
    ////////                            else
    ////////                            {
    ////////                                usermode = "Z"; // Not Authorised
    ////////                            }
    ////////                        }

    ////////                    break;
                        
    ////////                }
                   
    ////////            }
    ////////            else
    ////////            {
    ////////                usermode = "N";
    ////////            }
    ////////        }
    ////////        else
    ////////        {
    ////////            usermode = "X";
    ////////        }
    ////////        lc.UpdateLastSerialStatus("UserMode", true);
    ////////    }
    ////////   //if((usermode=="X") || (usermode=="M") || (usermode =="A") || (usermode=="S"))
    ////////   // {
    ////////   //     prgnames = new DataTable();
    ////////   //     prgnames = GetProgramNames(user,password,true,
    ////////   // }  
        
        
    ////////    return usermode;
    

    ////////    }


    //vihanga 2009-11-29
    public string GetLogin(string user, string password, string ip)
    {
        lc = new LastSerialClass();
        string usermode = "X";
        dt = new DataTable();
        re = new RegistryEditor();
        fc = new FunctionClass();
        ds = new DayStartClass();
        enc = new Encryption();

        DataTable adminStatus = new DataTable();
        if (re.RegKey != null)
        {
            usermode = "R";
        }
        else
        {
            user = "0000" + user;

            //check Encrypted Password
            password = enc.encryptPassword(password);

            dt = CheckUser(user, password, usermode);
            if (dt.Rows.Count == 0)
            {
                string brcode = re.ReadMyTestRegKey();
                user = user.Substring(4);
                user = brcode + user;
                dt = CheckUser(user, password);
                if (dt.Rows.Count != 0)
                {
                    ip = SetIP(ip);
                    usermode = dt.Rows[0]["usermode"].ToString();
                    //long userstatus = lc.GetMaxNumber("UserMode", true);

                    //vihanga 2009-11-09 begin check Super user

                    if (usermode == "S")
                    {
                        if (GetBranchCode(user, ip, brcode) != "0")
                        {
                            usermode = dt.Rows[0]["usermode"].ToString();
                        }
                        else
                        {
                            usermode = "C";
                        }
                    }

                    else
                    {
                        adminStatus = ds.GetBrancAdminConfirmation(brcode);

                        int userstatus = int.Parse(adminStatus.Rows[0]["serialno"].ToString());

                        switch (userstatus)
                        {
                            case 1:
                                if (usermode == "A")
                                {
                                    if (GetBranchCode(user, ip, brcode) != "0")
                                    {
                                        usermode = dt.Rows[0]["usermode"].ToString();
                                    }
                                    else
                                    {
                                        usermode = "C"; // Not Authorised
                                    }
                                }
                                else
                                {
                                    usermode = "Z"; // Not Authorised
                                }
                                break;

                            case 2:
                                if (usermode == "U")
                                {
                                    if (GetBranchCode(user, ip, brcode) != "0")
                                    {
                                        usermode = dt.Rows[0]["usermode"].ToString();
                                    }
                                    else
                                    {
                                        usermode = "C"; // Not Authorised
                                    }
                                }
                                else if (usermode == "A")
                                {
                                    if (GetBranchCode(user, ip, brcode) != "0")
                                    {
                                        usermode = dt.Rows[0]["usermode"].ToString();
                                    }
                                    else
                                    {
                                        usermode = "C"; // Not Authorised
                                    }
                                }
                                else
                                {
                                    usermode = "Z"; // Not Authorised
                                }
                                break;


                        }
                        //vihanga 2009-11-09 End
                        //check Admin

                        //switch (userstatus)
                        //{
                        //    case 0:
                        //        usermode = "T"; // Transaction Initiated wait for 5 sec
                        //        break;

                        //    case 1:

                        //        //string OperationDate = fc.GetSystemDateKey("N");
                        //        //int BranchCode = Convert.ToInt32(dt.Rows[0]["brcode"].ToString());
                        //        usermode = GetUserMode(user, password);

                        //        if (usermode == "S")
                        //        {
                        //            if (GetBranchCode(user, ip, brcode) != "0")
                        //            {
                        //                usermode = dt.Rows[0]["usermode"].ToString();
                        //            }
                        //            else
                        //            {
                        //                usermode = "C";
                        //            }
                        //            break;
                        //        }
                        //        else
                        //        {
                        //            usermode = "Z"; // Not Authorised
                        //        }
                        //        break;

                        //    case 2:


                        //        if (usermode == "M")
                        //        {
                        //            if (GetBranchCode(user, ip, brcode) != "0")
                        //            {
                        //                usermode = dt.Rows[0]["usermode"].ToString();
                        //            }
                        //            else
                        //            {
                        //                usermode = "C"; // Not Authorised
                        //            }

                        //        }
                        //        else
                        //        {
                        //            if (usermode == "A")
                        //            {
                        //                if (GetBranchCode(user, ip, brcode) != "0")
                        //                {
                        //                    usermode = dt.Rows[0]["usermode"].ToString();
                        //                }
                        //                else
                        //                {
                        //                    usermode = "C"; // Not Authorised
                        //                }
                        //            }
                        //            else
                        //            {
                        //                usermode = "Z"; // Not Authorised
                        //            }
                        //        }

                        //        break;

                        //}
                    }

                }
                else
                {
                    usermode = "N";
                }
            }
            else
            {
                usermode = "X";
            }
            lc.UpdateLastSerialStatus("UserMode", true);
        }
        //if((usermode=="X") || (usermode=="M") || (usermode =="A") || (usermode=="S"))
        // {
        //     prgnames = new DataTable();
        //     prgnames = GetProgramNames(user,password,true,
        // }  


        return usermode;


    }

    public string GetSecurityType(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select SecurityType from CrApp where appno =@appno");
        dw.SetSqlCommandParameters("appno", appno);
        return dw.GetSingleData();
    }


    public string GetEpfNo(string epfno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select RIGHT(EPFNo,5) from epfdetails where RIGHT(epfno,5)=@epfno");
        dw.SetSqlCommandParameters("epfno", epfno);
        return dw.GetSingleData();
    }

    public DataTable GetEPFDetails(string epfno)
    {

        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select RIGHT(EPFNo,5) as EpfNo,RTRIM(Initials)+' '+RTRIM(Surname) as FullName 
                            from epfdetails where RIGHT(epfno,5)=@epfno");
        dw.SetDataAdapterParameters("epfno", epfno);
        return dw.GetDataTable();
    }
   

    #endregion 

#region userValidation
    public bool IsExpire(string userid)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select count(*) from users where userid=@userid and getdate()>dateadd(day,60,adddate)");
        dw.SetSqlCommandParameters("userid", userid);
        int count = int.Parse(dw.GetSingleData());

        if (count > 0)
            return true;
        else
            return false;
    }

    public bool validatePassword(string NewPassword)
    {
        bool returnValue = false;
        int numericC = 0, letterC = 0;
        int length = NewPassword.Length;
        char[] charArray = NewPassword.ToCharArray();

        for (int a = 0; a < length; a++)
        {
            char xx = charArray[a];

            if (char.IsNumber(xx))
                numericC++;
            else if (char.IsLetter(xx))
                letterC++;

        }

        if ((numericC >= 2) && (letterC >= 4) && (length > 7))
            returnValue = true;
        else
            returnValue = false;

        return returnValue;
    }
    #endregion

    public int ResetPassword(string userid, string paswd)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update users set paswd=@paswd where userid=@userid");
        dw.SetSqlCommandParameters("userid", userid);
        dw.SetSqlCommandParameters("paswd", paswd);
        return dw.Update();
    }

    public int Updatestatus(string username, string status)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update users set status=@status where userid=@username");
        dw.SetSqlCommandParameters("username", username);
        dw.SetSqlCommandParameters("status", status);
        return dw.Update();
    }

}
