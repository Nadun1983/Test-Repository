﻿
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// Summary description for ExtTransactions
/// </summary>
public class ExtTransactions
{
    public ExtTransactions()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    DataWorksClass dw;
    RegistryEditor re;
    DataTable dt, prgnames;
    LastSerialClass lc;
    FunctionClass fc;
    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();
    string oldconstring = ConfigurationManager.ConnectionStrings["oldhousdbString"].ConnectionString.ToString();

    public DataTable GetTransAssign(DateTime adddate, string system)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"SELECT * FROM transassign where adddate=@adddate and system=@system");
        dw.SetDataAdapterParameters("adddate", adddate);
        dw.SetDataAdapterParameters("system", system);
        return dw.GetDataTable();
    }


    public int UpdateIsReady(DateTime adddate, string system, bool IsReady)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update TransAssign set IsReady=@IsReady where adddate=@adddate and system=@system");
        dw.SetSqlCommandParameters("adddate", adddate);
        dw.SetSqlCommandParameters("system", system);
        dw.SetSqlCommandParameters("IsReady", IsReady);
        return dw.Update();
    }

    //public long GetMaxRef(DateTime adddate, string system)
    //{
    //    dw = new DataWorksClass(constring);
    //    dw.SetCommand(@"select max(disbrefno) from TransAssign where adddate=@adddate and system=@system");
    //    dw.SetSqlCommandParameters("adddate", adddate);
    //    dw.SetSqlCommandParameters("system", system);
    //    return long.Parse(dw.GetSingleData());
    //}

    public DataTable GetDisbRefNo(DateTime adddate, string system)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select distinct disbrefno from TransAssign where adddate=@adddate and system=@system");
        dw.SetDataAdapterParameters("adddate", adddate);
        dw.SetDataAdapterParameters("system", system);
        return dw.GetDataTable();
    }

    //public long GetMinRef(DateTime adddate, string system)
    //{
    //    dw = new DataWorksClass(constring);
    //    dw.SetCommand(@"select min(disbrefno) from TransAssign where adddate=@adddate and system=@system");
    //    dw.SetSqlCommandParameters("adddate", adddate);
    //    dw.SetSqlCommandParameters("system", system);
    //    return long.Parse(dw.GetSingleData());
    //}



    public DataTable GetTransAssign(long disbref)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"SELECT * transassign where disbrefno=@disbref");
        dw.SetDataAdapterParameters("disbref", disbref);
        return dw.GetDataTable();
    }



//    public DataTable GetRecvTrans(DateTime date)
//    {
//        dw = new DataWorksClass(oldconstring);
//        dw.SetDataAdapter(@"select c.crcat, sum(r.transamt) as AssignAmt,sum(r.transamt) as TrAmt, r.transdate as adddate,
//                            i.intrate as intrate, t.TaskId,'I' AS TrType,'O' as System
//                            from recvtrans r, TransCat t, CrMast C,CreditScheme S, InterestCode I 
//                            where t.trcode=r.trcode and r.cracno=c.cracno and C.SchemNo=S.SchemNo
//                            and S.Intcode=I.IntCode and transdate=@date
//                            group by c.crcat, r.transdate,i.intrate,t.taskid");
//        dw.SetDataAdapterParameters("date", date);
//        return dw.GetDataTable();
//    }



    public DataTable GetRecvTrans(DateTime date)
    {
        dw = new DataWorksClass(oldconstring);
        dw.SetDataAdapter(@"select c.crcat, r.transamt as AssignAmt, r.transamt as TrAmt, r.transdate as adddate,
                            i.intrate as intrate, t.TaskId,'I' AS TrType,'O' as System, r.cracno, r.transno
                            from recvtrans r, TransCat t, CrMast C,CreditScheme S, InterestCode I 
                            where t.trcode=r.trcode and r.cracno=c.cracno and C.SchemNo=S.SchemNo
                            and S.Intcode=I.IntCode and transdate=@date");
        dw.SetDataAdapterParameters("date", date);
        return dw.GetDataTable();
    }

    public DataTable GetDisbTrans(DateTime date)
    {
        dw = new DataWorksClass(oldconstring);
        dw.SetDataAdapter(@"select r.cracno, r.tramt as AssignAmt, r.tramt as TrAmt, r.trdate as adddate,
                            t.TaskId,'I' AS TrType,'O' as System, r.cracno, r.transno
                            from disbtrans r, TransCat t
                            where t.trcode=r.trcode and  trdate=@date");
        dw.SetDataAdapterParameters("date", date);
        return dw.GetDataTable();
    }


    public int InsertTransAssign(string cracno,double AssignAmt, double TrAmt, bool IsReady, string TrStatus, string AddUser,
                        DateTime AddDate, double intrate,string TransRef,string TaskID, string TrType,
                        long DisbRefNo, string System, string crcat)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@" insert into Transassign (cracno,AssignAmt,TrAmt,IsReady,TrStatus,AddUser,
                        AddDate,intrate,TransRef,TaskID,TrType,DisbRefNo,System,crcat)
                        VALUES(@cracno,@AssignAmt,@TrAmt,@IsReady,@TrStatus,@AddUser,
                        @AddDate,@intrate,@TransRef,@TaskID,@TrType,@DisbRefNo,@System,@crcat)");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("AssignAmt", AssignAmt);
        dw.SetSqlCommandParameters("TrAmt", TrAmt);
        dw.SetSqlCommandParameters("IsReady", IsReady);
        dw.SetSqlCommandParameters("TrStatus", TrStatus);
        dw.SetSqlCommandParameters("AddUser", AddUser);
        dw.SetSqlCommandParameters("AddDate", AddDate);
        dw.SetSqlCommandParameters("intrate", intrate);
        dw.SetSqlCommandParameters("TransRef", TransRef);
        dw.SetSqlCommandParameters("TaskID", TaskID);
        dw.SetSqlCommandParameters("TrType", TrType);
        dw.SetSqlCommandParameters("DisbRefNo", DisbRefNo);
        dw.SetSqlCommandParameters("System", System);
        dw.SetSqlCommandParameters("crcat", crcat);
        return dw.Insert();
    }



    public int InsertTransAssign(string cracno, double AssignAmt, double TrAmt, bool IsReady, string TrStatus,
                                    string AddUser, DateTime AddDate, string TransRef, string TaskID, string TrType,
                                    long DisbRefNo, string System)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@" insert into Transassign (cracno,AssignAmt,TrAmt,IsReady,TrStatus,AddUser,
                        AddDate,TransRef,TaskID,TrType,DisbRefNo,System)
                        VALUES(@cracno,@AssignAmt,@TrAmt,@IsReady,@TrStatus,@AddUser,
                        @AddDate,@TransRef,@TaskID,@TrType,@DisbRefNo,@System)");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("AssignAmt", AssignAmt);
        dw.SetSqlCommandParameters("TrAmt", TrAmt);
        dw.SetSqlCommandParameters("IsReady", IsReady);
        dw.SetSqlCommandParameters("TrStatus", TrStatus);
        dw.SetSqlCommandParameters("AddUser", AddUser);
        dw.SetSqlCommandParameters("AddDate", AddDate);
        dw.SetSqlCommandParameters("TransRef", TransRef);
        dw.SetSqlCommandParameters("TaskID", TaskID);
        dw.SetSqlCommandParameters("TrType", TrType);
        dw.SetSqlCommandParameters("DisbRefNo", DisbRefNo);
        dw.SetSqlCommandParameters("System", System);
        return dw.Insert();
    }
}


   
