﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

/// <summary>
/// Summary description for InternetFunction
/// </summary>
public class InternetFunction
{
    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();
    string tconstring = ConfigurationManager.ConnectionStrings["informixdbString"].ConnectionString;
    DataWorksClass dw;
    FunctionClass fc;
    DataTable dt;
    CrTransClass ctc;
    PrintClass p;
    Recovery rc;
    LastSerialClass ls;
    RecoveryProcesClass rpc;
    Trans tr;
    BatchEnter be;
    AccountPosition ap;

    DataWorksODBC dwo;
    public DataTable InsertRow(string batchno, DateTime batchDate, string cracno, DateTime transDate, string acsign,
                               string tramt, string trDetail, string taskid, string oldtransno, string batchType, string status,
                               int isglupdate, string transno, string errorref, string dnumber, string dbankname, string dbranchname, DataTable dt)
    {
        DataRow dr;
        dr = dt.NewRow();
        dr["batchno"] = batchno;
        dr["batchDate"] = batchDate;
        dr["cracno"] = cracno;
        dr["transDate"] = transDate;
        dr["acsign"] = acsign;
        dr["tramt"] = tramt;
        dr["trDetail"] = trDetail;
        dr["taskid"] = taskid;
        dr["oldtransno"] = oldtransno;
        dr["batchType"] = batchType;
        dr["status"] = status;
        dr["isglupdate"] = isglupdate;
        dr["transno"] = transno;
        dr["errorref"] = errorref;
        dr["dnumber"] = dnumber;
        dr["dbankname"] = dbankname;
        dr["dbranchname"] = dbranchname;
        dt.Rows.Add(dr);
        return dt;
    }

    public DataTable SetDataTable(DataTable dt)
    {
        dt = new DataTable();

        DataColumn batchno;
        batchno = new DataColumn();
        batchno.DataType = Type.GetType("System.String");
        batchno.ColumnName = "batchno";
        dt.Columns.Add(batchno);

        DataColumn batchDate;
        batchDate = new DataColumn();
        batchDate.DataType = Type.GetType("System.DateTime");
        batchDate.ColumnName = "batchDate";
        dt.Columns.Add(batchDate);

        DataColumn cracno;
        cracno = new DataColumn();
        cracno.DataType = Type.GetType("System.String");
        cracno.ColumnName = "cracno";
        dt.Columns.Add(cracno);

        DataColumn transDate;
        transDate = new DataColumn();
        transDate.DataType = Type.GetType("System.DateTime");
        transDate.ColumnName = "transDate";
        dt.Columns.Add(transDate);

        DataColumn acsign;
        acsign = new DataColumn();
        acsign.DataType = Type.GetType("System.String");
        acsign.ColumnName = "acsign";
        dt.Columns.Add(acsign);

        DataColumn tramt;
        tramt = new DataColumn();
        tramt.DataType = Type.GetType("System.String");
        tramt.ColumnName = "tramt";
        dt.Columns.Add(tramt);

        DataColumn trDetail;
        trDetail = new DataColumn();
        trDetail.DataType = Type.GetType("System.String");
        trDetail.ColumnName = "trDetail";
        dt.Columns.Add(trDetail);

        DataColumn taskid;
        taskid = new DataColumn();
        taskid.DataType = Type.GetType("System.String");
        taskid.ColumnName = "taskid";
        dt.Columns.Add(taskid);

        DataColumn oldtransno;
        oldtransno = new DataColumn();
        oldtransno.DataType = Type.GetType("System.String");
        oldtransno.ColumnName = "oldtransno";
        dt.Columns.Add(oldtransno);

        DataColumn batchType;
        batchType = new DataColumn();
        batchType.DataType = Type.GetType("System.String");
        batchType.ColumnName = "batchType";
        dt.Columns.Add(batchType);

        DataColumn status;
        status = new DataColumn();
        status.DataType = Type.GetType("System.String");
        status.ColumnName = "status";
        dt.Columns.Add(status);

        DataColumn isglupdate;
        isglupdate = new DataColumn();
        isglupdate.DataType = Type.GetType("System.Int16");
        isglupdate.ColumnName = "isglupdate";
        dt.Columns.Add(isglupdate);

        DataColumn transno;
        transno = new DataColumn();
        transno.DataType = Type.GetType("System.String");
        transno.ColumnName = "transno";
        dt.Columns.Add(transno);

        //transno
        DataColumn errorref;
        errorref = new DataColumn();
        errorref.DataType = Type.GetType("System.String");
        errorref.ColumnName = "errorref";
        dt.Columns.Add(errorref);

        DataColumn dnumber;
        dnumber = new DataColumn();
        dnumber.DataType = Type.GetType("System.String");
        dnumber.ColumnName = "dnumber";
        dt.Columns.Add(dnumber);

        DataColumn dbankname;
        dbankname = new DataColumn();
        dbankname.DataType = Type.GetType("System.String");
        dbankname.ColumnName = "dbankname";
        dt.Columns.Add(dbankname);

        DataColumn dbranchname;
        dbranchname = new DataColumn();
        dbranchname.DataType = Type.GetType("System.String");
        dbranchname.ColumnName = "dbranchname";
        dt.Columns.Add(dbranchname);

        return dt;
    }

    

    public DataTable GetInternetTransaction(string trstatus, string isUpdated)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select inetrefno,cracno,convert(datetime,CONVERT(VARCHAR(10), trdate, 120)) as trdate,tramt,trstatus,trnbrcode,isupdated from inettransaction 
    		where isUpdated = @isUpdated and trstatus = @trstatus 
		and CONVERT(VARCHAR(10), trdate, 120) < CONVERT(VARCHAR(10), getdate(), 120) order by trdate");
        dw.SetDataAdapterParameters("trstatus", trstatus);
        dw.SetDataAdapterParameters("isUpdated", isUpdated);
        return dw.GetDataTable();
    }

    // Get Otherbank transactions from informix base
    public DataTable GetOtherBankTransaction()
    {
         
        dwo = new DataWorksODBC(tconstring);
        dwo.SetDataAdapter(@"SELECT rrn, acno, batch_date, trn_amount FROM cefttrnjrn where stat_01='X'");
        return dwo.GetDataTable();
    }

    public int InsertOtherBankDetails(string inetrefno, string cracno, DateTime trdate, double tramt, string trstatus,
                                         string trnbrcode, string isupdated, DateTime logtime, string iscompleted, string TrnType,
                                        decimal TransassignRefno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into InetTransaction(inetrefno, cracno, trdate,tramt,trstatus, trnbrcode, 
                                                           isupdated, logtime, iscompleted, TrnType, TransassignRefno) VALUES 
                        (@inetrefno, @cracno,@trdate,@tramt,@trstatus, @trnbrcode, @isupdated, @logtime, @iscompleted, 
                        @TrnType,@TransassignRefno)");
        dw.SetSqlCommandParameters("inetrefno", inetrefno);
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("trdate", trdate);
        dw.SetSqlCommandParameters("tramt", tramt);
        dw.SetSqlCommandParameters("trstatus", trstatus);
        dw.SetSqlCommandParameters("trnbrcode", trnbrcode);
        dw.SetSqlCommandParameters("isupdated", isupdated);
        dw.SetSqlCommandParameters("logtime", logtime);
        dw.SetSqlCommandParameters("iscompleted", iscompleted);
        dw.SetSqlCommandParameters("TrnType", TrnType);
        dw.SetSqlCommandParameters("TransassignRefno", TransassignRefno);
        return dw.Insert();
    }

    public int UpdateOtherBankStatus(string stat_01, string rrn, string acno)
    {
        dwo = new DataWorksODBC(tconstring);
        dwo.SetCommand(@"update cefttrnjrn set stat_01=? where rrn=? and acno=?");
        dwo.SetOdbcCommandParameters("@stat_01", stat_01);
        dwo.SetOdbcCommandParameters("@rrn", rrn);
        dwo.SetOdbcCommandParameters("@acno", acno);
        return dwo.Update();
    }

    public void doBatchTransaction(DataTable dt,string userid)
    {
        //Get max Batch Number
        DateTime date = DateTime.Parse(DateTime.Now.ToString("yyyy-MM-dd"));
        string newdate = fc.GetSystemDateKey("A");
        string textBatchNo;
        string hiddenBatchNo;
        long batchno = 0;
        try
        {
            batchno = be.GetBatchNo(fc.GetSystemDate("A"));
        }
        catch (Exception er)
        {
            //
        }

        if (batchno == 0)
        {
            textBatchNo = newdate + "0001";
            hiddenBatchNo = textBatchNo.ToString();
        }
        else
        {
            textBatchNo = (batchno + 1).ToString();
            hiddenBatchNo = textBatchNo.ToString();
        }
        batchno = long.Parse(textBatchNo);
        //Label1.Visible = true;

        //Create Batch Header Start
        fc = new FunctionClass();
        double TotAmount = 0;
        be = new BatchEnter();
        string batchDetails = "Internet Transactions";
        int rowadded = 0;
        string batchStatus = "X";
        string cracno;
        long inetref;
        DateTime trdate;
        double tramt;
        rowadded = be.InsertBatchTransaction(batchno.ToString(), date, "RVS", batchDetails, "IbankTr", date, TotAmount, batchStatus);
        //Batch Header Create End

        if (rowadded != 0)
        {
            DataTable dtnew = new DataTable();
            DataTable tmpDatatTable = SetDataTable(dtnew);
            //Insert data into batchtmp;
            foreach (DataRow dr in dt.Rows)
            {
                //Enable for batch transaction
                try
                {
                    cracno = dr["cracno"].ToString();
                    inetref = long.Parse(dr["inetrefno"].ToString());
                    trdate = DateTime.Parse(dr["trdate"].ToString());
                    tramt = double.Parse(dr["tramt"].ToString());

                    //add Correct data to Tempary DataTable
                    tmpDatatTable = InsertRow(batchno.ToString(), fc.GetSystemDate("A")
                                             , cracno, trdate, "CR", tramt.ToString(),
                                              inetref.ToString() + '|' + userid, "Normal", "-97", "RVS", "X", 0, null, null, inetref.ToString(),
                                              "7000", "0308", tmpDatatTable);
                }
                catch
                {
                }


            }
            foreach (DataRow datar in tmpDatatTable.Rows)
            {
            }
            be.InsertBulkBatch(tmpDatatTable);

            //Update InetTransactions table for inserted records
            //lblMsg.Text = tmpDatatTable.Rows.Count.ToString() + " rows inserted";
        }
        else
        {
            //lblMsg.Text = "New batch cannot be created. Please contact system administrator !";
        }
    }

    public void doAsCounterTransaction(DataTable dtDoTrans,string user)
    {
        foreach (DataRow dr in dtDoTrans.Rows)
        {
            ap = new AccountPosition();
            ctc = new CrTransClass();
            p = new PrintClass();
            rc = new Recovery();
            ls = new LastSerialClass();
            fc = new FunctionClass();
            rpc = new RecoveryProcesClass();
            tr = new Trans();
            dt = new DataTable();
            string transno="";
            DateTime acttrdate = DateTime.Parse(DateTime.Now.ToString("yyyy-MM-dd"));
            long disbrefno;
            DateTime trdate = DateTime.Parse(dr["trdate"].ToString());
            string cracno = dr["cracno"].ToString();
            double amount = double.Parse(dr["tramt"].ToString());
            long inetrefno = long.Parse(dr["inetrefno"].ToString());
            string fullname = inetrefno.ToString();
            double tramt = amount;
            double sum=0;
            string message;
            string batchno = "";
            string isUpdated="";
            string isCompleted = "";

            transno = ls.GetMaxNumber("TransNo", true).ToString();
            if (transno != "0")
            {
                disbrefno = ls.GetMaxNumber("DisbRefNo", true);
                string batchrefno = tr.InsertCashierTransaction(transno, user, cracno, amount, "Internet Payment - Normal Recovery", trdate, DateTime.Now, fullname, disbrefno.ToString(), "CR");
                ap.GetRecoveryData(cracno, tramt, trdate, acttrdate, disbrefno, user, batchrefno, 1);
                ls.UpdateLastserial("DisbRefNo", disbrefno + 1);

                int paymentmode = 13;
                string time = DateTime.Now.TimeOfDay.ToString();
                tr = new Trans();
                tr.Transaction("RECV", 9, 0, paymentmode, user, trdate, time, disbrefno, transno);

                rc = new Recovery();
                
                rc.UpdateActStatusinHousprop(cracno, transno, "CAPD", trdate, trdate);
                
                dt = new DataTable();
                dt = ctc.GetClosedPaymentsInternet(transno);
                sum = fc.CalculateTotal(dt, "Sub Total");
                ls.UpdateLastserial("TransNo", long.Parse(transno) + 1);

                batchno = ctc.GetBatchno(transno);
                message = "Success";
                isUpdated="Y";
                isCompleted="Y";
            }

            else
            {
                message = "Transaction wait for 15 seconds";
                isUpdated="Y";
                isCompleted="N";
            }

            updateInetTransaction(inetrefno,cracno,isUpdated,transno,batchno,sum,message,DateTime.Now,user,isCompleted);
            
        }
    }

    private void updateInetTransaction(long inetrefno, string cracno, string isupdated, string TransNo
            , string batchno, double updatedtotal, string messages, DateTime updatetime, string updatedby, string iscompleted)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"UPDATE InetTransaction
                           SET 
                              isupdated = @isupdated
                              ,TransNo = @TransNo
                              ,batchno = @batchno
                              ,updatedtotal = @updatedtotal
                              ,messages = @messages
                              ,iscompleted = @iscompleted
                              ,updatetime = @updatetime
                              ,updatedby = @updatedby
                         WHERE inetrefno=@inetrefno and cracno = @cracno");
        dw.SetSqlCommandParameters("isupdated", isupdated);
        dw.SetSqlCommandParameters("TransNo", TransNo);
        dw.SetSqlCommandParameters("batchno", batchno);
        dw.SetSqlCommandParameters("updatedtotal", updatedtotal);
        dw.SetSqlCommandParameters("messages", messages);
        dw.SetSqlCommandParameters("iscompleted", iscompleted);
        dw.SetSqlCommandParameters("updatetime", updatetime);
        dw.SetSqlCommandParameters("updatedby", updatedby);
        dw.SetSqlCommandParameters("inetrefno", inetrefno);
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.Insert();
    }

    public DataTable getTransactionSummery(DateTime fromdate, DateTime todate)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"exec InternetTransactionSummery @fromdate,@todate");
        dw.SetDataAdapterParameters("fromdate", fromdate);
        dw.SetDataAdapterParameters("todate", todate);
        return dw.GetDataTable();
    }

    public DataTable getTransactionDetail(DateTime fromdate, DateTime todate)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"exec InternetTransactiondetail @fromdate,@todate");
        dw.SetDataAdapterParameters("fromdate", fromdate);
        dw.SetDataAdapterParameters("todate", todate);
        return dw.GetDataTable();
    }

    //2017/11/14 inserted TrnType for interest only requirement
    public DataTable GetInternetTransactionBatch(string trstatus, string isUpdated, DateTime dateTime)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select inetrefno,cracno,convert(datetime,CONVERT(VARCHAR(10), trdate, 120)) as trdate,
                            tramt,trstatus,trnbrcode,isupdated,TrnType from inettransaction 
    		                where isUpdated = @isUpdated and trstatus = @trstatus 
		                    and CONVERT(VARCHAR(10), trdate, 120) <= @dateTime order by trdate");
        dw.SetDataAdapterParameters("trstatus", trstatus);
        dw.SetDataAdapterParameters("isUpdated", isUpdated);
        dw.SetDataAdapterParameters("dateTime", dateTime);
        return dw.GetDataTable();
    }

    public int UpdateinettransactionTable(long transno, long batchno, double updatedtotal, string messages, char iscompleted,
                DateTime updatetime, string updatedby, DateTime trDate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update inettransaction set isupdated='Y',transno=@transno,batchno=@batchno,updatedtotal=@updatedtotal,
                        messages=@messages,iscompleted=@iscompleted,updatetime=@updatetime,updatedby=@updatedby
                        where isUpdated = 'N' and trstatus = 'Y' and CONVERT(VARCHAR(10), trdate, 120)=@trDate");
        dw.SetSqlCommandParameters("transno", transno);
        dw.SetSqlCommandParameters("batchno", batchno);
        dw.SetSqlCommandParameters("updatedtotal", updatedtotal);
        dw.SetSqlCommandParameters("messages", messages);
        dw.SetSqlCommandParameters("iscompleted", iscompleted);
        dw.SetSqlCommandParameters("updatetime", updatetime);
        dw.SetSqlCommandParameters("updatedby", updatedby);
        dw.SetSqlCommandParameters("trDate", trDate);
        return dw.Update();
    }

    public int UpdateinettransactionTable(long transno, long batchno, double updatedtotal, string messages, char iscompleted,
                DateTime updatetime, string updatedby,  string inetrefno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update inettransaction set isupdated='Y',transno=@transno,batchno=@batchno,updatedtotal=@updatedtotal,
                        messages=@messages,iscompleted=@iscompleted,updatetime=@updatetime,updatedby=@updatedby
                        where isUpdated = 'N' and trstatus = 'Y' and inetrefno=@inetrefno");
        dw.SetSqlCommandParameters("transno", transno);
        dw.SetSqlCommandParameters("batchno", batchno);
        dw.SetSqlCommandParameters("updatedtotal", updatedtotal);
        dw.SetSqlCommandParameters("messages", messages);
        dw.SetSqlCommandParameters("iscompleted", iscompleted);
        dw.SetSqlCommandParameters("updatetime", updatetime);
        dw.SetSqlCommandParameters("updatedby", updatedby);
        dw.SetSqlCommandParameters("inetrefno", inetrefno);
        return dw.Update();
    }

    public DataTable GetCondominiumDetails(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from CrMast C, CrCatPurpose P where C.CatPurposeId = P.catpurposeid
                            and C.Aprovdamt != C.GrantAmt and P.purposecode = 45 and C.GrantAmt != 0
                            and C.CrAcNo=@cracno");
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }
}
