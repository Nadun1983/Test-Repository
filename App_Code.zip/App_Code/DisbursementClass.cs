using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for DisbursementClass
/// </summary>
public class DisbursementClass
{
    DataWorksClass dw;
    DataTable dt;
    CrTransClass ctc;
    FunctionClass fc;

    DisbursementClass dc;
    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();


    #region To Disburse


    public int InsertCrMast(string AcStatus, string Appno, double Aprovdamt, string CrAcNo, int CrCat, double CrPeriod,
                           double Instalment, double IntRate, double GrantAmt, int CatPurposeId, double OriginalGrantAmt)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO CrMast(AcStatus,Appno,Aprovdamt,CrAcNo,CrCat,CrPeriod,instalment,IntRate,GrantAmt,
                       CatPurposeId,OriginalGrantAmt)
                      VALUES (@AcStatus,@Appno,@Aprovdamt,@CrAcNo,@CrCat,@CrPeriod,@instalment,@IntRate,@GrantAmt,@CatPurposeId,@OriginalGrantAmt)");
        dw.SetSqlCommandParameters("AcStatus", AcStatus);
        dw.SetSqlCommandParameters("Appno", Appno);
        dw.SetSqlCommandParameters("Aprovdamt", Aprovdamt);
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        dw.SetSqlCommandParameters("CrCat", CrCat);
        dw.SetSqlCommandParameters("CrPeriod", CrPeriod);
        dw.SetSqlCommandParameters("Instalment", Instalment);
        dw.SetSqlCommandParameters("IntRate", IntRate);
        dw.SetSqlCommandParameters("GrantAmt", GrantAmt);
        dw.SetSqlCommandParameters("CatPurposeId", CatPurposeId);
        dw.SetSqlCommandParameters("OriginalGrantAmt", OriginalGrantAmt);
        return dw.Insert();
    }

    public int InsertCrMast(string AcStatus, string Appno, double Aprovdamt, string CrAcNo, int CrCat, double CrPeriod,
                            double Instalment, double IntRate, double GrantAmt, int CatPurposeId, DateTime GrantDate, string IsDisburse,
                            double OriginalGrantAmt)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO CrMast(AcStatus,Appno,Aprovdamt,CrAcNo,CrCat,CrPeriod,instalment,IntRate,GrantAmt,CatPurposeId,GrantDate,
                        IsDisburse,OriginalGrantAmt)
                      VALUES (@AcStatus,@Appno,@Aprovdamt,@CrAcNo,@CrCat,@CrPeriod,@instalment,@IntRate,@GrantAmt,@CatPurposeId,@GrantDate,
                        @IsDisburse,@OriginalGrantAmt)");
        dw.SetSqlCommandParameters("AcStatus", AcStatus);
        dw.SetSqlCommandParameters("Appno", Appno);
        dw.SetSqlCommandParameters("Aprovdamt", Aprovdamt);
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        dw.SetSqlCommandParameters("CrCat", CrCat);
        dw.SetSqlCommandParameters("CrPeriod", CrPeriod);
        dw.SetSqlCommandParameters("Instalment", Instalment);
        dw.SetSqlCommandParameters("IntRate", IntRate);
        dw.SetSqlCommandParameters("GrantAmt", GrantAmt);
        dw.SetSqlCommandParameters("CatPurposeId", CatPurposeId);
        dw.SetSqlCommandParameters("GrantDate", GrantDate);
        dw.SetSqlCommandParameters("IsDisburse", IsDisburse);
        dw.SetSqlCommandParameters("OriginalGrantAmt", OriginalGrantAmt);
        return dw.Insert();
    }


    public int InsertHousProp(DateTime Adddate, string AddUser, string CrAcNo, double Instalment, string IsDisbursed,
                            int CrPeriod, int LoanStatusCode, int crcat, double intrate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO HousProp (CrAcNo,Instalment,AddUser,Adddate,IsDisbursed,CrPeriod,LoanStatusCode,crcat,intrate)
                      VALUES (@CrAcNo,@Instalment,@AddUser,@Adddate,@IsDisbursed,@CrPeriod,@LoanStatusCode,@crcat,@intrate)");
        dw.SetSqlCommandParameters("Adddate", Adddate);
        dw.SetSqlCommandParameters("AddUser", AddUser);
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        dw.SetSqlCommandParameters("Instalment", Instalment);
        dw.SetSqlCommandParameters("IsDisbursed", IsDisbursed);
        dw.SetSqlCommandParameters("CrPeriod", CrPeriod);
        dw.SetSqlCommandParameters("LoanStatusCode", LoanStatusCode);
        dw.SetSqlCommandParameters("crcat", crcat);
        dw.SetSqlCommandParameters("intrate", intrate);
        return dw.Insert();
    }
//(****)
    public int InsertHousProp(DateTime Adddate, string AddUser, string CrAcNo, double Instalment, string IsDisbursed,
                          int CrPeriod, int LoanStatusCode, DateTime DateDue, DateTime LastCompletedDueDate,
                             DateTime penalvaliddate, int GracePeriod,
                            DateTime LstTrDate, DateTime LstPaiddate, int PaidInstalments, double ActOutBal,
                            string recstatus, double intrate, int crcat)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO HousProp (CrAcNo,Instalment,AddUser,Adddate,IsDisbursed,CrPeriod,LoanStatusCode,DateDue,
                        LastCompletedDueDate,penalvaliddate,GracePeriod,LstTrDate,LstPaiddate,
                        PaidInstalments,ActOutBal,recstatus,intrate,crcat)
                      VALUES (@CrAcNo,@Instalment,@AddUser,@Adddate,@IsDisbursed,@CrPeriod,@LoanStatusCode,@DateDue,
                        @LastCompletedDueDate,@penalvaliddate,@GracePeriod,@LstTrDate,@LstPaiddate,
                        @PaidInstalments,@ActOutBal,@recstatus,@intrate,@crcat)");
        dw.SetSqlCommandParameters("Adddate", Adddate);
        dw.SetSqlCommandParameters("AddUser", AddUser);
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        dw.SetSqlCommandParameters("Instalment", Instalment);
        dw.SetSqlCommandParameters("IsDisbursed", IsDisbursed);
        dw.SetSqlCommandParameters("CrPeriod", CrPeriod);
        dw.SetSqlCommandParameters("LoanStatusCode", LoanStatusCode);
        dw.SetSqlCommandParameters("DateDue", DateDue);
        dw.SetSqlCommandParameters("LastCompletedDueDate", LastCompletedDueDate);
        dw.SetSqlCommandParameters("penalvaliddate", penalvaliddate);
        dw.SetSqlCommandParameters("GracePeriod", GracePeriod);
        dw.SetSqlCommandParameters("LstTrDate", LstTrDate);
        dw.SetSqlCommandParameters("LstPaiddate", LstPaiddate);
        dw.SetSqlCommandParameters("PaidInstalments", PaidInstalments);
        dw.SetSqlCommandParameters("ActOutBal", ActOutBal);
        dw.SetSqlCommandParameters("recstatus", recstatus);
        dw.SetSqlCommandParameters("intrate", intrate);
        dw.SetSqlCommandParameters("crcat", crcat);
        return dw.Insert();
    }

    public int InsertCrHolder(string nicno, string appno, string cracno, string holdertype)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO CrHolder(nicno,appno,cracno,holdertype)
                      VALUES (@nicno,@appno,@cracno,@holdertype)");
        dw.SetSqlCommandParameters("nicno", nicno);
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("holdertype", holdertype);
        return dw.Insert();
    }


    public DataTable GetSecondryDetails(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"SELECT C.AppNo AS AppNo, A.Amount AS ApprovedAmt, cc.CrDes As LoanCategory, Cp.CrCatCode,c.RecvDate, c.AppCat,
                            c.BoqAmount, c.RedemPurchaseAmt, GracePeriod, IntRate, cp.catpurposeid, c.NoOfDisb, 
                            CrPeriod AS [No of Instalments], C.IsAdditional AS Additional,c.ClientType,
                            c.SecurityType,cp.purposecode, c.CrAmt, P.Descrip, A.RecordNo
                            FROM CrApp C, AppCategory A, CrCatPurpose Cp, CrCategory cc, CrPurpose P
                            WHERE C.AppNo=@appno and cc.CrCatCode = cp.CrCatCode AND C.AppNo=A.AppNo
                            AND cp.purposecode=P.PurposeCode
                            AND A.CatPurposeId=Cp.CatPurposeId
                            order by descrip desc,intrate");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();
    }

    //public DataTable GetSecondryDetails(string appno)
    //{
    //    dw = new DataWorksClass(constring);
    //    dw.SetDataAdapter(@"SELECT C.AppNo AS AppNo, A.Amount AS ApprovedAmt, cc.CrDes As LoanCategory, C.CrCatCode,c.RecvDate, c.AppCat,
    //                        c.BoqAmount, c.RedemPurchaseAmt, C.GracePeriod, IntRate, a.catpurposeid, c.NoOfDisb, 
    //                        CrPeriod AS [No of Instalments], C.IsAdditional AS Additional,c.ClientType,c.SecurityType, P.Descrip,
    //                        P.PurposeCode, A.RecordNo
    //                        FROM CrApp C, AppCategory A, CrCatPurpose Cp, CrCategory cc, CrPurpose P
    //                        WHERE C.AppNo=@appno and cc.CrCatCode = c.CrCatCode AND C.AppNo=A.AppNo
    //                        AND cp.purposecode=P.PurposeCode
    //                        AND A.CatPurposeId=Cp.CatPurposeId
    //                        order by descrip desc,intrate");
    //    dw.SetDataAdapterParameters("appno", appno);
    //    return dw.GetDataTable();
    //}

    //change Dilanka on 18092010
    public DataTable GetApplicationsToDisb(string status, bool IsToDisburse)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select distinct aps.appno , cm.nicno , rtrim(rtrim(cm.initials) 
                                + ' ' + rtrim(cm.surname)) as customerName , ca.cramt from 
                                ApprovalStatus aps , appholder ah , customermain cm , crapp ca
                                where aps.IsValuationOK=1 and aps.IsInspectionOK=1 and aps.IsLegalOK=1 and
                                aps.IsPaymentOK=1 and aps.IsIncomeOK=1 and aps.IsSecurityOK=1 
                                and aps.status='A' and IsToDisburse=0
                                and ah.appno=aps.appno and cm.nicno=ah.nicno 
                                and ca.appno = ah.appno and ah.holdertype='P' 
                                union
                                select distinct aps.appno , cm.nicno , rtrim(rtrim(cm.initials) 
                                + ' ' + rtrim(cm.surname)) as customerName , ca.cramt from 
                                ApprovalStatus aps , appholder ah , customermain cm , crapp ca
                                where aps.status='A' and IsToDisburse=0 and crcatcode in (16,5,19,11) 
                                and ah.appno=aps.appno and cm.nicno=ah.nicno 
                                and ca.appno = ah.appno and ah.holdertype='P'"); //change 2011-08-15
        dw.SetDataAdapterParameters("status", status);
        dw.SetDataAdapterParameters("IsToDisburse", IsToDisburse);
        return dw.GetDataTable();
    }

    public int UpdateIsToDisburseInApprovalStat(string appno, bool IsToDisburse)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update ApprovalStatus set IsToDisburse=@IsToDisburse where AppNo=@appno");
        dw.SetSqlCommandParameters("IsToDisburse", IsToDisburse);
        dw.SetSqlCommandParameters("appno", appno);
        return dw.Update();
    }

    //ammend it on 2016/08/16 by Bimali
    public int UpdateAppCategory(string appno, double IntRate, int newcatpurposeid, double amount, int oldcatpurposeid)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update AppCategory set catpurposeid=@newcatpurposeid where AppNo=@appno and IntRate=@IntRate and amount=@amount
                        and catpurposeid=@oldcatpurposeid");
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("IntRate", IntRate);
        dw.SetSqlCommandParameters("newcatpurposeid", newcatpurposeid);
        dw.SetSqlCommandParameters("oldcatpurposeid", oldcatpurposeid);
        dw.SetSqlCommandParameters("amount", amount);
        return dw.Update();
    
    }


    //change dilanka on 18092010
    public DataTable GetPrimaryDetails(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select distinct aps.appno ,  rtrim(rtrim(cm.initials) + ' ' + rtrim(cm.surname)) as
                                customerName, cm.nicno , ah.holdertype  from ApprovalStatus aps , appholder ah , customermain cm,
                                crapp cp
                                where aps.IsValuationOK=1 and aps.IsInspectionOK=1 and aps.IsLegalOK=1 and
                                aps.IsPaymentOK=1 and aps.IsIncomeOK=1 and aps.IsSecurityOK=1 and aps.status='A'
                                and ah.appno=aps.appno and aps.appno=cp.appno and cm.nicno=ah.nicno and
                                cp.crcatcode !=16 and ah.appno=@appno
                                union
                                select distinct aps.appno ,  rtrim(rtrim(cm.initials) + ' ' + rtrim(cm.surname)) as
                                customerName, cm.nicno , ah.holdertype  from ApprovalStatus aps , appholder ah , customermain cm,
                                crapp cp
                                where aps.status='A' and cp.crcatcode in (16,5,19,11) 
                                and ah.appno=aps.appno and cm.nicno=ah.nicno and aps.appno=cp.appno and ah.appno=@appno"); //change 2011-08-15
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();
    }

    public DataTable GetApprovedLoanDetails(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select cracno,appno,aprovdamt,instalment,intrate from crmast where appno=@appno and acstatus='A'");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();
    }

    #endregion


    public DisbursementClass()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    // Get the customer info
    public DataTable GetCustomerInfo(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select rTrim(INitials) + ' ' + rTrim(Surname) as [Name], c.NicNo, Holdertype
                          from customermain c, appholder a , crmast cr
                          where c.nicno = a.nicno and a.appno = cr.appno and cr.cracno=@cracno and cr.acstatus='A'");
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }

    public DataTable GetCustomerInformation(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select rTrim(INitials) + ' ' + rTrim(Surname) as [Name], c.NicNo, Holdertype
                          from customermain c, appholder a 
                          where c.nicno = a.nicno and a.appno=@appno");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();
    }


    // Get Payments
    public DataTable GetPayments(string UpdateLevel/* Templr Filed*/)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select Description from PaymentType where UpdateLevel = @UpdateLevel");
        dw.SetDataAdapterParameters("UpdateLevel", UpdateLevel);
        return dw.GetDataTable();
    }


    public int InsertPayments(string appno, int PaymentTypeId, double amount)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into PaymentMade (AppNo,PaymentTypeId,IsPaid,Amount,ConfirmPayment,ConfirmDate)
                       values (@AppNo,@PaymentTypeId,@IsPaid,@Amount,@ConfirmPayment,@ConfirmDate) ");
        dw.SetSqlCommandParameters("AppNo", appno);
        dw.SetSqlCommandParameters("PaymentTypeId", PaymentTypeId);
        dw.SetSqlCommandParameters("IsPaid", false);
        dw.SetSqlCommandParameters("Amount", amount);
        dw.SetSqlCommandParameters("ConfirmPayment", true);
        dw.SetSqlCommandParameters("ConfirmDate", DateTime.Now);
        return dw.Insert();
    }

    //26/05/2009 - Vihanga // edit 05/06/2009 (||||)
    public int UpdateDateDue(string cracno, DateTime datedue, double intrate, double outbal,
                            int paidInstallment, int gracePeriod, DateTime LastCompletedDueDate,
                            double ActOutBal, DateTime penalvaliddate, int crcat)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update housprop set datedue=@datedue, intrate=@intrate,outbal=@outbal,
                        PaidInstalments=@paidInstallment, gracePeriod=@gracePeriod, 
                        LastCompletedDueDate=@LastCompletedDueDate, ActOutBal=@ActOutBal,
                        penalvaliddate=@penalvaliddate, crcat=@crcat
                        where cracno=@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("datedue", datedue);
        dw.SetSqlCommandParameters("intrate", intrate);
        dw.SetSqlCommandParameters("outbal", outbal);
        dw.SetSqlCommandParameters("paidInstallment", paidInstallment);
        dw.SetSqlCommandParameters("gracePeriod", gracePeriod);
        dw.SetSqlCommandParameters("LastCompletedDueDate", LastCompletedDueDate);
        dw.SetSqlCommandParameters("ActOutBal", ActOutBal);
        dw.SetSqlCommandParameters("penalvaliddate", penalvaliddate);
        dw.SetSqlCommandParameters("crcat", crcat);
        return dw.Update();
    }


    //2009-05-26 vihanga
    //public bool ChequeLoanStatus(string appno)
    //{
    //    string applicationNum = null;
    //    dw = new DataWorksClass(constring);
    //    dw.SetCommand(@"select appno from disbbalsum where isfinalrelease='N' and schedulestatus<>'C' and appno=@appno");
    //    dw.SetSqlCommandParameters("appno", appno);
    //    applicationNum = dw.GetSingleData();
    //    if (applicationNum == null)
    //        return false;
    //    if (applicationNum == "0")
    //        return false;
    //    else
    //        return true;
    //}

    //2009-05-26 vihanga
    public bool ChequeLoanStatus(string appno)
    {
        string applicationNum = null;
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select appno from disbbalsum where isfinalrelease='Y' and schedulestatus<>'C' and appno=@appno and transno is not null");
        dw.SetSqlCommandParameters("appno", appno);
        applicationNum = dw.GetSingleData();
        if (applicationNum == null)
            return false;
        if (applicationNum == "0")
            return false;
        else
            return true;
    }

    //Bimali : 30/01/2009
    public bool GetRecordExist(string appno)
    {
        dw = new DataWorksClass(constring);
        dt = new DataTable();
        bool status = false;
        dw.SetDataAdapter(@"SELECT * FROM DisbBalSum WHERE AppNo=@appno AND ScheduleStatus='O' AND 
                            TransNo IS NULL AND Status='A' ORDER BY CrAcNo");
        dw.SetDataAdapterParameters("appno", appno);
        dt = dw.GetDataTable();

        if (dt.Rows.Count > 0)
            status = true;
        else
            status = false;
        return status;

    }

    //Bimali : 30/01/2009
    public int GetNoOfDisbursements(string appno)
    {
        int disbursements = 0;
        dw = new DataWorksClass(constring);
        dt = new DataTable();
        dw.SetDataAdapter(@"select noofdisb from crapp where appno=@appno");
        dw.SetDataAdapterParameters("appno", appno);
        dt = dw.GetDataTable();
        if (dt.Rows.Count > 0)
            disbursements = int.Parse(dt.Rows[0][0].ToString());
        else
            disbursements = 0;
        return disbursements;
    }

    //Bimali : 30/01/2009
    //edit bimali
    public DataTable GetCrMastAccountDetails(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select aprovdamt-grantamt as grantamt,cracno,aprovdamt,grantamt as existamt 
                            from CrMast where appno=@appno and acstatus='A' order by cracno");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();
    }

    //Bimali : 30/01/2009
    public int GetTransNo(string cracno)
    {
        dw = new DataWorksClass(constring);
        int transno = 0;
        dw.SetCommand(@"select transno from crtransjrnl where cracno=@cracno and action='DIS'");
        dw.SetSqlCommandParameters("cracno", cracno);
        return int.Parse(dw.GetSingleData());
    }

    //Bimali: 02/02/2009

    public int GetDisbBalSumCount(string appno)
    {
        dt = new DataTable();
        dw = new DataWorksClass(constring);

        int countDisb = 0;
        dw.SetDataAdapter(@"select count(appno) AS countApp from disbbalsum where appno=@appno");
        dw.SetDataAdapterParameters("appno", appno);
        dt = dw.GetDataTable();
        countDisb = int.Parse(dt.Rows[0][0].ToString());
        return countDisb;
    }


    //Bimali: 02/02/2009
    public bool CheckdisbAmount(DataTable dt, decimal intdisb, decimal amountrequest, decimal totamt)
    {
        bool status = false;
        if (totamt <= amountrequest)
        {
            status = false;
        }
        else
        {
            foreach (DataRow dr in dt.Rows)
            {
                decimal loanamt = +decimal.Parse(dr[0].ToString());
                if (amountrequest <= loanamt)
                {
                    status = true;
                    break;
                }
                else
                {
                    status = false;
                }
            }
        }
        return status;
    }

    //Bimali
    public decimal TotalDisbAmount(string appno, string cracno)
    {
        dt = new DataTable();
        dw = new DataWorksClass(constring);

        string totalDisbamt = "";
        decimal disAmt = 0;
        dw.SetCommand(@"select SUM(TransAmt) AS TransAmt from disbbalsum where appno=@appno and cracno=@cracno
                        and status='A' and transno is not null");
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("cracno", cracno);
        //dt = dw.GetDataTable();
        totalDisbamt = dw.GetSingleData();
        if (totalDisbamt == "")
            disAmt = 0;
        else
            disAmt = decimal.Parse(dw.GetSingleData());
        return disAmt;
    }



    //Bimali
    public decimal GetCrAmount(string appno)
    {
        dt = new DataTable();
        dw = new DataWorksClass(constring);

        decimal totalAmt = 0;
        dw.SetDataAdapter(@"select SUM(AprovdAmt) AS CrAmt from CrMast where appno=@appno");
        dw.SetDataAdapterParameters("appno", appno);
        dt = dw.GetDataTable();
        totalAmt = decimal.Parse(dt.Rows[0][0].ToString());
        return totalAmt;
    }



    ////Bimali
    public decimal GetLegalCharges(long cracno, string taskid, string transref)
    {
        dt = new DataTable();
        dw = new DataWorksClass(constring);

        decimal Legalcharges = 0;
        dw.SetDataAdapter(@"SELECT AssignAmt FROM TransAssign A, TransCat T 
                            WHERE A.taskid=T.taskid AND A.CrAcNo=@cracno AND 
                            T.transref = @transref and t.taskid=@taskid AND 
                            (TrStatus='P' OR TrStatus='N')");
        dw.SetDataAdapterParameters("cracno", cracno);
        dw.SetDataAdapterParameters("taskid", taskid);
        dw.SetDataAdapterParameters("transref", transref);
        dt = dw.GetDataTable();
        if (dt.Rows.Count > 0)
        {
            Legalcharges = decimal.Parse(dt.Rows[0][0].ToString());
        }
        else
        {
            Legalcharges = 0;
        }
        return Legalcharges;
    }

    //bimali

    public int UpdateIsFinalStatus(string appno, string isfinalrelease, string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@" UPDATE DisbBalSum SET IsFinalRelease=@isfinalrelease WHERE AppNo=@appno 
                         AND CrAcNo=@cracno");
        dw.SetSqlCommandParameters("isfinalrelease", isfinalrelease);
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("cracno", cracno);
        return dw.Update();
    }

    public bool GetScheduleStatus(string appno)
    {
        bool status = false;
        dt = new DataTable();
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from DisbBalSum where appno=@appno AND ScheduleStatus='O'");
        dw.SetDataAdapterParameters("appno", appno);
        dt = dw.GetDataTable();
        if (dt.Rows.Count > 0)
        {
            status = true;
        }
        else
        {
            status = false;
        }
        return status;

    }

    public bool GetNotRealeasedChqDetails(string appno)
    {
        bool status = false;
        dt = new DataTable();
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"SELECT * FROM DisbBalSum WHERE GrantDate IS NULL AND ScheduleStatus='C'
                            AND AppNo=@appno AND Status='A'");
        dw.SetDataAdapterParameters("appno", appno);
        dt = dw.GetDataTable();
        if (dt.Rows.Count > 0)
        {
            status = true;
        }
        else
        {
            status = false;
        }
        return status;
    }

    public void SetDisbusment(DataTable dt, decimal inputamount, string appno, int disbno)
    {
        decimal grantamount = 0;
        decimal existamt = 0;
        string finalrelease;
        decimal approvedamount = 0;
        decimal outbal = 0;
        decimal crupdateamt = 0;
        fc = new FunctionClass();

        dc = new DisbursementClass();
        ctc = new CrTransClass();
        if (dc.GetRecordExist(appno) == true)
        {
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string cracno = dt.Rows[i]["cracno"].ToString();
                approvedamount = decimal.Parse(dt.Rows[i]["aprovdAmt"].ToString());
                //25032010
                    grantamount = decimal.Parse(dt.Rows[i]["GrantAmt"].ToString());
                    existamt = decimal.Parse(dt.Rows[i]["existamt"].ToString());
                    decimal disbmount = dc.TotalDisbAmount(appno, cracno);
               //upto here


                //grantamount = approvedamount;//decimal.Parse(dt.Rows[i]["GrantAmt"].ToString());
                //existamt = decimal.Parse(dt.Rows[i]["existamt"].ToString()); //edit bimali
                if (grantamount >= inputamount)
                {
                    //outbal = approvedamount - (inputamount + 0);

                    outbal = approvedamount - (inputamount + disbmount);

                    if (/*approvedamount*/ grantamount == inputamount)
                    {
                        finalrelease = "Y";
                    }
                    else
                    {
                        finalrelease = "N";
                    }

                    ctc.UpdateDibBalSum(cracno, inputamount, outbal, fc.GetSystemDate("A"), "A", finalrelease, "O", disbno);
                    if (inputamount == grantamount)
                        inputamount = grantamount /*approvedamount*/;
                    else
                    {
                        inputamount = inputamount;
                    }

                    approvedamount = 0;
                    inputamount = 0;
                    //existamt = GetExsistingAmountFromDisbBalSum(cracno);
                    //ctc.UpdateCrMastGrantAmt(existamt, cracno);
                    inputamount = 0;

                }
                else
                {
                    if (approvedamount == grantamount)
                    {
                        finalrelease = "Y";
                    }
                    else
                    {
                        finalrelease = "N";
                    }
                    outbal = approvedamount - (grantamount + disbmount);
                    ctc.UpdateDibBalSum(cracno, grantamount, outbal, fc.GetSystemDate("A"), "A", finalrelease, "O", disbno);
                    //ctc.UpdateCrMastGrantAmt(approvedamount, cracno);
                    inputamount = inputamount - grantamount;

                }
            }
        }
        else
        {
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string cracno = dt.Rows[i]["cracno"].ToString();
                grantamount = decimal.Parse(dt.Rows[i]["GrantAmt"].ToString());
                approvedamount = decimal.Parse(dt.Rows[i]["aprovdAmt"].ToString());
                existamt = decimal.Parse(dt.Rows[i]["existamt"].ToString());
                decimal disbmount = dc.TotalDisbAmount(appno, cracno);

                if (grantamount >= inputamount)
                {
                    outbal = approvedamount - (inputamount + disbmount);

                    if (/*approvedamount*/ grantamount == inputamount)
                    {
                        finalrelease = "Y";
                    }
                    else
                    {
                        finalrelease = "N";
                    }

                    if (inputamount == grantamount)
                        inputamount = grantamount /*approvedamount*/;
                    else
                        inputamount = inputamount;
                    existamt = existamt + inputamount;
                    ctc.InsertIntoDibBalSum(cracno, appno, inputamount, outbal, fc.GetSystemDate("A"), "A", finalrelease, "O", disbno);
                    //ctc.UpdateCrMastGrantAmt(existamt, cracno);
                    approvedamount = 0;
                    inputamount = 0;
                }
                else
                {
                    if (approvedamount == grantamount)
                    {
                        finalrelease = "Y";
                    }
                    else
                    {
                        finalrelease = "N";
                    }
                    outbal = approvedamount - (grantamount + disbmount);
                    ctc.InsertIntoDibBalSum(cracno, appno, grantamount, outbal, fc.GetSystemDate("A"), "A", finalrelease, "O", disbno);
                    //ctc.UpdateCrMastGrantAmt(approvedamount, cracno);
                    inputamount = inputamount - grantamount;
                }
            }
        }
    }


    //bimali 13/05/2009
    public int UpdateCrMastGrantAmt(decimal grantamt, string cracno)
    {
        //dt = new DataTable();
        dw = new DataWorksClass(constring);
        dw.SetCommand(@" UPDATE CrMast SET GrantAmt=@grantamt WHERE CrAcNo=@cracno");
        dw.SetSqlCommandParameters("grantamt", grantamt);
        dw.SetSqlCommandParameters("cracno", cracno);
        return dw.Update();
    }


    private decimal GetExsistingAmountFromDisbBalSum(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select sum(transamt) from disbbalsum 
                        where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return decimal.Parse(dw.GetSingleData());
    }

    // 2009/02/16 Dilanka // edit 05/06/2009
    public DataTable GetCrAcNo(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select distinct c.cracno, d.IsFinalRelease, c.intrate,c.grantamt,crperiod,c.crcat as crcat 
                            from disbbalsum d, crmast c where d.appno= @appno and c.acstatus='A'
                            and d.appno=c.appno and d.batchdate = (select max(batchdate) 
                            from disbbalsum where appno = @appno)
                            and d.transamt != 0");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();
    }


    // 2009/02/16 Dilanka
    public int UpdateIsDisburse(bool IsDisburse, string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand("update CrMast set IsDisburse=@IsDisburse where cracno=@cracno");
        dw.SetSqlCommandParameters("IsDisburse", IsDisburse);
        dw.SetSqlCommandParameters("cracno", cracno);
        return dw.Update();
    }



    
    public double GetTotalDisbAmt(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select sum(transamt) as transamt from disbbalsum D, CrMast c
                        where d.cracno=@cracno and
                        d.cracno=c.cracno 
                        and d.schedulestatus='C'
                        and d.transamt<>0 and d.grantdate is not null
                        and d.Status='A'");
        dw.SetSqlCommandParameters("cracno", cracno);
        return double.Parse(dw.GetSingleData());
    }

    //edit bimali 13/05/2009
    public DataRow GetDisbursedDetails(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@" select distinct  d.CrAcNo,IntRate,d.GrantDate from disbbalsum D, CrMast c
                            where d.cracno=@cracno and d.cracno=c.cracno and c.acstatus='A'
                            and d.schedulestatus='C'
                            and d.transamt<>0 and d.grantdate is not null
                            and d.Status='A' and d.GrantDate = 
                            (select max(GrantDate) as GrantDate from disbbalsum where cracno=@cracno)");
        dw.SetDataAdapterParameters("cracno", cracno);
        DataTable dt = new DataTable();
        dt = dw.GetDataTable();
        DataRow dr;
        if (dt.Rows.Count != 0)
        {
            dr = dt.Rows[0];
        }
        else
        {
            dr = null;
        }

        return dr;

    }


    public DataTable GetCurrentDisbursementDetails(string appno, string status)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@" select TransAmt,CrAcNo from disbbalsum 
                            where transamt<>0 and batchdate is not null and status = @status and appno = @appno and
                            grantdate is null and batchdate = (select max(batchdate) from disbbalsum where appno = @appno)");
        dw.SetDataAdapterParameters("appno", appno);
        dw.SetDataAdapterParameters("status", status);
        return dw.GetDataTable();
    }

    //edit bimali 18/03/2009
    //edit bimali 18/03/2009 //edit again on 01/04/2009
    public DataTable GetApprovedDisbDetails(string appno, string status, string schedulestatus)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@" select m.nicno, rtrim(m.initials) + rtrim(m.surname) as fullname,d.cracno as cracno,
                            d.transamt as transamt,c.intrate as intrate
                            from disbbalsum d, crmast c, appholder a, customermain m where d.appno=@appno
                            and d.transamt <> 0 and d.grantdate is null 
                            and d.schedulestatus=@schedulestatus AND d.Status=@status
                            and d.cracno=c.cracno and c.appno=a.appno and a.nicno=m.nicno and a.holdertype='P'
                            and c.acstatus='A'");
        dw.SetDataAdapterParameters("appno", appno);
        dw.SetDataAdapterParameters("status", status);
        dw.SetDataAdapterParameters("schedulestatus", schedulestatus);
        return dw.GetDataTable();
    }

    public decimal GetCreditAmountCrAcNo(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"SELECT GrantAmt FROM CrMast WHERE CrAcno=@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return decimal.Parse(dw.GetSingleData());
    }

    public DataTable GetBankDetails()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select BankNo,BankName from bank");
        return dw.GetDataTable();
    }

    public string GetChequeAmout(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select sum(AssignAmt) as Amount from transassign ta , DisbBalSum dbs
                        where dbs.cracno=ta.cracno and ta.transref='DISB' and ta.TrStatus='N'
                        and dbs.appno=@appno and dbs.Grantdate is null and status='A'");
        dw.SetSqlCommandParameters("appno", appno);
        return dw.GetSingleData();
    }

    public string GetChargesAmount(string cracno, /*string TransRef,*/ string TrStatus1, string TrStatus2)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select sum(AssignAmt) as Amount from transassign 
                        where cracno = @cracno 
                        and (TrStatus=@TrStatus1 or TrStatus=@TrStatus2)");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("TrStatus1", TrStatus1);
        dw.SetSqlCommandParameters("TrStatus2", TrStatus2);
        //dw.SetSqlCommandParameters("TransRef", TransRef);
        return dw.GetSingleData();
    }

    //2009-03-23U vihanga
    public int InsertDisbChqData(string appno, string chequeNo, string chequeAmt, int BankCode, DateTime printDate,
                                 string ChequeStatus, string ChequeHolderName, bool IsChequePrint)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into ChequePrintDetails(appno,chequeNo,chequeAmt,BankCode,
                        printDate,ChequeStatus,Chequeholdername, IsChequePrint)
                        values(@appno,@chequeNo,@chequeAmt,@BankCode,@printDate,@ChequeStatus,@ChequeHolderName,@IsChequePrint)");
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("chequeNo", chequeNo);
        dw.SetSqlCommandParameters("chequeAmt", chequeAmt);
        dw.SetSqlCommandParameters("BankCode", BankCode);
        dw.SetSqlCommandParameters("printDate", printDate);
        dw.SetSqlCommandParameters("ChequeStatus", ChequeStatus);
        dw.SetSqlCommandParameters("ChequeHolderName", ChequeHolderName);
        dw.SetSqlCommandParameters("IsChequePrint", IsChequePrint);

        return dw.Insert();
    }

    //    public int UpdateGrantDateInDisbBalSum(string appno, DateTime grantdate)
    //    {
    //        dw = new DataWorksClass(constring);
    //        dw.SetCommand(@"update disbbalsum set grantdate=@grantdate where appno=@appno and batchdate = (select max(batchdate) 
    //                        from DisbBalSum where appno=@appno) and grantdate is null");
    //        dw.SetSqlCommandParameters("appno", appno);
    //        dw.SetSqlCommandParameters("grantdate", grantdate);
    //        return dw.Update();
    //    }

    //edit bimali 18/03/2009
    //edit bimali 18/03/2009 (edit bimali 01/04/2009)
    public int UpdateGrantDateInDisbBalSum(string appno, DateTime grantdate, int transno, string status)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update disbbalsum set grantdate=@grantdate,transno=@transno where appno=@appno 
                        and batchdate = (select max(batchdate) 
                        from DisbBalSum where appno=@appno) and grantdate is null and status=@status");
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("grantdate", grantdate);
        dw.SetSqlCommandParameters("transno", transno);
        dw.SetSqlCommandParameters("status", status);
        return dw.Update();
    }

    public int UpdatGrantDate(string cracno, DateTime grantdate, double grantamt, double OriginalGrantAmt)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update crmast set grantdate=@grantdate,grantamt=@grantamt, OriginalGrantAmt=@OriginalGrantAmt 
                        where cracno=@cracno and acstatus='A'");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("grantdate", grantdate);
        dw.SetSqlCommandParameters("grantamt", grantamt);
        dw.SetSqlCommandParameters("OriginalGrantAmt", OriginalGrantAmt);
        return dw.Update();
    }

 
    // edit bimali 18/03/2009
    public int GetTransNoToUpdate(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select transno from transassign where CrAcNo=@cracno and adddate=(select max(adddate)
                        from transassign where cracno=@cracno) and trstatus='F' and TransRef='DISB' and TaskId='CAPD'");
        dw.SetSqlCommandParameters("cracno", cracno);
        return int.Parse(dw.GetSingleData());
    }

    //Get Application Number using Cracno
    public string Getappno(long cracno)
    {
        dw = new DataWorksClass(constring);
        dt = new DataTable();
        dw.SetDataAdapter(@"select appno from crmast where cracno=@cracno and acstatus='A'");
        dw.SetDataAdapterParameters("cracno", cracno);
        dt = dw.GetDataTable();
        return dt.Rows[0][0].ToString();
    }

    public DataTable GetCustomerDetails(string appno)
    {
        dw = new DataWorksClass(constring);
        dt = new DataTable();
        dw.SetDataAdapter(@"select  distinct cm.nicno AS NicNo, rtrim(rtrim(t.titledesc) + '  ' + rtrim(cm.Initials) + '  ' + rtrim(cm.surname)) as [Customer Name] ,
                        rtrim(rtrim(cm.location) + '  ' + rtrim(cm.street) + '  ' + rtrim(cm.city)) as Address
                        from CustomerMain cm ,TITLE t , AppHolder ah
                        where cm.titlecode=t.titlecode and ah.nicno=cm.nicno and ah.appno=@appno");
        dw.SetDataAdapterParameters("appno", appno);
        dt = dw.GetDataTable();
        return dt;
    }

    public DataTable GetCreditAccountDetails(string appno)
    {
        dw = new DataWorksClass(constring);
        dt = new DataTable();
        dw.SetDataAdapter(@"select m.Cracno AS CrAcNo,p.Descrip AS [Loan Description],m.AprovdAmt AS ApprovedAmt,
                            m.GrantAmt,m.Instalment,a.NoOfDisb AS [No Of Disbursements],
                            m.CrPeriod,m.IntRate
                            from crmast m,crcatpurpose cp,crpurpose p, crapp a
                            where m.appno=@appno and m.catpurposeid=cp.catpurposeid
                            and cp.purposecode=p.purposecode and m.appno=a.appno and m.acstatus='A'");
        dw.SetDataAdapterParameters("appno", appno);
        dt = dw.GetDataTable();
        return dt;
    }

    public DataTable GetAccountInformation(string appno)
    {
        dw = new DataWorksClass(constring);
        dt = new DataTable();
        dw.SetDataAdapter(@"select c.Appno,v.PresentVal,im.AmtWorkdone,c.Cracno,c.AprovdAmt,dbs.TransAmt,dbs.OutBal,
                            dbs.IsFinalRelease
                            from crmast c, valuation v,inspectmast im,disbbalsum dbs
                            where v.appno=c.appno and im.appno=c.appno and dbs.cracno=c.cracno and c.appno=@appno and c.acstatus='A'");
        dw.SetDataAdapterParameters("appno", appno);
        dt = dw.GetDataTable();
        return dt;
    }

    public DataTable ChargesDetails(string appno)
    {
        dw = new DataWorksClass(constring);
        dt = new DataTable();
        dw.SetDataAdapter(@"select refno,taskid,CrAcNo,AssignAmt from TransAssign 
                            where cracno=@appno and (trstatus='N' OR trstatus='P')");
        dw.SetDataAdapterParameters("appno", appno);
        dt = dw.GetDataTable();
        return dt;
    }

    public DataTable DisburseMentHistory(string appno)
    {
        dw = new DataWorksClass(constring);
        dt = new DataTable();
        dw.SetDataAdapter(@"select cracno,appno,transamt,outbal,grantdate from disbbalsum where appno=@appno
                            and grantdate is not null and transamt<>0 and status='A' order by grantdate");
        dw.SetDataAdapterParameters("appno", appno);
        dt = dw.GetDataTable();
        return dt;
    }

    public DataTable GetBankNames()
    {
        dw = new DataWorksClass(constring);
        dt = new DataTable();
        dw.SetDataAdapter(@"select bankname from bank");
        dt = dw.GetDataTable();
        return dt;
    }

    public DataTable GetOtherDetails(string appno)
    {
        dw = new DataWorksClass(constring);
        dt = new DataTable();
        dw.SetDataAdapter(@"select ca.noOfDisb,cm.Aprovdamt,grantamt from crapp ca , crmast cm
                            where ca.appno=cm.appno and cm.appno=@appno and cm.acstatus='A'");
        dw.SetDataAdapterParameters("appno", appno);
        dt = dw.GetDataTable();
        return dt;
    }


    //Bimali = March 03rd 2009
    public bool GetChequeStatus(string appno, string status)
    {
        dw = new DataWorksClass(constring);
        dt = new DataTable();
        bool recstatus = false;
        dw.SetDataAdapter(@"select ChequeStatus from ChequePrintDetails 
                            where appno=@appno and PrintDate=(select max(printdate) 
                            from ChequePrintDetails where appno=@appno)");
        dw.SetDataAdapterParameters("appno", appno);
        dw.SetDataAdapterParameters("status", status);
        dt = dw.GetDataTable();
        if (dt.Rows.Count > 0)
            recstatus = true;
        else
            recstatus = false;
        return recstatus;

    }

    public int CancelCheque(string appno, string status)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update ChequePrintDetails set ChequeStatus=@status where appno=@appno 
                        and printdate = (select max(printdate) 
                        from ChequePrintDetails where appno=@appno) and ChequeStatus='A'");
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("status", status);
        return dw.Update();
    }


    //select cd.AppNo,dbs.cracno,cm.grantamt, cast(year(getdate()) as varchar) + '/' + 
    //                        cast(month(getdate()) as varchar) + '/' + cast(day(getdate()) as varchar) as Approvdate ,
    //                        cm.intrate ,ca.GracePeriod , cd.chequeNo,cd.chequeAmt , b.BankName , 
    //                        cast(year(cd.printdate) as varchar) + '/' + cast(month(cd.printdate) as varchar) + '/' + 
    //                        cast(day(cd.printdate) as varchar) as ChequePrintDate ,cd.ChequeHolderName,cd.IsChequePrint
    //                        from disbbalsum dbs , crmast cm , ChequePrintDetails cd , bank b ,crapp ca
    //                        where dbs.grantdate is null and transno is null and ca.appno=cm.appno and
    //                        dbs.status='A' and cd.appno=@appno and ischequeprint is null and dbs.transamt!=0 and
    //                        dbs.cracno=cm.cracno and cd.bankcode=b.bankno and dbs.appno=@appno

    public DataTable GetChequeDetails(string appno, bool IsChequePrint)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from ChequePrintDetails where appno=@appno and IsChequePrint=@IsChequePrint");
        dw.SetDataAdapterParameters("appno", appno);
        dw.SetDataAdapterParameters("IsChequePrint", IsChequePrint);
        return dw.GetDataTable();
    }

    public int Updatehouspropwithtransact(double outbal, DateTime datedue, int graceperiod, DateTime lsttrdate,
                                          DateTime lastcompletedduedate, double intrate, string cracno, string isDisbursed)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update housprop set outbal=@outbal , datedue=@datedue , graceperiod=@graceperiod , lsttrdate=@lsttrdate ,
                        lastcompletedduedate=@lastcompletedduedate , intrate=@intrate, isDisbursed=@isDisbursed where cracno=@cracno");
        dw.SetSqlCommandParameters("outbal", outbal);
        dw.SetSqlCommandParameters("datedue", datedue);
        dw.SetSqlCommandParameters("graceperiod", graceperiod);
        dw.SetSqlCommandParameters("lsttrdate", lsttrdate);
        dw.SetSqlCommandParameters("lastcompletedduedate", lastcompletedduedate);
        dw.SetSqlCommandParameters("intrate", intrate);
        dw.SetSqlCommandParameters("isDisbursed", isDisbursed);
        dw.SetSqlCommandParameters("cracno", cracno);

        return dw.Update();
    }

    public int GetCatPurposeId(string appno)
    {
        dw = new DataWorksClass(constring);
        dt = new DataTable();
        dw.SetCommand(@"select catpurposeid from AppCategory where appno=@appno");
        dw.SetSqlCommandParameters("appno", appno);
        return int.Parse(dw.GetSingleData());

    }

    //    public string GetPrimaryCustomerName(string appno)
    //    {
    //        dw = new DataWorksClass(constring);
    //        dw.SetCommand(@"select rTrim(INitials) + ' ' + rTrim(Surname) as [Name]
    //                          from customermain c, appholder a 
    //                          where c.nicno = a.nicno and a.appno=@appno and holdertype='P' ");
    //        dw.SetSqlCommandParameters("appno", appno);
    //        return dw.GetSingleData();
    //    }

    public DataTable GetCustomerNames(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select rTrim(INitials) + ' ' + rTrim(Surname) as [Name]
                          from customermain c, appholder a 
                          where c.nicno = a.nicno and a.appno=@appno order by holdertype");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();
    }

    //    public string GetNoofSecondaryCustomerName(string appno)
    //    {
    //        dw = new DataWorksClass(constring);
    //        dw.SetCommand(@"select rTrim(INitials) + ' ' + rTrim(Surname) as [Name]
    //                          from customermain c, appholder a 
    //                          where c.nicno = a.nicno and a.appno=@appno and holdertype='S' ");
    //        dw.SetSqlCommandParameters("appno", appno);
    //        return dw.GetSingleData();
    //    }

    public string GetOwnerName(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select ownersname from HpSec where appno=@appno");
        dw.SetSqlCommandParameters("appno", appno);
        return dw.GetSingleData();
    }

    public int InsertFireInsurance(string appno, string Status, DateTime AssignDate, string Adduser)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"insert into FireInsurance (AppNo,Status,AssignDate,AddUser)
                       values (@AppNo,@Status,@AssignDate,@AddUser) ");
        dw.SetSqlCommandParameters("AppNo", appno);
        dw.SetSqlCommandParameters("Status", Status);
        dw.SetSqlCommandParameters("AssignDate", AssignDate);
        dw.SetSqlCommandParameters("AddUser", Adduser);
        return dw.Insert();
    }

    public DataTable GetFireInsuranseDetails(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from CreditAdmin.FireInsurance where appno=@appno");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();
    }

    public int UpdateFireInsuranse(string Appno, string RefNo, string Institute, string Status, string AssignAmt, DateTime RecieveDate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update FireInsurance set RefNo=@RefNo , Institute=@Institute , Status=@Status , AssignAmt=@AssignAmt ,
                        RecieveDate=@RecieveDate where Appno=@Appno");
        dw.SetSqlCommandParameters("Appno", Appno);
        dw.SetSqlCommandParameters("RefNo", RefNo);
        dw.SetSqlCommandParameters("Institute", Institute);
        dw.SetSqlCommandParameters("Status", Status);
        dw.SetSqlCommandParameters("AssignAmt", AssignAmt);
        dw.SetSqlCommandParameters("RecieveDate", RecieveDate);
        return dw.Update();
    }

    //2009-03-17
    public string GetAprovdAmount(string appno, string acstatus)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select aprovdamt from crmast where appno=@appno and acstatus=@acstatus");
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("acstatus", acstatus);
        return dw.GetSingleData();
    }




    public DataTable GetApprovedDisbDetailsToCancel(string appno, string status)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@" select cracno,transamt
                             from disbbalsum where appno=@appno
                             and transamt <> 0 and grantdate is null 
                             and schedulestatus='C' AND Status=@status");
        dw.SetDataAdapterParameters("appno", appno);
        dw.SetDataAdapterParameters("status", status);
        return dw.GetDataTable();
    }

    //2009-03-19
    public string GetAprovdSumAmount(string appno, string acstatus)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select sum(c.aprovdamt) from crmast c , crcatpurpose cp where c.catpurposeid=cp.catpurposeid 
                        and cp.purposecode=1 and c.appno=@appno and c.acstatus=@acstatus");
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("acstatus", acstatus);
        return dw.GetSingleData();
    }

    public int UpdateIschequePrint(string appno, string chequeNo, bool Ischequeprint)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update ChequePrintDetails set Ischequeprint=@Ischequeprint where appno=@appno and chequeNo=@chequeNo");
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("chequeNo", chequeNo);
        dw.SetSqlCommandParameters("Ischequeprint", Ischequeprint);
        return dw.Update();
    }

    //  20-03-2009 edit bimali/vihanga
    public DataTable GetPreviousDisbCrAcNos(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select d.cracno as cracno,c.intrate as intrate from disbbalsum d, crmast c where 
                        d.grantdate is not null and d.transamt <> 0 and d.grantdate=(select max(grantdate) from disbbalsum
                        where appno=@appno) AND d.isfinalrelease != 'Y' and d.appno=@appno 
                        and d.transno is not null and d.cracno=c.cracno and d.outbal<>0
                        and c.acstatus='A'");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();
    }

    //edit bimali 232/03/2009
    public int CancelInterestInTransAssignWhenComplete(string cracno, string trstatus)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update transassign set trstatus=@trstatus 
                        where cracno=@cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("trstatus", trstatus);
        return dw.Update();
    }

    //edit bimali 23/03/2009
    public DataTable GetInterestAssignedForDisbursement(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select t.cracno from transassign t, disbbalsum d 
                            where d.appno=@appno and d.cracno=t.cracno and (trastatus='N' or trstatus='P')
                            and t.taskid='INTR' and t.transref='DISB'");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();
    }



    //2009-03-23N vihanga
    //public string GetgrntamtFromCrmast(string appno)
    //{
    //    dw = new DataWorksClass(constring);
    //    dw.SetCommand(@"select sum(grantamt) from crmast where appno=@appno and acstatus='A'");
    //    dw.SetSqlCommandParameters("appno", appno);
    //    return dw.GetSingleData();
    //}

    public string GetgrntamtFromCrmast(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select sum(transamt) from disbbalsum where appno=@appno and status='A' and transamt != 0");
        dw.SetSqlCommandParameters("appno", appno);
        return dw.GetSingleData();
    }

    //2009-03-23N vihanga
    public string GetchequeamtFromchequeprintDetails(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select sum(chequeamt) from ChequePrintDetails where appno=@appno and chequestatus='A'");
        dw.SetSqlCommandParameters("appno", appno);
        return dw.GetSingleData();
    }

    //23-03-2009 Dilanka 
    public DataTable GetChqueDeatails(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select appno,chequeno,chequeamt,noofcheque,bankcode,printdate,chequestatus,chequeholdername 
                                   from chequeprintdetails where appno=@appno and printdate=(select max(printdate) 
                                   from chequeprintdetails where appno=@appno)");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();
    }

    //23-03-2009 Dilanka 
    public string GetStatusForCheque(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select chequestatus from ChequePrintDetails where appno=@appno and printdate=(select max(printdate) 
                                from chequeprintdetails where appno=@appno)");
        dw.SetSqlCommandParameters("appno", appno);
        return dw.GetSingleData();
    }

    //25-03-2009  Dilanka
    public DataTable GetPaymentType(string status)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from PaymentMode where status=@status");
        dw.SetDataAdapterParameters("status", status);
        return dw.GetDataTable();
    }


    // 27-03-2009 Dilanka U
    public string GetSeduleStatus(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select ScheduleStatus from DisbBalSum 
                        where appno = @appno and grantdate is null and status='A' group by ScheduleStatus");
        dw.SetSqlCommandParameters("appno", appno);
        return dw.GetSingleData();
    }


    public int UpdateDisbRefNo(long disbrefno, long refno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update TransAssign set disbrefno=@disbrefno where refno=@refno");
        dw.SetSqlCommandParameters("disbrefno", disbrefno);
        dw.SetSqlCommandParameters("refno", refno);
        return dw.Update();
    }


    //public int UpdateDisbRefNoandTrDate(long disbrefno, long refno, DateTime trdate)
    //{
    //    dw = new DataWorksClass(constring);
    //    dw.SetCommand(@"update TransAssign set disbrefno=@disbrefno, trdate=@trdate where refno=@refno");
    //    dw.SetSqlCommandParameters("disbrefno", disbrefno);
    //    dw.SetSqlCommandParameters("refno", refno);
    //    dw.SetSqlCommandParameters("trdate", trdate);
    //    return dw.Update();
    //}


    //Dilanka 31-03-2009
    public DataTable GetChequeDeatails(string chequeno, string ChequeStatus)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from CreditAdmin.ChequePrintDetails where chequeno=@chequeno and ChequeStatus=@ChequeStatus");
        dw.SetDataAdapterParameters("chequeno", chequeno);
        dw.SetDataAdapterParameters("ChequeStatus", ChequeStatus);
        return dw.GetDataTable();
    }

    public int UpdateCancelCheque(string chequeno, string appno, string ChequeStatus)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update ChequePrintDetails set ChequeStatus=@ChequeStatus where chequeno=@chequeno and appno=@appno");
        dw.SetSqlCommandParameters("chequeno", chequeno);
        dw.SetSqlCommandParameters("ChequeStatus", ChequeStatus);
        dw.SetSqlCommandParameters("appno", appno);
        return dw.Update();
    }

    //2009-04-01 Vihanga N
    public int GetNumOfInspectionReports(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select count(appno) from inspectmast where appno=@appno and daterecv is null and inspectionstatus='R'");
        dw.SetSqlCommandParameters("appno", appno);
        return Convert.ToInt32(dw.GetSingleData());
    }

    //2009-04-01 Vihanga N
    public DataTable GetInspectionReportsDetails(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select AppNo,AddDateTime,DateRecv,Remarks from inspectmast where appno=@appno");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();
    }


    //Dilanka   01-04-2009
    public DataTable GetDisbTime(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select Appno,Status,CrAmt,BoqAmount,NoOFDisb,IsApproved from CreditAdmin.CrApp where appno=@appno");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();
    }
    public int UpdateDisbTime(string appno, int NoOFDisbOld, int NoOFDisbNew)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update crapp set NoOFDisb=@NoOFDisbNew where appno=@appno and NoOFDisb=@NoOFDisbOld");
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("NoOFDisbNew", NoOFDisbNew);
        dw.SetSqlCommandParameters("NoOFDisbOld", NoOFDisbOld);
        return dw.Update();
    }

    public double GetOutBal(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select OutBal from DisbBalSum where appno = @appno and grantdate=(select max(grantdate)
                        from disbbalsum where appno=@appno)");
        dw.SetSqlCommandParameters("appno", appno);
        return double.Parse(dw.GetSingleData());
    }

    public string GetChequeBreakAmount(string textline, int breakLength)
    {
        string returntext = "";
        if (textline.Length <= breakLength)
        {
            returntext = textline;
        }
        else
        {
            // int b = 0;
            for (int a = 0; a < textline.Length; a++)
            {
                if (textline.Length <= breakLength)
                {
                    returntext += textline;
                    break;
                }
                else if (textline.Substring(breakLength - 1, 1) == " ")
                {
                    returntext += textline.Substring(a, breakLength - 1) + "*";
                    textline = textline.Substring(breakLength, (textline.Length - breakLength));
                }
                else
                {
                    for (int c = breakLength; c > 1; c--)
                    {
                        if (textline.Substring(c, 1) == " ")
                        {
                            returntext += textline.Substring(0, c) + "*";
                            textline = textline.Substring(c + 1, textline.Length - (c + 1));
                            break;
                        }
                    }
                }
            }
        }

        return returntext;
    }

    //2009-05-13 vihanga**
    public DataTable ConfirmFullyGrant(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select aprovdamt,grantamt,grantdate from crmast  where cracno=@cracno and acstatus='A'");
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }

    //2009-05-25 edit GetChequeDate vihanga
    public string GetChequeDate()
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select (rtrim(day(max(operationdate))) + ' | ' + rtrim(month(max(operationdate))) + ' | ' + 
                        rtrim(year(max(operationdate)))) as operationdate from OperationCalendar where currentstatus='A'");
        return dw.GetSingleData();
    }


    public DataTable GetTransferddisbursement(DateTime date)
    {
        DateTime date1 = date.AddDays(1);
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select appno, ApprovedDate, ApprovedUser, IsToDisburse
                            from ApprovalStatus 
                            where approveddate<=@date1 and approveddate>=@date and Istodisburse =1
                            and appno not in (select appno from DisbBalSum)");
        dw.SetDataAdapterParameters("date", date);
        dw.SetDataAdapterParameters("date1", date1);
        return dw.GetDataTable();
    }

    public DataTable GetSheduleStatusData(DateTime date, string Shedulestatus)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select cracno,appno,transno,grantdate,transamt as DisburesAmt,IsFinalRelease from
                            CreditAdmin.DisbBalSum where Schedulestatus =@Shedulestatus and batchdate=@date
                            and transno is null and transamt != 0");
        dw.SetDataAdapterParameters("date", date);
        dw.SetDataAdapterParameters("Shedulestatus", Shedulestatus);
        return dw.GetDataTable();
    }

    public DataTable GetCompleteDisburesment(DateTime date, string Shedulestatus)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select cracno,appno,transno,grantdate,transamt as DisburesAmt,IsFinalRelease from
                            CreditAdmin.DisbBalSum where Schedulestatus =@Shedulestatus and batchdate=@date
                            and transno is not null and transamt != 0");
        dw.SetDataAdapterParameters("date", date);
        dw.SetDataAdapterParameters("Shedulestatus", Shedulestatus);
        return dw.GetDataTable();
    }

    //- Amila 21/05/2009
    public double GetInterestCalculationForDisbDays(DataRow dr, double outbal)
    {
        AccountPosition a = new AccountPosition();
        //int data = a.GetNoDaysForInterest(DateTime.Parse("12/16/2008"), DateTime.Now);

        FunctionClass fc = new FunctionClass();

        double intForDays;
        int days = 0;

        double intrate = double.Parse(dr["IntRate"].ToString());

        DateTime LastDisbDate = DateTime.Parse(dr["GrantDate"].ToString());
        DateTime today = fc.GetSystemDate("A");
        //TimeSpan t = today.Subtract(LastDisbDate);
        //days = t.Days;
        days = a.GetNoDaysForInterest(LastDisbDate, today);
        intForDays = Math.Round((outbal * days * intrate) / (100 * 365), 2);

        return intForDays;
    }

    // 26-03-2009 bimali - Amila 21/05/2009
    public double GetInterestAmountBeforeInsert(string appno)
    {
        DataRow disbr;
        string cracno;
        double intrate, IntrestAmt = 0;
        DataTable dtCracNo = new DataTable();
        dtCracNo = GetPreviousDisbCrAcNos(appno);
        if (dtCracNo.Rows.Count != 0)
        {
            for (int i = 0; i < dtCracNo.Rows.Count; i++)
            {
                cracno = dtCracNo.Rows[i]["cracno"].ToString();
                disbr = GetDisbursedDetails(cracno);
                double totamt = GetTotalDisbAmt(cracno);
                if (disbr != null)
                {
                    IntrestAmt = GetInterestCalculationForDisbDays(disbr, totamt);
                }
            }
        }
        return IntrestAmt;
    }


    public double GetRemainingInterestAmount(string cracno)
    {
        DataRow disbr;
        double intrate, IntrestAmt = 0;
                
        disbr = GetDisbursedDetails(cracno);
        double totamt = GetTotalDisbAmt(cracno); 
        IntrestAmt = GetInterestCalculationForDisbDays(disbr, totamt);
        return IntrestAmt;
    }


    //2009-05-25 vihanga 
    public DataTable GetLateGrantAppNumbers(DateTime @datetime)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select t1.appno,c.nicno,rtrim(rtrim(initials) + '  ' + rtrim(surname)) as cusName , 
                                rtrim(rtrim(location) + ' , ' + rtrim(street) +' , '+ rtrim(city)) as Address from 
                                (select distinct appno from crmast where aprovdamt <> grantamt and acstatus='A' and grantdate <= @datetime) as t1,
                                customermain c , appholder a where a.appno=t1.appno and c.nicno=a.nicno and a.holdertype='P'");
        dw.SetDataAdapterParameters("datetime", datetime);
        return dw.GetDataTable();
    }


    public double GetintRate(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select intrate from housprop where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        return double.Parse(dw.GetSingleData());
    }
    // new bimali 13/08/2009
    public double GetintRateWithAppNo(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@" select c.intrate as intrate from appcategory a, crmast c
                         where a.appno=@appno and a.catpurposeid=c.catpurposeid
                         and a.appno=c.appno and c.acstatus='A'");
        dw.SetSqlCommandParameters("appno", appno);
        return double.Parse(dw.GetSingleData());
    }


//     public DataTable GetRemainingLoans(DateTime datetime)
//    {
//        dw = new DataWorksClass(constring);
//        dw.SetDataAdapter(@"select cracno,appno,max(grantdate) as grantdate from disbbalsum where isfinalrelease = 'N' and transamt != 0 and 
//                           grantdate < @datetime
//                           group by cracno, appno order by grantdate,cracno, appno");
//        dw.SetDataAdapterParameters("datetime", datetime);
//        return dw.GetDataTable();
//    }

 

	public DataTable GetRemainingLoans(DateTime fromdate)
      {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select c.cracno,c.appno,CONVERT(VARCHAR(10), c.grantdate, 103) AS grantdate  from crmast c, housprop h
                            where c.cracno=h.cracno and
                            h.actoutbal > 0 and datediff(day,grantdate,@fromdate) > 90
                            and aprovdamt != grantamt and c.CrAcNo in (select CrAcNo from DisbBalSum
                            where TransNo is Not null and Status='A') order by c.cracno");
        dw.SetDataAdapterParameters("fromdate", fromdate);
        return dw.GetDataTable();
       }



     public DataTable GetRemainingLoanDetails(string cracno, double IntAmt)
     {
         dw = new DataWorksClass(constring);
         dw.SetDataAdapter(@"select distinct rtrim(t.titledesc + ' '+ rtrim(c.initials) + ' '+ rtrim(c.surname)) as Name,
                             c.location, c.street, c.city,d.cracno,cm.aprovdamt,@IntAmt as InterestAmount, cm.GrantAmt from crholder cr, customermain c, crmast cm,
                             title t, disbbalsum d where t.titlecode=c.titlecode and cr.holdertype='P' and 
                             c.nicno=cr.nicno and d.cracno=cr.cracno and cm.cracno=cr.cracno and cr.cracno=@cracno");
         dw.SetDataAdapterParameters("cracno", cracno);
         dw.SetDataAdapterParameters("IntAmt", IntAmt);
         return dw.GetDataTable();
     }

     public int UpdateIsRemSent(string cracno)
     {
         dw = new DataWorksClass(constring);
         dw.SetCommand(@"update housprop set IsRemSent=1 where cracno=@cracno");
         dw.SetSqlCommandParameters("cracno", cracno);
         return dw.Update();
     }

     public int GetCrCatPurposeId(string crcatcode, string purposecode)
     {
         dw = new DataWorksClass(constring);
         dw.SetCommand(@" select catpurposeid from CrCatPurpose where crcatcode=@crcatcode 
                          and purposecode=@purposecode");
         dw.SetSqlCommandParameters("crcatcode", crcatcode);
         dw.SetSqlCommandParameters("purposecode", purposecode);
         return int.Parse(dw.GetSingleData());
     }

     public double GetTransAmtinDisbbalsum(string cracno)
     {
         dw = new DataWorksClass(constring);
         dw.SetCommand(@" select isnull(sum(transamt),0) as grantamt from 
                          disbbalsum where cracno=@cracno
                          and transamt != 0 and status='A'");
         dw.SetSqlCommandParameters("cracno", cracno);
         return double.Parse(dw.GetSingleData());
     }

     public DataTable GetAllCrAcNos(string appno)
     {
         dw = new DataWorksClass(constring);
         dw.SetDataAdapter(@"select cracno from crmast where 
                            appno=@appno and acstatus='A'");
         dw.SetDataAdapterParameters("appno", appno);
         return dw.GetDataTable();
     }

     public DataTable GetDisbDetailsToupdate(string cracno, DateTime batchdate)
     {
         dw = new DataWorksClass(constring);
         dw.SetDataAdapter(@"select c.intrate,c.grantamt,crperiod,c.crcat 
                            from disbbalsum d, crmast c where 
                            c.cracno=@cracno and c.cracno=d.cracno
                            and d.transamt!=0
                            and d.batchdate=@batchdate and c.acstatus='A' and d.status='A'");
         dw.SetDataAdapterParameters("cracno", cracno);
         dw.SetDataAdapterParameters("batchdate", batchdate);
         return dw.GetDataTable();
     }

     public DataTable GetFinalReleaseData(string appno, DateTime grantdate)
     {
         dw = new DataWorksClass(constring);
         dw.SetDataAdapter(@"select c.cracno,c.grantamt,c.grantdate,c.instalment,h.nicno,
                            rtrim(rtrim(t.titledesc) + ' ' + rtrim(cm.initials) + ' ' + rtrim(cm.surname)) as CustName,
                            rtrim(rtrim(cm.location) + ', ' + rtrim(cm.street) + ', ') as Address1,cm.city
                            from crmast c,crholder h,customermain cm,title t
                            where c.cracno in (select cracno from disbbalsum where 
                            appno=@appno and grantdate=@grantdate 
                            and isfinalrelease='Y' and transamt<>0) and c.cracno=h.cracno and holdertype='P' and 
                            c.aprovdamt=c.grantamt and cm.nicno=h.nicno and cm.titlecode=t.titlecode");
         dw.SetDataAdapterParameters("appno",appno);
         dw.SetDataAdapterParameters("grantdate", grantdate);
         return dw.GetDataTable();
     }

     public int InsertLoanFloatingRates(string AppNo, string CrAcNo, double ApprovedAmt, double LoanAmt, double CurrentIntRate,
                                        double NewIntRate, string DisbursedStatus)
     {
         dw = new DataWorksClass(constring);
         dw.SetCommand(@"INSERT INTO LoanFloatingRates(AppNo,CrAcNo,ApprovedAmt,LoanAmt, CurrentIntRate,NewIntRate,DisbursedStatus)
                      VALUES (@AppNo,@CrAcNo,@ApprovedAmt,@LoanAmt,@CurrentIntRate,@NewIntRate,@DisbursedStatus)");
         dw.SetSqlCommandParameters("AppNo", AppNo);
         dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
         dw.SetSqlCommandParameters("ApprovedAmt", ApprovedAmt);
         dw.SetSqlCommandParameters("LoanAmt", LoanAmt);
         dw.SetSqlCommandParameters("CurrentIntRate", CurrentIntRate);
         dw.SetSqlCommandParameters("NewIntRate", NewIntRate);
         dw.SetSqlCommandParameters("DisbursedStatus", DisbursedStatus);
         return dw.Insert();
     }

     public int GetPurposeCode(string appno)
     {
         dw = new DataWorksClass(constring);
         dw.SetCommand(@"select distinct purposecode from CrMast C, CrCatPurpose P 
                         where Appno = @appno
                         and C.CatPurposeId = P.catpurposeid");
         dw.SetSqlCommandParameters("appno", appno);
         return int.Parse(dw.GetSingleData());
     }

     public DataTable GetBuddhiLoanDetails(string appno)
     {
         dw = new DataWorksClass(constring);
         dw.SetDataAdapter(@"select C.CrAcNo, H.IntRate, H.Instalment, H.CrPeriod, H.GracePeriod 
                            from CrMast C, HousProp H where GrantAmt=0.00 and Aprovdamt != 0.00 
                            and Appno=@appno and C.CrAcNo = H.CrAcNo");
         dw.SetDataAdapterParameters("appno", appno);
         return dw.GetDataTable();
     }

     public int UpdateBuddhiLoanGrace(string cracno, int graceperiod)
     {
         dw = new DataWorksClass(constring);
         dw.SetCommand(@"update housprop set graceperiod=@graceperiod where cracno=@cracno");
         dw.SetSqlCommandParameters("cracno", cracno);
         dw.SetSqlCommandParameters("graceperiod", graceperiod);
         return dw.Update();
     }

     public DataTable GetNotFullyDisbursed(string appno)
     {
         dw = new DataWorksClass(constring);
         dw.SetDataAdapter(@"select * from CrMast where AppNo=@appno and Aprovdamt!=GrantAmt");
         dw.SetDataAdapterParameters("appno", appno);
         return dw.GetDataTable();
     }

     public double GetRecoveredInt(string appno)
     {
         dw = new DataWorksClass(constring);
         dw.SetCommand(@"select (select ISNULL(SUM(TrAmt),0) from TransAssign T, 
                        CrMast C where T.CrAcNo=C.CrAcNo 
                        and C.Appno=@appno and TaskID='INTR'
                        and TrType = 'I' and T.Trdate > C.GrantDate and TrStatus != 'C')-
                        (select ISNULL(SUM(TrAmt),0) from TransAssign T, 
                        CrMast C where T.CrAcNo=C.CrAcNo 
                        and C.Appno=@appno and TaskID='INTR'
                        and TrType = 'E' and T.Trdate > C.GrantDate and TrStatus != 'C') as InterestRecovered
                        ");
         dw.SetSqlCommandParameters("appno", appno);
         return double.Parse(dw.GetSingleData());
     }
}
