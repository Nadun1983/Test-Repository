using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for GlCodesGenerator
/// </summary>
public class GlCodesGenerator
{
    private string constring = ConfigurationManager.ConnectionStrings["housdbString"].ToString();
    DataWorksClass dw; // dataworks class
    LastSerialClass ls; // last serial class
    FunctionClass fc; // function class

    //public GlCodesGenerator()
    //{
    //    //
    //    // TODO: Add constructor logic here
    //    //
    //}

    private DataTable GetCrCategory()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from CrCategory where CrCatCode!=0");
        return dw.GetDataTable();
    }


    private DataTable GetCrCategorygl()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from CrCategory");
        return dw.GetDataTable();
    }


    private DataTable GetTransCat(int listorder, bool isglaccount)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from TransCat WHERE listorder = @listorder and isglaccount=@isglaccount");
        dw.SetDataAdapterParameters("listorder", listorder);
        dw.SetDataAdapterParameters("isglaccount", isglaccount);
        return dw.GetDataTable();
    }


    private DataTable GetCategory()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from Category");
        return dw.GetDataTable();
    }


    private DataTable GetLoanStatus()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from LoanStatus where statusid!=0");
        return dw.GetDataTable();
    }

    private DataTable GetLoanStatusGL()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from LoanStatus ");
        return dw.GetDataTable();
    }


    private DataTable GetNsb_Branch()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from nsb_branch");
        return dw.GetDataTable();
    }

    private DataTable GetExtraField()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from ExtraField");
        return dw.GetDataTable();
    }



    private DataTable GetLoan()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from Loan");
        return dw.GetDataTable();
    }

    private DataTable GetPaymentMode()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from paymentmode where paymentid!=0");
        return dw.GetDataTable();
    }

    private DataTable GetPaymentMode(int ListOrder)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from paymentmode where ListOrder=@ListOrder");
        dw.SetDataAdapterParameters("ListOrder", ListOrder);
        return dw.GetDataTable();
    }

    private DataTable GetSerial(string CategoryID, string LoanCategoryID, string Loan, string LoanStatus)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from LoanSerial where CategoryID = @CategoryID 
                          and LoanCategoryID =@LoanCategoryID and Loan=@Loan and LoanStatus=@LoanStatus ");
        dw.SetDataAdapterParameters("CategoryID", CategoryID);
        dw.SetDataAdapterParameters("LoanCategoryID", LoanCategoryID);
        dw.SetDataAdapterParameters("Loan", Loan);
        dw.SetDataAdapterParameters("LoanStatus", LoanStatus);
        return dw.GetDataTable();
    }

    private DataTable GetSerial()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from LoanSerial ");
        return dw.GetDataTable();
    }

    private int InsertGLCode(string RefGlCode, string glcode, string CurBal, DateTime LastTrDate, string Status, string GlDesc)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO GlCode (RefGlCode, glcode, CurBal,LastTrDate,Status,GlDesc)
                            VALUES (@RefGlCode, @glcode, @CurBal,@LastTrDate,@Status,@GlDesc)");
        dw.SetSqlCommandParameters("glcode", glcode);
        dw.SetSqlCommandParameters("RefGlCode", RefGlCode);
        dw.SetSqlCommandParameters("CurBal", CurBal);
        dw.SetSqlCommandParameters("LastTrDate", LastTrDate);
        dw.SetSqlCommandParameters("Status", Status);
        dw.SetSqlCommandParameters("GlDesc", GlDesc);
        return dw.Insert();
    }

    private int InsertTransParam(string TaskID, int Loan, int Category, int LoanCategory, int Status, int ExtraField, int SerialNo,
          string AcRef, int PaymentMode, decimal Factor, string Accsign)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@" INSERT INTO TransParam (TaskID,Loan,Category,LoanCategory,Status,SerialNo,AcRef,PaymentMode,Factor,Accsign, ExtraField)
                            VALUES (@TaskID,@Loan,@Category,@LoanCategory,@Status,@SerialNo,@AcRef,@PaymentMode,@Factor,@Accsign,@ExtraField)");
        dw.SetSqlCommandParameters("TaskID", TaskID);
        dw.SetSqlCommandParameters("Loan", Loan);
        dw.SetSqlCommandParameters("Category", Category);
        dw.SetSqlCommandParameters("LoanCategory", LoanCategory);
        dw.SetSqlCommandParameters("Status", Status);
        dw.SetSqlCommandParameters("SerialNo", SerialNo);
        dw.SetSqlCommandParameters("AcRef", AcRef);
        dw.SetSqlCommandParameters("PaymentMode", PaymentMode);
        dw.SetSqlCommandParameters("Factor", Factor);
        dw.SetSqlCommandParameters("Accsign", Accsign);
        dw.SetSqlCommandParameters("ExtraField", ExtraField);
        return dw.Insert();
    }

    private int InsertLoanSerial(int serialNo, string taskid, string Description, string status, int loan, int categoryid, int loanCategoryid,
          int loanStatus, int extraField,string transRef,string accSign,bool isInList)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@" INSERT INTO LoanSerial(serialNo,taskid,Description,status,loan,categoryid,loanCategoryid,loanStatus,extraField,transRef,accSign,isInList)
                            VALUES (@serialNo,@taskid,@Description,@status,@loan,@categoryid,@loanCategoryid,@loanStatus,@extraField,@transRef,@accSign,@isInList)");
        dw.SetSqlCommandParameters("serialNo", serialNo);
        dw.SetSqlCommandParameters("taskid", taskid);
        dw.SetSqlCommandParameters("Description", Description);
        dw.SetSqlCommandParameters("status", status);
        dw.SetSqlCommandParameters("loan", loan);
        dw.SetSqlCommandParameters("categoryid", categoryid);
        dw.SetSqlCommandParameters("loanCategoryid", loanCategoryid);
        dw.SetSqlCommandParameters("loanStatus", loanStatus);
        dw.SetSqlCommandParameters("extraField", extraField);
        dw.SetSqlCommandParameters("transRef", transRef);
        dw.SetSqlCommandParameters("accSign", accSign);
        dw.SetSqlCommandParameters("isInList", isInList);
        return dw.Insert();
    }

    public int GenerateGLCodes()
    {
        fc = new FunctionClass();
        DataTable loan, branch, category, loancategory, loanstatus, extrafield, serial;
        loan = new DataTable();
        branch = new DataTable();
        category = new DataTable();
        loancategory = new DataTable();
        loanstatus = new DataTable();
        extrafield = new DataTable();
        serial = new DataTable();

        loan = GetLoan();
        branch = GetNsb_Branch();
        category = GetCategory();
        loancategory = GetCrCategorygl();
        loanstatus = GetLoanStatusGL();
        extrafield = GetExtraField();

        int noofrows = 0;

        for (int q = 0; loan.Rows.Count > q; q++)
        {
            string loanno = int.Parse(loan.Rows[q]["loanid"].ToString()).ToString("0");
            string loandes = loan.Rows[q]["Description"].ToString().Trim();
            for (int w = 0; branch.Rows.Count > w; w++)
            {
                string branchno = int.Parse(branch.Rows[w]["BranchNo"].ToString()).ToString("0000");
                string branchdes = branch.Rows[w]["BranchName"].ToString().Trim();
                for (int e = 0; category.Rows.Count > e; e++)
                {
                    string categoryno = int.Parse(category.Rows[e]["CategeryId"].ToString()).ToString("0");
                    string categorydes = category.Rows[e]["Description"].ToString().Trim();
                    for (int r = 0; loancategory.Rows.Count > r; r++)
                    {
                        string loancategoryno = int.Parse(loancategory.Rows[r]["crcatcode"].ToString()).ToString("00");
                        string loancategorydes = loancategory.Rows[r]["CrDes"].ToString().Trim();

                        for (int t = 0; loanstatus.Rows.Count > t; t++)
                        {
                            string statusid = int.Parse(loanstatus.Rows[t]["statusid"].ToString()).ToString("0");
                            string statusdes = loanstatus.Rows[t]["StatusName"].ToString().Trim();
                            for (int y = 0; extrafield.Rows.Count > y; y++)
                            {
                                string ExtraFieldId = int.Parse(extrafield.Rows[y]["ExtraFieldId"].ToString()).ToString("00");
                                string Extrafirlddes = extrafield.Rows[y]["Description"].ToString().Trim();

                                serial = GetSerial(categoryno, loancategoryno, loanno, statusid);
                                if (serial.Rows.Count != 0)
                                {
                                    for (int u = 0; serial.Rows.Count > u; u++)
                                    {
                                        string serialno = int.Parse(serial.Rows[u]["SerialNo"].ToString()).ToString("000");
                                        string serialdesc = serial.Rows[u]["Description"].ToString().Trim();
                                        string taskid = serial.Rows[u]["TaskID"].ToString();
                                        string refglcode = loanno + branchno + categoryno + loancategoryno + statusid + ExtraFieldId + serialno;
                                        string glcode = loanno + branchno + categoryno + loancategoryno + statusid + serialno.Remove(0, 1);
                                        refglcode += fc.GetModuler10(refglcode);
                                        glcode += fc.GetModuler10(glcode);
                                        DateTime date = fc.GetSystemDate("A");
                                        string GlDesc = loandes + " " + branchdes + " " + categorydes + " " + loancategorydes + " "
                                             + statusdes + " " + Extrafirlddes + " " + serialdesc;
                                        InsertGLCode(refglcode, glcode, "0", date, "A", GlDesc);
                                    }
                                }
                            }

                        }

                    }

                }

            }

        }

        return noofrows;
    }


    public int GenerateLOanSerial(int listorder)
    {
       
        fc = new FunctionClass();
        DataTable loan, branch, category, loancategory, loanstatus, extrafield, serial, transcat;
        loan = new DataTable();
        branch = new DataTable();
        category = new DataTable();
        loancategory = new DataTable();
        loanstatus = new DataTable();
        extrafield = new DataTable();
        serial = new DataTable();
        transcat = new DataTable();

        loan = GetLoan();
        branch = GetNsb_Branch();
        category = GetCategory();
        loancategory = GetCrCategory();
        loanstatus = GetLoanStatus();
        extrafield = GetExtraField();
        transcat = GetTransCat(listorder, true);
        int noofrows = 0;

        for (int q = 0; loan.Rows.Count > q; q++)
        {
            int loanno = int.Parse(loan.Rows[q]["loanid"].ToString());

            for (int w = 0; transcat.Rows.Count > w; w++)
            {
                string taskid = transcat.Rows[w]["taskid"].ToString();

                string transref = transcat.Rows[w]["transref"].ToString();
                string description = transcat.Rows[w]["Description"].ToString();
                int categoryid = int.Parse(transcat.Rows[w]["categoryid"].ToString());
                bool BasedOnLoans = bool.Parse(transcat.Rows[w]["BasedOnLoans"].ToString());
                bool BasedOnStatus = bool.Parse(transcat.Rows[w]["BasedOnStatus"].ToString());
                string BasedOnIncome = transcat.Rows[w]["BasedOnIncome"].ToString();

                int loancategoryno = 0;
                int loanstatusno = 0;
                int extrafieldno = 0;
                int serialno = 1;
                if (BasedOnLoans)
                {
                    for (int e = 0; loancategory.Rows.Count > e; e++)
                    {
                        loancategoryno = int.Parse(loancategory.Rows[e]["CrCatCode"].ToString());
                        if (BasedOnStatus)
                        {
                            for (int r = 0; loanstatus.Rows.Count > r; r++)
                            {
                                loanstatusno = int.Parse(loanstatus.Rows[r]["StatusId"].ToString());
                                switch (BasedOnIncome)
                                {
                                    case "I":
                                        serialno = GetMaxNumber(loanno, categoryid, loancategoryno, loanstatusno, extrafieldno);
                                        InsertLoanSerial(serialno, taskid, description, "A", loanno, categoryid, loancategoryno, loanstatusno, extrafieldno, transref, "I", true);
                                        break;


                                    case "E":
                                        serialno = GetMaxNumber(loanno, categoryid, loancategoryno, loanstatusno, extrafieldno);
                                        InsertLoanSerial(serialno, taskid, description, "A", loanno, categoryid, loancategoryno, loanstatusno, extrafieldno, transref, "I", true);
                                        break;

                                    case "B":
                                        serialno = GetMaxNumber(loanno, categoryid, loancategoryno, loanstatusno, extrafieldno);
                                        InsertLoanSerial(serialno, taskid, description, "A", loanno, categoryid, loancategoryno, loanstatusno, extrafieldno, transref, "I", true);
                                        InsertLoanSerial(serialno, taskid, description, "A", loanno, categoryid, loancategoryno, loanstatusno, extrafieldno, transref, "E", true);
                                        break;
                                }
                            }

                        }
                        else
                        {
                            loanstatusno = 0;
                            switch (BasedOnIncome)
                            {
                                case "I":
                                    serialno = GetMaxNumber(loanno, categoryid, loancategoryno, loanstatusno, extrafieldno);
                                    InsertLoanSerial(serialno, taskid, description, "A", loanno, categoryid, loancategoryno, loanstatusno, extrafieldno, transref, "I", true);
                                    break;


                                case "E":
                                    serialno = GetMaxNumber(loanno, categoryid, loancategoryno, loanstatusno, extrafieldno);
                                    InsertLoanSerial(serialno, taskid, description, "A", loanno, categoryid, loancategoryno, loanstatusno, extrafieldno, transref, "I", true);
                                    break;

                                case "B":
                                    serialno = GetMaxNumber(loanno, categoryid, loancategoryno, loanstatusno, extrafieldno);
                                    InsertLoanSerial(serialno, taskid, description, "A", loanno, categoryid, loancategoryno, loanstatusno, extrafieldno, transref, "I", true);
                                    InsertLoanSerial(serialno, taskid, description, "A", loanno, categoryid, loancategoryno, loanstatusno, extrafieldno, transref, "E", true);
                                    break;
                            }

                        }
                    }
                }
                else
                {
                    loancategoryno = 0;
                    loanstatusno = 0;
                    switch (BasedOnIncome)
                    {
                           
                        case "I":
                            serialno = GetMaxNumber(loanno, categoryid, loancategoryno, loanstatusno, extrafieldno);
                            InsertLoanSerial(serialno, taskid, description, "A", loanno, categoryid, loancategoryno, loanstatusno, extrafieldno, transref, "I", true);
                            break;


                        case "E":
                            serialno = GetMaxNumber(loanno, categoryid, loancategoryno, loanstatusno, extrafieldno);
                            InsertLoanSerial(serialno, taskid, description, "A", loanno, categoryid, loancategoryno, loanstatusno, extrafieldno, transref, "I", true);
                            break;

                        case "B":
                            serialno = GetMaxNumber(loanno, categoryid, loancategoryno, loanstatusno, extrafieldno);
                            InsertLoanSerial(serialno, taskid, description, "A", loanno, categoryid, loancategoryno, loanstatusno, extrafieldno, transref, "I", true);
                            InsertLoanSerial(serialno, taskid, description, "A", loanno, categoryid, loancategoryno, loanstatusno, extrafieldno, transref, "E", true);
                            break;
                    }

                }
            }


            //InsertLoanSerial(0,taskid, description, "A", loanno, categoryid, 14, 4, 0, transref,  
        }
                return noofrows;
  
            
            
            
       
        //        for (int e = 0; category.Rows.Count > e; e++)
        //        {
        //            string categoryno = int.Parse(category.Rows[e]["CategeryId"].ToString()).ToString("0");
        //            string categorydes = category.Rows[e]["Description"].ToString().Trim();
        //            for (int r = 0; loancategory.Rows.Count > r; r++)
        //            {
        //                string loancategoryno = int.Parse(loancategory.Rows[r]["crcatcode"].ToString()).ToString("00");
        //                string loancategorydes = loancategory.Rows[r]["CrDes"].ToString().Trim();

        //                for (int t = 0; loanstatus.Rows.Count > t; t++)
        //                {
        //                    string statusid = int.Parse(loanstatus.Rows[t]["statusid"].ToString()).ToString("0");
        //                    string statusdes = loanstatus.Rows[t]["StatusName"].ToString().Trim();
        //                    for (int y = 0; extrafield.Rows.Count > y; y++)
        //                    {
        //                        string ExtraFieldId = int.Parse(extrafield.Rows[y]["ExtraFieldId"].ToString()).ToString("00");
        //                        string Extrafirlddes = extrafield.Rows[y]["Description"].ToString().Trim();

        //                        serial = GetSerial(categoryno, loancategoryno, loanno, statusid);
        //                        if (serial.Rows.Count != 0)
        //                        {
        //                            for (int u = 0; serial.Rows.Count > u; u++)
        //                            {
        //                                string serialno = int.Parse(serial.Rows[u]["SerialNo"].ToString()).ToString("000");
        //                                string serialdesc = serial.Rows[u]["Description"].ToString().Trim();
        //                                string taskid = serial.Rows[u]["TaskID"].ToString();
        //                                string refglcode = loanno + branchno + categoryno + loancategoryno + statusid + ExtraFieldId + serialno;
        //                                string glcode = loanno + branchno + categoryno + loancategoryno + statusid + serialno.Remove(0, 1);
        //                                refglcode += fc.GetModuler10(refglcode);
        //                                glcode += fc.GetModuler10(glcode);
        //                                DateTime date = fc.GetSystemDate("A");
        //                                string GlDesc = loandes + " " + branchdes + " " + categorydes + " " + loancategorydes + " "
        //                                     + statusdes + " " + Extrafirlddes + " " + serialdesc;
        //                                InsertGLCode(refglcode, glcode, "0", date, "A", GlDesc, taskid);
        //                            }
        //                        }
        //                    }

        //                }

        //            }

        //        }

        //    }

        //}

    }

    private int GetMaxNumber(int loan, int CategoryID, int LoanCategoryID, int LoanStatus, int ExtraField)
    {
        int serialno = 0;
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select max(serialNo) from loanserial where 
                        loan=@loan and 
                        CategoryID=@CategoryID and 
                        LoanCategoryID=@LoanCategoryID and 
                        LoanStatus=@LoanStatus and 
                        ExtraField=@ExtraField");
        dw.SetSqlCommandParameters("loan", loan);
        dw.SetSqlCommandParameters("CategoryID", CategoryID);
        dw.SetSqlCommandParameters("LoanCategoryID", LoanCategoryID);
        dw.SetSqlCommandParameters("LoanStatus", LoanStatus);
        dw.SetSqlCommandParameters("ExtraField", ExtraField);
        serialno = int.Parse(dw.GetSingleData());
        return serialno + 1;
    }



    //Identifieng payments modes
    public int GetPaymentTypes()
    {
        fc = new FunctionClass();
        DataTable loan, branch, category, loancategory, loanstatus, extrafield, serial, paymentmode;
        loan = new DataTable();
        branch = new DataTable();
        category = new DataTable();
        loancategory = new DataTable();
        loanstatus = new DataTable();
        extrafield = new DataTable();
        serial = new DataTable();
        paymentmode = new DataTable();

        serial = GetSerial();
        paymentmode = GetPaymentMode();

        for (int w = 0; paymentmode.Rows.Count > w; w++)
        {
            int paymentmodeno = int.Parse(paymentmode.Rows[w]["PaymentId"].ToString());
            int pmserial = int.Parse(paymentmode.Rows[w]["serial"].ToString());
            for (int q = 0; serial.Rows.Count > q; q++)
            {
                string taskid = serial.Rows[q]["taskid"].ToString();
                int loanno = 9;
                int categoryno = int.Parse(serial.Rows[q]["categoryid"].ToString());
                int loancategoryno = int.Parse(serial.Rows[q]["loancategoryid"].ToString());
                int statusno = int.Parse(serial.Rows[q]["loanstatus"].ToString());
                int extrafieldno = int.Parse(serial.Rows[q]["Extrafield"].ToString());
                int serialno = int.Parse(serial.Rows[q]["serialno"].ToString());
                if (serialno == 52)
                {
                    //
                }
                string transref = serial.Rows[q]["transref"].ToString();

                switch (taskid.Length)
                {
                    case 4:
                        taskid = taskid + loanno.ToString("0") + loancategoryno.ToString("00") + statusno.ToString("0") + extrafieldno.ToString("00") + paymentmodeno.ToString("0") + "I";
                        break;

                    case 10:
                        taskid = taskid + paymentmodeno + "I";
                        break;
                }

                    //{
                //case "APPN":
                //Insert Loan Account
                InsertTransParam(taskid, loanno, categoryno, loancategoryno, statusno, extrafieldno, serialno, transref, paymentmodeno, 1, "CR");
                //For Loan Account References
                InsertTransParam(taskid, loanno, categoryno, loancategoryno, statusno, extrafieldno, serialno, "GLAC", paymentmodeno, 1, "CR");
                //GL Mirror Account
                InsertTransParam(taskid, loanno, 1, 0, 0, 0, pmserial, "GLAC", paymentmodeno, 1, "DR");
                //    break;
                //case "RECV":
                //    InsertTransParam(taskid, loanno, 0, loancategoryno, statusno, 0, refacc, paymentmodeno, 1, "CR");
                //    InsertTransParam(taskid, loanno, categoryno, loancategoryno, statusno, serialno, "GLAC", paymentmodeno, 1, "CR");
                //    InsertTransParam(taskid, loanno, 2, loancategoryno, statusno, pmserial, "GLAC", paymentmodeno, 1, "DR");
                //    break;
                //}

                // ** vihanga ** 2009-03-02 #Rows=4 Begin
                taskid = taskid.Remove(11) + "E";
                //Insert Loan Account
                InsertTransParam(taskid, loanno, categoryno, loancategoryno, statusno, extrafieldno, serialno, transref, paymentmodeno, 1, "DR");
                //For Loan Account References
                InsertTransParam(taskid, loanno, categoryno, loancategoryno, statusno, extrafieldno, serialno, "GLAC", paymentmodeno, 1, "DR");
                //GL Mirror Account
                InsertTransParam(taskid, loanno, 1, 0, 0, 0, pmserial, "GLAC", paymentmodeno, 1, "CR");
                // ** vihanga ** 2009-03-02 #Rows=4 End


            }
        }
        return 0;
    }



    //Identifieng payments modes
    public int GetTransactionGLAaccounts()
    {
        DataTable branch, paymentmode;
        fc = new FunctionClass();
        branch = new DataTable();
        paymentmode = new DataTable();

        branch = GetNsb_Branch();
        paymentmode = GetPaymentMode(0);

        for (int w = 0; paymentmode.Rows.Count > w; w++)
        {
            int paymentmodeno = int.Parse(paymentmode.Rows[w]["PaymentId"].ToString());
            int pmserial = int.Parse(paymentmode.Rows[w]["serial"].ToString());
            string paymentdescription = paymentmode.Rows[w]["GLDescription"].ToString();
            string category = paymentmode.Rows[w]["category"].ToString();
            for (int q = 0; branch.Rows.Count > q; q++)
            {
                string branchcode = int.Parse(branch.Rows[q]["BranchNo"].ToString()).ToString("0000");
                string branchname = branch.Rows[q]["BranchName"].ToString().Trim();
                string transrefglcode = "9" + branchcode + category+ "00000"+ pmserial.ToString("000");
                string transglcode = "9" + branchcode + category+ "000"+ pmserial.ToString("00");
                transrefglcode = transrefglcode + fc.GetModuler10(transrefglcode);
                transglcode = transglcode + fc.GetModuler10(transglcode);
                string des="";
                switch (category)
                {
                    case "2":
                        des = "Liability";
                        break;

                    case "1":
                        des = "Asset";
                        break;
                }
                InsertGLCode(transrefglcode, transglcode, "0", DateTime.Now, "A", "Gl Account " + branchname + " " + des+" "+ paymentdescription);
            }
        }
        return 0;
    }


    private DataTable GetNPLSeries(string taskid)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from LoanSerial where taskid = @taskid");
        dw.SetDataAdapterParameters("taskid", taskid);
        return dw.GetDataTable();
    }


    private DataTable GetOtherKeyVal(string keyval)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from LoanStatus where keyval != @keyval and StatusID!=0");
        dw.SetDataAdapterParameters("keyval", keyval);
        return dw.GetDataTable();
    }



    public int GetNPLTransactions()
    {
        DataTable loancategory, status, otherstatus;
        fc = new FunctionClass();
        loancategory = new DataTable();

        loancategory = GetCrCategory();
        status = GetLoanStatus();


        for (int w = 0; loancategory.Rows.Count > w; w++)
        {
            string taskid = "NPLC";
            string transref = "NPLT";
            int loanno = 9;
            int categoryno = 1;
            int loancategoryno = int.Parse(loancategory.Rows[w]["crcatcode"].ToString());


            for (int e=0; status.Rows.Count > e; e++)
            {
                int statusno = int.Parse(status.Rows[e]["statusid"].ToString());
                string keyval = status.Rows[e]["keyval"].ToString();
                int extrafieldno = 0;
                int serialno = 1;

                taskid = taskid + loanno.ToString("0") + loancategoryno.ToString("00") + extrafieldno.ToString("00") + keyval;
                //
                otherstatus = new DataTable();
                otherstatus = GetOtherKeyVal(keyval);
                for (int r = 0; otherstatus.Rows.Count > r; r++)
                {
                    string otherkeyval = otherstatus.Rows[r]["keyval"].ToString();
                    int otherstatusno = int.Parse(otherstatus.Rows[r]["statusid"].ToString());
                    if (taskid.Length > 10)
                    {
                        taskid = taskid.Substring(0, 10);
                    }
                   
                    taskid += otherkeyval;
                    

                    InsertTransParam(taskid, loanno, categoryno, loancategoryno, statusno, extrafieldno, serialno, transref, 0, 1, "CR");
                    //
                    InsertTransParam(taskid, loanno, categoryno, loancategoryno, otherstatusno, extrafieldno, serialno, transref, 0, 1, "DR");
                }
                taskid = "NPLC";
            }

        }
        //}
        return 0;
    }

    public string GetGlName(string refglcode)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select gldesc from glcode where refglcode=@refglcode");
        dw.SetSqlCommandParameters("refglcode", refglcode);
        return dw.GetSingleData();
    }


    public bool GetGLTaskNames(string taskid)
    {
        DataTable dt = new DataTable();
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from transcat where left(taskid,4) = @taskid");
        dw.SetDataAdapterParameters("taskid", taskid);
        dt = dw.GetDataTable();

        if (dt.Rows.Count > 0)
            return true;
        else
            return false;
    }

    public DataTable GetNewTranscatData(string TaskId, string ListOrder, string IsGLAccount, string TransRef, 
        string Description, string CategoryId, string Status, string ValueType, string Types, string UnitCharge, 
        string PriorityList, string BasedOnLoans, string BasedOnStatus, string BasedOnIncome)
    {
        DataTable dt = new DataTable();
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"SELECT @TaskId as taskid ,@ListOrder as ListOrder ,@IsGLAccount as IsGLAccount  ,@TransRef as  TransRef ,@Description as Description ,@CategoryId as CategoryId ,@Status as Status ,@ValueType as ValueType ,@Types as Type ,@UnitCharge as UnitCharge  ,@PriorityList as PriorityList ,@BasedOnLoans as BasedOnLoans ,@BasedOnStatus as BasedOnStatus ,@BasedOnIncome as BasedOnIncome");
        dw.SetDataAdapterParameters("TaskId", TaskId);
        dw.SetDataAdapterParameters("ListOrder", ListOrder);
        dw.SetDataAdapterParameters("IsGLAccount", IsGLAccount);
        dw.SetDataAdapterParameters("TransRef", TransRef);
        dw.SetDataAdapterParameters("Description", Description);
        dw.SetDataAdapterParameters("CategoryId", CategoryId);
        dw.SetDataAdapterParameters("ValueType", ValueType);
        dw.SetDataAdapterParameters("Types", Types);
        dw.SetDataAdapterParameters("Status", Status);
        dw.SetDataAdapterParameters("UnitCharge", UnitCharge);
        dw.SetDataAdapterParameters("PriorityList", PriorityList);
        dw.SetDataAdapterParameters("BasedOnLoans", BasedOnLoans);
        dw.SetDataAdapterParameters("BasedOnStatus", BasedOnStatus);
        dw.SetDataAdapterParameters("BasedOnIncome", BasedOnIncome);
        return dw.GetDataTable();
    }

    public int GenerateLOanSerial(int categoryid,string taskid,string description,string transref)
    {
        int loanno = 9;
        int loancategoryno = 0;
        int loanstatusno = 0;
        int extrafieldno =0;
        int serialno;

        serialno = GetMaxNumber(loanno, categoryid, loancategoryno, loanstatusno, extrafieldno);
        InsertLoanSerial(serialno, taskid, description, "A", loanno, categoryid, loancategoryno, loanstatusno, extrafieldno, transref, "I", true);
        return serialno;
    }

    public string GenerateGLCodes(int serno, string serialdesc, string taskid, string branchno, string categoryno,
        string statusid,  string branchdes, string categorydes, string loancategorydes, string statusdes, string Extrafirlddes)
    {
        fc = new FunctionClass();
        string loanno = "9";
        string loandes = "GL Code";
        string loancategoryno ="0";
        int extrafieldid = 0;
        string serialno = serno.ToString("000");
        string refglcode = loanno + branchno + categoryno + loancategoryno + statusid + extrafieldid.ToString("000") + serialno;
        //string glcode = loanno + branchno + categoryno + loancategoryno + statusid + serialno.Remove(0, 1);
        string glcode = loanno + branchno + categoryno + loancategoryno + statusid + serialno;
        refglcode += fc.GetModuler10(refglcode);
        glcode += fc.GetModuler10(glcode);
        DateTime date = fc.GetSystemDate("A");
        string GlDesc = loandes + " " + branchdes + " " + categorydes + " " + loancategorydes + " "
             + statusdes + " " + "0" + " " + serialdesc;
        InsertGLCode(refglcode, glcode, "0", date, "A", GlDesc);

        return "RefGLCode = " + refglcode.ToString() + ",GLCode = " + glcode.ToString();
    }
}
