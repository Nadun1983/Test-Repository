using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using System.Data.SqlClient;

/// <summary>
/// Summary description for Class1
/// </summary>
public class Class1
{
    private SqlConnection sqlConn;
    private SqlCommand sqlCmd;
    private SqlDataAdapter sqlAdaper;
    private SqlDataReader dr;
    DataWorksClass dw;
    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();
    string oldconstring = ConfigurationManager.ConnectionStrings["TestOld"].ConnectionString.ToString();
    string Branchconstring = ConfigurationManager.ConnectionStrings["TDBBranchesConString"].ConnectionString.ToString();

	public Class1()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public DataTable GetCrAcNosofTransAssign()
    {
        string sqlSelect;
        DataTable dt = new DataTable();

        sqlSelect = @"select distinct t.cracno from transassign t,crmast c where 
                    t.transref != 'DISB' and t.trstatus<>'C'
                    and(t.datedue is not null or t.datedue = '')
                    and t.transno is not null and left(t.cracno,1)=6 and t.taskid='CAPD'
                    and t.cracno=c.cracno and len(c.appno)=10 order by t.cracno";

        sqlConn = new SqlConnection(constring);
        sqlAdaper = new SqlDataAdapter(sqlSelect, sqlConn);


        try
        {
            sqlConn.Open();
            sqlAdaper.Fill(dt);
        }

        catch (Exception err)
        {
            //_errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
        }
        return dt;

    }

    public int GetCapitalCount(string cracno)
    {
        string sqlInsert;

        sqlInsert = @"select isnull(count(taskid), 0) as capdcount from transassign where cracno=@cracno 
                      and taskid='CAPD' and trstatus<>'C' and transref != 'DISB' and trtype = 'I'
                         and (system <> 'M' or system is null)";

        sqlConn = new SqlConnection(constring);
        sqlCmd = new SqlCommand(sqlInsert, sqlConn);

        sqlCmd.Parameters.AddWithValue("cracno", cracno);

        //sqlCmd.Parameters.AddWithValue("recordno", recordno);

        int capitalcount = 0;

        try
        {
            sqlConn.Open();
            dr = sqlCmd.ExecuteReader();
            if (dr.Read())
            {
                capitalcount = int.Parse(dr["capdcount"].ToString());
            }
        }

        catch (Exception err)
        {
            // InsertRepeatNIC(custno, nicno);
            //
        }

        finally
        {
            sqlConn.Close();
        }

        return capitalcount;
    }

    public DataTable GeTrAndAssgAmt(string cracno)
    {
        string sqlSelect;
        DataTable dt = new DataTable();

        sqlSelect = @"select tramt,assignamt from transassign where refno in 
                    (select max(refno) from transassign where (cracno=@cracno
                    and taskid='CAPD' and trstatus<>'C' and transref != 'DISB') 
                    and (system <> 'M' or system is null))";

        sqlConn = new SqlConnection(constring);
        sqlAdaper = new SqlDataAdapter(sqlSelect, sqlConn);

        sqlAdaper.SelectCommand.Parameters.AddWithValue("cracno", cracno);


        try
        {
            sqlConn.Open();
            sqlAdaper.Fill(dt);
        }

        catch (Exception err)
        {
            //_errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
        }
        return dt;
    }

    public DateTime GetMaxDateDue(string cracno)
    {
        string sqlSelect;

        sqlSelect = @"select datedue from housprop where cracno = @cracno";

        sqlConn = new SqlConnection(oldconstring);
        sqlCmd = new SqlCommand(sqlSelect, sqlConn);

        sqlCmd.Parameters.AddWithValue("cracno", cracno);

        DateTime maxdate = new DateTime();

        try
        {
            sqlConn.Open();
            dr = sqlCmd.ExecuteReader();
            if (dr.Read())
            {
                maxdate = DateTime.Parse(dr["datedue"].ToString());
            }
        }

        catch (Exception err)
        {
            // InsertRepeatNIC(custno, nicno);
            //
        }

        finally
        {
            sqlConn.Close();
        }

        return maxdate;
    }



    public int updateHousPropDueDates(string cracno, DateTime lstcmpleteduedate,DateTime datedue)
    {
        string sqlInsert;

        sqlInsert = @"update housprop set datedue = @datedue, LastCompletedDueDate = @lstcmpleteduedate where cracno = @cracno";

        sqlConn = new SqlConnection(constring);
        sqlCmd = new SqlCommand(sqlInsert, sqlConn);

        sqlCmd.Parameters.AddWithValue("datedue", datedue);
        sqlCmd.Parameters.AddWithValue("lstcmpleteduedate", lstcmpleteduedate);
        sqlCmd.Parameters.AddWithValue("cracno", cracno);

        int rowcount = 0;

        try
        {
            sqlConn.Open();
            rowcount = sqlCmd.ExecuteNonQuery();
        }

        catch (Exception err)
        {
            //
        }

        finally
        {
            sqlConn.Close();
        }

        return rowcount;

    }
    public DataTable getcustomerdeta(string appno)
    {
        dw = new DataWorksClass(Branchconstring);
        dw.SetDataAdapter(@"select C.AppNo,C.BranchCode,C.RecvDate,C.CrAmt,A.NicNo,
                                (rtrim(CM.initials) + ' ' + rtrim(CM.surname)) as CustName 
                                from Crapp C,Appholder A,Customermain CM where C.AppNo=@AppNo
                                and C.AppNo=A.AppNo and A.HolderType='P' and A.NicNo= CM.NicNo
                                and C.BranchCode=A.branchcode and A.branchcode=CM.BranchCode");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();

    }

    public int insertdate(string appno, string savingsNo, string branchcode, DateTime dateTime, string User, string cracno)
    {
        dw = new DataWorksClass(Branchconstring);
        dw.SetCommand(@"INSERT INTO NITFDetails(Appno,SavingsAcNo,BranchCode,AddDate,AddUser, Cracno) VALUES 
                        (@appno,@savingsNo,@branchcode,@adddate,@adduser,@cracno)");
        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("savingsNo", savingsNo);
        dw.SetSqlCommandParameters("branchcode", branchcode);
        dw.SetSqlCommandParameters("adddate", dateTime);
        dw.SetSqlCommandParameters("adduser", User);
        dw.SetSqlCommandParameters("cracno", cracno);
        return int.Parse(dw.InsertandReturnID());
    }
}
