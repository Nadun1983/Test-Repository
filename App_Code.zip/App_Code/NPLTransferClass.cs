﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;


/// <summary>
/// Summary description for NPLTransferClass
/// </summary>
public class NPLTransferClass
{
    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();
    DataWorksClass dw;
    DataTable npldata, loanstatus, loancatogory, nsbbranches, otherloanstatus;
    DateDifference dd;
    FunctionClass fc;
    CrTransClass ct;
    LastSerialClass lc;
    long minrefno, maxrefno;
    string errMsg;

    public string ErrMsg
    {
        get
        {
            return errMsg;
        }
    }
   
    public NPLTransferClass()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public long MinRefNo
    {
        get
        {
            return minrefno;
        }
    }

    public long MaxRefNo
    {
        get
        {
            return maxrefno;
        }
    }


    public void NPLProcess(string oprationaldate)
    {
        int reccount = 0;
        lc = new LastSerialClass();
        fc= new FunctionClass();
        npldata = new DataTable();
        nsbbranches = new DataTable();
        nsbbranches = GetNsb_Branch();
        ct = new  CrTransClass();
        loanstatus = new DataTable();
        loanstatus = GetLoanLoanStatus();

        loancatogory = new DataTable();
        loancatogory = GetLoanCatogory();
        
        //for (int brno = 0; nsbbranches.Rows.Count > brno; brno++)
        //{
            string brcode = "0308"; // int.Parse(nsbbranches.Rows[brno]["Branchno"].ToString()).ToString("0000");

            for(int q = 0; loanstatus.Rows.Count > q; q++)
            {
                int currentStatusCode = int.Parse(loanstatus.Rows[q]["statusID"].ToString());
                string currentkeyval = loanstatus.Rows[q]["keyval"].ToString();

                for (int w = 0; loancatogory.Rows.Count > w; w++)
                {
                    int crcatcode = int.Parse(loancatogory.Rows[w]["CrCatCode"].ToString());

                    otherloanstatus = new DataTable();
                    otherloanstatus = GetLoanLoanStatus(currentStatusCode);
                    for (int r = 0; otherloanstatus.Rows.Count > r; r++)
                    {
                        string otherkeyval = otherloanstatus.Rows[r]["keyval"].ToString();
                        int otherstatuscode = int.Parse(otherloanstatus.Rows[r]["StatusID"].ToString());
                        int Param1 = int.Parse(otherloanstatus.Rows[r]["Param1"].ToString());
                        int Param2 = int.Parse(otherloanstatus.Rows[r]["Param2"].ToString());
                        npldata = GetNPLData(oprationaldate, "Y", currentStatusCode, brcode, Param1, Param2, crcatcode);
                        double totoutbal = 0;
                        if (npldata != null)
                        {
                            for (int i = 0; i < npldata.Rows.Count; i++)
                            {
                                if (otherstatuscode != currentStatusCode)
                                {
                                    // int newStatusCode = int.Parse(npldata.Rows[i]["LoanStatusCode"].ToString());
                                    double outbal = double.Parse(npldata.Rows[i]["outbal"].ToString());
                                    string cracno = npldata.Rows[i]["cracno"].ToString();
                                    int DateDifferance = int.Parse(npldata.Rows[i]["DateDifferance"].ToString());
                                    UpdateLoanStatusCode(cracno, otherstatuscode, DateDifferance);

                                    totoutbal += outbal;
                                }
                            }
                            if (totoutbal != 0)
                            {
                                reccount++;
                                string category = "1";

                                string currentGLCode = "9" + brcode + category + crcatcode.ToString("00") + currentStatusCode + "00" + "001";
                                currentGLCode += fc.GetModuler10(currentGLCode);
                                string newGLCode = "9" + brcode + category + crcatcode.ToString("00") + otherstatuscode + "00" + "001";
                                newGLCode += fc.GetModuler10(newGLCode);
                                long nplrefno = lc.GetMaxNumber("NPLRefNo", true);
                                if (reccount == 1)
                                {
                                    minrefno = nplrefno;
                                }
                                maxrefno = nplrefno;
                                string taskid = "NPLC" + currentkeyval + otherkeyval;
                                if (nplrefno != 0)
                                {
                                    ct.InsertTransAssign(newGLCode, taskid, totoutbal, "T", "User", DateTime.Now, "NPLT", "I", nplrefno, oprationaldate);
                                    ct.InsertTransAssign(currentGLCode, taskid, totoutbal, "T", "User", DateTime.Now, "NPLT", "E", nplrefno, oprationaldate);
                                    lc.UpdateLastserial("NPLRefNo", nplrefno + 1);
                                }
                            }
                        }
                        else
                        {
                            errMsg = "No Records to Process";
                        }

                    }
                }
            }
        }
    //}
    private int GetArriesMonths(string lastcomleteddue, string operationdate)
    {
        DateTime lastcompleteddateD, operationdateD;
        fc = new FunctionClass();
        lastcompleteddateD = fc.GetDateinDateKey(lastcomleteddue); // Get DateFomat
        operationdateD =  fc.GetDateinDateKey(operationdate); // Get DateFormat
        dd = new DateDifference(operationdateD, lastcompleteddateD);
        return dd.NoofDayes;
    }

    private int UpdateLoanStatusCode(string cracno, int loanStatusCode, int DateDifferance)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update housprop set LoanStatusCode=@LoanStatusCode, 
                        DateDifferance=@DateDifferance
                        where cracno = @cracno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("loanStatusCode", loanStatusCode);
        dw.SetSqlCommandParameters("DateDifferance", DateDifferance);
        return dw.Update();
    }

    private DataTable GetNsb_Branch()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select BranchNo from nsb_branch where branchno = '0308'");
        return dw.GetDataTable();
    }


    private DataTable GetNPLData(string operationdate, string IsDisbursed, int LoanStatusCode, 
        string brcode, int Param1, int Param2, int crcatcode)
    {
        fc = new FunctionClass();
        DateTime operationdateD;
        operationdateD = fc.GetDateinDateKey(operationdate);
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select cracno, intrate, outbal, graceperiod, DATEDIFF(month, LastCompletedDueDate, @operationdate) as [DateDifferance],
                            LastCompletedDueDate, LoanStatusCode, OutBal 
                            from housprop 
                            where DATEDIFF(month, LastCompletedDueDate, @operationdate)>@Param1 and 
                            DATEDIFF(month, LastCompletedDueDate, @operationdate)<@Param2 and
                            CrCat = @CrCat and right(left(cracno,5), 4) =@brcode and
                            IsDisbursed = @IsDisbursed and
                            LoanStatusCode=@LoanStatusCode");

        dw.SetDataAdapterParameters("LoanStatusCode", LoanStatusCode);
        dw.SetDataAdapterParameters("IsDisbursed", IsDisbursed);
        dw.SetDataAdapterParameters("Param1", Param1);
        dw.SetDataAdapterParameters("Param2", Param2);
        dw.SetDataAdapterParameters("operationdate", operationdateD);
        dw.SetDataAdapterParameters("CrCat", crcatcode);
        dw.SetDataAdapterParameters("brcode", brcode);
        return dw.GetDataTable();
    }


    private DataTable GetLoanLoanStatus()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from LoanStatus where StatusID != 0");
        return dw.GetDataTable();

    }


    private DataTable GetLoanLoanStatus(int StatusID)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from LoanStatus where StatusID != @StatusID and StatusID!=0");
        dw.SetDataAdapterParameters("StatusID", StatusID);
        return dw.GetDataTable();

    }

    private DataTable GetLoanCatogory()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from CrCategory where CrCatCode!=0");
        return dw.GetDataTable();
    }

   
    private void TrnaferGlAccounts(string currentLoanStatusCode, string newLoanstatusCode, string cracno, double outBal)
    {
        
    }

    public DataTable GetGlBackup(string Date)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select @Date as OperationDate, RefGlCode,CurBal from Glcode");
        dw.SetDataAdapterParameters("Date", Date);
        return dw.GetDataTable();
    }


}