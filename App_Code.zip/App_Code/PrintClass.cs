using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System.Data.SqlClient;
using System.Security.Permissions;
using System.IO;


    public class PrintClass
    {

        ReportDocument myReportDocument;
        ExportOptions ExOpt;
        DiskFileDestinationOptions diskOpts;
        DataWorksClass dw;
        string fpath;
        string sFileName;
        public PrintClass()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        private string constring = ConfigurationManager.ConnectionStrings["housdbString"].ToString();
        public void SetConnection(string reportpath, string path, string dbusername, string dbpassword, string servernmaer, string dbname)
        {
            myReportDocument = new ReportDocument();
            ExOpt = new ExportOptions();
            diskOpts = new DiskFileDestinationOptions();
            sFileName = path;
            fpath = reportpath;
            myReportDocument.Load(fpath);
            myReportDocument.SetDatabaseLogon(dbusername, dbpassword, servernmaer, dbname);
            diskOpts.DiskFileName = sFileName;
            ExOpt = myReportDocument.ExportOptions;
            ExOpt.ExportDestinationType = ExportDestinationType.DiskFile;
            ExOpt.ExportFormatType = ExportFormatType.PortableDocFormat;
            ExOpt.DestinationOptions = diskOpts;
        }

        public void SetConnectionForExcel(string reportpath, string path, string dbusername, string dbpassword, string servernmaer, string dbname)
        {
            myReportDocument = new ReportDocument();
            ExOpt = new ExportOptions();
            diskOpts = new DiskFileDestinationOptions();
            sFileName = path;
            fpath = reportpath;
            myReportDocument.Load(fpath);
            myReportDocument.SetDatabaseLogon(dbusername, dbpassword, servernmaer, dbname);
            diskOpts.DiskFileName = sFileName;
            ExOpt = myReportDocument.ExportOptions;
            ExOpt.ExportDestinationType = ExportDestinationType.DiskFile;
            ExOpt.ExportFormatType = ExportFormatType.Excel;
            ExOpt.DestinationOptions = diskOpts;
        }

        public void SetConnectionForEmail(string reportpath, string path, string dbusername, string dbpassword, string servernmaer, string dbname)
        {
            myReportDocument = new ReportDocument();
            ExOpt = new ExportOptions();
            diskOpts = new DiskFileDestinationOptions();
            sFileName = path;
            fpath = reportpath;
            myReportDocument.Load(fpath);
            myReportDocument.SetDatabaseLogon(dbusername, dbpassword, servernmaer, dbname);
            diskOpts.DiskFileName = sFileName;
            ExOpt = myReportDocument.ExportOptions;
            ExOpt.ExportDestinationType = ExportDestinationType.DiskFile;
            ExOpt.ExportFormatType = ExportFormatType.PortableDocFormat;
            ExOpt.DestinationOptions = diskOpts;
            ExportOptions CrExportOptions;
            DiskFileDestinationOptions CrDiskFileDestinationOptions = new DiskFileDestinationOptions();
            PdfRtfWordFormatOptions CrFormatTypeOptions = new PdfRtfWordFormatOptions();
            CrDiskFileDestinationOptions.DiskFileName = sFileName;
            CrExportOptions = myReportDocument.ExportOptions;
            CrExportOptions.ExportDestinationType = ExportDestinationType.DiskFile;
            CrExportOptions.ExportFormatType = ExportFormatType.PortableDocFormat;
            CrExportOptions.DestinationOptions = CrDiskFileDestinationOptions;
            CrExportOptions.FormatOptions = CrFormatTypeOptions;
        }

        public void SetParams(string paramname, string paramvalue)
        {
            paramname = "@" + paramname;
            myReportDocument.SetParameterValue(paramname, paramvalue);
        }
        public void SetParams(string paramname, int paramvalue)
        {
            paramname = "@" + paramname;
            myReportDocument.SetParameterValue(paramname, paramvalue);
        }
        public void SetParams(string paramname, bool paramvalue)
        {
            paramname = "@" + paramname;
            myReportDocument.SetParameterValue(paramname, paramvalue);
        }
        public void SetParams(string paramname, long paramvalue)
        {
            paramname = "@" + paramname;
            myReportDocument.SetParameterValue(paramname, paramvalue);
        }
        public void SetParams(string paramname, float paramvalue)
        {
            paramname = "@" + paramname;
            myReportDocument.SetParameterValue(paramname, paramvalue);
        }
        public void SetParams(string paramname, short paramvalue)
        {
            paramname = "@" + paramname;
            myReportDocument.SetParameterValue(paramname, paramvalue);
        }
        public void SetParams(string paramname, byte paramvalue)
        {
            paramname = "@" + paramname;
            myReportDocument.SetParameterValue(paramname, paramvalue);
        }
        public void SetParams(string paramname, double paramvalue)
        {
            paramname = "@" + paramname;
            myReportDocument.SetParameterValue(paramname, paramvalue);
        }
        public void SetParams(string paramname, decimal paramvalue)
        {
            paramname = "@" + paramname;
            myReportDocument.SetParameterValue(paramname, paramvalue);
        }
        public void SetParams(string paramname, char paramvalue)
        {
            paramname = "@" + paramname;
            myReportDocument.SetParameterValue(paramname, paramvalue);
        }
        public void SetParams(string paramname, DateTime paramvalue)
        {
            paramname = "@" + paramname;
            myReportDocument.SetParameterValue(paramname, paramvalue);
        }
        public void SetParams(string paramname, string paramvalue, string subreportname)
        {
            paramname = "@" + paramname;
            myReportDocument.SetParameterValue(paramname, paramvalue, subreportname);
        }
        public void SetParams(string paramname, int paramvalue, string subreportname)
        {
            paramname = "@" + paramname;
            myReportDocument.SetParameterValue(paramname, paramvalue, subreportname);
        }
        public void SetParams(string paramname, long paramvalue, string subreportname)
        {
            paramname = "@" + paramname;
            myReportDocument.SetParameterValue(paramname, paramvalue, subreportname);
        }
        public void SetParams(string paramname, short paramvalue, string subreportname)
        {
            paramname = "@" + paramname;
            myReportDocument.SetParameterValue(paramname, paramvalue, subreportname);
        }
        public void SetParams(string paramname, float paramvalue, string subreportname)
        {
            paramname = "@" + paramname;
            myReportDocument.SetParameterValue(paramname, paramvalue, subreportname);
        }
        public void SetParams(string paramname, double paramvalue, string subreportname)
        {
            paramname = "@" + paramname;
            myReportDocument.SetParameterValue(paramname, paramvalue, subreportname);
        }
        public void SetParams(string paramname, decimal paramvalue, string subreportname)
        {
            paramname = "@" + paramname;
            myReportDocument.SetParameterValue(paramname, paramvalue, subreportname);
        }
        public void SetParams(string paramname, char paramvalue, string subreportname)
        {
            paramname = "@" + paramname;
            myReportDocument.SetParameterValue(paramname, paramvalue, subreportname);
        }
        public void SetParams(string paramname, byte paramvalue, string subreportname)
        {
            paramname = "@" + paramname;
            myReportDocument.SetParameterValue(paramname, paramvalue, subreportname);
        }
        public void SetParams(string paramname, bool paramvalue, string subreportname)
        {
            paramname = "@" + paramname;
            myReportDocument.SetParameterValue(paramname, paramvalue, subreportname);
        }

        public void SetParams(string paramname, DateTime paramvalue, string subreportname)
        {
            paramname = "@" + paramname;
            myReportDocument.SetParameterValue(paramname, paramvalue, subreportname);
        }
        public void GetPdfReport(System.Web.HttpResponse Response)
        {
            myReportDocument.Export();
            Response.ClearContent();
            Response.ClearHeaders();
            Response.ContentType = "application/pdf";
            Response.WriteFile(sFileName);
            Response.Flush();
            Response.Close();

            if (myReportDocument != null)
            {
                myReportDocument.Dispose();
                myReportDocument.Close();
            }
        }

        public void GetPdfReportForEmail(System.Web.HttpResponse Response)
        {
            myReportDocument.Export();
            //Response.ClearContent();
            //Response.ClearHeaders();
            //Response.ContentType = "application/pdf";
            //Response.WriteFile(sFileName);
            //Response.Flush();
            //Response.Close();
        }

        public void GetHTMLReport(System.Web.HttpResponse Response)
        {
            myReportDocument.Export();
            Response.ClearContent();
            Response.ClearHeaders();
            Response.ContentType = "application/pdf";
            Response.WriteFile(sFileName);
            Response.Flush();
            Response.Close();
            if (myReportDocument != null)
            {
                myReportDocument.Dispose();
                myReportDocument.Close();
            }
        }

        public void ForSendEmail(System.Web.HttpResponse Response)
        {
            //myReportDocument.Export();
            //Response.ClearContent();
            //Response.ClearHeaders();
            //Response.ContentType = "application/pdf";
            //Response.WriteFile(sFileName);
            //Response.Flush();
            //Response.Close();
            myReportDocument.Close();
            myReportDocument.Dispose();
        }
//        public void GetDirectReport(string username, string branchcode)
//        {
//            dw = new DataWorksClass(constring);
//            dw.SetDataAdapter(@"select ServerName, PrinterName from BranchPrinters
//                        where userid=@username and BranchCode=@BranchCode");
//            dw.SetDataAdapterParameters("userid", username);
//            dw.SetDataAdapterParameters("BranchCode", branchcode);
//            DataTable dt = new DataTable();
//            dt = dw.GetDataTable();
//            string servername = dt.Rows[0]["servername"].ToString();

//            string printername = dt.Rows[0]["printername"].ToString();
//            printername = @"\\" + servername + @"\" + printername;
//            myReportDocument.PrintOptions.PrinterName = printername;
//            myReportDocument.PrintToPrinter(1, true, 0, 0);
//            //Response.ClearContent();
//            //Response.ClearHeaders();
//            //Response.ContentType = "application/x-cdf";
//            //Response.WriteFile(sFileName);
//            //Response.Flush();
//            //Response.Close();



//        }

        public string GetDirectReport(string servername, string printername)
        {
            
//            dw = new DataWorksClass(constring);
//            dw.SetDataAdapter(@"select ServerName, PrinterName from BranchPrinters
//                        where userid=@username and BranchCode=@BranchCode");
//            dw.SetDataAdapterParameters("userid", username);
//            dw.SetDataAdapterParameters("BranchCode", branchcode);
//            DataTable dt = new DataTable();
//            dt = dw.GetDataTable();
//            string servername = dt.Rows[0]["servername"].ToString();

            //string printername = dt.Rows[0]["printername"].ToString();

            try
            {
                printername = @"\\" + servername + @"\" + printername;
                myReportDocument.PrintOptions.PrinterName = printername;
                myReportDocument.PrintToPrinter(1, true, 0, 0);
                return "ok";
            }
            catch(Exception ex)
            {
                return ex.Message;
            }
            
            //Response.ClearContent();
            //Response.ClearHeaders();
            //Response.ContentType = "application/x-cdf";
            //Response.WriteFile(sFileName);
            //Response.Flush();
            //Response.Close();
        }

        public string GetDirectReport(string servername, string printername, int from, int to)
        {

            //            dw = new DataWorksClass(constring);
            //            dw.SetDataAdapter(@"select ServerName, PrinterName from BranchPrinters
            //                        where userid=@username and BranchCode=@BranchCode");
            //            dw.SetDataAdapterParameters("userid", username);
            //            dw.SetDataAdapterParameters("BranchCode", branchcode);
            //            DataTable dt = new DataTable();
            //            dt = dw.GetDataTable();
            //            string servername = dt.Rows[0]["servername"].ToString();

            //string printername = dt.Rows[0]["printername"].ToString();

            try
            {
                printername = @"\\" + servername + @"\" + printername;
                myReportDocument.PrintOptions.PrinterName = printername;
                myReportDocument.PrintToPrinter(1, true, from, to);
                return "ok";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }

            //Response.ClearContent();
            //Response.ClearHeaders();
            //Response.ContentType = "application/x-cdf";
            //Response.WriteFile(sFileName);
            //Response.Flush();
            //Response.Close();
        }

        public void GetExcelReport(System.Web.HttpResponse Response, string sFileName)
        {

            myReportDocument.Export();

            if (System.IO.File.Exists(sFileName))
            {
                Response.WriteFile(sFileName);
            }
            else
            {
                System.IO.File.Create(sFileName);
                Response.WriteFile(sFileName);
            }

            string filepath = sFileName;

            string filename = Path.GetFileName(filepath);
            Stream stream = null;
            try
            {
                stream = new FileStream(filepath, FileMode.Open, FileAccess.Read, FileShare.Read);
                long bytesToRead = stream.Length;
                Response.ContentType = "application/octet-stream";
                Response.AddHeader("Content-Disposition", "attachment; filename=" + filename);
                while (bytesToRead > 0)
                {
                    if (Response.IsClientConnected)
                    {
                        byte[] buffer = new Byte[10000];
                        int length = stream.Read(buffer, 0, 10000);
                        Response.OutputStream.Write(buffer, 0, length);
                        Response.Flush();
                        bytesToRead = bytesToRead - length;
                    }
                    else
                    {
                        bytesToRead = -1;
                    }
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
            finally
            {
                if (stream != null)
                {
                    stream.Close();
                }
            }    
        }

        public void Close()
        {
            this.myReportDocument.Close();
        }

        public void SetConnection(string reportpath, string path, string dbusername, string dbpassword, string servernmaer, string dbname, DataTable dt)
        {
            myReportDocument = new ReportDocument();
            ExOpt = new ExportOptions();
            diskOpts = new DiskFileDestinationOptions();
            sFileName = path;
            fpath = reportpath;
            myReportDocument.Load(fpath);
            myReportDocument.SetDatabaseLogon(dbusername, dbpassword, servernmaer, dbname);
            myReportDocument.SetDataSource(dt);
            diskOpts.DiskFileName = sFileName;
            ExOpt = myReportDocument.ExportOptions;
            ExOpt.ExportDestinationType = ExportDestinationType.DiskFile;
            ExOpt.ExportFormatType = ExportFormatType.PortableDocFormat;
            ExOpt.DestinationOptions = diskOpts;
        }

        public void SetConnection(string reportpath, string path, DataTable dt)
        {
            myReportDocument = new ReportDocument();
            ExOpt = new ExportOptions();
            diskOpts = new DiskFileDestinationOptions();
            sFileName = path;
            fpath = reportpath;
            myReportDocument.Load(fpath);
            myReportDocument.SetDataSource(dt);
            diskOpts.DiskFileName = sFileName;
            ExOpt = myReportDocument.ExportOptions;
            ExOpt.ExportDestinationType = ExportDestinationType.DiskFile;
            ExOpt.ExportFormatType = ExportFormatType.PortableDocFormat;
            ExOpt.DestinationOptions = diskOpts;
        }

        
    }
