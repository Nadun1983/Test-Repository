using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// Summary description for CustomerIncome
/// </summary>
public class CustomerIncomeClass
{
    private SqlConnection sqlConn;
    SqlCommand sqlCmd;
    SqlDataReader sqlDataReader;
    SqlDataAdapter sqldataAdapter;
    DataTable dt;
    
	public CustomerIncomeClass()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();
    string _errmessage;

    public DataTable GetTaxDetails()
    {
        string sqlSelect = @"select TaxFileNo,CUSTNO,ASSESYEAR,ASSBLINCOME,TAXBLINCOME,AddDateTime,
                           TOTTAXPAID,PAIDATE,STATUS,IsPayeTax,AppNo,NotConfirmedReason,
                           NIC,SendDate,RecvDate from custax";

        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);
        
        dt = new DataTable();

        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return dt;
    }

    public DataTable GetTaxDetailsusingNIC(string NIC)
    {
        string sqlSelect = @"select TaxFileNo,CUSTNO,ASSESYEAR,ASSBLINCOME,TAXBLINCOME,
                           TOTTAXPAID,PAIDATE,STATUS,IsPayeTax,AppNo,NotConfirmedReason,
                           NIC,SendDate,RecvDate from custax where NIC=@NIC";
                
        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);

        sqldataAdapter.SelectCommand.Parameters.AddWithValue("NIC", NIC);

        dt = new DataTable();

        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return dt;
    }

    public DataTable GetTaxDetailsusingTaxFileNo(string TaxFileNo)
    {
        string sqlSelect = @"select TaxFileNo,CUSTNO,ASSESYEAR,ASSBLINCOME,TAXBLINCOME,
                           TOTTAXPAID,PAIDATE,STATUS,IsPayeTax,AppNo,NotConfirmedReason,
                           NIC,SendDate,RecvDate from custax where TaxFileNo=@TaxFileNo";

        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);

        sqldataAdapter.SelectCommand.Parameters.AddWithValue("TaxFileNo", TaxFileNo);

        dt = new DataTable();

        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return dt;
    }

    public DataTable GetTaxDetailsusingAppNo(string AppNo)
    {
        string sqlSelect = @"select TaxFileNo,CUSTNO,ASSESYEAR,ASSBLINCOME,TAXBLINCOME,
                           TOTTAXPAID,PAIDATE,STATUS,IsPayeTax,AppNo,NotConfirmedReason,AddDateTime,
                           NIC,SendDate,RecvDate from custax where AppNo=@AppNo";

        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);

        sqldataAdapter.SelectCommand.Parameters.AddWithValue("AppNo", AppNo);

        dt = new DataTable();

        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return dt;
    }

    public int InsertTaxdetails(string TaxFileNo, int CUSTNO, string ASSESYEAR, double ASSBLINCOME, double TAXBLINCOME,
               double TOTTAXPAID, DateTime PAIDATE, string AddUser, string STATUS, string IsPayeTax, long AppNo,
               string NotConfirmedReason, DateTime AddDateTime, string NIC, DateTime SendDate, DateTime RecvDate,
               int UpdateLevel)
    {
        SqlTransaction sqlTrans;
        string sqlInsert;

        sqlInsert = @"insert into CUSTAX (TaxFileNo,CUSTNO,ASSESYEAR,ASSBLINCOME,TAXBLINCOME,TOTTAXPAID,
                    PAIDATE,AddUser,STATUS,IsPayeTax,AppNo,NotConfirmedReason,AddDateTime,NIC,SendDate,
                    RecvDate,UpdateLevel) values(@TaxFileNo,@CUSTNO,@ASSESYEAR,@ASSBLINCOME,@TAXBLINCOME,@TOTTAXPAID,
                    @PAIDATE,@AddUser,@STATUS,@IsPayeTax,@AppNo,@NotConfirmedReason,@AddDateTime,@NIC,@SendDate,
                    @RecvDate,@UpdateLevel)";

        sqlConn = new SqlConnection(constring);
        sqlCmd = new SqlCommand(sqlInsert, sqlConn);

        sqlCmd.Parameters.AddWithValue("TaxFileNo", TaxFileNo);
        sqlCmd.Parameters.AddWithValue("CUSTNO", CUSTNO);
        sqlCmd.Parameters.AddWithValue("ASSESYEAR", ASSESYEAR);
        sqlCmd.Parameters.AddWithValue("ASSBLINCOME", ASSBLINCOME);
        sqlCmd.Parameters.AddWithValue("TAXBLINCOME", TAXBLINCOME);

        sqlCmd.Parameters.AddWithValue("TOTTAXPAID", TOTTAXPAID);
        sqlCmd.Parameters.AddWithValue("PAIDATE",PAIDATE);
        sqlCmd.Parameters.AddWithValue("AddUser", AddUser);
        sqlCmd.Parameters.AddWithValue("STATUS",STATUS);
        sqlCmd.Parameters.AddWithValue("IsPayeTax",IsPayeTax);

        sqlCmd.Parameters.AddWithValue("AppNo",AppNo);
        sqlCmd.Parameters.AddWithValue("NotConfirmedReason",NotConfirmedReason);
        sqlCmd.Parameters.AddWithValue("AddDateTime",AddDateTime);
        sqlCmd.Parameters.AddWithValue("NIC",NIC);
        sqlCmd.Parameters.AddWithValue("SendDate",SendDate);

        sqlCmd.Parameters.AddWithValue("RecvDate",RecvDate);
        sqlCmd.Parameters.AddWithValue("UpdateLevel", UpdateLevel);

        int Rowadd = 0;

        try
        {
            sqlConn.Open();
            Rowadd = sqlCmd.ExecuteNonQuery();
        }
        catch (Exception er)
        {
            _errmessage = er.ToString();
        }
        finally
        {
            sqlConn.Close();
        }

        return Rowadd;
    }


    public int UpdateTaxDetails(string TaxFileNo, int CUSTNO, string ASSESYEAR, double ASSBLINCOME, double TAXBLINCOME,
               double TOTTAXPAID, DateTime PAIDATE, string AddUser, string STATUS, string IsPayeTax, long AppNo,
               string NotConfirmedReason, DateTime AddDateTime, string NIC, DateTime SendDate, DateTime RecvDate,
               int UpdateLevel)
    {
        SqlTransaction sqlTrans;
        string sqlUpdate;

        sqlUpdate = @"update CUSTAX set TaxFileNo=@TaxFileNo,CUSTNO=@CUSTNO,
                    ASSBLINCOME=@ASSBLINCOME,TAXBLINCOME=@TAXBLINCOME,TOTTAXPAID=@TOTTAXPAID,PAIDATE=@PAIDATE,
                    AddUser=@AddUser,STATUS=@STATUS,IsPayeTax=@IsPayeTax,AppNo=@AppNo,NotConfirmedReason=@NotConfirmedReason,
                    AddDateTime=@AddDateTime,SendDate=@SendDate,RecvDate=@RecvDate,UpdateLevel=@UpdateLevel
                    where NIC=@NIC and ASSESYEAR=@ASSESYEAR";

        sqlConn = new SqlConnection(constring);
        sqlCmd = new SqlCommand(sqlUpdate, sqlConn);

        sqlCmd.Parameters.AddWithValue("TaxFileNo", TaxFileNo);
        sqlCmd.Parameters.AddWithValue("CUSTNO", CUSTNO);
        sqlCmd.Parameters.AddWithValue("ASSESYEAR", ASSESYEAR);
        sqlCmd.Parameters.AddWithValue("ASSBLINCOME", ASSBLINCOME);
        sqlCmd.Parameters.AddWithValue("TAXBLINCOME", TAXBLINCOME);

        sqlCmd.Parameters.AddWithValue("TOTTAXPAID", TOTTAXPAID);
        sqlCmd.Parameters.AddWithValue("PAIDATE", PAIDATE);
        sqlCmd.Parameters.AddWithValue("AddUser", AddUser);
        sqlCmd.Parameters.AddWithValue("STATUS", STATUS);
        sqlCmd.Parameters.AddWithValue("IsPayeTax", IsPayeTax);

        sqlCmd.Parameters.AddWithValue("AppNo", AppNo);
        sqlCmd.Parameters.AddWithValue("NotConfirmedReason", NotConfirmedReason);
        sqlCmd.Parameters.AddWithValue("AddDateTime", AddDateTime);
        sqlCmd.Parameters.AddWithValue("NIC", NIC);
        sqlCmd.Parameters.AddWithValue("SendDate", SendDate);

        sqlCmd.Parameters.AddWithValue("RecvDate", RecvDate);
        sqlCmd.Parameters.AddWithValue("UpdateLevel", UpdateLevel);

        int Rowadd = 0;

        try
        {
            sqlConn.Open();
            Rowadd = sqlCmd.ExecuteNonQuery();
        }
        catch (Exception er)
        {
            _errmessage = er.ToString();
        }
        finally
        {
            sqlConn.Close();
        }

        return Rowadd;
    }


    public DataTable GetShlDetails()
    {
        string sqlSelect = @"select AppNo,NICNo,PassbookNo,BranchCode,MonthlyDeposit,Period,AddUser
                            from CusSHL";

        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);

        dt = new DataTable();

        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return dt;
    }

    public DataTable GetShlDetailsusingNIC(string NICNo)
    {
        string sqlSelect = @"select AppNo,NICNo,PassbookNo,BranchCode,MonthlyDeposit,Period,AddUser
                            from CusSHL  where NICNo=@NICNo";

        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);

        sqldataAdapter.SelectCommand.Parameters.AddWithValue("NICNo", NICNo);

        dt = new DataTable();

        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return dt;
    }

    public DataTable GetShlDetailsusingAppNo(string AppNo)
    {
        string sqlSelect = @"select AppNo,NICNo,PassbookNo,BranchCode,MonthlyDeposit,Period,AddUser
                             from CusSHL  where AppNo=@AppNo";

        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);

        sqldataAdapter.SelectCommand.Parameters.AddWithValue("AppNo", AppNo);

        dt = new DataTable();

        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return dt;
    }

    public int InsertSHLdetails(long AppNo, string NICNo, string PassbookNo, long BranchCode, decimal MonthlyDeposit,
                                string Period, string AddUser, DateTime AddDateTime, int UpdateLevel)
    {
        SqlTransaction sqlTrans;
        string sqlInsert;

        sqlInsert = @"insert into CusSHL (AppNo,NICNo,PassbookNo,BranchCode,MonthlyDeposit,Period,AddUser,
                      AddDateTime,UpdateLevel)
                      values(@AppNo,@NICNo,@PassbookNo,@BranchCode,@MonthlyDeposit,@Period,@AddUser,
                      @AddDateTime,@UpdateLevel)";

        sqlConn = new SqlConnection(constring);
        sqlCmd = new SqlCommand(sqlInsert, sqlConn);

        sqlCmd.Parameters.AddWithValue("AppNo", AppNo);
        sqlCmd.Parameters.AddWithValue("NICNo", NICNo);
        sqlCmd.Parameters.AddWithValue("PassbookNo", PassbookNo);
        sqlCmd.Parameters.AddWithValue("BranchCode", BranchCode);
        sqlCmd.Parameters.AddWithValue("MonthlyDeposit", MonthlyDeposit);

        sqlCmd.Parameters.AddWithValue("Period", Period);
        sqlCmd.Parameters.AddWithValue("AddUser", AddUser);
        sqlCmd.Parameters.AddWithValue("AddDateTime", AddDateTime);
        sqlCmd.Parameters.AddWithValue("UpdateLevel", UpdateLevel);        

        int Rowadd = 0;

        try
        {
            sqlConn.Open();
            Rowadd = sqlCmd.ExecuteNonQuery();
        }
        catch (Exception er)
        {            
            _errmessage = er.ToString();
        }
        finally
        {
            sqlConn.Close();
        }

        return Rowadd;
    }


    public int UpdateSHLDetails(long AppNo, string NICNo, string PassbookNo, long BranchCode, decimal MonthlyDeposit,
                                string Period, string AddUser, DateTime AddDateTime, int UpdateLevel)
    {
        SqlTransaction sqlTrans;
        string sqlUpdate;

        sqlUpdate = @"update CusSHL set PassbookNo=@PassbookNo,BranchCode=@BranchCode,
                    MonthlyDeposit=@MonthlyDeposit,Period=@Period,AddUser=@AddUser                  
                    where NICNo=@NICNo and AppNo=@AppNo";

        sqlConn = new SqlConnection(constring);
        sqlCmd = new SqlCommand(sqlUpdate, sqlConn);

        sqlCmd.Parameters.AddWithValue("AppNo", AppNo);
        sqlCmd.Parameters.AddWithValue("NICNo", NICNo);
        sqlCmd.Parameters.AddWithValue("PassbookNo", PassbookNo);
        sqlCmd.Parameters.AddWithValue("BranchCode", BranchCode);
        sqlCmd.Parameters.AddWithValue("MonthlyDeposit", MonthlyDeposit);

        sqlCmd.Parameters.AddWithValue("Period", Period);
        sqlCmd.Parameters.AddWithValue("AddUser", AddUser);
        sqlCmd.Parameters.AddWithValue("AddDateTime", AddDateTime);
        sqlCmd.Parameters.AddWithValue("UpdateLevel", UpdateLevel);   

        int Rowadd = 0;

        try
        {
            sqlConn.Open();
            Rowadd = sqlCmd.ExecuteNonQuery();
        }
        catch (Exception er)
        {
            _errmessage = er.ToString();
        }
        finally
        {
            sqlConn.Close();
        }

        return Rowadd;
    }

    public string GetNIC(long AppNo)
    {
        string sqlSelect = @"select NicNo from AppHolder where AppNo=@AppNo";

        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);

        sqldataAdapter.SelectCommand.Parameters.AddWithValue("AppNo", AppNo);

        dt = new DataTable();

        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        string SendNIC = dt.Rows[0][0].ToString();
        return SendNIC;
    }

    public DataTable GetCustomerNameAndNic(long AppNo)
    {
        string SqlSelect;
        string Error;

        SqlSelect = @"select cm.NicNo as NIC, rtrim(cm.Surname + cm.Initials) as FullName
                     from AppHolder ah ,  CustomerMain cm
                     where cm.NicNo = ah.NicNo and ah.appno=@AppNo";

        SqlConnection SqlCon = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(SqlSelect, SqlCon);

        sqldataAdapter.SelectCommand.Parameters.AddWithValue("AppNo", AppNo);

        dt = new DataTable();

        try
        {
            SqlCon.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            Error = er.ToString();
        }
        finally
        {
            SqlCon.Close();
        }

        return dt;
    }
}
