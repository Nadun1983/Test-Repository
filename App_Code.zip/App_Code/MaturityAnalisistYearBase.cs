﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

/// <summary>
/// Summary description for MaturityAnalisistYearBase
/// </summary>
public class MaturityAnalisistYearBase
{

    double noutbal = 0;
    DateTime ndatedue, transdate;
    DataTable dt;
    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();
    string reporTString = ConfigurationManager.ConnectionStrings["reporTString"].ConnectionString.ToString();
    DataWorksClass dw;

    public MaturityAnalisistYearBase()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    double capital, interest, penal;

    public DataTable getMaturityAnalysisDetails(DateTime operationdate, string caldate)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select c.cracno,h.intrate,h.instalment,
                            d.actoutbal,h.lastcompletedduedate,h.crcat
                            ,datediff(day,h.lastcompletedduedate,@OperationDate)
                            as Arreas, h.graceperiod,c.aprovdamt,c.grantamt from 
                            housprop h,crmast c,CreditReportsDb.ReportUser.DailyHousProp d
                            where h.cracno=c.cracno and h.actoutbal > 0.00 
                            and d.OperationDate=@caldate
                            and c.cracno = d.CrAcNo and c.cracno= d.CrAcNo");
        dw.SetDataAdapterParameters("operationdate", operationdate);
        dw.SetDataAdapterParameters("caldate", caldate);
        dt = dw.GetDataTable();
        return dt;
    }
    public DataTable getMaturityAnalysisDetails(string cracno)
    {
        dw = new DataWorksClass(reporTString);
        dw.SetDataAdapter(@"select cracno,intrate,instalment,actoutbal,lastcompletedduedate,crcat
                            from housprop where cracno = @cracno");
        dw.SetDataAdapterParameters("cracno", cracno);
        dt = dw.GetDataTable();
        return dt;
    }

    public void GetMaturityAnalsys(DateTime transdate, string caldate)
    {
        dt = new DataTable();
        FunctionClass fc = new FunctionClass();
        dt = getMaturityAnalysisDetails(transdate, caldate);
        foreach (DataRow dr in dt.Rows)
        {
            string cracno = dr["cracno"].ToString();
            double intrate = double.Parse(dr["intrate"].ToString());
            double outbal = double.Parse(dr["actoutbal"].ToString());
            double actoutbal = double.Parse(dr["actoutbal"].ToString());
            DateTime ldatedue = DateTime.Parse(dr["lastcompletedduedate"].ToString());
            DateTime llastcompletedduedate = DateTime.Parse(dr["lastcompletedduedate"].ToString());
            double installment = double.Parse(dr["instalment"].ToString());
            int graceperiod = int.Parse(dr["graceperiod"].ToString());
            int arreasdays = int.Parse(dr["Arreas"].ToString());
            int crcat = int.Parse(dr["crcat"].ToString());
            string matcat = "";  // dr["matcat"].ToString(); 
            double approvedAmr = double.Parse(dr["aprovdamt"].ToString());
            double grantAmt = double.Parse(dr["grantamt"].ToString());
            DateTime opdate = DateTime.Now;

            DateTime nplDate = llastcompletedduedate.AddMonths(2);

            if (approvedAmr == grantAmt)
            {

               // if (nplDate.Date < opdate.Date) //time to be taken out of the date
               // {
                //    InsertMaturityDataYearBase(fc.GetEnterDateinDate(transdate), cracno, crcat, intrate, opdate, actoutbal, "CAPD", llastcompletedduedate, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0);
               // }

               // else
                //{
                    if (actoutbal < installment)
                    {
                        InsertMaturityDataYearBase(fc.GetEnterDateinDate(transdate), cracno, crcat, intrate, opdate, actoutbal, "CAPD", llastcompletedduedate, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0);
                    }
                    else
                    {
                        InsertPL(fc.GetEnterDateinDate(transdate), cracno, intrate, outbal, crcat, ldatedue, outbal, installment, graceperiod, opdate, actoutbal, matcat, llastcompletedduedate);
                    }
                //}

            }
            else
            {
                InsertMaturityDataYearBase(fc.GetEnterDateinDate(transdate), cracno, crcat, intrate, opdate, actoutbal, "CAPD", llastcompletedduedate, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0);
            }
        }

    }

    private void InsertMaturityDataYearBase(string datekey, string cracno, int crcat, double intrate, DateTime opdate, double actoutbal, string matcat, DateTime llastcompletedduedate, double mat1, double mat2, double mat3, double mat4, double mat5, double mat6, double mat7, double mat8, double mat9, double mat10, double mat11, double mat12, double mat13, double mat14, double mat15, double mat16, double mat17, double mat18, double mat19, double mat20, double mat21, double mat22, double mat23, double mat24, double mat25, double mat26, double mat27, double mat28, double mat29, double mat30, double mat31)
    {
        int rowAdded = 0;
        dw = new DataWorksClass(reporTString);
        dw.SetCommand(@"INSERT INTO MaturitydataYearbase (datekey ,cracno ,crcat,intrate,lastcompletedduedate,outbal,MatCat,DateDue,
                        Mat1 ,Mat2 ,Mat3 ,Mat4 ,Mat5 ,Mat6 ,Mat7 ,Mat8 ,Mat9 ,Mat10, Mat11, Mat12, Mat13, Mat14, Mat15, Mat16,Mat17,
                        Mat18 ,Mat19 ,Mat20 ,Mat21 ,Mat22 ,Mat23 ,Mat24 ,Mat25 ,Mat26 ,Mat27, Mat28, Mat29, Mat30, Mat31)
                    VALUES
                    (@datekey ,@cracno ,@crcat,@intrate,@opdate,@actoutbal,@matcat,@llastcompletedduedate,
                        @Mat1 ,@Mat2 ,@Mat3 ,@Mat4 ,@Mat5 ,@Mat6 ,@Mat7 ,@Mat8 ,@Mat9 ,@Mat10, @Mat11, @Mat12, @Mat13, @Mat14, @Mat15, @Mat16,@Mat17,
                        @Mat18 ,@Mat19 ,@Mat20 ,@Mat21 ,@Mat22 ,@Mat23 ,@Mat24 ,@Mat25 ,@Mat26 ,@Mat27, @Mat28, @Mat29, @Mat30, @Mat31)");
        dw.SetSqlCommandParameters("datekey", datekey);
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("crcat", crcat);
        dw.SetSqlCommandParameters("intrate", intrate);
        dw.SetSqlCommandParameters("opdate", opdate);
        dw.SetSqlCommandParameters("actoutbal", actoutbal);
        dw.SetSqlCommandParameters("matcat", matcat);
        dw.SetSqlCommandParameters("llastcompletedduedate", llastcompletedduedate);
        dw.SetSqlCommandParameters("Mat1", mat1);
        dw.SetSqlCommandParameters("Mat2", mat2);
        dw.SetSqlCommandParameters("Mat3", mat3);
        dw.SetSqlCommandParameters("Mat4", mat4);
        dw.SetSqlCommandParameters("Mat5", mat5);
        dw.SetSqlCommandParameters("Mat6", mat6);
        dw.SetSqlCommandParameters("Mat7", mat7);
        dw.SetSqlCommandParameters("Mat8", mat8);
        dw.SetSqlCommandParameters("Mat9", mat9);
        dw.SetSqlCommandParameters("Mat10", mat10);
        dw.SetSqlCommandParameters("Mat11", mat11);
        dw.SetSqlCommandParameters("Mat12", mat12);
        dw.SetSqlCommandParameters("Mat13", mat13);
        dw.SetSqlCommandParameters("Mat14", mat14);
        dw.SetSqlCommandParameters("Mat15", mat15);
        dw.SetSqlCommandParameters("Mat16", mat16);
        dw.SetSqlCommandParameters("Mat17", mat17);
        dw.SetSqlCommandParameters("Mat18", mat18);
        dw.SetSqlCommandParameters("Mat19", mat19);
        dw.SetSqlCommandParameters("Mat20", mat20);
        dw.SetSqlCommandParameters("Mat21", mat21);
        dw.SetSqlCommandParameters("Mat22", mat22);
        dw.SetSqlCommandParameters("Mat23", mat23);
        dw.SetSqlCommandParameters("Mat24", mat24);
        dw.SetSqlCommandParameters("Mat25", mat25);
        dw.SetSqlCommandParameters("Mat26", mat26);
        dw.SetSqlCommandParameters("Mat27", mat27);
        dw.SetSqlCommandParameters("Mat28", mat28);
        dw.SetSqlCommandParameters("Mat29", mat29);
        dw.SetSqlCommandParameters("Mat30", mat30);
        dw.SetSqlCommandParameters("Mat31", mat31);
        rowAdded = dw.Insert();
    }


    private void InsertPL(string transdate, string cracno, double intrate, double actoutbal, int crcat, DateTime ldatedue, double outbal, double installment, int graceperiod, DateTime opdate, double extoutbal, string matcat, DateTime llastcompletedduedate)
    {
        FunctionClass fc = new FunctionClass();
        DataTable bulkdata = new DataTable();
        bulkdata = SetBucketTable(bulkdata);
        double caparreas = 0, intarreas = 0;
        //DataTable dt = new DataTable();
        DateTime trdate;
        //int matnumber = 0;
        //dt = GetMaturityBuckets();
        int[] arr = { 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 500};


        for (int i = 0; i < arr.Length; i++)
        {
            while (ldatedue.Date < opdate.Date)
            {
                ldatedue = opdate.AddMonths(1);
            }

            if (ldatedue.Date >= opdate.Date)
            {
                trdate = ldatedue.AddMonths(arr[i]);

                if (i == 0)
                {
                    if (ldatedue.Date < opdate.Date.AddDays(7) && ldatedue.Date >= opdate.Date)
                    {
                        //add to bucket1
                        caparreas = GetArreasInstalment(cracno, "capd");
                        intarreas = GetArreasInstalment(cracno, "intr");
                        outbal -= caparreas;
                        ldatedue = ndatedue;
                        if (installment > outbal)
                        {
                            outbal = 0.00;
                            bulkdata = GetMaturityBucket(trdate, 1, cracno, ldatedue, outbal, installment, intrate, graceperiod, crcat, caparreas, intarreas, bulkdata);
                            bulkdata = InsertRow(0, 0, bulkdata);
                        }
                        else
                        {
                            bulkdata = GetMaturityBucket(trdate, 1, cracno, ldatedue, outbal, installment, intrate, graceperiod, crcat, caparreas, intarreas, bulkdata);
                            bulkdata = InsertRow(0, 0, bulkdata);
                        }
                    }

                    else if (ldatedue.Date <= trdate.Date && ldatedue.Date >= opdate.Date.AddDays(7))
                    {
                        //add to bucket 2
                        //caparreas = GetArreasInstalment(cracno, "capd");
                        //intarreas = GetArreasInstalment(cracno, "intr");
                        caparreas = 0.00;
                        intarreas = 0.00;
                        bulkdata = InsertRow(0, 0, bulkdata);
                        bulkdata = GetMaturityBucket(trdate, 2, cracno, ldatedue, outbal, installment, intrate, graceperiod, crcat, caparreas, intarreas, bulkdata);
                        ldatedue = ndatedue;
                        outbal = noutbal;
                    }
                    else
                    {
                        bulkdata = InsertRow(0, 0, bulkdata);
                        bulkdata = InsertRow(0, 0, bulkdata);
                    }

                }

                else
                {

                    if (ldatedue.Date < trdate.Date && noutbal > 0)
                    {
                        //caparreas = GetArreasInstalment(cracno, "capd");
                        //intarreas = GetArreasInstalment(cracno, "intr");
                        caparreas = 0.00;
                        intarreas = 0.00;
                        bulkdata = GetMaturityBucket(trdate, i + 2, cracno, ldatedue, noutbal, installment, intrate, graceperiod, crcat, caparreas, intarreas, bulkdata);
                        ldatedue = ndatedue;
                        outbal = noutbal;

                    }
                    else
                    {

                        bulkdata = InsertRow(0, 0, bulkdata);

                    }

                }
            }

        }


        fc = new FunctionClass();
        double[] arrd = new double[32];
        for (int i = 0; bulkdata.Rows.Count > i; i++)
        {
            arrd[i] = double.Parse(bulkdata.Rows[i]["arrcap"].ToString());
        }

        InsertMaturityDataYearBase(transdate, cracno, crcat, intrate, opdate, actoutbal, "CAPD", llastcompletedduedate, arrd[0], arrd[1], arrd[2], arrd[3], arrd[4], arrd[5], arrd[6], arrd[7], arrd[8], arrd[9], arrd[10], arrd[11], arrd[12], arrd[13], arrd[14], arrd[15], arrd[16], arrd[17], arrd[18], arrd[19], arrd[20], arrd[21], arrd[22], arrd[23], arrd[24], arrd[25], arrd[26], arrd[27], arrd[28], arrd[29], outbal);

        double[] arri = new double[32];
        for (int i = 0; bulkdata.Rows.Count > i; i++)
        {

            arri[i] = double.Parse(bulkdata.Rows[i]["arrint"].ToString());
        }

        InsertMaturityDataYearBase(transdate, cracno, crcat, intrate, opdate, actoutbal, "INTR", llastcompletedduedate, arri[0], arri[1], arri[2], arri[3], arri[4], arri[5], arri[6], arri[7], arri[8], arri[9], arri[10], arri[11], arri[12], arri[13], arri[14], arri[15], arri[16], arri[17], arri[18], arri[19], arri[20], arri[21], arri[22], arri[23], arri[24], arri[25], arri[26], arri[27], arri[28], arri[29], outbal);
    }

    private DataTable GetMaturityBucket(DateTime trdate, int matnumber, string cracno, DateTime datedue, double outbal, double installment, double intrate, int graceperiod, int crcat, double caparreas, double intarreas, DataTable bulkdata)
    {
        interest = penal = capital = 0;
        RecoveryProcesClass rpc = new RecoveryProcesClass();
        //DataTable setclosingdata = new DataTable();
        //setclosingdata = SetDataTable(setclosingdata);
        rpc.MaturityAnalysis(cracno, datedue, outbal, installment, intrate, graceperiod, crcat, caparreas, intarreas, trdate);
        capital = rpc.MCapital;
        interest = rpc.MInterest;
        penal = rpc.MPenal;
        this.noutbal = rpc.Noutbal;
        this.ndatedue = rpc.Ndatedue;
        dt = InsertRow(capital, interest, dt);
        return dt;

    }

    private DataTable InsertRow(double arrcap, double arrint, DataTable dt)
    {
        DataRow dr;
        dr = dt.NewRow();
        dr["arrcap"] = arrcap;
        dr["arrint"] = arrint;
        dt.Rows.Add(dr);
        return dt;
    }

    private double GetArreasInstalment(string cracno, string taskid)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select assignamt-tramt as arreas from  transassign 
                            where cracno =  @cracno and (trstatus = 'p' or trstatus='n') and trtype = 'I'
                            and taskid = @taskid and tramt != assignamt");
        dw.SetSqlCommandParameters(@"cracno", cracno);
        dw.SetSqlCommandParameters(@"taskid", taskid);
        return double.Parse(dw.GetSingleData());

    }

    private DataTable SetBucketTable(DataTable bulkdata)
    {
        dt = new DataTable();

        DataColumn arrint;
        arrint = new DataColumn();
        arrint.DataType = Type.GetType("System.Double");
        arrint.ColumnName = "arrint";
        dt.Columns.Add(arrint);


        DataColumn arrcap;
        arrcap = new DataColumn();
        arrcap.DataType = Type.GetType("System.Double");
        arrcap.ColumnName = "arrcap";
        dt.Columns.Add(arrcap);

        return dt;

    }


    public object GetLoanCatogery()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select CRDES as LoanCatogery,Crcatcode from CrCategory");
        return dw.GetDataTable();
    }

    public string GetMaturityDate(string datekey)
    {
        dw = new DataWorksClass(reporTString);
        dw.SetCommand(@"select  distinct isnull((datekey),0) as datekey from 
                          ReportUser.MaturitydataYearbase where datekey=@datekey");
        dw.SetSqlCommandParameters("datekey", datekey);
        datekey = dw.GetSingleData();
        return datekey;
    }
    public DataTable DisplayData(string date, int crcat, string Crdesc)
    {
        dw = new DataWorksClass(reporTString);

        dt = new DataTable();
        dw.SetDataAdapter(@"select cracno, Mat2 as [1Year],Mat3 as [2Year],
                                    Mat4 as [3Year],Mat5 as [4Year],
                                    Mat6 as [5Year],Mat7 as [6Year],
                                    Mat8 as [7Year],Mat9 as [8Year],
                                    Mat10 as [9Year],Mat11 as [10Year],Mat12 as [11Year],
                                    Mat13 as [12Year],Mat14 as [13Year],Mat15 as [14Year],
                                    Mat16 as [15Year],Mat17 as [16Year],
                                    Mat18 as [17Year],Mat19 as [18Year],
                                    Mat20 as [19Year],Mat21 as [20Year],
                                    Mat22 as [21Year],Mat23 as [22Year],
                                    Mat24 as [23Year],Mat25 as [24Year],
                                    Mat26 as [25Year],Mat27 as [26Year],Mat28 as [27Year],
                                    Mat29 as [28Year],Mat30 as [29Year],Mat31 as [30Year],
                                    outbal as OutBal from MaturitydataYearbase where
                                    datekey=@date and crcat=@crcat and MatCat=@Crdesc");
        dw.SetDataAdapterParameters("date", date);
        dw.SetDataAdapterParameters("crcat", crcat);
        dw.SetDataAdapterParameters("Crdesc", Crdesc);
        dt = dw.GetDataTable();
        return dt;
    }
}
