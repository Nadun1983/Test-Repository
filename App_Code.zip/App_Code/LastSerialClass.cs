using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;


/// <summary>
/// Summary description for LastSerialClass
/// </summary>
public class LastSerialClass
{
    DataWorksClass dw;
	public LastSerialClass()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    string oldhousdbString = ConfigurationManager.ConnectionStrings["oldhousdbString"].ConnectionString.ToString();
    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString;
    string testhousdbString = ConfigurationManager.ConnectionStrings["testhousdbString"].ConnectionString.ToString();
    private SqlDataAdapter sqlAdapter;
    private SqlCommand sqlCmd;
    private DataTable dt;
    private SqlConnection sqlConn;
    private SqlDataReader sqldatareader;
    string _errmessage;

    // Get the Factore of Charge
    public long GetMaxNumber(string SerialDesc, bool status)
    {
        int rowadded = 0;
        string sqlSelect;
        long serialNo = 0;
        sqlSelect = @"Select SerialNo from LastSerial where SerialDesc = @SerialDesc and status = @status";

        sqlConn = new SqlConnection(constring);

        sqlCmd = new SqlCommand(sqlSelect, sqlConn);
        sqlCmd.Parameters.AddWithValue("SerialDesc", SerialDesc);
        sqlCmd.Parameters.AddWithValue("status", status);
        try
        {
            sqlConn.Open();
            sqldatareader = sqlCmd.ExecuteReader();
            sqldatareader.Read();
            if (sqldatareader.HasRows == true)
            {
                serialNo = long.Parse(sqldatareader["SerialNo"].ToString());
                if (SerialDesc.ToLower() == "disbrefno")
                {
                    long testno = GetSerial(serialNo);
                    if (testno == serialNo)
                    {
                        serialNo = getmaxBatchNo();
                    }
                }

                if (serialNo != 0)
                {
                    UpdateLastSerialStatus(SerialDesc, false);
                }

            }
            else
            {
                serialNo = 0;
            }
            sqldatareader.Close();

        }

        catch (Exception err)
        {
            this._errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return serialNo;
    }

    private long getmaxBatchNo()
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select max(batchno) + 1 from gltrans");
        return long.Parse(dw.GetSingleData());
    }
        
    private long GetSerial(long batchno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select batchno from gltrans where batchno=@batchno");
        dw.SetSqlCommandParameters("batchno", batchno);
        return long.Parse(dw.GetSingleData());

    }

    // Get the Factore of Charge
    public long GetMaxNumberInOldSystem(string SerialDesc, bool status)
    {
        int rowadded = 0;
        string sqlSelect;
        long serialNo = 0;
        sqlSelect = @"Select SerialNo from LastSerial where SerialDesc = @SerialDesc and status = @status";

        sqlConn = new SqlConnection(oldhousdbString);

        sqlCmd = new SqlCommand(sqlSelect, sqlConn);
        sqlCmd.Parameters.AddWithValue("SerialDesc", SerialDesc);
        sqlCmd.Parameters.AddWithValue("status", status);
        try
        {
            sqlConn.Open();
            sqldatareader = sqlCmd.ExecuteReader();
            sqldatareader.Read();
            if (sqldatareader.HasRows == true)
            {
                serialNo = long.Parse(sqldatareader["SerialNo"].ToString());
                if (serialNo != 0)
                {
                    UpdateLastSerialStatus(SerialDesc, false);
                }

            }
            else
            {
                serialNo = 0;
            }
            sqldatareader.Close();
            sqlConn.Dispose();

        }

        catch (Exception err)
        {
            this._errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return serialNo;
    }

    // Update Apprval Status
    public int UpdateLastserial(string SerialDesc, long SerialNo)
    {
        string sqlUpdate;


        sqlUpdate = @"update LastSerial set SerialNo = @SerialNo where SerialDesc = @SerialDesc";

        sqlConn = new SqlConnection(constring);
        sqlCmd = new SqlCommand(sqlUpdate, sqlConn);

        sqlCmd.Parameters.AddWithValue("SerialDesc", SerialDesc);
        sqlCmd.Parameters.AddWithValue("SerialNo", SerialNo);

        int rowAdded = 0;

        try
        {
            sqlConn.Open();

            rowAdded = sqlCmd.ExecuteNonQuery();
            if (rowAdded != 0)
            {
                UpdateLastSerialStatus(SerialDesc, true);
            }

        }

        catch (Exception err)
        {


            _errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return rowAdded;
    }

    // Update Apprval Status
    public int UpdateLastserialInOldSystem(string SerialDesc, long SerialNo)
    {
        string sqlUpdate;


        sqlUpdate = @"update LastSerial set SerialNo = @SerialNo where SerialDesc = @SerialDesc";

        sqlConn = new SqlConnection(oldhousdbString);
        sqlCmd = new SqlCommand(sqlUpdate, sqlConn);

        sqlCmd.Parameters.AddWithValue("SerialDesc", SerialDesc);
        sqlCmd.Parameters.AddWithValue("SerialNo", SerialNo);

        int rowAdded = 0;

        try
        {
            sqlConn.Open();

            rowAdded = sqlCmd.ExecuteNonQuery();
            if (rowAdded != 0)
            {
                UpdateLastSerialStatus(SerialDesc, true);
            }

        }

        catch (Exception err)
        {


            _errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return rowAdded;
    }

    // Update Apprval Status
    public int UpdateLastSerialStatus(string SerialDesc, bool status)
    {
        string sqlUpdate;


        sqlUpdate = @"update LastSerial set status = @status where SerialDesc = @SerialDesc";

        sqlConn = new SqlConnection(constring);
        sqlCmd = new SqlCommand(sqlUpdate, sqlConn);

        sqlCmd.Parameters.AddWithValue("SerialDesc", SerialDesc);
        sqlCmd.Parameters.AddWithValue("status", status);


        int rowAdded = 0;

        try
        {
            sqlConn.Open();

            rowAdded = sqlCmd.ExecuteNonQuery();

        }

        catch (Exception err)
        {


            _errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return rowAdded;
    }


    // Update Apprval Status
    public int UpdateLastSerialStatusInOldSystem(string SerialDesc, bool status)
    {
        string sqlUpdate;


        sqlUpdate = @"update LastSerial set status = @status where SerialDesc = @SerialDesc";

        sqlConn = new SqlConnection(oldhousdbString);
        sqlCmd = new SqlCommand(sqlUpdate, sqlConn);

        sqlCmd.Parameters.AddWithValue("SerialDesc", SerialDesc);
        sqlCmd.Parameters.AddWithValue("status", status);


        int rowAdded = 0;

        try
        {
            sqlConn.Open();

            rowAdded = sqlCmd.ExecuteNonQuery();

        }

        catch (Exception err)
        {


            _errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return rowAdded;
    }

   
}
