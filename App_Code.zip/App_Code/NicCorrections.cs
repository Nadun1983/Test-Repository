﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Configuration;

/// <summary>
/// Summary description for NicCorrections
/// </summary>
public class NicCorrections
{
    string msg = "";
    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();
    DateTime datedue, nextdue, intdatedue;
    int intdays;
    DataWorksClass dw;

	public NicCorrections()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    

    public int InsertCRHolder(decimal CrAcNo,decimal AppNo,string HolderType,int HolderCount ,string NicNo,int CustNo,string HoldRelation,string IsAdditional)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO CrHolder
                        CrAcNo,AppNo,HolderType,HolderCount,NicNo,CustNo,HoldRelation,IsAdditional
                    VALUES
                            @cracno,@AppNo,@HolderType,@HolderCount,@NicNo,@CustNo,@HoldRelation,@IsAdditional");
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        dw.SetSqlCommandParameters("AppNo", AppNo);
        dw.SetSqlCommandParameters("HolderType", HolderType);
        dw.SetSqlCommandParameters("HolderCount", HolderCount);
        dw.SetSqlCommandParameters("NicNo", NicNo);
        dw.SetSqlCommandParameters("CustNo", CustNo);
        dw.SetSqlCommandParameters("HoldRelation", HoldRelation);
        dw.SetSqlCommandParameters("IsAdditional", IsAdditional);
        return dw.Insert();
    }

    public int InsertAppHolder(decimal AppNo, string HolderType, string NicNo, int CustNo, string HoldRelation, string IsAdditional, int UpdateLevel)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO Appholder
           AppNo,HolderType,NicNo,CustNo,HoldRelation,IsAdditional,UpdateLevel
     VALUES
           @AppNo,@HolderType,@NicNo,@CustNo,@HoldRelation,@IsAdditional,@UpdateLevel");
        dw.SetSqlCommandParameters("AppNo", AppNo);
        dw.SetSqlCommandParameters("HolderType", HolderType);
        dw.SetSqlCommandParameters("NicNo", NicNo);
        dw.SetSqlCommandParameters("CustNo", CustNo);
        dw.SetSqlCommandParameters("HoldRelation", HoldRelation);
        dw.SetSqlCommandParameters("IsAdditional", IsAdditional);
        dw.SetSqlCommandParameters("UpdateLevel", UpdateLevel);
        return dw.Insert();
    }

    public int InsertCustomerMain(int CustNo,string NicNo,char PassportNo,int TitleCode,string Surname,string Initials,string Othername,string Cstatus,string Location,string Street,string City,string HomeNo,string Mobile,DateTime DoBirth,string Email,string Country,string CustomerType,int UpdateLevel)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO Customermain
           CustNo,NicNo,PassportNo,TitleCode,Surname,Initials
           ,Othername,Cstatus,Location,Street,City,HomeNo,Mobile
           ,DoBirth,Email,Country,CustomerType,UpdateLevel
     VALUES
           @CustNo,@NicNo,@PassportNo,@TitleCode,@Surname,@Initials
           ,@Othername,@Cstatus,@Location,@Street,@City,@HomeNo,@Mobile
           ,@DoBirth,@Email,@Country,@CustomerType,@UpdateLevel");
        dw.SetSqlCommandParameters("CustNo", CustNo);
        dw.SetSqlCommandParameters("NicNo", NicNo);
        dw.SetSqlCommandParameters("PassportNo", PassportNo);
        dw.SetSqlCommandParameters("TitleCode", TitleCode);
        dw.SetSqlCommandParameters("Surname", Surname);
        dw.SetSqlCommandParameters("Initials", Initials);
        dw.SetSqlCommandParameters("Othername", Othername);
        dw.SetSqlCommandParameters("Cstatus", Cstatus);
        dw.SetSqlCommandParameters("Location", Location);
        dw.SetSqlCommandParameters("Street", Street);
        dw.SetSqlCommandParameters("City", City);
        dw.SetSqlCommandParameters("HomeNo", HomeNo);
        dw.SetSqlCommandParameters("Mobile", Mobile);
        dw.SetSqlCommandParameters("DoBirth", DoBirth);
        dw.SetSqlCommandParameters("Email", Email);
        dw.SetSqlCommandParameters("Country", Country);
        dw.SetSqlCommandParameters("CustomerType", CustomerType);
        dw.SetSqlCommandParameters("UpdateLevel", UpdateLevel);
        return dw.Insert();
    }
}
