﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Data;
using System.Configuration;

/// <summary>
/// Summary description for Corrections
/// </summary>
public class Corrections
{
    DataTable dt;
    DataWorksClass dw;
    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();
    string constringold = ConfigurationManager.ConnectionStrings["TestOld"].ConnectionString.ToString();
	public Corrections()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    private DataTable GetWrongDueDatesRecords()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select distinct cracno ,datedue,trdate ,(count(datedue)) as Noofdates from transassign 
                        where trstatus <> 'c'
                        group by datedue , cracno ,trdate
                        having count(datedue)>3 order by cracno");
        return dw.GetDataTable();
    }

    private DataTable GetdateDue(string cracno)
    {
        dw = new DataWorksClass(constringold);
        dw.SetDataAdapter(@"select datedue, lastcompletedduedate from housprop where cracno = @cracno");
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }



    public void CorrectData()
    {
        dt = new DataTable();
        dt = GetWrongDueDatesRecords();
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            string cracno = dt.Rows[i]["cracno"].ToString();
            DataTable dt1 = new DataTable();
            dt1 = GetdateDue(cracno);
            DateTime datedue = DateTime.Parse(dt1.Rows[0]["datedue"].ToString());
            DateTime lastcompletedduedate = DateTime.Parse(dt1.Rows[0]["lastcompletedduedate"].ToString());

            if (datedue >= lastcompletedduedate)
            {
                DataTable dt2 = new DataTable();
                dt2 = GetCapIntRecord(cracno);
                for (int x = 0; x < dt2.Rows.Count; x++)
                {
                    string refno = dt2.Rows[x]["refno"].ToString();
                    string taskidint = dt2.Rows[x]["taskid"].ToString();
                    if (taskidint == "INTR")
                    {
                        UpdateDateDue(cracno, datedue, refno);
                        if (dt2.Rows.Count - 1 > x)
                        {
                            string taskidcap = dt2.Rows[x + 1]["taskid"].ToString();
                            refno = dt2.Rows[x + 1]["refno"].ToString();
                            UpdateDateDue(cracno, datedue, refno);
                        }
                        datedue = datedue.AddMonths(1);
                        x++;
                    }
                    else
                    {
                        datedue = datedue.AddMonths(1);
                    }
                }
            }
            else
            {
                // WorngData
            }
        }
    }

    public void SetTransDateDue(string cracno)
    {
        DataTable dt1 = new DataTable();
        dt1 = GetdateDue(cracno);
        try
        {
            DateTime datedue = DateTime.Parse(dt1.Rows[0]["datedue"].ToString());
            DateTime lastcompletedduedate = DateTime.Parse(dt1.Rows[0]["lastcompletedduedate"].ToString());

            if (datedue >= lastcompletedduedate)
            {
                DataTable dt2 = new DataTable();
                dt2 = GetCapIntRecord(cracno);
                for (int x = 0; x < dt2.Rows.Count; x++)
                {
                    string refno = dt2.Rows[x]["refno"].ToString();
                    string taskidint = dt2.Rows[x]["taskid"].ToString();
                    if (taskidint == "INTR")
                    {
                        UpdateDateDue(cracno, datedue, refno);
                        if (dt2.Rows.Count - 1 > x)
                        {
                            string taskidcap = dt2.Rows[x + 1]["taskid"].ToString();
                            refno = dt2.Rows[x + 1]["refno"].ToString();
                            UpdateDateDue(cracno, datedue, refno);
                        }
                        datedue = datedue.AddMonths(1);
                        x++;
                    }
                    else
                    {
                        //datedue = datedue.AddMonths(1);
                    }
                }
            }
            else
            {
                // WorngData
            }
        }
        catch(Exception ex)
        {
            //
        }

       
    }

    private int UpdateDateDue(string cracno, DateTime datedue, string refno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update transassign set datedue = @datedue where cracno = @cracno and refno = @refno");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("datedue", datedue);
        dw.SetSqlCommandParameters("refno", refno);
        return dw.Update();
    }

    private DataTable GetCapIntRecord(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from transassign where cracno = @cracno 
                            and (taskid ='CAPD' or taskid = 'INTR') and trtype = 'I'
                            and trstatus <> 'c' and (system is null or system != 'M')
                            order by refno, taskid desc");
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }


    //2009-09-08 vihanga
    public DataTable GetTransNo(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select distinct Transno from gltrans where cracno=@cracno order by transno");
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }

    //2009-09-08 vihanga
    public DataTable GetDatedueLoans()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select distinct cracno ,datedue,trdate ,(count(datedue)) as Noofdates from transassign 
                            where trstatus <> 'c' group by datedue , cracno ,trdate
                            having count(datedue)>3 order by cracno");
        return dw.GetDataTable();
    }

    //2009-09-08 vihanga
    public DataTable GetCapitalInsertRecord()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select distinct assignamt,tramt,transno,cracno ,datedue,trdate ,(count(datedue)) as Noofdates ,
                            disbrefno,trdate,datedue from transassign 
                            where trstatus <> 'c' and taskid='INTR' and adddate='2009-09-07 00:00:00.000' and trstatus = 'P' and assignamt>tramt
                            group by datedue , cracno ,trdate,transno,assignamt,tramt,disbrefno,trdate,datedue
                            having count(datedue)=1 order by cracno");
        return dw.GetDataTable();
    }

    public int GetCapRecord(string cracno, double assignamt)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select count(*)  from transassign where cracno = @cracno and assignamt=@assignamt");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("assignamt", assignamt);
        string a = dw.GetSingleData();
        int count = int.Parse(dw.GetSingleData());
        return count;
    }

    //2009-09-08 vihanga
    public DataTable GetInstalment(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select h.instalment,h.intrate,c.crcat from housprop h,crmast c where h.cracno=@cracno and c.cracno=h.cracno");
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }

    //2009-09-08 vihanga
    public string InsertTransAssign(string CrAcNo, string taskid, double AssignAmt, double tramt, string TrStatus,
      string AddUser, DateTime AddDate, string TransRef, string trtype, double intrate, int RecOrder,
      long disbrefno, DateTime trdate, string description, DateTime DateDue, int crcat)
    {
        if (taskid == "CAPD")
        {
            dw = new DataWorksClass(constring);
            dw.SetCommand(@"INSERT INTO TransAssign (CrAcNo,taskid,AssignAmt, tramt,TrStatus,AddUser,
                        AddDate,TransRef,trtype, intrate,RecOrder,disbrefno, trdate, DateDue, 
                        description, crcat)
                       values (@CrAcNo,@taskid,@AssignAmt, @tramt,@TrStatus,@AddUser,@AddDate,
                        @TransRef,@trtype,@intrate,@RecOrder,@disbrefno, @trdate, @DateDue, 
                        @description, @crcat) SELECT IDENT_CURRENT('TransAssign')  ");
            dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
            dw.SetSqlCommandParameters("taskid", taskid);
            dw.SetSqlCommandParameters("AssignAmt", AssignAmt);
            dw.SetSqlCommandParameters("tramt", tramt);
            dw.SetSqlCommandParameters("TrStatus", TrStatus);
            dw.SetSqlCommandParameters("AddUser", AddUser);
            dw.SetSqlCommandParameters("AddDate", AddDate);
            dw.SetSqlCommandParameters("TransRef", TransRef);
            dw.SetSqlCommandParameters("trtype", trtype);
            dw.SetSqlCommandParameters("intrate", intrate);
            dw.SetSqlCommandParameters("RecOrder", RecOrder);
            dw.SetSqlCommandParameters("disbrefno", disbrefno);
            dw.SetSqlCommandParameters("trdate", trdate);
            dw.SetSqlCommandParameters("DateDue", DateDue);
            dw.SetSqlCommandParameters("description", description);
            dw.SetSqlCommandParameters("crcat", crcat);
            return dw.InsertandReturnID();
        }
        else
        {
            if (tramt > 0)
            {
                dw = new DataWorksClass(constring);
                dw.SetCommand(@"INSERT INTO TransAssign (CrAcNo,taskid,AssignAmt, tramt,TrStatus,AddUser,
                        AddDate,TransRef,trtype, intrate,RecOrder,disbrefno, trdate, DateDue, 
                        description, crcat)
                       values (@CrAcNo,@taskid,@AssignAmt, @tramt,@TrStatus,@AddUser,@AddDate,
                        @TransRef,@trtype,@intrate,@RecOrder,@disbrefno, @trdate, @DateDue, 
                        @description, @crcat) SELECT IDENT_CURRENT('TransAssign')  ");
                dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
                dw.SetSqlCommandParameters("taskid", taskid);
                dw.SetSqlCommandParameters("AssignAmt", AssignAmt);
                dw.SetSqlCommandParameters("tramt", tramt);
                dw.SetSqlCommandParameters("TrStatus", TrStatus);
                dw.SetSqlCommandParameters("AddUser", AddUser);
                dw.SetSqlCommandParameters("AddDate", AddDate);
                dw.SetSqlCommandParameters("TransRef", TransRef);
                dw.SetSqlCommandParameters("trtype", trtype);
                dw.SetSqlCommandParameters("intrate", intrate);
                dw.SetSqlCommandParameters("RecOrder", RecOrder);
                dw.SetSqlCommandParameters("disbrefno", disbrefno);
                dw.SetSqlCommandParameters("trdate", trdate);
                dw.SetSqlCommandParameters("DateDue", DateDue);
                dw.SetSqlCommandParameters("description", description);
                dw.SetSqlCommandParameters("crcat", crcat);
                return dw.InsertandReturnID();
            }
            else
            {
                return "0";
            }
        }
    }

    //2009-09-08 vihanga
    public DataTable GetTransactions()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select  batchno, cracno from batchtmp order by batchno");
        return dw.GetDataTable();
    }


    public void SetGLTrans()
    {
        dt = new DataTable();
        dt = GetTransactions();
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            //string transno = 603080
        }
    }

    //2009-09-21 vihanga
    public DataTable GetTransassignData(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from transassign where cracno=@cracno");
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }

    //2009-09-21 vihanga
    public DataTable GetHouspropData(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from housprop where cracno=@cracno");
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }


    public DataTable GEtErrorDateDues()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select cracno, lastcompletedduedate, datedue,  datediff(day,lastcompletedduedate, datedue)
                            from housprop where datediff(day,lastcompletedduedate, datedue) > 31");
        return dw.GetDataTable();
    }


//    public string GetRefNo(string cracno)
//    {
//        dw = new DataWorksClass(constring);
//        dw.SetCommand(@"select max(refno) as ref from transassign where cracno=@cracno and trstatus != 'C'
//                        and taskid='CAPD'");
//        dw.SetSqlCommandParameters("cracno", cracno);
//        return dw.GetSingleData();
//    }


    public DataTable GetdateDueCorrection(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select isNULL(max(datedue), '01/01/1900') as datedue, trstatus from transassign where cracno=@cracno 
                            and trstatus != 'C'
                            and taskid='CAPD'
                            group by trstatus
                            order by trstatus desc");
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }

     public int InsertIntoDueDateCorrection(DateTime ChangeDate, string CrAcNo, DateTime nextdue, DateTime lastcompletedduedate,
                                           string ChangeUser, string Status)
    {

        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO DueDateCorrection (ChangeDate,CrAcNo,nextdue,lastcompletedduedate,ChangeUser,Status)
                       values (@ChangeDate,@CrAcNo,@nextdue,@lastcompletedduedate,@ChangeUser,@Status)");
        dw.SetSqlCommandParameters("ChangeDate", ChangeDate);
        dw.SetSqlCommandParameters("CrAcNo", CrAcNo);
        dw.SetSqlCommandParameters("nextdue", nextdue);
        dw.SetSqlCommandParameters("lastcompletedduedate", lastcompletedduedate);
        dw.SetSqlCommandParameters("ChangeUser", ChangeUser);
        dw.SetSqlCommandParameters("Status", Status);
        return dw.Insert();
    }

    public DataTable GetErrorTrstatusRec()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select distinct cracno from transassign where trstatus = 'P' and system is null");
        return dw.GetDataTable();
    }

    private string GetMaxPartialPayment(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select max(refno) as refno from transassign where trstatus = 'P' and trtype = 'I' and cracno=@cracno ");
        dw.SetSqlCommandParameters("cracno", cracno);
        return dw.GetSingleData();
    }


    private double GetTransactions(string transassignrefno, string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select sum(tramt) from gltrans where cracno = @cracno and transassignrefno = @transassignrefno
                        and refglcode != 903081000000994");
        dw.SetSqlCommandParameters("transassignrefno", transassignrefno);
        dw.SetSqlCommandParameters("cracno", cracno);
        return double.Parse(dw.GetSingleData());
    }

    private double UpdateTramt(string cracno, string refno, double tramt)
    {

        double extamt = GetTramt(refno, cracno);
        if (extamt != tramt)
        {
            dw = new DataWorksClass(constring);
            dw.SetCommand(@"Update transassign set tramt=@tramt where cracno=@cracno and refno=@refno");
            dw.SetSqlCommandParameters("cracno", cracno);
            dw.SetSqlCommandParameters("refno", refno);
            dw.SetSqlCommandParameters("tramt", tramt);
            dw.Update();
            return extamt;
        }
        else
        {
            return 0;
        }
    }

    private double GetTramt(string refno, string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select tramt from transassign where refno = @refno and cracno = @cracno");
        dw.SetSqlCommandParameters("refno", refno);
        dw.SetSqlCommandParameters("cracno", cracno);
        return double.Parse(dw.GetSingleData());
    }

    public void CorrectTrStatus()
    {
        dt = new DataTable();
        dt = GetErrorTrstatusRec();
        for (int i = 0; dt.Rows.Count > i; i++)
        {
            string cracno = dt.Rows[i]["cracno"].ToString();
            string refno = GetMaxPartialPayment(cracno);
            double tramt = GetTransactions(refno, cracno);
            double extamt = UpdateTramt(cracno, refno, tramt);
            if (extamt != 0)
            {
                InsertTrstatustemp(cracno, tramt, refno, extamt);
            }

        }
    }

    private int InsertTrstatustemp(string cracno, double tramt, string refno, double extamt)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO TrStatusTemp (Cracno,tramt,refno, extamt) VALUES (@Cracno, @tramt, @refno,@extamt)");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("tramt", tramt);
        dw.SetSqlCommandParameters("extamt", extamt);
        dw.SetSqlCommandParameters("refno", refno);
        return dw.Insert();
    }

    public DataTable getloanno()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select p.CrAcNo as cracno From crmast c,housprop p where 
                                c.cracno=p.CrAcNo and p.CrCat =4 and c.GrantDate <= '2007-06-15'
                                and c.IntRate = 11.00");
        return dw.GetDataTable(); 
    }
}
