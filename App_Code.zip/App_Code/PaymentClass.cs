using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// Summary description for PaymentClass
/// </summary>
public class PaymentClass
{
	public PaymentClass()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    private SqlConnection sqlConn;
    SqlCommand sqlCmd;
    SqlDataReader sqlDataReader;
    SqlDataAdapter sqldataAdapter;
    DataTable dt;
    DataWorksClass dw;
    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();
    string _errmessage;


    // Isert Method

    //public int TextInserter(DateTime trdate,string trtime,DateTime capdate,string acno,decimal amount,string cardnumber,string atmnumber,
    //    int trnno,string accsign,string sbranch,int lineno,string mti,string trcode,string trmode,string status1,string billcode,decimal adddate)

//    public int InsertPossiblePayments(int PaymentTypeID, bool IsPaid, string AppNo, decimal Amount, bool confirmPayment, DateTime confirmdate)
//    {
//        SqlTransaction sqlTrans;
//        string sqlInsert;

//        sqlInsert = @"INSERT INTO PaymentMade(PaymentTypeID, IsPaid, AppNo, Amount, ConfirmPayment, ConfirmDate)
//                      VALUES (@PaymentTypeID, @IsPaid, @AppNo, @Amount, @ConfirmPayment, @ConfirmDate)";
        
//        sqlConn = new SqlConnection(constring);
//        sqlCmd = new SqlCommand(sqlInsert, sqlConn);

//        sqlCmd.Parameters.AddWithValue("PaymentTypeID", PaymentTypeID);
//        sqlCmd.Parameters.AddWithValue("IsPaid", IsPaid);
//        sqlCmd.Parameters.AddWithValue("AppNo", AppNo);
//        sqlCmd.Parameters.AddWithValue("Amount", Amount);
//        sqlCmd.Parameters.AddWithValue("ConfirmPayment", confirmPayment);
//        sqlCmd.Parameters.AddWithValue("ConfirmDate", confirmdate);
       
//        int rowAdded = 0;

//        sqlConn.Open();
//        sqlTrans = sqlConn.BeginTransaction();
//        sqlCmd.Connection = sqlConn;
//        sqlCmd.Transaction = sqlTrans;
        
//        try
//        {
//            rowAdded = sqlCmd.ExecuteNonQuery();
//            sqlTrans.Commit();
//        }

//        catch (Exception err)
//        {

//            //Console.WriteLine("Commit Exception Type: {0}", ex.GetType());
//            //Console.WriteLine("  Message: {0}", ex.Message);

//            // Attempt to roll back the transaction.
//            try
//            {
//                sqlTrans = sqlConn.BeginTransaction();
//                sqlTrans.Rollback();
//            }
//            catch (Exception ex2)
//            {
//                // This catch block will handle any errors that may have occurred
//                // on the server that would cause the rollback to fail, such as
//                // a closed connection
//            }
//            _errmessage = err.Message;
//        }

//        finally
//        {
//            sqlConn.Close();
//            sqlTrans.Dispose();
//            sqlConn.Dispose();
//        }

//        return rowAdded;
//    }


  
    //// Update branchinfo with Branch Code
    //public int UpdateBranchCode(string branchcode)
    //{
    //    string sqlUpdate;


    //    sqlUpdate = @"";

    //    sqlConn = new SqlConnection(constring);
    //    sqlCmd = new SqlCommand(sqlUpdate, sqlConn);

    //    sqlCmd.Parameters.AddWithValue("branchcode", branchcode);
       

    //    int rowAdded = 0;



    //    try
    //    {
    //        sqlConn.Open();

    //        rowAdded = sqlCmd.ExecuteNonQuery();

    //    }

    //    catch (Exception err)
    //    {


    //        _errmessage = err.Message;
    //    }

    //    finally
    //    {
    //        sqlConn.Close();
    //        sqlConn.Dispose();
    //    }

    //    return rowAdded;
    //}


  
    // Get LoanType
    //public string GetLoanType(string appno)
    //{
    //    int rowadded = 0;
    //    string sqlSelect;
    //    string appCat = "";
    //    sqlSelect = @"SELECT AppCat from CrApp where AppNo = @AppNo";

    //    sqlConn = new SqlConnection(constring);

    //    sqlCmd = new SqlCommand(sqlSelect, sqlConn);
    //    sqlCmd.Parameters.AddWithValue("AppNo", appno);


    //    try
    //    {
    //        sqlConn.Open();
    //        sqlDataReader = sqlCmd.ExecuteReader();
    //        sqlDataReader.Read();
    //        if (sqlDataReader.HasRows == true)
    //        {
    //            appCat = sqlDataReader["AppCat"].ToString();
    //        }
    //        else
    //        {
              
    //        }
    //        sqlDataReader.Close();

    //    }

    //    catch (Exception err)
    //    {
    //        this._errmessage = err.Message;
    //    }

    //    finally
    //    {
    //        sqlConn.Close();
    //    }

    //    return appCat;

    //}

    // Get LoanType
    public decimal GetTotAmount(string appno)
    {
        int rowadded = 0;
        string sqlSelect;
        decimal totamount = 0;
        sqlSelect = @"SELECT sum(amount) as [Total] from paymentmade where AppNo = @AppNo";

        sqlConn = new SqlConnection(constring);

        sqlCmd = new SqlCommand(sqlSelect, sqlConn);
        sqlCmd.Parameters.AddWithValue("AppNo", appno);


        try
        {
            sqlConn.Open();
            sqlDataReader = sqlCmd.ExecuteReader();
            sqlDataReader.Read();
            if (sqlDataReader.HasRows == true)
            {
                totamount = decimal.Parse(sqlDataReader["Total"].ToString());
            }
            else
            {

            }
            sqlDataReader.Close();

        }

        catch (Exception err)
        {
            this._errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
        }

        return totamount;

    }


    // Get LoanType
    public int GetCatCodeId(string appno)
    {
        int crcatcode = 0;
        string sqlSelect;
        sqlSelect = @"select crcatcode from CrApp where appno = @appno";

        sqlConn = new SqlConnection(constring);

        sqlCmd = new SqlCommand(sqlSelect, sqlConn);
        sqlCmd.Parameters.AddWithValue("appno", appno);


        try
        {
            sqlConn.Open();
            sqlDataReader = sqlCmd.ExecuteReader();
            sqlDataReader.Read();
            if (sqlDataReader.HasRows == true)
            {
                crcatcode = int.Parse(sqlDataReader["crcatcode"].ToString());
            }
            else
            {

            }
            sqlDataReader.Close();

        }

        catch (Exception err)
        {
            this._errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
        }

        return crcatcode;

    }


//    //Get Possible Payments
//    public DataTable GetPossiblePayment(int catpurposeid, string loantype)
//    {
//        string sqlSelect = @"select pt.Description, pt.trcode, pt.UnitCharge, pt.ValueType, pt.type  
//                            from PaymentType pt, PossiblePayments pp
//                            where crcatcode = 1 and pt.type= 'n' and  
//                            pt.trcode = pp.trcode order by pt.Description";

//        SqlConnection sqlConn = new SqlConnection(constring);
//        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);

//        sqldataAdapter.SelectCommand.Parameters.AddWithValue("catpurposeid", catpurposeid);
//        sqldataAdapter.SelectCommand.Parameters.AddWithValue("type", loantype);
//        dt = new DataTable();

//        try
//        {
//            sqlConn.Open();
//            sqldataAdapter.Fill(dt);
//        }
//        catch (Exception er)
//        {
//            //
//        }

//        finally
//        {
//            sqlConn.Close();
//            sqlConn.Dispose();
//        }

//        return dt;

//    }


//    // Get Assigned Payments
//    public DataTable GetAssignedPayments(string appno, string TrStatus, string TransRef)
//    {
//        dw = new DataWorksClass(constring);
//        dw.SetDataAdapter(@"select ta.refno, ta.AssignAmt, ta.AddDate, tc.TrDesc from TransAssign ta, transCat tc where ta.cracno = @cracno 
//                            and ta.TrStatus=@TrStatus and  ta.TransRef = @TransRef");
//        dw.SetDataAdapterParameters("cracno", appno);
//        dw.SetDataAdapterParameters("TrStatus", TrStatus);
//        dw.SetDataAdapterParameters("TransRef", TransRef);
//        return dw.GetDataTable();
//    }


//    //Get Possible Payments
//    public DataTable GetPaymentMade(string appno, bool ConfirmPayment, bool ispaid, string TranStatus)
//    {
//        string sqlSelect = @"select  pm.PaymentTypeID, tc.TrDesc, pm.amount, pm.ConfirmPayment, pm.ConfirmDate
//                             from paymentmade pm, TransCat tc
//                             where pm.PaymentTypeID = tc.trcode and pm.appno = @appno
//                             and pm.ispaid = @ispaid and ConfirmPayment = @ConfirmPayment
//                             and TranStatus=@TranStatus   ";

//        SqlConnection sqlConn = new SqlConnection(constring);
//        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);

//        sqldataAdapter.SelectCommand.Parameters.AddWithValue("AppNo", appno);
//        sqldataAdapter.SelectCommand.Parameters.AddWithValue("ispaid", ispaid);
//        sqldataAdapter.SelectCommand.Parameters.AddWithValue("ConfirmPayment", ConfirmPayment);
//        sqldataAdapter.SelectCommand.Parameters.AddWithValue("TranStatus", TranStatus);
//        dt = new DataTable();

//        try
//        {
//            sqlConn.Open();
//            sqldataAdapter.Fill(dt);
//        }
//        catch (Exception er)
//        {
//            //
//        }

//        finally
//        {
//            sqlConn.Close();
//            sqlConn.Dispose();
//        }

//        return dt;

//    }



    //GetDistance
    public DataTable GetDistance(string appno)
    {
        string sqlSelect = @"select  DistanceInspect, DistanceValuation
                             from crapp where appno = @appno";

        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);

        sqldataAdapter.SelectCommand.Parameters.AddWithValue("appno", appno);
       
        dt = new DataTable();

        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return dt;

    }


//    // Update Payment made with new values
//    public int UpdatePaymentMade(string appno, int paymenttypeid, bool ispaid, decimal amount)
//    {
//        string sqlUpdate;

//        sqlUpdate = @"update paymentmade set IsPaid=@IsPaid, Amount = @Amount where 
//                       PaymentTypeId=@PaymentTypeId and appno = @OriginalAppNo";

//        sqlConn = new SqlConnection(constring);
//        sqlCmd = new SqlCommand(sqlUpdate, sqlConn);

//        sqlCmd.Parameters.AddWithValue("IsPaid", ispaid);
//        sqlCmd.Parameters.AddWithValue("Amount", amount);
//        sqlCmd.Parameters.AddWithValue("OriginalAppNo", appno);

//        int rowAdded = 0;
        
//        try
//        {
//            sqlConn.Open();

//            rowAdded = sqlCmd.ExecuteNonQuery();

//        }

//        catch (Exception err)
//        {


//            _errmessage = err.Message;
//        }

//        finally
//        {
//            sqlConn.Close();
//            sqlConn.Dispose();
//        }

//        return rowAdded;
//    }


   

//    // Update PaymentType confirmation
//    public int UpdateConfirmPayment(string appno, int paymenttypeid, bool confirmPayment)
//    {
//        string sqlUpdate;

//        sqlUpdate = @"update paymentmade set ConfirmPayment=@ConfirmPayment where 
//                       appno = @OriginalAppNo and PaymentTypeId = @PaymentTypeId";

//        sqlConn = new SqlConnection(constring);
//        sqlCmd = new SqlCommand(sqlUpdate, sqlConn);

//        sqlCmd.Parameters.AddWithValue("OriginalAppNo", appno);
//        sqlCmd.Parameters.AddWithValue("ConfirmPayment", confirmPayment);
//        sqlCmd.Parameters.AddWithValue("PaymentTypeId", paymenttypeid);

//        int rowAdded = 0;

//        try
//        {
//            sqlConn.Open();

//            rowAdded = sqlCmd.ExecuteNonQuery();

//        }

//        catch (Exception err)
//        {


//            _errmessage = err.Message;
//        }

//        finally
//        {
//            sqlConn.Close();
//            sqlConn.Dispose();
//        }

//        return rowAdded;
//    }



    // Get the Factore of Charge

    public decimal GetFactor(string taskid, string type, decimal crAmt)
    {
        int rowadded = 0;
        string sqlSelect;
        decimal factor = 0;
        sqlSelect = @"select max(factor) as factor from parameterrange where taskid =@taskid
                      and type=@type  and (range < @amount)    ";

        sqlConn = new SqlConnection(constring);

        sqlCmd = new SqlCommand(sqlSelect, sqlConn);
        sqlCmd.Parameters.AddWithValue("taskid", taskid);
        sqlCmd.Parameters.AddWithValue("type", type);
        sqlCmd.Parameters.AddWithValue("amount", crAmt);


        try
        {
            sqlConn.Open();
            sqlDataReader = sqlCmd.ExecuteReader();
            sqlDataReader.Read();
            if (sqlDataReader.HasRows == true)
            {
                factor = decimal.Parse(sqlDataReader["factor"].ToString());
            }
            else
            {
                
            }
            sqlDataReader.Close();

        }

        catch (Exception err)
        {
            this._errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
        }

        return factor;

    }


    // Generate A file No
    public decimal GetCrAmt(string appno)
    {
        int rowadded = 0;
        string sqlSelect;
        decimal cramt = 0;
        sqlSelect = @"SELECT CrAmt from CrApp where AppNo = @AppNo";

        sqlConn = new SqlConnection(constring);

        sqlCmd = new SqlCommand(sqlSelect, sqlConn);
        sqlCmd.Parameters.AddWithValue("AppNo", appno);


        try
        {
            sqlConn.Open();
            sqlDataReader = sqlCmd.ExecuteReader();
            sqlDataReader.Read();
            if (sqlDataReader.HasRows == true)
            {
                cramt = decimal.Parse(sqlDataReader["CrAmt"].ToString());
            }
            else
            {

            }
            sqlDataReader.Close();

        }

        catch (Exception err)
        {
            this._errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
        }

        return cramt;

    }

//    // Update PaymentType confirmation
//    public int UpdatePaymentMade(string appno, int paymenttypeid, bool ispaid, DateTime paiddate)
//    {
//        string sqlUpdate;

//        sqlUpdate = @"update PaymentMade set ispaid=@ispaid, PaidDate=@paiddate where 
//                       appno = @OriginalAppNo and PaymentTypeId = @PaymentTypeId";

//        sqlConn = new SqlConnection(constring);
//        sqlCmd = new SqlCommand(sqlUpdate, sqlConn);

//        sqlCmd.Parameters.AddWithValue("OriginalAppNo", appno);
//        sqlCmd.Parameters.AddWithValue("ispaid", ispaid);
//        sqlCmd.Parameters.AddWithValue("PaymentTypeId", paymenttypeid);
//        sqlCmd.Parameters.AddWithValue("paiddate", paiddate);



//        int rowAdded = 0;

//        try
//        {
//            sqlConn.Open();

//            rowAdded = sqlCmd.ExecuteNonQuery();

//        }

//        catch (Exception err)
//        {


//            _errmessage = err.Message;
//        }

//        finally
//        {
//            sqlConn.Close();
//            sqlConn.Dispose();
//        }

//        return rowAdded;
//    }

    // new methord in CRtranse Class 


//    public int UpdatePaymentMadeTrans(string appno, int paymenttypeid, bool ispaid, bool IsTranferedToCrTranse, string userid)
//    {
//        string sqlUpdate;

//        sqlUpdate = @"update PaymentMade set IsTranferedToCrTranse=@IsTranferedToCrTranse, userid = @userid where 
//                       appno = @OriginalAppNo and PaymentTypeId = @PaymentTypeId and ispaid = @ispaid";

//        sqlConn = new SqlConnection(constring);
//        sqlCmd = new SqlCommand(sqlUpdate, sqlConn);

//        sqlCmd.Parameters.AddWithValue("OriginalAppNo", appno);
//        sqlCmd.Parameters.AddWithValue("ispaid", ispaid);
//        sqlCmd.Parameters.AddWithValue("PaymentTypeId", paymenttypeid);
//        sqlCmd.Parameters.AddWithValue("IsTranferedToCrTranse", IsTranferedToCrTranse);
//        sqlCmd.Parameters.AddWithValue("userid", userid);
//        int rowAdded = 0;

//        try
//        {
//            sqlConn.Open();

//            rowAdded = sqlCmd.ExecuteNonQuery();

//        }

//        catch (Exception err)
//        {


//            _errmessage = err.Message;
//        }

//        finally
//        {
//            sqlConn.Close();
//            sqlConn.Dispose();
//        }

//        return rowAdded;
//    }
    


    // Valuation Fees Updation

    public int InsertValuationFees(string AppNo, decimal ValuerFee, decimal TrportFee, decimal ExpressTrport, decimal ExpValuerFee, decimal CommisFee, string ValuationStatus)
    {
      
        string sqlInsert;

        sqlInsert = @"INSERT INTO Valuation(AppNo, ValuerFee, TrportFee, ExpressTrport, ExpValuerFee, CommisFee, ValuationStatus)
                      VALUES (@AppNo, @ValuerFee, @TrportFee, @ExpressTrport, @ExpValuerFee, @CommisFee, @ValuationStatus)";

        sqlConn = new SqlConnection(constring);
        sqlCmd = new SqlCommand(sqlInsert, sqlConn);

        sqlCmd.Parameters.AddWithValue("ValuerFee", ValuerFee);
        sqlCmd.Parameters.AddWithValue("TrportFee", TrportFee);
        sqlCmd.Parameters.AddWithValue("ExpressTrport", ExpressTrport);
        sqlCmd.Parameters.AddWithValue("ExpValuerFee", ExpValuerFee);
        sqlCmd.Parameters.AddWithValue("CommisFee", CommisFee);
        sqlCmd.Parameters.AddWithValue("ValuationStatus", ValuationStatus);
        sqlCmd.Parameters.AddWithValue("AppNo", AppNo);
        int rowAdded = 0;

        try
        {
            sqlConn.Open();
            rowAdded = sqlCmd.ExecuteNonQuery();
           
        }

        catch (Exception err)
        {

        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return rowAdded;
    }

    public int UpdateDistance(string AppNo, int DistanceInspect, int DistanceValuation)
    {

        string sqlInsert;

        sqlInsert = @"update crapp set DistanceInspect=@DistanceInspect, DistanceValuation = @DistanceValuation
                        where appno = @OriginalAppNo";

        sqlConn = new SqlConnection(constring);
        sqlCmd = new SqlCommand(sqlInsert, sqlConn);

        sqlCmd.Parameters.AddWithValue("OriginalAppNo", AppNo);
        sqlCmd.Parameters.AddWithValue("DistanceInspect", DistanceInspect);
        sqlCmd.Parameters.AddWithValue("DistanceValuation", DistanceValuation);
       
        int rowAdded = 0;

        try
        {
            sqlConn.Open();
            rowAdded = sqlCmd.ExecuteNonQuery();

        }

        catch (Exception err)
        {

        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return rowAdded;
    }

//    // Delete Possible Payments
//    public int DeleteAssignPayments(string appno, int paymenttypeid, bool ispaid)
//    {
//        string sqlUpdate;

//        sqlUpdate = @"delete from paymentmade where appno = @appno and 
//                    PaymentTypeId = @PaymentTypeId and ispaid = @ispaid";

//        sqlConn = new SqlConnection(constring);
//        sqlCmd = new SqlCommand(sqlUpdate, sqlConn);

//        sqlCmd.Parameters.AddWithValue("appno", appno);
//        sqlCmd.Parameters.AddWithValue("PaymentTypeId", paymenttypeid);
//        sqlCmd.Parameters.AddWithValue("ispaid", ispaid);

//        int rowAdded = 0;

//        try
//        {
//            sqlConn.Open();

//            rowAdded = sqlCmd.ExecuteNonQuery();

//        }

//        catch (Exception err)
//        {


//            _errmessage = err.Message;
//        }

//        finally
//        {
//            sqlConn.Close();
//            sqlConn.Dispose();
//        }

//        return rowAdded;
//    }

    // Update PaymentType confirmation
    public int UpdateApprovalStatus(string appno, bool IsPaymentOK)
    {
        string sqlUpdate;

        sqlUpdate = @"update ApprovalStatus set IsPaymentOK=@IsPaymentOK where 
                       appno = @OriginalAppNo";

        sqlConn = new SqlConnection(constring);
        sqlCmd = new SqlCommand(sqlUpdate, sqlConn);

        sqlCmd.Parameters.AddWithValue("OriginalAppNo", appno);
        sqlCmd.Parameters.AddWithValue("IsPaymentOK", IsPaymentOK);

        int rowAdded = 0;

        try
        {
            sqlConn.Open();

            rowAdded = sqlCmd.ExecuteNonQuery();

        }

        catch (Exception err)
        {


            _errmessage = err.Message;
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return rowAdded;
    }

   
}
