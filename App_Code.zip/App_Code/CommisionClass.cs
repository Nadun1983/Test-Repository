using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// Summary description for CommisionClass
/// </summary>
public class CommisionClass
{

    private SqlConnection sqlConn;
    SqlCommand sqlCmd;
    SqlDataReader sqlDataReader;
    SqlDataAdapter sqldataAdapter;
    DataTable dt;

    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();
    string _errmessage;

	public CommisionClass()
	{
		//
		// TODO: Add constructor logic here
		//
	}


    

    //Get payment Commisions
    public DataTable GetCommisionPayment(int Employerno, DateTime todate, DateTime fromdate, string IsCommisPaid)
    {
        string sqlSelect = @"select v.SurName, 
                            vt.valuerid, 
                            sum(vt.ValuerFee + vt.ExpValuerFee)*.1 as [Commision Fee] 
                            from valuation vt, valuer v where v.ValuerId = vt.ValuerId and v.valuerid in 
                            (select valuerid from valuer where Employerno = @Employerno) 
                            AND Vt.SENDDATE >= @fromdate 
                            AND vt.SENDDATE <= @todate
                            AND Vt.RECVDATE IS NOT NULL 
                            AND vt.IsCommisPaid = @IsCommisPaid
                            group by vt.valuerid, v.SurName";

        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);

        sqldataAdapter.SelectCommand.Parameters.AddWithValue("Employerno", Employerno);
        sqldataAdapter.SelectCommand.Parameters.AddWithValue("fromdate", fromdate);
        sqldataAdapter.SelectCommand.Parameters.AddWithValue("todate", todate);
        sqldataAdapter.SelectCommand.Parameters.AddWithValue("IsCommisPaid", IsCommisPaid);
        dt = new DataTable();

        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return dt;

    }

     public string GetPaidStatus(string appno, string IsInspecPd)
    {
        string sqlSelect, paidStatus;
        sqlSelect = @"select IsInspecPd from  CreditAdmin.InspectMast";

        sqlConn = new SqlConnection(constring);

        sqlCmd = new SqlCommand(sqlSelect, sqlConn);
        sqlCmd.Parameters.AddWithValue("PaidStatus", IsInspecPd);

        try
        {
            sqlConn.Open();
            sqlDataReader = sqlCmd.ExecuteReader();
            sqlDataReader.Read();
            if (sqlDataReader != null)
            {
                paidStatus = sqlDataReader["PaidStatus"].ToString();
            }
            sqlDataReader.Close();
        }

        catch (Exception ex)
        {
            // error massage
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return IsInspecPd;
    }


    public int InsertTransaction(long TransactionId, double TotalAmount, DateTime SendDate, bool Status, string PaymentType)
    {

        string sqlinsert;
        sqlinsert = @"insert into OutsidePayments (TransactionId, TotalAmount, SendDate, Status, PaymentType) 
                      values (@TransactionId, @TotalAmount, @SendDate, @Status, @PaymentType)";

        sqlConn = new SqlConnection(constring);
        sqlCmd = new SqlCommand(sqlinsert, sqlConn);

        sqlCmd.Parameters.AddWithValue("TotalAmount", TotalAmount);
        sqlCmd.Parameters.AddWithValue("SendDate", SendDate);
        sqlCmd.Parameters.AddWithValue("Status", Status);
        sqlCmd.Parameters.AddWithValue("PaymentType", PaymentType);
        sqlCmd.Parameters.AddWithValue("TransactionId", TransactionId);
               

        int addesdata = 0;

        try
        {
            sqlConn.Open();
            addesdata = sqlCmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            //
        }

        finally
        {
            sqlConn.Close();
        }

        return addesdata;
    }

    public int UpdateCommissionTransactionID(int valuerid, DateTime todate, DateTime fromdate, string IsCommisPaid, long CommissionTransactionNo)
    {

        string sqlinsert;
        sqlinsert = @"Update valuation Set CommissionTransactionNo = @CommissionTransactionNo , IsCommisPaid=@IsCommisPaid
                        where VALUERID = @VALUERID
	                    AND SENDDATE >= @fromdate 
	                    AND SENDDATE <= @todate
	                    AND RECVDATE IS NOT NULL 
	                    AND IsCommisPaid = 'N' ";

        sqlConn = new SqlConnection(constring);
        sqlCmd = new SqlCommand(sqlinsert, sqlConn);

        sqlCmd.Parameters.AddWithValue("VALUERID", valuerid);
        sqlCmd.Parameters.AddWithValue("fromdate", fromdate);
        sqlCmd.Parameters.AddWithValue("todate", todate);
        sqlCmd.Parameters.AddWithValue("IsCommisPaid", IsCommisPaid);
        sqlCmd.Parameters.AddWithValue("CommissionTransactionNo", CommissionTransactionNo);


        int addesdata = 0;

        try
        {
            sqlConn.Open();
            addesdata = sqlCmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            //
        }

        finally
        {
            sqlConn.Close();
        }

        return addesdata;
    }

    //Get Valuer Id
    public DataTable GetValuerID(int Employerno, DateTime todate, DateTime fromdate, string IsCommisPaid)
    {
        string sqlSelect = @"select distinct vt.valuerid from valuer v, valuation vt where 
                            v.ValuerId = vt.ValuerId and
                            v.Employerno = @Employerno
	                        AND vt.SENDDATE >= @fromdate 
	                        AND vt.SENDDATE <= @todate
	                        AND Vt.RECVDATE IS NOT NULL 
	                        AND vt.IsCommisPaid = @IsCommisPaid";

        SqlConnection sqlConn = new SqlConnection(constring);
        sqldataAdapter = new SqlDataAdapter(sqlSelect, sqlConn);

        sqldataAdapter.SelectCommand.Parameters.AddWithValue("Employerno", Employerno);
        sqldataAdapter.SelectCommand.Parameters.AddWithValue("fromdate", fromdate);
        sqldataAdapter.SelectCommand.Parameters.AddWithValue("todate", todate);
        sqldataAdapter.SelectCommand.Parameters.AddWithValue("IsCommisPaid", IsCommisPaid);
        dt = new DataTable();

        try
        {
            sqlConn.Open();
            sqldataAdapter.Fill(dt);
        }
        catch (Exception er)
        {
            //
        }

        finally
        {
            sqlConn.Close();
            sqlConn.Dispose();
        }

        return dt;

    }
}
