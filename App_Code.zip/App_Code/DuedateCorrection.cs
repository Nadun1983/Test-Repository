﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Configuration;
using System.Data;

/// <summary>
/// Summary description for DuedateCorrection
/// </summary>
public class DuedateCorrection
{
    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();
    DataWorksClass dw;
    FunctionClass fc;
    CrTransClass ctc;
    LastSerialClass ls;
    Recovery rc;
    Trans tr;
    DataTable dt;
   
	public DuedateCorrection()
	{
		//
		// TODO: Add constructor logic here
		//
	}



    public DataTable GetRecords(string cracno, string transno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select refno, CONVERT(VARCHAR(10), datedue, 112) AS datedue, 
                            t.assignamt, g.tramt, taskid, g.trstatus, g.transno
                            from transassign t, gltrans g
                            where g.cracno =@cracno 
                            and g.transno =@transno
                            and g.transassignrefno=t.refno
                            order by t.trtype,  t.datedue, t.taskid desc");
        dw.SetDataAdapterParameters("cracno", cracno);
        dw.SetDataAdapterParameters("transno",transno);
        return dw.GetDataTable();
    }

    public int UpdatedateDue(string refno, string datedue)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"Update transassign set datedue = @datedue where refno = @refno");
        dw.SetSqlCommandParameters("refno", refno);
        dw.SetSqlCommandParameters("datedue",datedue);
        return dw.Update();
    }

    public DataTable GetRecords(string cracno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select refno, CONVERT(VARCHAR(10), datedue, 112) AS datedue, 
                            t.assignamt, g.tramt, taskid, g.trstatus, g.transno
                            from transassign t, gltrans g
                            where g.cracno =@cracno 
                            and g.transassignrefno=t.refno
                            order by t.trtype,  t.datedue, t.taskid desc");
        dw.SetDataAdapterParameters("cracno", cracno);
        return dw.GetDataTable();
    }
}
