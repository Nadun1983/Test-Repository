﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;


/// <summary>
/// Summary description for batchcorrectionclass
/// </summary>
public class batchcorrectionclass
{
    private string constring = ConfigurationManager.ConnectionStrings["housdbString"].ToString();
    private string oldconstring = ConfigurationManager.ConnectionStrings["oldhousdbString"].ToString();
    DataWorksClass dw;
    LastSerialClass ls;
    FunctionClass fc;
    CancelTransaction ct;
	public batchcorrectionclass()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public DataTable GetCrAcNoandTramt(string batchno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select cracno,sum(tramt) as tramt from batchtmp where batchno=@batchno and left(cracno,1)='6'
                            group by cracno");
        dw.SetDataAdapterParameters("batchno", batchno);
        return dw.GetDataTable();
    }


    public double GetTrAmtinGlTrans(string cracno, string batchno)
    { 
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select sum(tramt) as tramt from gltrans where cracno=@cracno
                        and acsign='CR' and batchno=@batchno and trstatus<>'C' ");
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("batchno", batchno);
        return double.Parse(dw.GetSingleData());
        
    }

    public DataTable GetGLTransNo(string cracno, string batchno, double tramt)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select GLTransNo,RefGLCode,tramt from gltrans where batchno=@batchno and 
                        cracno=@cracno and trstatus<>'C' and tramt>=@tramt and acsign='CR'");
        dw.SetDataAdapterParameters("cracno", cracno);
        dw.SetDataAdapterParameters("batchno", batchno);
        dw.SetDataAdapterParameters("tramt", tramt);
        return dw.GetDataTable();

    }


    public int UpdateGlTrans(string GLTransno, double extamount)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update gltrans set tramt=@tramt where GLTransno=@GLTransno");
        dw.SetSqlCommandParameters("GLTransno", GLTransno);
        dw.SetSqlCommandParameters("tramt", extamount);
        return dw.Update();
    }

    public int UpdateGl(string RefGlcode, double extamount, string acsign)
    {
        ct = new CancelTransaction();
        double curbal = ct.GetCurrentBalance(RefGlcode);
        curbal -= extamount;
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"update glcode set curbal=@curbal where RefGlcode=@RefGlcode");
        dw.SetSqlCommandParameters("RefGlcode", RefGlcode);
        dw.SetSqlCommandParameters("curbal", curbal);
        return dw.Update();
    }
}
