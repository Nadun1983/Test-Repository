using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// Summary description for LegalCompletion
/// </summary>
public class LegalCompletion
{
    private SqlDataAdapter da;
    DataSet ds;
    private SqlConnection mycon;
    DataWorksClass dw;
    private string constring = ConfigurationManager.ConnectionStrings["housdbString"].ToString();

	public LegalCompletion()
	{
       //
	}

    public DataTable ExistLegalAppno(string AppNo)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"SELECT * FROM FacilityLegalDetails WHERE AppNo=@AppNo");
        dw.SetDataAdapterParameters("AppNo", AppNo);
        return dw.GetDataTable();
    }

    public DataTable GetLegalOfficer()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"SELECT * FROM Employee WHERE Designation IN ('Legal Officer','AGM-LEGAL')");
        return dw.GetDataTable();
    }

    public int SaveLegalDetails(string AppNo, int LegalOfficer, DateTime Rdate, string TitleOrder, int UpdateLevel)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO FacilityLegalDetails (AppNo, LegalOfficer, Rdate, TitleOrder, UpdateLevel)
                        values(@AppNo, @LegalOfficer, @Rdate, @TitleOrder, @UpdateLevel)");
        dw.SetSqlCommandParameters("AppNo", AppNo);
        dw.SetSqlCommandParameters("LegalOfficer", LegalOfficer);
        dw.SetSqlCommandParameters("Rdate", Rdate);
        dw.SetSqlCommandParameters("TitleOrder", TitleOrder);
        dw.SetSqlCommandParameters("UpdateLevel", UpdateLevel);
        return dw.Insert();
    }

    public int UpdateLegalDetails(string AppNo, int LegalOfficer, DateTime Rdate, string TitleOrder)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"UPDATE FacilityLegalDetails SET LegalOfficer= @LegalOfficer, Rdate=@Rdate,
                        TitleOrder=@TitleOrder WHERE AppNo=@AppNo");
        dw.SetSqlCommandParameters("AppNo", AppNo);
        dw.SetSqlCommandParameters("LegalOfficer", LegalOfficer);
        dw.SetSqlCommandParameters("Rdate", Rdate);
        dw.SetSqlCommandParameters("TitleOrder", TitleOrder);
        return dw.Update();
    }

    public int InsertLegalStatus(bool status, string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"UPDATE ApprovalStatus SET IsLegalOK=@IsLegalOK WHERE AppNo=@AppNo");
        dw.SetSqlCommandParameters("AppNo", appno);
        dw.SetSqlCommandParameters("IsLegalOK", status);
        return dw.Update();
    }
}
