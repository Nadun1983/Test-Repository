﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

/// <summary>
/// Summary description for ArreasSMS
/// </summary>
public class ArreasSMS
{
    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();
    DataWorksClass dw;
    private DataTable dt;
	public ArreasSMS()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public DataTable GetArreasData(string Datekey)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"exec spGetSMSOutput @Datekey");
        dw.SetDataAdapterParameters("Datekey", Datekey);
        dt = dw.GetDataTable();
        return dt;
    }

    public void insertSMSLog(string IDNo, string MobileNo, string cracno,DateTime TrDate, string RequestType, string DateKey)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO SendArreasSMS
                                   (IDNo,MobileNo,cracno,TrDate,RequestType,DateKey)
                             VALUES
                                   (@IDNo,@MobileNo,@cracno,@TrDate,@RequestType,@DateKey)");
        dw.SetSqlCommandParameters("IDNo", IDNo);
        dw.SetSqlCommandParameters("MobileNo", MobileNo);
        dw.SetSqlCommandParameters("cracno", cracno);
        dw.SetSqlCommandParameters("TrDate", TrDate);
        dw.SetSqlCommandParameters("RequestType", RequestType);
        dw.SetSqlCommandParameters("DateKey", DateKey);
        dw.Insert();
    }
}
