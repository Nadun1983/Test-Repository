using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// Summary description for SecurityDet
/// </summary>
public class SecurityDet
{
    private SqlDataAdapter da;
    DataSet ds;
    private SqlConnection mycon;
    DataWorksClass dw;
    string constring = ConfigurationManager.ConnectionStrings["housdbstring"].ConnectionString.ToString();

	public SecurityDet()
	{
        SqlConnection myconnection = new SqlConnection(ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString);
        this.mycon = myconnection;
	}

    public DataTable GetHpSecDetails(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"SELECT H.AppNo,H.IsCondominium,H.LotNo,H.PlanNo,REPLACE(CONVERT(VARCHAR(10), H.PlanDate, 103), '/', '') as PlanDate,
	                        H.UnitNo,H.SchemeNo,H.SurveyName,H.IsOwner,H.LandExtent,M.MetricUnitDescription,H.LandName,
                            H.LandLocation,H.LandStreet,H.LandCity,H.FloorArea,H.VillageName,H.DivSecName,H.DistCode,H.OWNERSNAME, 
                            CASE Status 
		                    WHEN 'M' 
		                    THEN 'Mortage Property' 
		                    ELSE 'Alternative Property' 
		                    END AS Stat,                            
		                    RTRIM(status) AS status 
                            FROM HpSec H
                            FULL OUTER JOIN MetricUnit M ON 
                            H.MetricUnitID = M.MetricUnitID 
                            where AppNo=@appno");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();
    }

    public int InsertHpSecDetails(string appno, string IsCondominium, string lotno, string planno, DateTime PlanDate,
                                      string unitno, string SchemeNo,
                                      string SurveyName, string IsOwner, string LandExtent,int MetricUnitID, string LandName,
                                      string LandLocation, string LandStreet, string LandCity,
                                      decimal FloorArea, string VillageName, string DivSecName, int distcode,
                                      string OWNERSNAME, string AdUser, string status,
                                      DateTime addate, int UpdateLevel)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO HpSec (AppNo,IsCondominium,LotNo,PlanNo,PlanDate,UnitNo,SchemeNo,
                     SurveyName,IsOwner,LandExtent,MetricUnitID,LandName,LandLocation,LandStreet,LandCity,FloorArea,VillageName,DivSecName,
                     DistCode,OWNERSNAME,AdUser,status,AdDate,UpdateLevel) values (@appno,@IsCondominium,
                     @lotno,@planno,@PlanDate,@unitno,@SchemeNo,@SurveyName,@IsOwner,@LandExtent,@MetricUnitID,@LandName,@LandLocation,@LandStreet,
                     @LandCity,@FloorArea,@VillageName,@DivSecName,@distcode,@OWNERSNAME,@AdUser,@status,@addate,@UpdateLevel)");
        dw.SetSqlCommandParameters("AppNo", appno);
        dw.SetSqlCommandParameters("IsCondominium", IsCondominium);
        dw.SetSqlCommandParameters("LotNo", lotno);
        dw.SetSqlCommandParameters("PlanNo", planno);
        dw.SetSqlCommandParameters("PlanDate", PlanDate);
        dw.SetSqlCommandParameters("UnitNo", unitno);
        dw.SetSqlCommandParameters("SchemeNo", SchemeNo);
        dw.SetSqlCommandParameters("SurveyName", SurveyName);
        dw.SetSqlCommandParameters("IsOwner", IsOwner);
        dw.SetSqlCommandParameters("LandExtent", LandExtent);
        dw.SetSqlCommandParameters("MetricUnitID", MetricUnitID);
        dw.SetSqlCommandParameters("LandName", LandName);
        dw.SetSqlCommandParameters("LandLocation", LandLocation);
        dw.SetSqlCommandParameters("LandStreet", LandStreet);
        dw.SetSqlCommandParameters("LandCity", LandCity);
        dw.SetSqlCommandParameters("FloorArea", FloorArea);
        dw.SetSqlCommandParameters("VillageName", VillageName);
        dw.SetSqlCommandParameters("DivSecName", DivSecName);
        dw.SetSqlCommandParameters("DistCode", distcode);
        dw.SetSqlCommandParameters("OWNERSNAME", OWNERSNAME);
        dw.SetSqlCommandParameters("AdUser", AdUser);
        dw.SetSqlCommandParameters("status", status);
        dw.SetSqlCommandParameters("AdDate", addate);
        dw.SetSqlCommandParameters("UpdateLevel", UpdateLevel);
        return dw.Insert();
       
    }

    public DataTable GetLifInsuranceDet(string appno)
    {
        dw = new DataWorksClass(constring); 
        dw.SetDataAdapter("@SELECT * FROM AppSecPolicy WHERE AppNo=@appno");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable(); 
        
    }

    public int InsertToAppSecPolicy(string appno, string policyno, decimal svalue, string institute, DateTime pdate, 
                                        DateTime mdate, string user, DateTime cdate, int updatel)
    {
        dw = new DataWorksClass(constring);
       dw.SetCommand(@"INSERT INTO AppSecPolicy (AppNo,PolicyNo,SurrendVal,Institution,PolicyDate,MatDate,AdUser,AdDate,Updatelevel)
                     Values (@appno,@policyno,@svalue,@institute,@pdate,@mdate,@user,@cdate,@updatel)");
        dw.SetSqlCommandParameters("AppNo", appno);
        dw.SetSqlCommandParameters("policyno", policyno);
        dw.SetSqlCommandParameters("svalue", svalue);
        dw.SetSqlCommandParameters("institute", institute);
        dw.SetSqlCommandParameters("PolicyDate", pdate);
        dw.SetSqlCommandParameters("MatDate", mdate);
        dw.SetSqlCommandParameters("AdUser", user);
        dw.SetSqlCommandParameters("AdDate", cdate);
        dw.SetSqlCommandParameters("Updatelevel", updatel);
        return dw.Insert();
       
    }

    public int UpdateHPSecurity(string appno, string iscon, string lotno, string planno, DateTime pdate,
                                      string unitno, string schemno, string sname, string lextent,string Metric, string lname,
                                      string location, string street, string city, decimal floor, string vname, string divsec, 
                                      string oname, string proptype)
    {
        dw = new DataWorksClass(constring);
       dw.SetCommand(@"UPDATE HpSec SET IsCondominium=@iscon,LotNo=@lotno,PlanNo=@planno,
                     PlanDate=@pdate,UnitNo=@unitno,SchemeNo=@schemno,SurveyName=@sname,LandExtent=@lextent,MetricUnitID=@Metric,LandName=@lname,
                     LandLocation=@location,LandStreet=@street,LandCity=@city,FloorArea=@floor,VillageName=@vname,
                     DivSecName=@divsec,OWNERSNAME=@oname WHERE AppNo=@appno AND status=@proptype");
       dw.SetSqlCommandParameters("iscon", iscon);
       dw.SetSqlCommandParameters("lotno", lotno);
       dw.SetSqlCommandParameters("planno", planno);
       dw.SetSqlCommandParameters("pdate", pdate);
       dw.SetSqlCommandParameters("unitno", unitno);
       dw.SetSqlCommandParameters("schemno", schemno);
       dw.SetSqlCommandParameters("sname", sname);
       dw.SetSqlCommandParameters("lextent", lextent);
       dw.SetSqlCommandParameters("Metric", Metric);
       dw.SetSqlCommandParameters("lname", lname);
       dw.SetSqlCommandParameters("location", location);
       dw.SetSqlCommandParameters("street", street);
       dw.SetSqlCommandParameters("city", city);
       dw.SetSqlCommandParameters("floor", floor);
       dw.SetSqlCommandParameters("vname", vname);
       dw.SetSqlCommandParameters("divsec", divsec);
       dw.SetSqlCommandParameters("oname", oname);
       dw.SetSqlCommandParameters("appno", appno);
       dw.SetSqlCommandParameters("proptype", proptype);
        return dw.Update();

    }

    public int UpdateApprovalSecStat(string appno, bool status)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"UPDATE ApprovalStatus SET IsSecurityOK =@Status WHERE AppNo = @appno");
        dw.SetSqlCommandParameters("Status", status);
        dw.SetSqlCommandParameters("AppNo", appno);
        return dw.Update();
        
    }

    public DataTable GetExistVehicleDetails(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"SELECT * FROM AppSecVehi WHERE AppNo=@appno");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable(); 
    }

    public int InsertDetailsToVehicle(string AppNo,string RegdNo, string Veh_class, string Tax_class,
                                          string Make, string Model, string Body, string Manu_Des, string Colour, string Fuel,
                                          string Chasi_no, string EngineNo, string Cilinder, string Seating,
                                          string Unload_Wgt, string Gross_Wgt, string Manu_year,string Usefor,
                                          string Licen_autho, DateTime Taxdate, string Status, string AdUser,
                                          DateTime AdDate, string dealername, decimal VehicleValue,
                                          decimal InsuranceAmt, string insurance, string Valuername, decimal Valueramt, int UpdateLevel, decimal FSV)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO AppSecVehi (AppNo,RegdNo,Veh_class,Tax_class,Make,Model,Body,Manu_Des,Colour,Fuel,
                     Chasi_no,EngineNo,Cilinder,Seating,Unload_Wgt,Gross_Wgt,Manu_year,Usefor,Licen_autho,Taxdate,
                     Status,AdUser,AdDate, DealerName, VehicleValue,InsuranceAmt,insurance, Valuername, 
                    Valueramt,UpdateLevel, FSV) Values
                     (@AppNo,@RegdNo,@Veh_class,@Tax_class,@Make,@Model,@Body,@Manu_Des,@Colour,@Fuel,
                     @Chasi_no,@EngineNo,@Cilinder,@Seating,@Unload_Wgt,@Gross_Wgt,@Manu_year,@Usefor,@Licen_autho,@Taxdate,
                     @Status,@AdUser,@AdDate, @DealerName, @VehicleValue,@InsuranceAmt,
                     @insurance, @Valuername, @Valueramt,@UpdateLevel, @FSV)");
        dw.SetSqlCommandParameters("AppNo", AppNo);
        dw.SetSqlCommandParameters("RegdNo", RegdNo);
        dw.SetSqlCommandParameters("Veh_class", Veh_class);
        dw.SetSqlCommandParameters("Tax_class", Tax_class);
        dw.SetSqlCommandParameters("Make", Make);
        dw.SetSqlCommandParameters("Model", Model);
        dw.SetSqlCommandParameters("Body", Body);
        dw.SetSqlCommandParameters("Manu_Des", Manu_Des);
        dw.SetSqlCommandParameters("Colour", Colour);
        dw.SetSqlCommandParameters("Fuel", Fuel);
        dw.SetSqlCommandParameters("Chasi_no", Chasi_no);
        dw.SetSqlCommandParameters("EngineNo", EngineNo);
        dw.SetSqlCommandParameters("Cilinder", Cilinder);
        dw.SetSqlCommandParameters("Seating", Seating);
        dw.SetSqlCommandParameters("Unload_Wgt", Unload_Wgt);
        dw.SetSqlCommandParameters("Gross_Wgt", Gross_Wgt);
        dw.SetSqlCommandParameters("Manu_year", Manu_year);
        dw.SetSqlCommandParameters("Usefor", Usefor);
        dw.SetSqlCommandParameters("Licen_autho", Licen_autho);
        dw.SetSqlCommandParameters("Taxdate", Taxdate);
        dw.SetSqlCommandParameters("Status", Status);
        dw.SetSqlCommandParameters("AdUser", AdUser);
        dw.SetSqlCommandParameters("AdDate", AdDate);
        dw.SetSqlCommandParameters("dealername", dealername);
        dw.SetSqlCommandParameters("VehicleValue", VehicleValue);
        dw.SetSqlCommandParameters("InsuranceAmt", InsuranceAmt);
        dw.SetSqlCommandParameters("insurance", insurance);
        dw.SetSqlCommandParameters("Valuername", Valuername);
        dw.SetSqlCommandParameters("Valueramt", Valueramt);
        dw.SetSqlCommandParameters("UpdateLevel", UpdateLevel);
        dw.SetSqlCommandParameters("FSV", FSV);
        return dw.Insert();
       
    }
    public int UpdateVehicleDetails(string AppNo, string RegdNo, string Veh_class, string Tax_class,
                                         string Make, string Model, string Body, string Manu_Des, string Colour, string Fuel,
                                         string Chasi_no, string EngineNo, string Cilinder, string Seating,
                                         string Unload_Wgt, string Gross_Wgt, string Manu_year, string Usefor,
                                         string Licen_autho, DateTime Taxdate, string Status,
                                        string dealername, decimal VehicleValue,
                                         decimal InsuranceAmt, string insurance, string Valuername, 
                                          decimal Valueramt, decimal FSV)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"UPDATE AppSecVehi Set RegdNo=@RegdNo,Veh_class=@Veh_class,
                        Tax_class=@Tax_class,Make=@Make,Model=@Model,Body=@Body,Manu_Des=@Manu_Des,
                        Colour=@Colour,Fuel=@Fuel,Chasi_no=@Chasi_no,EngineNo=@EngineNo,Cilinder=@Cilinder,
                        Seating=@Seating,Unload_Wgt=@Unload_Wgt,Gross_Wgt=@Gross_Wgt,Manu_year=@Manu_year,
                        Usefor=@Usefor,Licen_autho=@Licen_autho,Taxdate=@Taxdate, Status=@Status,
                        DealerName=@DealerName, 
                        VehicleValue=@VehicleValue,InsuranceAmt=@InsuranceAmt,insurance=@insurance, 
                        Valuername=@Valuername, Valueramt=@Valueramt, FSV=@FSV Where AppNo=@AppNo");
        dw.SetSqlCommandParameters("AppNo", AppNo);
        dw.SetSqlCommandParameters("RegdNo", RegdNo);
        dw.SetSqlCommandParameters("Veh_class", Veh_class);
        dw.SetSqlCommandParameters("Tax_class", Tax_class);
        dw.SetSqlCommandParameters("Make", Make);
        dw.SetSqlCommandParameters("Model", Model);
        dw.SetSqlCommandParameters("Body", Body);
        dw.SetSqlCommandParameters("Manu_Des", Manu_Des);
        dw.SetSqlCommandParameters("Colour", Colour);
        dw.SetSqlCommandParameters("Fuel", Fuel);
        dw.SetSqlCommandParameters("Chasi_no", Chasi_no);
        dw.SetSqlCommandParameters("EngineNo", EngineNo);
        dw.SetSqlCommandParameters("Cilinder", Cilinder);
        dw.SetSqlCommandParameters("Seating", Seating);
        dw.SetSqlCommandParameters("Unload_Wgt", Unload_Wgt);
        dw.SetSqlCommandParameters("Gross_Wgt", Gross_Wgt);
        dw.SetSqlCommandParameters("Manu_year", Manu_year);
        dw.SetSqlCommandParameters("Usefor", Usefor);
        dw.SetSqlCommandParameters("Licen_autho", Licen_autho);
        dw.SetSqlCommandParameters("Taxdate", Taxdate);
        dw.SetSqlCommandParameters("Status", Status);
        dw.SetSqlCommandParameters("dealername", dealername);
        dw.SetSqlCommandParameters("VehicleValue", VehicleValue);
        dw.SetSqlCommandParameters("InsuranceAmt", InsuranceAmt);
        dw.SetSqlCommandParameters("insurance", insurance);
        dw.SetSqlCommandParameters("Valuername", Valuername);
        dw.SetSqlCommandParameters("Valueramt", Valueramt);
        dw.SetSqlCommandParameters("FSV", FSV);
        return dw.Update();

    }

    //---------------------insurance policy H/P -(Aruni)---------------
    //Bind InsuranceType
    public DataTable InsuranceType()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from InsuranceType");
        return dw.GetDataTable();

    }

    //Bind InsuranceCompany
    public DataTable InsuranceCompany()
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select * from InsuranceCompany");
        return dw.GetDataTable();

    }

    //insert policy insurance
    public int InsertPolicyInsurance(string AppNo, int InsuranceTypeID, int InsuranceCompanyID, decimal PolicyValue, string PolicyNumber, decimal InsuredValue, decimal PremiumValue, string AddUser, DateTime AddDate)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO InsurancePolicy (AppNo,InsuranceTypeID,InsuranceCoID,PolicyValue,PolicyNumber,InsuredValue,PremiumValue,AddUser,AddDate)
                     Values (@AppNo,@InsuranceTypeID,@InsuranceCompanyID,@PolicyValue,@PolicyNumber,@InsuredValue,@PremiumValue,@AddUser,@AddDate)");
        dw.SetSqlCommandParameters("AppNo", AppNo);
        dw.SetSqlCommandParameters("InsuranceTypeID", InsuranceTypeID);
        dw.SetSqlCommandParameters("InsuranceCompanyID", InsuranceCompanyID);
        dw.SetSqlCommandParameters("PolicyValue", PolicyValue);
        dw.SetSqlCommandParameters("PolicyNumber", PolicyNumber);
        dw.SetSqlCommandParameters("InsuredValue", InsuredValue);
        dw.SetSqlCommandParameters("PremiumValue", PremiumValue);
        dw.SetSqlCommandParameters("AddUser", AddUser);
        dw.SetSqlCommandParameters("AddDate", AddDate);

        return dw.Insert();

    }
    //update Insurance policy details
    public int UpdateInsurancePolicyDetails(string appno, int InsuranceType, int InsuranceCompany, string PolicyValue, string PolicyNumber, string InsuredValue, string PremiumValue)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"UPDATE InsurancePolicy SET AppNo=@appno,InsuranceTypeID=@InsuranceTypeID,InsuranceCoID=@InsuranceCompanyID,
                     PolicyValue=@PolicyValue,PolicyNumber=@PolicyNumber,InsuredValue=@InsuredValue,PremiumValue=@PremiumValue
                     WHERE AppNo=@appno");

        dw.SetSqlCommandParameters("appno", appno);
        dw.SetSqlCommandParameters("InsuranceTypeID", InsuranceType);
        dw.SetSqlCommandParameters("InsuranceCompanyID", InsuranceCompany);
        dw.SetSqlCommandParameters("PolicyValue", PolicyValue);
        dw.SetSqlCommandParameters("PolicyNumber", PolicyNumber);
        dw.SetSqlCommandParameters("InsuredValue", InsuredValue);
        dw.SetSqlCommandParameters("PremiumValue", PremiumValue);
        return dw.Update();
    }

    //check insurance policy exist
    public DataTable CheckInsurancepolicyExist(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select P.AppNo,T.InsuranceType,C.InsuranceCompany,P.PolicyValue,P.PolicyNumber,P.InsuredValue,P.PremiumValue 
                            from InsurancePolicy P,InsuranceCompany C, InsuranceType T 
                            where P.InsuranceCoID = C.InsuranceCoID and P.InsuranceTypeID = T.InsuranceTypeID and
                            Appno = @appno ");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();
    }
    //--------------------------auto-Loan(Arunee)------------------------
    //insert new company details
    public DataTable InsertNewInsuranceCompany(string InsuranceCompany, string CompanyCode, string ContactPerson, string ContactNumber, string CompanyEmail, string Location, string Street, string City, string AddUser)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"INSERT INTO InsuranceCompany(InsuranceCompany,CompanyCode,ContactPerson,ContactNumber,CompanyEmail,Location,Street,City,AddUser)
                     Values(@InsuranceCompany,@CompanyCode,@ContactPerson,@ContactNumber,@CompanyEmail,@Location,@Street,@City,@AddUser)");
        dw.SetDataAdapterParameters("InsuranceCompany", InsuranceCompany);
        dw.SetDataAdapterParameters("CompanyCode", CompanyCode);
        dw.SetDataAdapterParameters("ContactPerson", ContactPerson);
        dw.SetDataAdapterParameters("ContactNumber", ContactNumber);
        dw.SetDataAdapterParameters("CompanyEmail", CompanyEmail);
        dw.SetDataAdapterParameters("Location", Location);
        dw.SetDataAdapterParameters("Street", Street);
        dw.SetDataAdapterParameters("City", City);
        dw.SetDataAdapterParameters("AddUser", AddUser);

        return dw.GetDataTable();

    }

    //insert auto loan insurance policy details
    public DataTable InsertAutoLoanInsurancePolicy(decimal AppNo, DateTime AddDate, string VehicleNumber, int InsuranceCompanyID, string PolicyNo, DateTime InsuranceStartDate, decimal VehicleValue, decimal InsurancePremium, string AddUser)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"INSERT INTO AutoLoanInsurancePolicy(AppNo,AddDate,VehicleNumber,InsuranceCompanyID,PolicyNo,InsuranceStartDate,VehicleValue,InsurancePremium,AddUser)
                     Values(@AppNo,@AddDate,@VehicleNumber,@InsuranceCompanyID,@PolicyNo,@InsuranceStartDate,@VehicleValue,@InsurancePremium,@AddUser)");
        dw.SetDataAdapterParameters("AppNo", AppNo);
        dw.SetDataAdapterParameters("AddDate", AddDate);
        dw.SetDataAdapterParameters("VehicleNumber", VehicleNumber);
        dw.SetDataAdapterParameters("InsuranceCompanyID", InsuranceCompanyID);
        dw.SetDataAdapterParameters("PolicyNo", PolicyNo);
        dw.SetDataAdapterParameters("InsuranceStartDate", InsuranceStartDate);
        dw.SetDataAdapterParameters("VehicleValue", VehicleValue);
        dw.SetDataAdapterParameters("InsurancePremium", InsurancePremium);
        dw.SetDataAdapterParameters("AddUser", AddUser);

        return dw.GetDataTable();

    }

    //select Existing
    public DataTable CheckAtoLoanInsurancepolicyExist(decimal appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select A.AppNo,Convert(date,A.AddDate) as AddDate,A.VehicleNumber,C.InsuranceCompany,A.PolicyNo,Convert(Date,A.InsuranceStartDate) as InsuranceStartDate,A.VehicleValue,A.InsurancePremium 
                            from AutoLoanInsurancePolicy A,InsuranceCompany C
                            where A.InsuranceCompanyID = C.InsuranceCoID and AppNo = @appno order by AddDate DESC");
        dw.SetDataAdapterParameters("appno", appno);
        return dw.GetDataTable();
    }

    //update auto loan insurance policy
    public DataTable UpdateAutoLoanInsurancePolicy(decimal AppNo, DateTime AddDate, string VehicleNumber, int InsuranceCompanyID, string PolicyNo, DateTime InsuranceStartDate, decimal VehicleValue, decimal InsurancePremium)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"update AutoLoanInsurancePolicy set VehicleNumber=@VehicleNumber,
                            InsuranceCompanyID = @InsuranceCompanyID,PolicyNo =@PolicyNo,
                            InsuranceStartDate = @InsuranceStartDate,VehicleValue =@VehicleValue,
                            InsurancePremium =@InsurancePremium  
                            where Convert(date,AddDate) = @AddDate and  AppNo = @AppNo");
        dw.SetDataAdapterParameters("AppNo", AppNo);
        dw.SetDataAdapterParameters("AddDate", AddDate);
        dw.SetDataAdapterParameters("VehicleNumber", VehicleNumber);
        dw.SetDataAdapterParameters("InsuranceCompanyID", InsuranceCompanyID);
        dw.SetDataAdapterParameters("PolicyNo", PolicyNo);
        dw.SetDataAdapterParameters("InsuranceStartDate", InsuranceStartDate);
        dw.SetDataAdapterParameters("VehicleValue", VehicleValue);
        dw.SetDataAdapterParameters("InsurancePremium", InsurancePremium);

        return dw.GetDataTable();

    }

    public int GetPurposeName(string appno)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"select distinct purposecode from Appcategory A, CrCatPurpose P
                        where A.CatPurposeId = P.catpurposeid and A.AppNo=@appno");
        dw.SetSqlCommandParameters("appno", appno);
        return int.Parse(dw.GetSingleData());
    }
}
