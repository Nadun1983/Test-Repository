﻿using System;
using System.Data;
using System.Configuration;
//using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
//using System.Xml.Linq;
using System.Data.SqlClient;


/// <summary>
/// Summary description for ArreasLetters
/// </summary>
public class ArreasLetters
{
    string constring = ConfigurationManager.ConnectionStrings["housdbString"].ConnectionString.ToString();
    DataWorksClass dw;
    DataTable dt;

    //public ArreasLetters()
    //{
    //    //
    //    // TODO: Add constructor logic here
    //    //
    //}


    public DataTable getArreasCustomerList(int arrmonths, string cracnoFrom, string cracnoTo)
    {
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"exec ArreasLetterBulk @arrmonths,@cracnoFrom,@cracnoTo");
        dw.SetDataAdapterParameters("arrmonths", arrmonths);
        dw.SetDataAdapterParameters("cracnoFrom", cracnoFrom);
        dw.SetDataAdapterParameters("cracnoTo", cracnoTo);
        return dw.GetDataTable();
    }



    public void insertToDatabaseLog(string Cracno, double OutBal, int ArrInstalment,
            decimal ArrAmt, DateTime GenDate, string UserID)
    {
        dw = new DataWorksClass(constring);
        dw.SetCommand(@"INSERT INTO [CreditReportsDb].[ReportUser].[ArreasLetterBulk]
                                   ([Cracno],[OutBal],[ArrInstalment]
                                   ,[ArrAmt],[GenDate],[UserID])
                             VALUES
                                   (@Cracno,@OutBal,@ArrInstalment
                                   ,@ArrAmt,@GenDate,@UserID)");
        dw.SetSqlCommandParameters("Cracno", Cracno);
        dw.SetSqlCommandParameters("OutBal", OutBal);
        dw.SetSqlCommandParameters("ArrInstalment", ArrInstalment);
        dw.SetSqlCommandParameters("ArrAmt", ArrAmt);
        dw.SetSqlCommandParameters("GenDate", GenDate);
        dw.SetSqlCommandParameters("UserID", UserID);
        dw.Insert();
    }

    public DataTable getloanlist()
    {
        dt = new DataTable();
        dw = new DataWorksClass(constring);
        dw.SetDataAdapter(@"select NICNO,CrAcNo from Tmp_TopUp where status is NULL order by cracno");
        dt = dw.GetDataTable();
        return dt;
    }
}
